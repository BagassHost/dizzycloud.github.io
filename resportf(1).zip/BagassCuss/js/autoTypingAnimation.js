setTimeout(function() {
    $('.about-info-inner').typed({
      strings: [
        "<span>Hi, Selamat Datang</span> DizzyCloud Adalah Website Tempat Anda Dapat Mempelajari HTML, CSS, Dan JavaScript Bersama Dengan Animasi Dan Efek CSS Yang Kreatif. Kami Membagikan Atau Menyediakan Sumber Daya Gratis Terkait Desain Dan Pengembangan Web Untuk Menginspirasi Pengembang Frontend Yang Berfokus Pada Desain. Tingkatkan Keterampilan Coding Anda Dengan Program Gratis Dan Tutorial Coding Kami. <br><br> Terima kasih!"
      ],
      typeSpeed: 7,
      contentType: 'html'
    });
  }, 100);