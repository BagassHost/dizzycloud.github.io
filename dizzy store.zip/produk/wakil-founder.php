<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html b:css='false' b:defaultwidgetversion='2' b:layoutsVersion='3' b:responsive='true' b:templateUrl='indie.xml' b:templateVersion='1.3.0' expr:dir='data:blog.languageDirection' expr:lang='data:blog.locale.language' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
  <b:attr name='xmlns' value=''/> 
  <b:attr name='xmlns:b' value=''/>
  <b:attr name='xmlns:expr' value=''/>
  <b:attr name='xmlns:data' value=''/>

<!--
    Name      : Royal-Ui 
    Version   : 2.6
    Date      : [UPDATED] 21 JULY 2022
    Demo      : www.royal-ui.xyz
    Type      : Premium
    Designer  : TECHLY420
    Website   : www.techly420.co
    ============================================================================
    NOTE :
    This theme is premium (paid).
    You can only get it by purchasing officially.
    If you get it for free through any method, that means you get it illegally.
    ============================================================================

-->
    
  <!--[ <head> Open ]-->
  &lt;head&gt;
<script async='async' crossorigin='anonymous' src='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8760997910536491'/>
  
  <b:if cond='data:view.isMultipleItems'>
    <b:if cond='data:view.isHomepage'>
      <!--[ Homepage title ]-->
      <title><data:blog.title.escaped/></title>
      <b:elseif cond='data:view.search.query'/>
      <!--[ Search title ]-->
      <title><data:messages.search/>: <data:view.search.query/></title>
      <b:elseif cond='data:view.search.label'/>
      <!--[ Label title ]-->
      <title><data:blog.pageName.escaped/> - <data:blog.title.escaped/></title>
      <b:elseif cond='data:view.isArchive'/>
      <!--[ Archive title ]-->
      <title>Blog archive in: <data:blog.pageName.escaped/></title>
      <b:else/>
      <title>Blog: <data:blog.title.escaped/></title>
    </b:if>
    <b:elseif cond='data:view.isError'/>
    <!--[ Error title ]-->
    <title>Error 404: Not Found</title>
    <b:else/>
    <!--[ SingleItem title ]-->
    <title><data:blog.pageName.escaped/> - <data:blog.title.escaped/></title>
  </b:if>

  <!--[ Meta for browser ]-->
  <meta charset='UTF-8'/>
  <meta content='width=device-width, initial-scale=1, user-scalable=1, minimum-scale=1, maximum-scale=5' name='viewport'/>
  <meta content='IE=edge' http-equiv='X-UA-Compatible'/>
  <meta content='max-image-preview:large' name='robots'/>

  <!-- Link Canonical -->
  <link expr:href='data:blog.url.canonical' rel='canonical'/>

  <b:if cond='!data:view.isError'>
    <!--[ Browser data, description and keyword ]-->
    <b:if cond='data:blog.metaDescription'>
      <meta expr:content='data:blog.metaDescription.escaped' name='description'/>
      <b:elseif cond='data:view.isSingleItem'/>
      <meta expr:content='data:post.snippet.escaped snippet { length: 147, links: false, linebreaks: false, ellipsis: false }' name='description'/>
      <b:else/>
      <meta expr:content='data:blog.pageName.escaped ? data:blog.pageName.escaped : data:blog.title' name='description'/>
    </b:if>
    <meta expr:content='data:blog.title.escaped + &quot;, &quot; + data:blog.pageName.escaped + &quot;, Keyword_1, Keyword_2, Keyword_3 &quot;' name='keywords'/>
    <b:tag cond='data:view.isPost' expr:href='resizeImage(data:blog.postImageUrl, 0)' name='link' rel='image_src'/>
  
    <!--[ Generator and rrs ]-->
    <meta content='blogger' name='generator'/>
    <link expr:href='data:blog.homepageUrl.canonical + &quot;feeds/posts/default&quot;' expr:title='data:blog.title + &quot; Â» Atom&quot;' rel='alternate' type='application/atom+xml'/>
    <link expr:href='data:blog.homepageUrl.canonical + &quot;feeds/posts/default?alt=rss&quot;' expr:title='data:blog.title + &quot; Â» Feed&quot;' rel='alternate' type='application/rss+xml'/>
    <link expr:href='data:blog.homepageUrl.canonical + &quot;feeds/comments/default?alt=rss&quot;' expr:title='data:blog.title + &quot; Â» Comments Feed&quot;' rel='alternate' type='application/rss+xml'/>
  
    <!--[ Theme Color ]-->
    <meta expr:content='data:skin.vars.themeColor' name='theme-color'/>
    <meta expr:content='data:skin.vars.themeColor' name='msapplication-navbutton-color'/>
    <meta expr:content='data:skin.vars.themeColor' name='apple-mobile-web-app-status-bar-style'/>
    <meta expr:content='yes' name='apple-mobile-web-app-capable'/>
  
    <!--[ Favicon ]-->
    <link expr:href='data:blog.blogspotFaviconUrl' rel='apple-touch-icon' sizes='120x120'/>
    <link expr:href='data:blog.blogspotFaviconUrl' rel='apple-touch-icon' sizes='152x152'/>
    <link expr:href='data:blog.blogspotFaviconUrl' rel='icon' type='image/x-icon'/>
    <link expr:href='data:blog.blogspotFaviconUrl' rel='shortcut icon' type='image/x-icon'/>
    
    <!--[ Open graph ]-->
    <meta expr:content='data:blog.pageName.escaped ? data:blog.pageName.escaped : data:blog.title.escaped' property='og:title'/>
    <meta expr:content='data:blog.canonicalUrl' property='og:url'/>
    <meta expr:content='data:blog.title.escaped' property='og:site_name'/>
    <b:if cond='data:view.isMultipleItems'>
      <meta content='website' property='og:type'/>
      <b:if cond='data:blog.metaDescription'>
        <meta expr:content='data:blog.metaDescription.escaped' property='og:description'/>         
        <b:else/>
        <meta expr:content='data:blog.pageName.escaped ? data:blog.pageName.escaped : data:blog.title' property='og:description'/>
      </b:if>
      <b:else/>
      <meta content='article' property='og:type'/>
      <b:if cond='data:blog.metaDescription'>
        <meta expr:content='data:blog.metaDescription.escaped' property='og:description'/>            
        <b:else/>
        <meta expr:content='data:post.snippet.escaped snippet { length: 147, links: false, linebreaks: false, ellipsis: false }' property='og:description'/>
      </b:if>
    </b:if>
    <meta expr:content='data:blog.pageName.escaped ? data:blog.pageName.escaped : data:blog.title.escaped' property='og:image:alt'/>
    <b:if cond='data:blog.postImageUrl'>
      <meta expr:content='resizeImage(data:blog.postImageUrl, 0)' property='og:image'/>
      <b:else/>
      <meta content='Add_your_image_url_here' property='og:image'/>
    </b:if>
    
    <!--[ Twitter Card ]-->
    <meta expr:content='data:blog.pageName.escaped ? data:blog.pageName.escaped : data:blog.title.escaped' name='twitter:title'/>
    <meta expr:content='data:blog.canonicalUrl' name='twitter:url'/>
    <b:if cond='data:view.isMultipleItems'>
      <b:if cond='data:blog.metaDescription'>
        <meta expr:content='data:blog.metaDescription.escaped' name='twitter:description'/>         
        <b:else/>
        <meta expr:content='data:blog.pageName.escaped ? data:blog.pageName.escaped : data:blog.title' name='twitter:description'/>
      </b:if>
      <b:else/>
      <b:if cond='data:blog.metaDescription'>
        <meta expr:content='data:blog.metaDescription.escaped' name='twitter:description'/>            
        <b:else/>
        <meta expr:content='data:post.snippet.escaped snippet { length: 147, links: false, linebreaks: false, ellipsis: false }' name='twitter:description'/>
      </b:if>
    </b:if>
    <meta content='summary_large_image' name='twitter:card'/>
    <meta expr:content='data:blog.pageName.escaped ? data:blog.pageName.escaped : data:blog.title.escaped' name='twitter:image:alt'/>
    <b:if cond='data:blog.postImageUrl'>
      <meta expr:content='resizeImage(data:blog.postImageUrl, 0)' name='twitter:image:src'/>
      <b:else/>
      <meta content='Add_your_image_url_here' name='twitter:image:src'/>
    </b:if>
  
    <!-- Sife Verification -->
    <meta content='' name='msvalidate.01'/>
    
  </b:if>
  
  <b:if cond='data:view.isLayoutMode'>
    <!--[ CSS Layout ]-->    
    
<b:template-skin><![CDATA[
body#layout::before{content:'Royal-Ui 2.6 By Techly420';position:absolute;top:15px;right:15px;font-size:.8rem;font-family:Roboto, sans-serif;color:rgba(0,0,0,0.52)} body#layout{width:1025px;margin:0 !important;padding:60px 0 0 !important;border:0 !important;text-align:left !important;position:relative} body#layout div.layout-widget-description{font-size:12px !important;line-height:1.6em} body#layout div.layout-title{font-size:15px !important} body#layout div.section{border-radius:2px} body#layout .section h4{font-size:15px !important;margin-left:0!important} body#layout .add_widget a{font-size:13px !important} body#layout .Blog .widget-content{height:auto!important} body#layout #anchor-ad, body#layout #notif-widget .widget-content, body#layout #side-sticky, body#layout #HTML91 .widget-content, body#layout #HTML92 .widget-content, body#layout #HTML93 .widget-content, body#layout #HTML94 .widget-content, body#layout #HTML01 .widget-content, body#layout #HTML02 .widget-content, body#layout #HTML03 .widget-content, body#layout #HTML04 .widget-content{background:#f0f8ff !important} body#layout #maintenance-mode, body#layout .mobMn, body#layout #anchor-ad{margin-bottom:30px!important} body#layout .mainIn, body#layout .headCn, body#layout .blogM{display:flex} body#layout .mainbar, body#layout .headR{width:55%} body#layout .mainIn .blogCont{width:70%} body#layout .sidebar, body#layout .headL{width:45%} body#layout header, body#layout .mainIn, body#layout footer, body#layout .erroP, body#layout .addonsWidgets{border-top:1px solid #e5e5e5;padding:30px 0;position:relative} body#layout header::before, body#layout .mainIn::before, body#layout footer::before, body#layout .erroP::before, body#layout .addonsWidgets::before{content:'Header';position:absolute;top:-14px;left:20px;padding:5px 20px;border:1px solid #e5e5e5;border-radius:20px;font-size:.8rem;font-family:Roboto,sans-serif;color:rgba(0,0,0,0.52);background:#f1f1f1} body#layout #notif-widget h4{display:none} body#layout .mainIn{padding-bottom:0} body#layout .mainIn::before{content:'Main Content'} body#layout footer::before{content:'Footer'} body#layout .erroP::before{content:'Custom Error Page'} body#layout .addonsWidgets::before{content:'Add-ons'}
]]></b:template-skin>
</b:if>  
    
  <!--[ CSS stylesheet ]-->
  &lt;style&gt;&lt;!-- /* <b:skin version='1.3.0'><![CDATA[
/*
<Group description="Theme Color">
<Variable name="themeColor" description="Light Mode Address bar color" type="color" default="#2e51a2" value="transparent"/>
<Variable name="themeDark" description="Dark Mode Address bar color" type="color" default="#1e1e1e" value="#005cf4"/>
</Group>

<Group description="Border Radius">
<Variable name="button.radius" description="Buttons Border Radius" type="length" max="50px" default="3px" value="50px"/>
<Variable name="greet.radius" description="Greetings and Views Border Radius" type="length" max="25px" default="3px" value="25px"/>
<Variable name="iconhover.radius" description="Icon Hover Border Radius" type="length" max="15px" default="15px" value="15px"/>
<Variable name="thumbelem.radius" description="Thumbnail Elements Border Radius" type="length" max="15px" default="8px" value="15px"/>
<Variable name="moblsearch.radius" description="Blog Search Border Radius (Mobile)" type="length" max="20px" default="12px" value="20px"/>
<Variable name="desksearch.radius" description="Blog Search Border Radius (Desktop)" type="length" max="20px" default="8px" value="20px"/>
<Variable name="moblheader.radius" description="Header Style 2 Border Radius (Mobile)" type="length" max="30px" default="8px" value="30px"/>
</Group>

<Group description="Basic colors and Background">
<Variable name="head.color" description="Heading colors" type="color" default="#262d3d" value="#08102b"/>
<Variable name="body.color" description="Body colors" type="color" default="#48525c" value="#08102b"/>
<Variable name="body.colorAlt" description="Alternative body colors" type="color" default="#767676" value="#767676"/>
<Variable name="body.bgColor" description="Main page bakground color" type="color" default="#fffdfc" value="#fffdfc"/>
<Variable name="link.color" description="Link colors" type="color" default="#9C27B0" value="#D52C1F"/>
<Variable name="link.bgColor" description="Button link colors" type="color" default="#9C27B0" value="#D52C1F"/>
</Group>

<Group description="Icon colors">
<Variable name="icon.color" description="Icon colors" type="color" default="#48525c" value="#08102b"/>
<Variable name="icon.colorAlt" description="Alternative icon colors" type="color" default="#767676" value="#08102b"/>
<Variable name="icon.colorSec" description="Secondary icon colors" type="color" default="#767676" value="#767676"/>
</Group>

<Group description="Notification">
<Variable name="notif.height" description="Notification max height" type="length" max="60px" default="45px" value="60px"/>
<Variable name="notif.bg" description="Notification background color" type="color" default="#F3E5F5" value="#F3E5F5"/>
<Variable name="notif.color" description="Notification text color" type="color" default="#08102b" value="#3c4043"/>
<Variable name="notif.link" description="Notification link color" type="color" default="#9c27b0" value="#D52C1F"/>
</Group>

<Group description="Header colors, background and height">
<Variable name="header.height" description="Header height" type="length" max="80px" default="60px" value="60px"/>
<Variable name="header.heightM" description="Header height(mobile)" type="length" max="80px" default="60px" value="60px"/>
<Variable name="header.titleSize" description="Header title font size" type="length" max="20px" default="16px" value="16px"/>
<Variable name="header.text" description="Header text colors" type="color" default="#48525c" value="#48525c"/>
<Variable name="header.icon" description="Header icon colors" type="color" default="#262d3d" value="#262d3d"/>
<Variable name="header.bgColor" description="Header background color" type="color" default="#fffdfc" value="#fffdfc"/>
<Variable name="header.border" description="Header border" type="length" max="1px" default="0px" value="0px"/>
</Group>

<Group description="Navbar colors">
<Variable name="nav.width" description="Navbar max width" type="length" max="260px" default="230px" value="260px"/>
<Variable name="nav.border" description="Navbar border" type="length" max="1px" default="0px" value="1px"/>
<Variable name="nav.height" description="Navbar max height" type="length" max="50px" default="48px" value="48px"/>
<Variable name="nav.text" description="Navbar text colors" type="color" default="#48525c" value="#000000"/>
<Variable name="nav.icon" description="Navbar icon color" type="color" default="#48525c" value="#000000"/>
<Variable name="nav.bg" description="Navbar background color" type="color" default="$(header.bgColor)" value="#f5f5f5"/>
</Group>

<Group description="Border Radius iFxd ++">
<Variable name="If.brd" description="iFxd Border" type="length" max="100px" default="10px" value="30px"/>
<Variable name="tI.brd" description="tIc Border" type="length" max="100px" default="10px" value="30px"/>
</Group>

<Group description="Searchbar colors">
<Variable name="search.icon" description="Searchbar icon color" type="color" default="#48525c" value="#08102b"/>
<Variable name="search.bg" description="Searchbar background color" type="color" default="#fffdfc" value="#9E9E9E"/>
</Group>

<Group description="Content background">
<Variable name="content.bg" description="Content background color" type="color" default="#fffdfc" value="#fffdfc"/>
<Variable name="content.border" description="Content border color" type="color" default="#eceff1" value="#e6e6e6"/>
</Group>

<Group description="Content max width">
<Variable name="content.maxWidth" description="Max width of main content" type="length" max="1440px" default="1024px" value="1280px"/>
<Variable name="sidebar.maxWidth" description="Max width of sidebar" type="length" max="360px" default="300px" value="300px"/>
<Variable name="post.maxContent" description="Post max width" type="length" max="900px" default="720px" value="780px"/>
<Variable name="page.maxContent" description="Static page max width" type="length" max="900px" default="780px" value="780px"/>
</Group>

<Group description="Post font size">
<Variable name="post.titleSize" description="Post title font size" type="length" max="42px" default="28px" value="36px"/>
<Variable name="post.fontSize" description="Post font size (Default)" type="length" max="18px" default="16px" value="16px"/>
<Variable name="post.titleSizeMobile" description="Post title size (onMobile)" type="length" max="38px" default="22px" value="28px"/>
<Variable name="post.fontSizeMobile" description="Post font size (onMobile)" type="length" max="18px" default="16px" value="15px"/>
</Group>

<Group description="Widget title font size">
<Variable name="widget.titleSize" description="Widget title font size" type="length" max="18px" default="14px" value="15px"/>
<Variable name="widget.titleAfter" description="Widget title border" type="length" max="40px" default="25px" value="25px"/>
<Variable name="widget.titleAfterC" description="Widget title border color" type="color" default="#989b9f" value="#989b9f"/>
</Group>

<Group description="Mobile menu colors">
<Variable name="mob.border" description="Mobile menu border" type="length" max="2px" default="0px" value="0px"/>
<Variable name="mob.borderR" description="Mobile corder radius" type="length" max="20px" default="20px" value="20px"/>
<Variable name="mob.text" description="Mobile text colors" type="color" default="#48525c" value="#08102b"/>
<Variable name="mob.bg" description="Mobile background color" type="color" default="#fffdfc" value="#fffdfc"/>
<Variable name="mob.hovBg" description="Mobile hover background color" type="color" default="#f6f6f6" value="#f1f1f0"/>
</Group>

<Group description="Footer colors">
<Variable name="foot.border" description="Footer border" type="length" max="2px" default="0px" value="0px"/>
<Variable name="foot.text" description="Footer text colors" type="color" default="#48525c" value="#48525c"/>
<Variable name="foot.bg" description="Footer background color" type="color" default="#fffdfc" value="#fffdfc"/>
</Group>

<Group description="Dark mode colors and background">
<Variable name="dark.text" description="Dark mode text color" type="color" default="#fffdfc" value="#fffdfc"/>
<Variable name="dark.textAlt" description="Alternative text colors" type="color" default="#989b9f" value="#989b9f"/>
<Variable name="dark.link" description="Dark mode link colors" type="color" default="#f57c00" value="#4285F4"/>
<Variable name="dark.bg" description="Dark mode background color" type="color" default="#1e1e1e" value="#1c2733"/>
<Variable name="dark.bgAlt" description="Alternative background color" type="color" default="#2d2d30" value="#263545"/>
<Variable name="dark.bgSec" description="Secondary background color" type="color" default="#252526" value="#252526"/>
</Group>

<Group description="(Do not edit) New Blogger comment required">
<Variable name="body.background" description="Background" color="#505050" type="background" default="$(color) none repeat scroll center center"  value="$(color) url() no-repeat scroll center center"/>
<Variable name="body.text.font" description="Font Blogger comment" type="font" default="&#39;Roboto&#39;, sans-serif" value="400 14px &#39;Roboto&#39;, sans-serif"/>
<Variable name="body.text.color" description="Color" type="color" default="#505050"  value="#505050"/>
<Variable name="body.link.color" description="Link color" type="color" default="#262d3d"  value="#989b9f"/>
<Variable name="posts.title.color" description="Post title color" type="color" default="#262d3d"  value="#989b9f"/>
<Variable name="posts.text.color" description="Post text color" type="color" default="#48525c"  value="#989b9f"/>
<Variable name="posts.icons.color" description="Post info color" type="color" default="#262d3d" value="#989b9f"/>
<Variable name="posts.background.color" description="Post background color" type="color" default="#f7f7fc"  value="transparent"/>
<Variable name="tabs.font" description="Font" type="font" default="&#39;Roboto&#39;, sans-serif" value="400 14px &#39;Roboto&#39;, sans-serif"/>
<Variable name="tabs.color" description="Text color" type="color" default="#4d4d4d"  value="#08102b"/>
<Variable name="tabs.selected.color" description="Selected color" type="color" default="#fff"  value="#fffdfc"/>
<Variable name="tabs.overflow.background.color" description="Popup background color" type="color" default="$(posts.background.color)"  value="#fffdfc"/>
<Variable name="tabs.overflow.color" description="Popup text color" type="color" default="#48525c"  value="#08102b"/>
<Variable name="tabs.overflow.selected.color" description="Popup selected color" type="color" default="#262d3d"  value="#989b9f"/>
<Variable name="labels.background.color" description="Labels background color" type="color" default="#fff" value="#fffdfc"/>
<Variable name="blog.title.font" description="Blog title font" type="font" default="&#39;Roboto&#39;, sans-serif" value="400 14px &#39;Roboto&#39;, sans-serif"/>
<Variable name="blog.title.color" description="Blog title color" type="color" default="#fff" value="#fffdfc"/>
</Group>
*/
/* Variable color */ :root, :root .lgT:not(.drK), :root .theme0:not(.drK){/* Theme */--headC: #08102b ;--bodyC: #08102b ;--bodyCa: #767676 ;--bodyB: #fdfcff ;/* Link */ --linkC: #482dff; --linkB: #482dff; /* Wave */ --waveB: #C6DAFC; /* Icon */ --iconC: #08102b; --iconCa: #08102b; --iconCs: #767676; ;/* Header */--headerC: #08102b ;--headerT: 16px ;--headerW: 400 ; /* write 400(normal) or 700(bold) */--headerB: #fffdfc ;--headerL: 1px ;--headerI: #08102b ;--headerH: 51px ;--headerHi: -51px ;--headerHm: 51px ;/* Notif */--notifH: 53px ;--notifU: #e8f0fe ;--notifC: #3c4043 ;--notifL: #0b57cf ;/* Content Style */ --contentB: #fffdfc ;--contentL: #e6e6e6 ;--contentW: 1280px ;--sideW: 300px ;--transB: rgba(0,0,0,.05);/* Page */ --pageW: 780px ;--pageW: 780px ;--postT: 36px ;--postF: 16px ;--postTm: 28px ;--postFm: 15px ;



/* Widget */ --widgetT: 15px ;--widgetTw: 400 ; /* write 400(normal) or 700(bold) */--widgetTa: 25px ;--widgetTac: #989b9f;
/* Navbar */--navW: 260px ;--navT: #000000 ;--navI: #000000 ;--navSc: #fffdfc;--navB: #f5f5f5 ;--navL: 1px ;/* Search */ --srchI: #08102b ;--srchB: #fffdfc ;/* Mobile Menu */--mobT: #08102b;--mobHv: #f1f1f0 ;--mobB: #fffdfc ;--mobL: 0px ;--mobBr: 20px ;--mobSb: #bacfd9; --mbSb: 6px;/* Footer */--fotT: #48525c ;--fotB: #fffdfc ;--fotL: 0px ;/* Font Style */--fontH:Google Sans Text,Arial,Helvetica,sans-serif;--fontB:Google Sans Text,Arial,Helvetica,sans-serif;--fontBa:Google Sans Text,Arial,Helvetica,sans-serif;--fontC: 'Fira Mono', monospace ;/* Transition */--trans-1: all .1s ease ;--trans-2: all .2s ease ;--trans-4: all .4s ease ;/* Syntax hg */--synxBg: #f6f6f6 ;--synxC: #2f3337 ;--synxOrange: #b75501 ;--synxBlue: #015692 ;--synxGreen: #54790d ;--synxRed: #f15a5a ;--synxGray: #656e77 ;/* Brdr IFxd & tIc */--iFbR: 30px;--tIbR: 30px;--buttonR: 50px;--greetR: 25px;/* Music Tracker */ --TrBg : #FFFFFF ;--bTopMT : #E6E0FF ;--mtBtn : #E6E0FF ;--pRs : #E6E0FF ;--pRsB : #E6E0FF ;--svgStr : #A700FF;/* Dark */ --darkT: #fffdfc; --darkTa: #989b9f; --darkU: #41b375; --darkW: #343435; --darkB: #1e1e1e; --darkBa: #2d2d30; --darkBs: #252526;}



/* Theme 1 - Red */ :root .theme1:not(.drK){/* Theme */ --themeC: #D32F2F; /* Body */ --bodyB: #FFFCFD; /* Link */ --linkC: #F44336; --linkB: #F44336; /* Header */ --headerB: #FFEBEE; /* Notif */ --notifU: #FFEBEE; --notifC: #B71C1C; /* Search */ --srchB: #FFEBEE; /* MobMn */ --mobB: #FFEBEE; /* Wave */ --waveB: #FFEBEE;/* Border M Track */ --bTopMT : #FFEBEE ;/* Button M Track */--mtBtn : #FFEBEE ;/* Svg M Track */--svgStr : #F44336}
/* Theme 2 - Green */ :root .theme2:not(.drK){/* Theme */ --themeC: #00796B; /* Body */ --bodyB: #FCFFFC; /* Link */ --linkC: #009688; --linkB: #009688; /* Header */ --headerB: #E0F2F1; /* Notif */ --notifU: #E0F2F1; --notifC: #00796B; /* Search */ --srchB: #E0F2F1; /* MobMn */ --mobB: #E0F2F1; /* Wave */ --waveB: #E0F2F1; /* Border M Track */ --bTopMT : #E0F2F1 ;/* Button M Track */--mtBtn : #E0F2F1 ;/* Svg M Track */--svgStr : #009688}
/* Theme 3 - Blue */ :root .theme3:not(.drK){/* Theme */ --themeC: #1565C0; /* Body */ --bodyB: #FBFEFF; /* Link */ --linkC: #1976D2; --linkB: #1976D2; /* Header */ --headerB: #E3F2FD; /* Notif */ --notifU: #E3F2FD; --notifC: #1565C0; /* Search */ --srchB: #E3F2FD; /* MobMn */ --mobB: #E3F2FD; /* Wave */ --waveB: #E3F2FD; /* Border M Track */ --bTopMT : #E3F2FD ;/* Button M Track */--mtBtn : #E3F2FD ;/* Svg M Track */--svgStr : #1976D2}
/* Theme 4 - Yellow */ :root .theme4:not(.drK){/* Theme */ --themeC: #FFC107; /* Body */ --bodyB: #FFFEFA; /* Link */ --linkC: #FF8F00; --linkB: #FF8F00; /* Header */ --headerB: #FFF8E1; /* Notif */ --notifU: #FFF8E1; --notifC: #FF8F00; /* Search */ --srchB: #FFF8E1; /* MobMn */ --mobB: #FFF8E1; /* Wave */ --waveB: #FFF8E1; /* Border M Track */ --bTopMT : #FFF8E1 ;/* Button M Track */--mtBtn : #FFF8E1 ;/* Svg M Track */--svgStr : #FF8F00}
/* Theme 5 - Pink */ :root .theme5:not(.drK){/* Theme */ --themeC: #C2185B; /* Body */ --bodyB: #FFFCFD; /* Link */ --linkC: #D81B60; --linkB: #D81B60; /* Header */ --headerB: #FCE4EC; /* Notif */ --notifU: #FCE4EC; --notifC: #C2185B; /* Search */ --srchB: #FCE4EC; /* MobMn */ --mobB: #FCE4EC; /* Wave */ --waveB: #FCE4EC; /* Border M Track */ --bTopMT : #FCE4EC ;/* Button M Track */--mtBtn : #FCE4EC ;/* Svg M Track */--svgStr : #D81B60}
/* Theme 6 - Orange */ :root .theme6:not(.drK){/* Theme */ --themeC: #E64A19; /* Body */ --bodyB: #FBFEFF; /* Link */ --linkC: #F4511E; --linkB: #F4511E; /* Header */ --headerB: #FBE9E7; /* Notif */ --notifU: #FBE9E7; --notifC: #E64A19; /* Search */ --srchB: #FBE9E7; /* MobMn */ --mobB: #FBE9E7; /* Wave */ --waveB: #FBE9E7; /* Border M Track */ --bTopMT : #FBE9E7 ;/* Button M Track */--mtBtn : #FBE9E7 ;/* Svg M Track */--svgStr : #F4511E}
/* Theme 7 - Blue Grey */ :root .theme7:not(.drK){/* Theme */ --themeC: #455A64; /* Body */ --bodyB: #FBFEFF; /* Link */ --linkC: #546E7A; --linkB: #546E7A; /* Header */ --headerB: #ECEFF1; /* Notif */ --notifU: #ECEFF1; --notifC: #455A64; /* Search */ --srchB: #ECEFF1; /* MobMn */ --mobB: #ECEFF1; /* Wave */ --waveB: #ECEFF1;/* Border M Track */ --bTopMT : #ECEFF1 ;/* Button M Track */--mtBtn : #ECEFF1 ;/* Svg M Track */--svgStr : #546E7A}
/* Theme 8 - Brown */ :root .theme8:not(.drK){/* Theme */ --themeC: #5D4037; /* Body */ --bodyB: #FBFEFF; /* Link */ --linkC: #5D4037; --linkB: #5D4037; /* Header */ --headerB: #EFEBE9; /* Notif */ --notifU: #EFEBE9; --notifC: #5D4037; /* Search */ --srchB: #EFEBE9; /* MobMn */ --mobB: #EFEBE9; /* Wave */ --waveB: #EFEBE9;/* Border M Track */ --bTopMT : #EFEBE9 ;/* Button M Track */--mtBtn : #EFEBE9 ;/* Svg M Track */--svgStr : #5D4037}
/* Theme 9 - Purple */ :root .theme9:not(.drK){/* Theme */ --themeC: #7B1FA2; /* Body */ --bodyB: #FBFEFF; /* Link */ --linkC: #8E24AA; --linkB: #8E24AA; /* Header */ --headerB: #F3E5F5; /* Notif */ --notifU: #F3E5F5; --notifC: #7B1FA2; /* Search */ --srchB: #F3E5F5; /* MobMn */ --mobB: #F3E5F5; /* Wave */ --waveB: #F3E5F5;/* Border M Track */ --bTopMT : #F3E5F5 ;/* Button M Track */--mtBtn : #F3E5F5 ;/* Svg M Track */--svgStr : #8E24AA}
/* Theme 10 - Indigo */ :root .theme10:not(.drK){/* Theme */ --themeC: #283593; /* Body */ --bodyB: #FBFEFF; /* Link */ --linkC: #3949AB; --linkB: #3949AB; /* Header */ --headerB: #E8EAF6; /* Notif */ --notifU: #E8EAF6; --notifC: #283593; /* Search */ --srchB: #E8EAF6; /* MobMn */ --mobB: #E8EAF6; /* Wave */ --waveB: #E8EAF6;/* Border M Track */ --bTopMT : #E8EAF6 ;/* Button M Track */--mtBtn : #E8EAF6 ;/* Svg M Track */--svgStr : #3949AB}



/* Desktop Responsive */
@media screen and (min-width: 768px){
.slideshow img {
margin-left: -40px;
width: calc(100% + 80px);
max-width: calc(100% + 80px)!important;
}
.flex {display:flex;}
.jse {justify-content: space-between;}
.c-gap { column-gap: 20px;}
}
.darkMode .largeSection {
border-top: 5px solid var(--header-borderColor);
box-shadow: var(--top_shadow);
background: var(--dark-bg);
}
/* Desktop Responsive */
/* Mobile Responsive */
@media screen and (max-width: 768px){
.slideshow img {
margin-left: -40px;
width: calc(100% + 80px);
max-width: calc(100% + 80px)!important;
}
}
/* Mobile Responsive */
@media screen and (max-width: 640px){article.post .postEntry img.fullImg{width:calc(100% + 40px);left:-20px}}/* Category posts */ .ctgC{margin-bottom:20px} .ctgC.loaded{animation:opaC .5s 0s;-webkit-animation:opaC .5s 0s} .ctgC .blogPg >*{margin-left:auto;margin-right:auto} @keyframes opaC{0%{opacity:0}100%{opacity:1}} @-webkit-keyframes opaC{0%{opacity:0}100%{opacity:1}}]]></b:skin>

<style><b:if cond='!data:blog.isMobileRequest'>/*<![CDATA[*//* Desktop fonts */
/* Font Body and Alternative */ @font-face{font-family:'Google Sans Text';font-style:normal;font-weight:400;font-display:swap;src:local('Google Sans Text'),local('Google-Sans-Text'),url(https://fonts.gstatic.com/s/googlesanstext/v16/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEp2iw.woff2) format('woff2')} 
/* Font Heading */ @font-face{font-family:'Google Sans Text';font-style:normal;font-weight:700;font-display:swap;src:local('Google Sans Text'),local('Google-Sans-Text'),url(https://fonts.gstatic.com/s/googlesanstext/v16/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmhjtg.woff2) format('woff2')}
/* Source Code Font */ @font-face{font-family:'Google Sans Mono';font-style:normal;font-weight:400;font-display:swap;src:local('Google Sans Mono'),local('Google-Sans-Mono'),url(https://fonts.gstatic.com/s/googlesansmono/v4/P5sUzYWFYtnZ_Cg-t0Uq_rfivrdYH4RE8-pZ5gQ1abT53wVQGrk.woff2) format('woff2')}/*]]>*/</b:if></style>

<style>/*<![CDATA[*/
/* Cookies Consent */.ckWrap{position:fixed;right:0;left:0;bottom:-600px;z-index:50;width:100%;padding:20px;background:rgba(255, 255, 255, 0.8);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:30px 30px 0 0;box-shadow:0 -10px 25px -5px rgba(0,0,0,.1);align-items:center;justify-content:center;text-align:center;animation:ckUp 2.5s forwards;animation-delay:1s;-webkit-animation:ckUp 2.5s forwards;-webkit-animation-delay:1s}
.ckWrap.acptd{animation:ckDn 2.5s backwards;animation-delay:.3s;-webkit-animation:ckDn 2.5s backwards;-webkit-animation-delay:.3s}
.ckWrap.hidden{display:none}
.ckWrap .ckCont svg{width:50px;height:50px;fill:#08102b;stroke:#08102b;stroke-width:.8}
.ckCont h2{margin:0;color:#08102b;font-size:1.5rem;font-weight:800;font-family:inherit}
.ckCont p{margin:10px 0;line-height:1.7em;color:#08102b;font-size:0.9rem;font-weight:400;font-family:inherit}
@media screen and (min-width:768px){.ckWrap{max-width:450px;border-radius:10px;right:auto;left:30px;bottom:-500px;box-shadow:0 5px 35px rgba(0,0,0,.1);animation:ckdeskUp 2.5s forwards;animation-delay:1s;-webkit-animation:ckdeskUp 2.5s forwards;-webkit-animation-delay:1s}.ckWrap.acptd{animation:ckdeskDn 2.5s backwards;animation-delay:.3s;-webkit-animation:ckdeskDn 2.5s backwards;-webkit-animation-delay:0.3s}}
@-webkit-keyframes ckUp{100%{bottom:0}}
@keyframes ckUp{100%{bottom:0}}
@-webkit-keyframes ckdeskUp{100%{bottom:30px}}
@keyframes ckdeskUp{100%{bottom:30px}}
@-webkit-keyframes ckDn{0%{bottom:0}100%{bottom:-600px}}
@keyframes ckDn{0%{bottom:0}100%{bottom:-600px}}
@-webkit-keyframes ckdeskDn{0%{bottom:30px}100%{bottom:-600px}}
@keyframes ckdeskDn{0%{bottom:30px}100%{bottom:-600px}}

/* Footer yzkx */ footer{font-size:97%;line-height:1.8em;color:var(--fotT);padding:40px 0 20px} .footer{padding:20px;background:var(--fotB);box-shadow: 0 5px 35px rgba(0,0,0,.1);border-radius:10px} footer .LinkList a, footer .sL li >*{display:inline-block;color:inherit;line-height:20px} footer .LinkList a:hover{text-decoration:underline} footer .LinkList ul:not(.sL) li::before{content:'\2013'; opacity:.3} footer .sL{display:flex;flex-wrap:wrap;align-items:baseline;font-size:13px;opacity:.8} footer .sL li{display:inline-flex;align-items:baseline} footer .sL li:not(:first-child)::before{content:'/';margin:0 5px} footer .sL li >*::before{content:attr(data-text)} .fotIn ul{list-style:none;margin:0;padding:0} .fotIn{display:flex;flex-wrap:wrap;position:relative;width:calc(100% + 30px);left:-15px;right:-15px} .fotIn >*{width:calc(21.666% - 30px);margin:0 15px} .fotIn >*:first-child{width:calc(35% - 30px)} .fotIn .widget{margin-bottom:30px} .fotIn .widget .title{color:inherit;margin-bottom:12px;font-weight:700;font-size:14px} .abtU{max-width:calc(100% - 25px)} .abtU::before{content:attr(data-text);font-size:13px; opacity:.6;display:block;margin-bottom:3px} .abtU >*{align-items:center;display:flex;justify-content:space-between;margin:10px 0} .abtU .pu-views::before{content:'We have served the best performance ' attr(data-text) ' times.';opacity:.8} .abtL{flex:0 0 70px;width:70px;height:70px;background-repeat:no-repeat;background-size:100%;background-position:center;border-radius:10px} .abtT{flex:0 0 calc(100% - 82px)} .abtT .tl{color:inherit; font-size:1.3rem} .abtD{-webkit-box-orient:vertical;-webkit-line-clamp:2;display:-webkit-box;line-height:1.4em;margin:4px 0 0;overflow:hidden}
/* Footer Credit and Backtop yzkx */ footer .credit a{display:inline-flex;align-items:center} footer .credit a svg{width:13px;height:13px;margin:0 3px;fill:var(--linkC)} .cdtIn{display:flex;align-items:baseline;justify-content:space-between; position:relative;width:calc(100% + 20px);left:-10px;right:-10px} .cdtIn >*{margin:0 10px} .cdtIn .HTML{overflow:hidden;white-space:nowrap;text-overflow:ellipsis} .fotCd{display:inline-flex} .fotCd .creator{opacity:0} .tTop svg{width:20px;height:20px;stroke:var(--fotT)} .toTop{display:flex;align-items:center; white-space:nowrap} .toTop::before{content:attr(data-text); opacity:.7;margin:0 5px} .toTopF{display:flex;align-items:center;justify-content:center;width:45px;height:45px;border-radius:50%;background:var(--linkB);position:fixed;bottom:20px;right:20px} .toTopF svg{stroke:#fffdfc;stroke-width:2}
/* Footer */  .fotIn >*, .fotIn >*:first-child{width:calc(50% - 30px)}}



/* Entry font */ .fnIn:checked ~ .fnB .fCls{-webkit-backdrop-filter:none;backdrop-filter:none} .fnC{display:flex;list-style:none;margin:0;padding:0} .fnC li{flex:0 0 33.33%;display:flex;justify-content:center;align-items:baseline;padding-bottom:17px;position:relative} .fnC li:nth-child(1) label::before{font-size:25px;line-height:38px} .fnC li:nth-child(1) label::after{content:'Small'} .fnC li:nth-child(3) label::before{font-size:40px;line-height:27px} .fnC li:nth-child(3) label::after{content:'Large'} .fnC label{display:inline-flex;flex-direction:column;align-items:center;opacity:.6} .fnC label:hover{opacity:1} .fnC label::before{content:'A';font-size:32px;font-weight:700;line-height:34px} .fnC label::after{content:'Default';font-size:12px;position:absolute;bottom:0} .fontS1:checked ~ .fnB .fnt1, .fontS2:checked ~ .fnB .fnt2, .fontS3:checked ~ .fnB .fnt3{opacity:1} .fontS1:checked ~ .pInr .pEnt{font-size:var(--postFS)} .fontS3:checked ~ .pInr .pEnt{font-size:var(--postFL)} @media screen and (max-width:500px){.fontS1:checked ~ .pInr .pEnt{font-size:var(--postFSm)} .fontS3:checked ~ .pInr .pEnt{font-size:var(--postFLm)}}

/* Bookmark */.pop-area::-webkit-scrollbar{display:none}.pop-area{display:flex!important;width:100%;height:100%;position:fixed;top:0;left:0;background:rgb(0 0 0/51%);visibility:hidden;opacity:0;transition:var(--trans-2);z-index:999999;overflow-y:scroll}.pop-area.open{opacity:1;visibility:visible}.pop-area .pop-html{background:#fff;padding-bottom:10px;display:block;margin:auto auto;width:calc(100% - 20px);max-width:500px;visibility:hidden;opacity:0;overflow:hidden;transition:var(--trans-2);transform:scale(.5);border-radius:7px;box-shadow:0 9px 46px 8px rgba(0,0,0,.14),0 11px 15px -7px rgba(0,0,0,.12),0 24px 38px 3px rgba(0,0,0,.2)}.pop-area.open .pop-html{opacity:1;transform:scale(1);visibility:visible}.pop-area .head-pop{width:-webkit-fill-available;padding:12px 30px;overflow:hidden;}.pop-area .close-btn{float:right;cursor:pointer;fill:#7e7e7e}.pop-area .buka-tutup svg{width:20px;height:20px;fill:none!important;stroke:#08102b;stroke-linecap:round;stroke-linejoin:round;stroke-width:1px}
.pop-area .body-content{padding:10px}.pop-area .text-center{display:grid;text-align:center;grid-gap:15px}.pop-area .text-center svg{margin:0 auto}.pop-area .btn.btn-outline-info{width:fit-content;margin:0 auto;text-decoration:none}.pop-area .table{width:100%;box-shadow:0 5px 35px rgb(0 0 0 / 7%);background:var(--contentB);border-radius:10px;margin:5px 0;padding:5px}.pop-area .table img{border-radius:4px;width:auto;background:var(--mobHv)}.pop-area .img-left{width:140px;height:60px}.pop-area .item-left{padding-right:10px}.pop-area .btn-remove{cursor:pointer}.pop-area .btn-remove svg{fill:none!important;stroke:var(--iconC);stroke-linecap:round;stroke-linejoin:round;stroke-width:1}.pop-area .head-pop b:after{content:'';display:inline-block;vertical-align:middle;width:var(--widgetTa);margin:0 10px;opacity:.5}.pop-area .head-pop b{margin:0 0 25px;font-size:var(--widgetT);font-weight:var(--widgetTw);position:relative}
.pop-area .table img:before{content:'No image';display:block;position:absolute;top:50%;left:50%;max-width:none;max-height:100%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);font-size:12px;opacity:.7;white-space:nowrap}.show-bookmark{font-size:11px;line-height:18px;padding:0 5px;border-radius:10px;background:#e6e6e6;color:var(--bodyC);position:absolute;top:-5px;right:0;z-index:2}@-webkit-keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}@keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}.counterStat{color:#fff;font-size:16px}.drK .pop-area .pop-html{background:var(--darkB);color:var(--darkT)}.drK .pop-area .buka-tutup svg,.drK .btn-remove svg{stroke:var(--darkT)}.drK .pop-area .table img{background:var(--darkTa)} .drK .pop-area .table{background:var(--darkBa)}.iFxd .hartomy-bookmark-btn:before{content:'';font-size:12px;color:#767676;width:150px;padding-left:30px;padding:5px 0 5px 30px;background-color:var(--bodyB);border-radius:5px;position:absolute;right:0;display:none}.iFxd .hartomy-bookmark-btn{position:relative;transition:var(--trans-4)}

/* Wave Animation */ .wvC{position:absolute;bottom:0;width:100%;z-index:-1} .wvS{position:relative} .wvS .waves{position:absolute;bottom:0;width:100%;height:60px;min-height:100px;max-height:150px} .wvH{position:relative;height:0;background:var(--linkB);animation:waveHd 7s infinite} .plx > use{fill:var(--linkB);animation:waveMove 25s cubic-bezier(.55,.5,.45,.5) infinite} .plx > use:nth-child(1){opacity:.4;animation-delay:-2s;animation-duration:7s} .plx > use:nth-child(2){opacity:.4;animation-delay:-3s;animation-duration:10s} .plx > use:nth-child(3){opacity:.3;animation-delay:-4s;animation-duration:13s} .plx > use:nth-child(4){opacity:1;animation-delay:-5s;animation-duration:20s} @media (max-width:896px){.wvH{animation:waveHm 7s infinite}} .drK .wvH{background:var(--darkU);} .drK .plx > use{fill:var(--darkU);} @keyframes waveMove{0%{transform: translate3d(-90px,0,0)}100%{transform: translate3d(85px,0,0)}} @keyframes waveHm{0%{height:0}35%,65%{height:200px}100%{height:0}} @keyframes waveHd{0%{height:0}35%,65%{height:100px}100%{height:0}}

/* Category layout */.stw-feature{padding:5px;text-align:center;position:relative}.stw-feature h2{font-size:1.6em;line-height:1.6em;margin-bottom:0;padding-bottom:0}.stw-feature ul{clear:both;margin:15px 0 20px;width:100%;display:flex;padding:0;flex-wrap:wrap;justify-content:space-between}.stw-feature.icon-p-2 li{position:relative;width:30%;list-style:none;line-height:1.3em;text-align:center;border-radius:10px;margin:6px 0;background:var(--contentB);box-shadow:0 5px 35px rgb(0 0 0/7%);padding:6px 0 12px;display:flex;align-items:center;justify-content:center}.stw-feature li a{display:block;text-decoration:none;color:var(--fontC)}.stw-feature li svg{margin:3px 0;width:35px;height:35px;display:inline-block}.stw-feature li span{display:block;padding:0 3px}.drK .stw-feature li{background:var(--darkBa)}

/* Article Rating */.pRate{display:none;padding:30px 0 10px 0}.pRateC{display:flex;max-width:400px;margin-top:30px;padding:25px 17px;line-height:25px;background:var(--contentB);border-radius:10px;box-shadow:0 5px 35px rgba(149,157,165,.3);font-size:16px;font-family:inherit;color:#08102b;text-align:center;justify-content:center}.pRateC .ld{display:inline-flex;align-items:center;font-size:13px;opacity:.8}.pRateC .ld svg{width:18px;height:18px;margin-right:5px;stroke:none!important;fill:#08102b}.pRateS{background:#fff;position:absolute}

/* Post Icon Pack */ .icS:not(:last-child){margin-bottom:15px} .icS{display:flex; position:relative;width:calc(100% + 10px);left:-5px;right:-5px} .icS >*{background:var(--synBg);border-radius:var(--radius);color:var(--synC);direction:ltr; margin:0 5px} .icS .icI{display:flex;align-items:center;justify-content:center;flex:0 0 55px} .icS .icI svg{width:26px;height:26px} .icS .icC{position:relative;overflow:hidden;font-family:var(--fontC);flex-grow:1} .icS .icC::before{content:attr(data-text); display:flex;justify-content:flex-end;position:absolute;top:0;left:0;right:0;background:inherit;color:var(--synGray);font-size:10px;padding:0 10px;z-index:2;line-height:25px} .icS .icC pre{margin:0;padding:25px 15px 15px; color:inherit; background:inherit}.drK .icS >*{background:var(--drkBs);color:var(--darkBa)}

/* Preloader */.preloader{position:fixed;width:100%;height:100vh;background:var(--contentB);left:0;top:0;display:flex;flex-direction:column;align-items:center;justify-content:center;transition:all .4s;z-index:2000}.preloader.hide{opacity:0;pointer-events:none}.preloader .preloader-text{color:#838383;text-transform:uppercase;letter-spacing:8px;font-size:15px}.preloader .dots-container{display:flex;margin-bottom:48px}.preloader .dot{background:red;width:10px;height:10px;border-radius:50%;margin:0 5px}.preloader .dot.red{background:#ea4335;animation:bounce 1s infinite}.preloader .dot.green{background:#34a853;animation:bounce 1s infinite;animation-delay:.2s}.preloader .dot.yellow{background:#fbbc05;animation:bounce 1s infinite;animation-delay:.4s}@keyframes bounce{50%{transform:translateY(16px)}100%{transform:translateY(0)}}.drK .preloader{background:var(--darkB)}

/* Pay box and Changelog */.changeLog{position:fixed;bottom:0;left:0;right:0;margin:0;padding:40px 0;width:100%;height:100%;background-color:#fefefe;font-family:var(--fontB);font-size:15px;z-index:22;-webkit-transition:all .1s ease;transition:all .1s ease;overflow-y:auto;opacity:0;visibility:hidden}.changeLog .logClose{display:flex;align-items:center;height:22px;position:absolute;top:20px;right:25px}.changeLog .logClose:before{content:'Close';font-size:11px;padding-right:8px;font-family:var(--fontB)}.changeLog .logContent{width:100%;max-width:820px;padding:0 20px;margin-left:auto;margin-right:auto;font-family:var(--fontB)}.changeLog .logContent h2{margin-top:10px;font-family:var(--fontB)}.changeLog .logContent ol,.changeLog .logContent ul{padding-left:30px}.logInput:checked ~ .changeLog{opacity:1;visibility:visible}.I{color:inherit;text-decoration:underline;font-family:var(--fontBa);line-height:20px}-webkit-backdrop-filter:blur(5px);backdrop-filter:blur(5px);display:flex;align-items:center;justify-content:center;padding:0;overflow:hidden}.purchaseContent{width:calc(100% - 40px);max-width:780px;max-height:calc(100% - 40px);overflow-y:auto;position:relative;background-color:#fefefe;display:flex;flex-wrap:wrap;border-radius:2px;margin-top:-100%;-webkit-transition:all .1s ease;transition:all .1s ease;z-index:3}.purchaseDetail{width:55%;flex-shrink:0;background-color:#f1f1f0;padding:50px 25px 20px}.purchaseMethod{width:45%;flex-shrink:0;padding:50px 25px 20px}.purchaseContent .purchaseTitle{margin-top:0;margin-bottom:30px;font-size:1.3rem;font-family:var(--fontBa)}.purchaseName, .purchasePrice{font-weight:900;margin-bottom:20px;color:var(--headC)}.purchaseName:before, .purchasePrice:before{content:attr(data-text);font-size:12px;display:block;font-weight:400;color:var(--bodyC)}.purchasePrice{font-size:2rem} .purchasePrice span{font-size:15px}.purchasePrice .Paypal:before{content:'/ $'}.purchasePrice i{font-style:normal}.purchasePrice i:before, .purchasePrice span.Paypal:after{content:attr(data-text)}.purchaseName:after{content:attr(data-title)}.purchaseInfo{font-size:13px;line-height:1.7em;margin-top:40px}.purchaseLink .button{display:flex;margin-right:0;padding:12px 20px}.purchaseLink .button svg{margin-right:12px}.purchaseLink .button svg.line{fill:none;stroke-width:1.8}.purchaseLink .transfer svg{height:18px;stroke:#05275b}.purchaseLink .paypal svg{fill:#0079C1}.purchaseLink .gumroad svg{height:18px;fill:#1d1d1d}.purchaseLink .themeforest{}.purchaseConfirm{font-size:13px;text-align:right;margin-top:35px}.purchaseInput:checked ~ .purchase .purchaseContent{margin-top:0}@media screen and (max-width:480px){.purchaseContent{display:block}.purchaseDetail{width:100%;background-color:transparent;padding-top:16px}.purchaseMethod{width:100%;background-color:#f1f1f0;border-radius:5px 5px 0 0;padding-top:25px}.purchaseName{display:none}.purchaseInfo{margin-top:0;font-size:12px}.purchaseContent .purchaseDetail .purchaseTitle{margin-bottom:20px}.Blog .post .purchaseDetail .purchaseTitle{margin-bottom:10px}}.onHome .purchase .purchaseName:before{margin-bottom:8px}.drK .purchaseDetail, .drK .purchaseContent{background-color:var(--darkB)}.drK .purchaseMethod{background-color:var(--darkBs)}.drK .purchaseMethod, .drK .purchaseName, .drK .purchasePrice, .drK .purchaseName:before, .drK .purchasePrice:before, .drK .purchaseContent{color:var(--darkT)}.drK.purchaseLink .transfer svg{stroke:var(--darkT)}.drK .purchaseLink .paypal svg, .drK .purchaseLink .gumroad svg{fill:var(--darkT)}.drK .changeLog{background-color:var(--darkB)}.drK .logContent{background-color:var(--darkB)}.pay{display:flex;justify-content:center;flex-wrap:wrap; font-family:var(--fontB);font-size:14px}.pay > *{transition:transform .15s ease;-webkit-transition:transform .15s ease}.pay > *:hover{-webkit-transform:scale(1.05,1.05);transform:scale(1.05,1.05)}.pyM{min-width:250px;max-width:300px;display:block;position:relative;background:#fff;border-radius:3px;box-shadow:0 10px 40px rgba(149,157,165,.2);padding:0 0 74px;text-align:center;margin:0 10px 30px}.pyM.disc::before{content:'-30%'; display:block;font-weight:700;font-size:13px;width:50px;height:50px;padding:15px 0 10px;background:#ebeced;border-radius:5px 5px 50px 50px;position:absolute;top:-5px;right:10px}.pyM.disc.ds-40::before{content:'-40%'}.pyM i.strike{display:block;font-size:15px;font-style:normal;text-decoration:line-through}.pyM ol.pyI{list-style:none;margin:30px 0;padding:0 30px;font-size:13px;line-height:1.8em;opacity:.8}.pyH{padding:20px;text-transform:uppercase}.pyP{font-size:55px;line-height:normal;color:var(--linkC);font-weight:700}.pyP::before, .pyP::after{content:attr(data-currency);font-size:16px;font-weight:400}.pyP::after{content:attr(data-text)}.pyB{position:absolute;bottom:0;left:0;right:0}.pyB .button{margin:0 0 30px}.drK .pyM{background:var(--darkBa);box-shadow:0 10px 40px rgba(0,0,0,.2)} .drK .pyP{color:var(--darkU)} .drK.pyM.disc::before{background:var(--darkU)}

/* SVG Icon Color */svg{width:22px;height:22px;vertical-align:middle;fill:#161617}svg .svg-c{fill:var(--linkC)}svg.line .svg-c{fill:none;stroke:var(--linkC)}svg .line,svg.line{fill:none;stroke:#161617;stroke-linecap:round;stroke-linejoin:round;stroke-width:1}.hidden,.replaced{display:none}.invisible{visibility:hidden}.clear{width:100%;display:block;margin:0;padding:0;float:none;clear:both}.full-close{display:block;position:fixed;top:0;left:0;width:100%;height:100%;z-index:2;-webkit-transition:all .2s ease-in;transition:all .2s ease-in;background:0 0;opacity:0;visibility:hidden}.drK svg .svg-c{fill:none;stroke:var(--darkU)}

/* Pop-Up Box by Fineshop */.popSc{position:fixed;z-index:99999;top:0;bottom:0;left:0;right:0;padding:20px;background:#f3f5fe;display:flex;justify-content:center;align-items:center}.popSc.hidden{display:none}
.popSc .popBo{position:relative;background:#fff;max-width:400px;display:flex;justify-content:center;align-items:center;flex-direction:column;padding:30px;border-radius:30px}
.popSc .popBo svg{display:block;width:50px;height:50px;fill:none !important;stroke:#08102b;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5}
.popSc .popBo h2{margin:10px 0 15px 0;font-size:1.2rem;font-weight:800;color:#08102b}
.popSc .popBo p{margin:0;line-height:1.7em;font-size:0.9rem;color:#08102b}

/* TOC indicator */.tocC:before{content:'';display:block;width:10px;height:10px;background-color:var(--linkC);border-radius:50%;position:absolute;top:5px;left:12px;animation:indicator 1s ease infinite;-webkit-animation:indicator 1s ease infinite;z-index:1}@-webkit-keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}@keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}.drK .tocC:before{background-color:var(--darkU)}

/* Thumbnail hover effect */
article .pThmb a:hover, article .iThmb a:hover{transform:scale(1.025)}

/* Menu */ .headR .headM{display:block;position:absolute;top:0;right:0;padding:10px 0;width:150px;background:var(--contentB);font-size:13px;border-radius:10px 5px 10px 10px;box-shadow:0 0 15px rgba(0,0,0,.07);-webkit-transition:var(--trans-2);transition:var(--trans-2);overflow:hidden;z-index:18;opacity:0;visibility:hidden} .headR .headM:before{content:attr(data-text);display:block;padding:0 15px 10px;width:100%;font-size:11px;opacity:.7} .headR .headM >*{display:block;padding:9px 15px;width:100%;cursor:pointer} .headR .headM >*:before{content:attr(aria-label);opacity:.9} .headR .headM >*:hover{background:rgba(0,0,0,.05)} .navM:checked ~ .mainWrp .headM{visibility:visible;opacity:1} 

/* Settings */ .headR .headM{display:block;position:absolute;top:0;right:0;padding:10px 0;width:150px;background:var(--contentB);font-size:13px;border-radius:10px 5px 10px 10px;box-shadow:0 0 15px rgba(0,0,0,.07);-webkit-transition:var(--trans-2);transition:var(--trans-2);overflow:hidden;z-index:18;opacity:0;visibility:hidden} .headR .headM:before{content:attr(data-text);display:block;padding:0 15px 10px;width:100%;font-size:11px;opacity:.7} .headR .headM >*{display:block;padding:9px 15px;width:100%;cursor:pointer} .headR .headM >*:before{content:attr(aria-label);opacity:.9} .headR .headM >*:hover{background:rgba(0,0,0,.05)} .navM:checked ~ .mainWrp .headM{visibility:visible;opacity:1} .navM:checked ~ .mainWrp .headM + .fCls{visibility:visible;opacity:1;z-index:17} .bD:not(.drK):not(.syD) .headR .headM .lgtB{background-color:rgba(0,0,0,.1)} .drK:not(.syD) .headR .headM .drkB{background-color:rgba(0,0,0,.1)} .syD .headR .headM .sydB{background-color:rgba(0,0,0,.1)} .drK .headR .headM{background:var(--darkBa)} .Rtl .headR .headM{right:auto;left:0;border-radius:5px 10px 10px 10px}

/* Toast Notification */.tNtf span{position:fixed;left:24px;bottom:-70px;display:inline-flex;align-items:center;text-align:center;justify-content:center;margin-bottom:20px;z-index:99981;background:#323232;color:rgba(255,255,255,.8);font-size:14px;font-family:inherit;border-radius:3px;padding:13px 24px; box-shadow:0 5px 35px rgba(149,157,165,.3);opacity:0;transition:all .1s ease;animation:slideinwards 2s ease forwards;-webkit-animation:slideinwards 2s ease forwards}
@media screen and (max-width:500px){.tNtf span{margin-bottom:20px;left:20px;right:20px;font-size:13px}}
@keyframes slideinwards{0%{opacity:0}20%{opacity:1;bottom:0}50%{opacity:1;bottom:0}80%{opacity:1;bottom:0}100%{opacity:0;bottom:-70px;visibility:hidden}}
@-webkit-keyframes slideinwards{0%{opacity:0}20%{opacity:1;bottom:0}50%{opacity:1;bottom:0}80%{opacity:1;bottom:0}100%{opacity:0;bottom:-70px;visibility:hidden}}

/* Reading progress bar */ .progB{position:fixed;top:0;left:0;width:0;height:3px;z-index:97;background-color:var(--linkC)}.drK .progB{background-color:var(--darkU)}

/* RGB Effect */.stwRainbow,.stwBlurRainbow{position:fixed;width:100%;bottom:0;left:0;right:0;height:3px;z-index:23;background:linear-gradient(-45deg, #4086F4, #31A952, #FBBE01, #EB4132,#4086F4, #31A952, #FBBE01, #EB4132);background-size:200%;-webkit-animation:animeBar 5s linear infinite;animation:animeBar 5s linear infinite}.stwBlurRainbow{height:10px;z-index:22;filter:blur(10px);opacity:.7}@-webkit-keyframes animeBar{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}@keyframes animeBar{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

/* Music player */.player-STLH{transform:translate(0%,0%);width:330px;height:500px;border-radius:15px;background-color:var(--contentB);box-shadow:0 15px 20px 0 #dadada;}.player-STLH input[type=range]{-webkit-appearance:none!important;margin:0px;padding:0px;background:#e7e8ff;height:5px;width:150px;outline:none;cursor:pointer;overflow:hidden;border-radius:5px;}.player-STLH input[type=range]::-ms-fill-lower{background:var(--linkB);opacity:.2}.player-STLH input[type=range]::-ms-fill-upper{background:var(--linkB);opacity:.2}.player-STLH input[type=range]::-moz-range-track{border:none;background:var(--linkB);opacity:.2}.player-STLH input[type=range]::-webkit-slider-thumb{-webkit-appearance:none!important;background:var(--linkB);height:5px;width:5px;border-radius:50%;box-shadow:-100vw 0 0 100vw var(--linkB);}.player-STLH input[type=range]::-moz-range-thumb{background:var(--linkB);height:8px;width:8px;border-radius:100%;}.player-STLH input[type=range]::-ms-thumb{-webkit-appearance:none!important;background:var(--linkB);height:8px;width:8px;border-radius:100%;}.player-STLH .cover-PS{width:150px;height:150px;border-radius:50%;overflow:hidden;position:absolute;left:50%;top:50px;transform:translateX(-50%)}.player-STLH .cover-PS img{width:100%;height:100%;object-fit:cover-PS;}.player-STLH .info-MS{position:absolute;left:50%;top:240px;transform:translateX(-50%);text-align:center;}.player-STLH .info-MS .title-MS{font-size:20px;font-weight:700;margin-bottom:2px;}.player-STLH .info-MS .singer-MS{font-size:12px;}.player-STLH .btn-box{position:absolute;top:330px;width:100%;display:flex;justify-content:center;}.player-STLH .btn-box i{font-size:24px;color:#72646f;margin:0 30px;cursor:pointer;}.player-STLH .btn-box i.active{color:var(--linkB);}.player-STLH .volume-box{display:none;position:absolute;left:50%;top:295px;transform:translateX(-50%);z-index:1;padding:0 20px;}.player-STLH .volume-box .volume-down{position:absolute;left:-15px;top:50%;transform:translateY(-50%);cursor:pointer;color:#72646f;}.player-STLH .volume-box .volume-up{position:absolute;right:-15px;top:50%;transform:translateY(-50%);cursor:pointer;color:#72646f;}.player-STLH .volume-box .volume-up::selection{background-color:unset;}.player-STLH .volume-box input[type=range]{height:5px;width:150px;margin:0 0 15px 0;}.player-STLH .volume-box.active{display:block;}.player-STLH .music-box{position:absolute;left:50%;top:385px;transform:translateX(-50%);}.player-STLH .music-box input[type=range]{height:5px;width:230px;margin:0 0 10px 0;}.player-STLH .music-box input[type=range]::-webkit-slider-thumb{height:5px;width:7px;}.player-STLH .music-box .current-time{position:absolute;left:-35px;top:50%;transform:translateY(-50%);font-size:12px}.player-STLH .music-box .duration{position:absolute;right:-35px;top:50%;transform:translateY(-50%);font-size:12px}.player-STLH .music-box .play,.player-STLH .music-box .pause{position:absolute;left:50%;top:55px;transform:translateX(-50%);width:50px;height:50px;border-radius:50px;background-color:var(--linkB);cursor:pointer;transition:all 0.4s;}.player-STLH .music-box .play i,.player-STLH .music-box .pause i{font-size:36px;color:#fff;position:absolute;left:50%;top:50%;transform:translate(-48%,-50%);}.player-STLH .music-box .pause i{font-size:32px;transform:translate(-50%,-50%);}.drK .player-STLH{background:var(--darkBa); box-shadow:none} .drK .player-STLH .music-box .play,.drK .player-STLH .music-box .pause {background-color:var(--darkU)}.drK.player-STLH input[type=range]::-ms-fill-lower{background:var(--darkU);opacity:.2}.drK .player-STLH input[type=range]::-ms-fill-upper{background:var(--darkU);opacity:.2}.drK .player-STLH input[type=range]::-moz-range-track{border:none;background:var(--darkU);opacity:.2}.drK .player-STLH input[type=range]::-webkit-slider-thumb{-webkit-appearance:none!important;background:var(--darkU);height:5px;width:5px;border-radius:50%;box-shadow:-100vw 0 0 100vw var(--darkU);}.drK.player-STLH input[type=range]::-moz-range-thumb{background:var(--darkU);height:8px;width:8px;border-radius:100%;}.drK.player-STLH input[type=range]::-ms-thumb{-webkit-appearance:none!important;background:var(--darkU);height:8px;width:8px;border-radius:100%;}.drK .player-STLH .btn-box i.active{color:var(--darkU);}.drK.player-STLH input[type=range]::-ms-thumb{-webkit-appearance:none!important;background:var(--darkU);height:8px;width:8px;border-radius:100%;}

/* Double click to copy hover text */.pre:not(.tb):hover::before{content:'Double click to copy | </>'}
.pre:not(.tb).html:hover::before{content:'Double click to copy | .html'}
.pre:not(.tb).css:hover::before{content:'Double click to copy | .css'}
.pre:not(.tb).js:hover::before{content:'Double click to copy | .js'}

/* Standar CSS */ ::selection{color:#fff;background:var(--linkC)} *, ::after, ::before{-webkit-box-sizing:border-box;box-sizing:border-box} h1, h2, h3, h4, h5, h6{margin:0;font-weight:700;font-family:var(--fontH);color:var(--headC)} h1{font-size:1.9rem} h2{font-size:1.7rem} h3{font-size:1.5rem} h4{font-size:1.4rem} h5{font-size:1.3rem} h6{font-size:1.2rem} a{color:var(--linkC);text-decoration:none} a:hover{opacity:.9;transition:opacity .1s} table{border-spacing:0} iframe{max-width:100%;border:0;margin-left:auto;margin-right:auto} input, button, select, textarea{font:inherit;font-size:100%;color:inherit;line-height:normal} input::placeholder{color:rgba(0,0,0,.5)} img{display:block;position:relative;max-width:100%;height:auto} svg{width:22px;height:22px;fill:var(--iconC)} svg.line, svg .line{fill:none!important;stroke:var(--iconC);stroke-linecap:round;stroke-linejoin:round; stroke-width:1} svg.c-1{fill:var(--iconCa)} svg.c-2{fill:var(--iconCs); opacity:.4} .hidden{display:none} .invisible{visibility:hidden} .clear{width:100%;display:block;margin:0;padding:0;float:none;clear:both} .fCls{display:block;position:fixed;top:0;left:0;right:0;bottom:0;z-index:1;transition:var(--trans-1);background:transparent;opacity:0;visibility:hidden} .free::after, .soon::after, .new::after{display:inline-block;content:'Free!';color:var(--linkC);font-size:12px;font-weight:400;margin:0 5px} .new::after{content:'New!'}.soon::after{content:'Coming Soon!'}#HTML1 h3{display:none} #myIdBlog,#license-code{display:none}

/* Navbar */ .navbar{z-index:3;padding-top:10px;background:var(--navB);box-shadow:0 5px 35px rgba(0,0,0,.07);height:var(--navH);color:var(--navT);overflow:hidden} .navR .section{justify-content:flex-end} .navIn svg, header svg{width:20px;height:20px;fill:var(--navI); opacity:.8} .navIn svg.line{fill:none;stroke:var(--navI)} .navIn .section{display:flex;align-items:center;height:100%;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .navIn .section >*{margin:0 7px} .navIn .a{color:inherit} .navIn ul{list-style:none;margin:0;padding:0} .mLang{align-items:baseline;font-size:13px} .mLang, .mSocc{display:flex;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .mLang .a{width:30px;height:30px;display:flex;align-items:center;justify-content:center} .mLang .a::before{content:attr(data-text)} .mLang li.u{font-size:12px;text-transform:uppercase} .mLang li:not(:last-child){display:flex;align-items:center} .mLang li:not(:last-child)::after{content:'';height:14px; border-left:1px solid #999; margin:0 5px;opacity:.7; flex:0 0} .mLang span, .mSocc span{opacity:.5} .mSocc >*{position:relative} .mSocc svg{z-index:1} .mSocc svg{width:19px;height:19px;opacity:.8}#dateNow{right: 10px;position: absolute;top: 5px;opacity: 0.7;}
.drK .navbar{background:var(--darkB);color:var(--darkT)} .drK .navIn svg, header svg{opacity:100%}

/* Main Element */ html{scroll-behavior:smooth;overflow-x:hidden} body{position:relative;margin:0;padding:0!important;width:100%;font-family:var(--fontB);font-size:14px;color:var(--bodyC);background:var(--bodyB);-webkit-font-smoothing: antialiased;} .secIn{margin:0 auto;padding-left:20px;padding-right:20px;max-width:var(--contentW)} /* Notif Section */ .ntfC{display:flex;align-items:center;position:relative;min-height:var(--notifH);background:var(--notifU);color:var(--notifC);padding:10px 15px; font-size:13px; transition:var(--trans-1);overflow:hidden;border-radius:10px;margin-bottom:20px} .ntfC::before{content:'';width:60px;height:60px;background:rgba(0,0,0,.15);display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .Rtl .ntfC::before{left:unset;right:-12px} .ntfC .secIn{width:100%;position:relative} .ntfC .c{display:flex;align-items:center} .ntfT{width:100%; padding-right:15px; text-align:center} .ntfT a{color:var(--linkC);font-weight:700} .ntfI:checked ~ .ntfC{height:0;min-height:0;margin:0;padding:0;opacity:0;visibility:hidden} .ntfA{display:inline-flex;align-items:center;justify-content:center;text-align:initial} .ntfA >a{flex-shrink:0;white-space:nowrap;display:inline-block; margin-left:10px;padding:8px 12px;border-radius:20px;background:var(--notifL);color:#fff;font-size:12px;font-weight:400;box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%);text-decoration:none} .drK .ntfA >a{color:#fff} /* Fixed/Pop-up Element */ .fixL{display:flex;align-items:center;position:fixed;left:0;right:0;bottom:0;margin-bottom:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%;opacity:0;visibility:hidden} .fixLi, .fixL .cmBri{width:100%;max-width:680px;max-height:calc(100% - 60px);border-radius:12px;transition:inherit;z-index:3;display:flex;overflow:hidden;position:relative;margin:0 auto;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .fixLs{padding:60px 20px 20px;overflow-y:scroll;overflow-x:hidden;width:100%;background:var(--contentB)} .fixH, .mnH{display:flex;background:inherit;position:absolute;top:0;left:0;right:0;padding:0 10px;z-index:2} .fixH .cl{padding:0 10px;display:flex;align-items:center;justify-content:flex-end;position:relative;flex-shrink:0;min-width:40px} .fixH .c::after, .ntfC .c::after, .mnH .c::before{content:'\2715';line-height:18px;font-size:14px} .fixT::before{content:attr(data-text);flex-grow:1;padding:16px 10px;font-size:90%;opacity:.7} .fixT .c::before, .mnH .c::after{content:attr(aria-label);font-size:11px;margin:0 8px;opacity:.6} .fixi:checked ~ .fixL, #comment:target .fixL{margin-bottom:0;opacity:1;visibility:visible} .fixi:checked ~ .fixL .fCls, #comment:target .fixL .fCls, .BlogSearch input:focus ~ .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .shBri{max-width:520px} /* display:flex */ .headI, .bIc{display:flex;align-items:center}

/* Header Section */ header{width:100%;z-index:10; position:-webkit-sticky;position:sticky;top:0;} header a{display:block;color:inherit} header svg{width:20px;height:20px;fill:var(--headerI); opacity:.8} header svg.line{fill:none;stroke:var(--headerI)} .headCn{position:relative;height:var(--headerH);color:var(--headerC);background:var(--headerB);border-radius:0 0 2.20rem 2.20rem;box-shadow:0 0.125rem 0.5rem 0 rgb(0 0 0 / 3%), 0 0.125rem 2rem -0.5rem rgb(23 43 61 / 20%); display:flex} .headL{display:flex;align-items:center;width: var(--navW) ; /* change var(--navW) to increase header title width */ padding:0 0 0 20px; transition:var(--trans-1)} .headL .headIc{flex:0 0 30px} .headL .headN{width:calc(100% - 30px); padding:0 0 0 5px} .headR{padding:0 25px; flex-grow:1; transition:var(--trans-1)} .headI .headP{display:flex;justify-content:flex-end;position:relative} .headI .headS{} .headI{height:100%; justify-content:space-between; position:relative;width:calc(100% + 15px);left:-7.5px;right:-7.5px} .headI >*{margin:0 7.5px} .headIc{font-size:11px;display:flex;list-style:none;margin:0;padding:0} .headIc >*{position:relative} .headIc svg{z-index:1} .headIc .isSrh{display:none} ul.headIc{position:relative;width:calc(100% + 14px);left:-7px;right:-7px;justify-content:flex-end} ul.headIc li{margin:0 2px} .Header{background-repeat:no-repeat;background-size:100%;background-position:center} .Header img{max-width:160px;max-height:45px} .Header .headH{display:block;color:inherit;font-size:var(--headerT); font-weight:var(--headerW)} .Header .headTtl{overflow:hidden;white-space:nowrap;text-overflow:ellipsis; display:block}  .Header .headSub{margin:0 5px;font:400 11px var(--fontB); white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:60px;opacity:.6} .Header .headSub::before{content:attr(data-text)}/* Icon */ .tIc{width:30px;height:30px;justify-content:center} .tIc::after{content:'';background:var(--transB);border-radius:var(--tIbR);position:absolute;left:0;right:0;top:0;bottom:0;transition:var(--trans-1);opacity:0;visibility:hidden} .tIc:hover::after{opacity:1;visibility:visible;transform:scale(1.3,1.3)} .tDL .d2, .drK .tDL .d1{display:none} /* mainIn Section */ .shC{background:var(--navB);padding:10px;padding-top:15px;border-radius:20px}.drK .shC{background:var(--darkBa)}.mainWrp:after{content:'';display:block;position:absolute;top:0;right:0;width:170px;height:170px;border-radius:0 0 0 200px;background:rgba(0,0,0,.02);z-index:-1} .drK .mainWrp:after{background:rgba(0,0,0,.10)} .blogCont{flex-grow:1;padding:20px 0 0;position:relative;transition:var(--trans-1)} .blogCont .section:not(.no-items), .blogCont .widget:not(:first-child){margin-top:10px} .blogCont .section:first-child, .blogCont footer .widget:not(:first-child), .blogCont .section.mobMn{margin-top:0} .blogAd .section:not(.no-items){margin-bottom:40px} .blogM{flex-wrap:wrap;justify-content:center;padding-bottom:40px} .sidebar{max-width:500px;margin:50px auto 0} .sideSticky{position:-webkit-sticky;position:sticky;top:calc(var(--headerH) + 10px)} .onPs .blogM .mainbar{max-width:var(--pageW)} .onPg .blogM .mainbar{max-width:var(--pageW)}

/* mainNav */.mnBrs{background:var(--contentB);box-shadow: 0 5px 35px rgb(0 0 0 / 10%);border: 0;} .mnBr a{color:inherit} .mnBr ul{list-style:none;margin:0;padding:0} .mnMob{align-self:flex-end;position:absolute;left:0;right:0;bottom:0;background:inherit;padding:15px 20px 20px;z-index:1} .mnMob .mSoc{display:flex;position:relative;width:calc(100% + 14px);left:-7px;right:-7px;margin-top:5px} .mnMob:not(.no-items) + .mnMen{padding-bottom:100px} .mnMen{padding:20px 15px} .mMenu{margin-bottom:10px} .mMenu >*{display:inline} .mMenu >*:not(:last-child)::after{content:'\00B7';font-size:90%;opacity:.6} .mMenu a:hover{text-decoration:underline} .mSoc >*{position:relative} .mSoc svg{z-index:1} .mSoc svg, .mnMn svg{width:20px;height:20px;opacity:.8} .mSoc span, .mMenu span{opacity:.7} .mNav{display:none;position:relative;max-width:30px} .mNav svg{height:18px;opacity:.7;z-index:1} .mnMn >li{position:relative} .mnMn >li.br::after{content:'';display:block;border-bottom:1px solid var(--contentL);margin:12px 5px} .mnMn li:not(.mr) .a:hover, .mnMn ul li >*:hover{background:var(--transB)} .mnMn li:not(.mr) .a:hover, .mnMn ul li a:hover{color:var(--linkC)} .mnMn li:not(.mr) ul{padding-left:30px} .mnMn li ul{display:none;opacity:0;visibility:hidden} .mnMn ul li >*, .mnMn .a{display:flex;align-items:center;padding:10px 5px;position:relative;width:calc(100% + 10px);left:-5px;right:-5px;border-radius:var(--tIbR);transition:var(--trans-1)} .mnMn ul li >*{padding:10px} .mnMn .a >*{margin:0 5px} .mnMn .a:hover svg:not(.d){fill:var(--linkC)} .mnMn .a:hover svg.line:not(.d){fill:none;stroke:var(--linkC)} .mnMn .n, .mnMn ul li >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1 0 calc(100% - 64px)} .mnMn svg{flex-shrink:0} .mnMn svg.d{width:14px;height:14px} .mnMn .drp.mr .a{font-size:13px;padding-bottom:0;opacity:.7} .mnMn .drp.mr svg.d{display:none} .mnMn .drpI:checked ~ .a svg.d{transform:rotate(180deg)} .mnMn .drpI:checked ~ ul{display:block;opacity:1;visibility:visible} /* Mobile Menu */ .mobMn{position:fixed;left:0;right:0;bottom:0; border-top:1px solid var(--mobL);border-radius:var(--mobBr) var(--mobBr) 0 0;background:var(--mobB);color:var(--mobT);padding:0 20px;box-shadow:0 -10px 25px -5px rgba(0,0,0,.1);z-index:2;font-size:12px} .mobMn svg.line{stroke:var(--mobT);opacity:.8} .mobMn ul{height:55px;display:flex;align-items:center;justify-content:center;list-style:none;margin:0;padding:0} .mobMn li{display:flex;justify-content:center;flex:1 0 20%} .mobMn li >*{display:inline-flex;align-items:center;justify-content:center;min-width:35px;height:35px;border-radius:20px;padding:0 8px;transition:var(--trans-1);color:inherit} .mobMn li svg{margin:0 3px;flex-shrink:0} .mobMn li >*::after{content:attr(data-text);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:0;margin:0;transition:inherit;opacity:.7} .mobMn li >*:hover::after{max-width:70px;margin:0 3px} .mobMn .nmH{opacity:.7} .mobMn li >*:hover{background:var(--mobHv)} .mobMn li >*:hover svg.line{fill:var(--mobT) !important;opacity:.5} /* Style 2 */ .MN-2 .mobMn{font-size:10px} .mobS .mobMn li >*{flex-direction:column;position:relative} .mobS .mobMn li >*:hover{background:transparent} .MN-2 .mobMn li >*::after{max-width:none} /* Style 3 */ .MN-3 .mobMn li >*::after{content:'';width:4px;height:4px;border-radius:50%;position:absolute;bottom:-2px;opacity:0} .MN-3 .mobMn li >*:hover::after{background:var(--linkB);opacity:.7} .MN-3 .mobMn li >*:hover svg.line{stroke:var(--linkB);fill:var(--linkB) !important;opacity:.7}

/* Main  */.mainInner{border-bottom: 1px solid var(--content-border);border-bottom-left-radius: 15px;} .blogContent .mainbar > *:not(:last-child){border-bottom:none;}

/* Widget FollowByEmail */.FollowByEmail form{display:flex;max-width:320px;margin-top:20px}.FollowByEmail input[type=email]{margin:0 10px 0 0}.FollowByEmail input[type=submit]{margin:1px 0;flex-shrink:0}


/* Widget Input */.widget input[type=email],.widget input[type=text],.widget textarea{display:block;width:100%;border:1px solid rgba(0,0,0,.05);outline:0;padding:15px 15px;margin-bottom:15px;margin-top:5px}.widget input[type=email]:focus,.widget input[type=text]:focus,.widget textarea:focus{border-color:var(--bodyC)}.widget input[type=button],.widget input[type=submit]{display:inline-flex;align-items:center;margin:0 0 15px;padding:10px 20px;outline:0;border:0;border-radius:2px;color:#fefefe;background-color:#204ecf;font-size:14px;font-family:var(--fontB);white-space:nowrap;overflow:hidden;max-width:100%}.widget input[type=button]:hover,.widget input[type=submit]:hover{opacity:.7}

/* Article Section */.blogPts .ntry:not(.post):before{content: '';display: block;position: absolute;bottom: 0;right: 0;width: 100%;height: 110px;background: rgba(155,170,175,0.12);background-repeat: no-repeat;transition: opacity .3s;opacity: 0.8;border-radius: 100% 100% 17px 17px} .onIndx .blogPts, .itemFt .itm{display:flex;flex-wrap:wrap;align-items:center;position:relative; width:calc(100% + 20px);left:-10px;right:-10px} .onIndx .blogPts >*, .itemFt .itm >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px); margin-bottom:0;margin-left:10px;margin-right:10px} .onIndx .blogPts >*{background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px;margin-bottom:20px;padding:10px 10px 45px;position:relative} .onIndx .blogPts .pTag{padding-bottom:0} .onIndx .pTag .pInf{display:none} .onIndx .blogPts .pInf{position:absolute;bottom:15px;left:15px;right:15px} .onIndx .blogPts{align-items:stretch} .onIndx .blogPts.mty{display:block;width:100%;left:0;right:0} .onIndx .blogPts.mty .noPosts{width:100%;margin:0} .onIndx .blogPts div.ntry{padding-bottom:0;flex:0 0 calc(100% - 20px)} .blogPts .ntry.noAd .widget, .Blog ~ .HTML{display:none} 
/* Blog title */ .blogTtl{font-size:14px; margin:0 0 30px;width:calc(100% + 16px);display:flex;justify-content:space-between;position:relative;left:-8px;right:-8px} .blogTtl .t, .blogTtl.hm .title{margin:0 8px;flex-grow:1;margin-top:20px;} .blogTtl .t span{font-weight:400;font-size:90%; opacity:.7} .blogTtl .t span::before{content:attr(data-text)} .blogTtl .t span::after{content:''; margin:0 4px} .blogTtl .t span.hm::after{content:'/'; margin:0 8px} 
/*wiggle animation*/ 
.animated-wigle{animation: wiggle 2s infinite} @keyframes wiggle{0%{transform:rotate(0) scale(1)}60%{transform:rotate(0) scale(1)}75%{transform:rotate(0) scale(1.12)}80%{transform:rotate(0) scale(1.1)}84%{transform:rotate(-10deg) scale(1.1)}88%{transform:rotate(10deg) scale(1.1)}92%{transform:rotate(-10deg) scale(1.1)}96%{transform:rotate(10deg) scale(1.1)}100%{transform:rotate(0) scale(1)}} /* Thumbnail */ .pThmb{flex:0 0 calc(50% - 12.5px);overflow:hidden;position:relative;border-radius:10px; margin-bottom:20px; background:var(--transB)} .pThmb .thmb{display:block;position:relative;padding-top:52.335%; color:inherit; transition:var(--trans-1)} .pThmb .thmb amp-img{position:absolute;top:50%;left:50%;min-width:100%;min-height:100%;max-height:108%;text-align:center;transform:translate(-50%, -50%)} .pThmb div.thmb span::before{content:attr(data-text); opacity:.7; white-space:nowrap} .pThmb:not(.nul)::before{position:absolute;top:0;right:0;bottom:0;left:0; transform:translateX(-100%); background-image:linear-gradient(90deg, rgba(255,255,255,0) 0, rgba(255,255,255,.3) 20%, rgba(255,255,255,.6) 60%, rgba(255,255,255, 0)); animation:shimmer 2s infinite;content:''} .pThmb.iyt:not(.nul) .thmb::after{content:'';position:absolute;top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,.4) url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'><path d='M4 11.9999V8.43989C4 4.01989 7.13 2.2099 10.96 4.4199L14.05 6.1999L17.14 7.9799C20.97 10.1899 20.97 13.8099 17.14 16.0199L14.05 17.7999L10.96 19.5799C7.13 21.7899 4 19.9799 4 15.5599V11.9999Z'/></svg>") center / 35px no-repeat; opacity:0;transition:var(--trans-1)} .pThmb.iyt:not(.nul):hover .thmb::after{opacity:1}
 /* Sponsored */ .iFxd{display:flex;justify-content:flex-end;position:absolute;top:0;left:0;right:0;padding:10px 6px;font-size:13px;line-height:16px} .iFxd >*{display:flex;align-items:center;margin:0 5px;padding:5px 2.5px;border-radius:var(--iFbR);background:var(--contentB);color:inherit;box-shadow:0 8px 25px 0 rgba(0,0,0,.1)} .iFxd >* svg{width:16px;height:16px;stroke-width:1.5;margin:0 2.5px;opacity:.7} .iFxd .cmnt{padding:5px;color:var(--bodyC)} .iFxd .cmnt::after{content:attr(data-text);margin:0 2.5px;opacity:.7} .drK .iFxd >* svg.line{stroke:var(--iconC)} 

/* Label .pLbls::before, .pLbls >*::before{content:attr(data-text)} .pLbls::before{opacity:.7} .pLbls a:hover{text-decoration:underline} .pLbls >*{color:inherit;display:inline} .pLbls >*:not(:last-child)::after{content:'/'}*/
/* Label Custom */.pLbls::before, .pLbls >*::before{content:attr(data-text)} .pLbls::before{opacity:.8;margin-right: 5px} .pLbls a:hover{text-decoration:underline;font-weight:bold}.pLbls >*{color:inherit;display:inline}.pLbls >*:not(:last-child)::after{content:''}.iFxd.l .edit{padding:5px}
/* Label Bot in the post */
.pLbL > a{padding: 9px 12px;background:#fffdfc;color:#08102b;font-size: 13px;border-radius:50px;box-shadow: 3px 6px 15px rgba(0,0,0,.07);margin-right: 5px;}
.pLbL{display: block;direction: ltr;text-align: left;margin-bottom: 25px;}
.pLbL > a::before {content: '#';font-size: 15px;}
.drK .pLbL > a{background:var(--darkBa)}
/* Label Custom in Homepage */.pHdr .pLbls >*{color:#fefefe;display:inline;margin-right:5px;border-radius: 20px;background:#06D7A0;height:24px;padding:0 10px}.pHdr .pLbls >*:hover{text-decoration:none;color:#0b57cf;background:rgba(0,0,0,.05);font-weight:normal}.pHdr .pLbls a:nth-child(1){background:var(--linkB)}.pHdr .pLbls a:nth-child(2){background:var(--darkU)}.pHdr .pLbls a:nth-child(3){background:var(--linkC)}
/* Profile Images and Name */ .im{width:35px;height:35px;border-radius:16px; background-color:var(--transB);background-size:100%;background-position:center;background-repeat:no-repeat;display:flex;align-items:center;justify-content:center} .im svg{width:18px;height:18px;opacity:.4} .nm::after{content:attr(data-text)} /* Title and Entry */ .pTtl{font-size:1.1rem;line-height:1.5em} .pTtl.sml{font-size:1rem} .pTtl.itm{font-size:var(--postT);font-family:var(--fontBa);font-weight:900; line-height:1.3em} .pTtl.itm.nSpr{margin-bottom:30px} .aTtl a:hover{color:var(--linkC)} .aTtl a, .pSnpt{color:var(--fontC); display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden} .pEnt{margin-top:40px; font-size:var(--postF);font-family:var(--fontBa); line-height:1.8em} /* Snippet, Description, Headers and Info */ .pHdr{margin-bottom:8px} .pHdr .pLbls{white-space:nowrap;overflow:hidden;text-overflow:ellipsis; opacity:.8} .pSml{font-size:93%} .pSnpt{-webkit-line-clamp:2;margin:12px 0 0;font-family:var(--fontBa);font-size:14px;line-height:1.5em; opacity:.8} .pSnpt.nTag{color:var(--linkC);opacity:1;padding-bottom:15px} .pDesc{font-size:16px;line-height:1.5em;margin:8px 0 25px;opacity:.7} .pInf{display:flex;align-items:baseline;justify-content:space-between; margin-top:15px} .pInf.nTm{margin:0} .pInf.nSpr .pJmp{opacity:1} .pInf.nSpr .pJmp::before{content:attr(aria-label)} .pInf.ps{padding:10px 10px 10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px;justify-content:flex-start;align-items:center; margin-top:25px; position:relative;left:-4px;right:-4px;width:calc(100% + 8px)} .pInf.ps .pTtmp{opacity:1} .pInf.ps .pTtmp::before{content:attr(data-date) ' '} .pInf.ps .pTtmp::after{display:inline} .pInf.ps.nul{display:none} .pInf .pIm{flex-shrink:0; margin:0 4px} .pInf .pNm{flex-grow:1;width:calc(100% - 108px);display:inline-flex;flex-wrap:wrap;align-items:baseline} .pInf .pNm.l{display:none} .pInf .pCm{flex-shrink:0;max-width:24px;margin:0 2px} .pInf .pCm.l{max-width:58px} .pInf .pIc{display:inline-flex;justify-content:flex-end;position:relative;width:calc(100% + 10px);left:-5px;right:-5px} .pInf .pIc >*{display:flex;align-items:center;justify-content:center;width:30px;height:30px;position:relative;margin:0 2px;color:inherit} .pInf .pIc svg{width:20px;height:20px;opacity:.8;z-index:1} .pInf .pIc .cmnt::before{content:attr(data-text);font-size:11px;line-height:18px;padding:0 5px;border-radius:10px;background:#e6e6e6;color:var(--bodyC);position:absolute;top:-5px;right:0;z-index:2} .pInf .pDr{opacity:.7;display:inline-block;margin:0 4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:100%} .pInf .pDr >*:not(:first-child)::before{content:'\00B7';margin:0 5px} .pInf .pIn{display:inline} .pInf .nm{margin:0 4px} .pInf .n .nm::before{content:attr(data-write) ' ';opacity:.7} .pInf .im{width:28px;height:28px} .aTtmp{opacity:.8} .aTtmp, .pJmp{overflow:hidden} .pTtmp::after, .pJmp::before, .iTtmp::before{content:attr(data-text); display:block;line-height:18px; white-space:nowrap;text-overflow:ellipsis;overflow:hidden} .pJmp{display:inline-flex;align-items:center; opacity:0; transition:var(--trans-2)} .pJmp::before{content:attr(aria-label)} .pJmp svg{height:18px;width:18px;stroke:var(--linkC); flex-shrink:0} .ntry:hover .pJmp, .itm:hover .pJmp{opacity:1} /* Product view */ .pTag .pPad{padding:10px 0} .pTag .pPric{font-size:20px;color:var(--linkC);padding-top:20px} .pTag .pPric::before, .pTag .pInfo small{content:attr(data-text);font-size:small;opacity:.8;display:block;line-height:1.5em;color:var(--bodyC)} .pTag .pInfo{font-size:14px;line-height:1.6em} .pTag .pInfo:not(.o){position:relative;width:calc(100% + 20px);left:-10px;right:-10px;display:flex} .pTag .pInfo:not(.o) >*{width:50%;padding:0 10px} .pTag .pMart{margin:10px 0 12px;display:flex;flex-wrap:wrap;line-height:1.6em; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .pTag .pMart >*{margin:0 4px} .pTag .pMart small{width:calc(100% - 8px);margin-bottom:10px} .pTag .pMart a{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border:1px solid var(--contentL);border-radius:12px;margin-bottom:8px} .pTag .pMart img{width:20px;display:block} /* Blog pager */ .blogPg{display:flex;display:flex;align-items:center;flex-wrap:wrap;justify-content:space-between; font-size:90%;font-family:var(--fontB);line-height:20px; color:#fffdfc; margin:30px 0 50px; max-width:100%} .blogPg >*{display:flex;align-items:center; padding:10px 13px;margin-bottom:10px; color:inherit;background:var(--linkB); border-radius:35px} .blogPg >* svg{width:18px;height:18px; stroke:var(--darkT); stroke-width:1.5} .blogPg >*::before{content:attr(data-text)} .blogPg .jsLd{margin-left:auto;margin-right:auto} .blogPg .nwLnk::before, .blogPg .jsLd::before{display:none} .blogPg .nwLnk::after, .blogPg .jsLd::after{content:attr(data-text); margin:0 8px} .blogPg .olLnk::before{margin:0 8px} .blogPg .nPst, .blogPg .current{background:var(--contentL); color:var(--bodyCa)} .blogPg .nPst.jsLd svg{fill:var(--darkTa);stroke:var(--darkTa)} .blogPg .nPst svg.line{stroke:var(--darkTa)} /* Breadcrumb */ .brdCmb{margin-bottom:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .brdCmb a{color:var(--fontC)} .brdCmb >*:not(:last-child)::after{content:'/'; margin:0 4px;font-size:90%;opacity:.6} .brdCmb >*{display:inline} .brdCmb .tl::before{content:attr(data-text)} .brdCmb .hm a{font-size:90%;opacity:.7}

/* Article Style */ .pS h1, .pS h2, .pS h3, .pS h4, .pS h5, .pS h6{margin:1.5em 0 18px; font-family:var(--fontBa);font-weight:900; line-height:1.5em} .pS h1:target, .pS h2:target, .pS h3:target, .pS h4:target, .pS h5:target, .pS h6:target{padding-top:var(--headerH);margin-top:0} /* Paragraph */ .pS p{margin:1.7em 0} .pIndent{text-indent:2.5rem} .onItm:not(.Rtl) .dropCap{float:left;margin:4px 8px 0 0; font-size:55px;line-height:45px;opacity:.8} .pS hr{margin:3em 0; border:0} .pS hr::before{content:'\2027 \2027 \2027'; display:block;text-align:center; font-size:24px;letter-spacing:0.6em;text-indent:0.6em;opacity:.8;clear:both} .pRef{display:block;font-size:14px;line-height:1.5em; opacity:.7; word-break:break-word} /* Img and Ad */ .pS img{display:inline-block;border-radius:8px;height:auto !important} .pS img.full{display:block !important; margin-bottom:10px; position:relative; width:100%;max-width:none} .pS .widget, .ps .pAd >*{margin:40px 0} /* Note */ .note{position:relative;padding:16px 20px 16px 50px; background:var(--notifU);color:#3c4043; font-size:.85rem;font-family:var(--fontB);line-height:1.6em;border-radius:10px;overflow:hidden} .note::before{content:'';width:60px;height:60px;background:rgba(0,0,0,.15);display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .note::after{content:'\002A';position:absolute;left:18px;top:16px; font-size:20px; min-width:15px;text-align:center} .note.wr{background:#ffdfdf;color:#48525c} .note.wr::before{background:#e65151} .note.wr::after{content:'\0021'} /* Ext link */ .extL::after{content:''; width:14px;height:14px; display:inline-block;margin:0 5px; background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23989b9f' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M13 11L21.2 2.80005'/><path d='M22 6.8V2H17.2'/><path d='M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13'/></svg>") center / 14px no-repeat} /* Scroll img */ .psImg{display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:center; margin:2em 0; position:relative;left:-7px;right:-7px; width:calc(100% + 14px)} .psImg >*{width:calc(50% - 14px); margin:0 7px 14px; position:relative} .psImg img{display:block} .scImg >*{width:calc(33.3% - 14px); margin:0 7px} .btImg label{position:absolute;top:0;left:0;right:0;bottom:0; border-radius:10px; display:flex;align-items:center;justify-content:center; background:rgba(0,0,0,.6); transition:var(--trans-1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px); color:var(--darkT); font-size:13px;font-family:var(--fontB)} .hdImg .shImg{width:100%;margin:0; left:0;right:0; transition:var(--trans-1); max-height:0;opacity:0;visibility:hidden} .inImg:checked ~ .hdImg .shImg{max-height:1000vh;opacity:1;visibility:visible} .inImg:checked ~ .hdImg .btImg label{opacity:0;visibility:hidden} /* Post related */ .pRelate{padding: 16px 20px; background: var(--contentB); box-shadow: 0 5px 35px rgb(0 0 0 / 7%); border: 0; border-radius: 10px; font-size:14px} .pRelate b{font-weight:400; margin:0;opacity:.8} .pRelate ul, .pRelate ol{margin:8px 0 0;padding:0 20px} /* Blockquote */ blockquote, .cmC i[rel=quote]{position:relative;font-size:.97rem; opacity:.8;line-height:1.6em;margin-left:0;margin-right:0;padding:5px 20px;border-left:2px solid var(--contentL)} blockquote.s-1, details.sp{font-size:.93rem; padding:25px 25px 25px 45px; border:1px solid #989b9f;border-left:0;border-right:0;line-height:1.7em} blockquote.s-1::before{content:'\201D';position:absolute;top:10px;left:0; font-size:60px;line-height:normal;opacity:.5}/* Table */ .ps table{margin:0 auto; font-size:14px;font-family:var(--fontB)} .ps table:not(.tr-caption-container){min-width:90%;border:1px solid var(--contentL);border-radius:3px;overflow:hidden} .ps table:not(.tr-caption-container) td{padding:16px} .ps table:not(.tr-caption-container) tr:not(:last-child) td{border-bottom:1px solid var(--contentL)} .ps table:not(.tr-caption-container) tr:nth-child(2n+1) td{background:rgba(0,0,0,.01)} .ps table th{padding:16px; text-align:inherit; border-bottom:1px solid var(--contentL)} .ps .table{display:block; overflow-y:hidden;overflow-x:auto;scroll-behavior:smooth} /* Img caption */ figure{margin-left:0;margin-right:0} .ps .tr-caption, .psCaption, figcaption{display:block; font-size:14px;line-height:1.6em; font-family:var(--fontB);opacity:.7} /* Syntax */ .pre{background:var(--synxBg);color:var(--synxC); direction: ltr} .pre:not(.tb){position:relative;border-radius:10px;overflow:hidden;margin:1.7em auto;font-family:var(--fontC)} .pre pre{margin:0;color:inherit;background:inherit} .pre:not(.tb)::before, .cmC i[rel=pre]::before{content:'</>';display:flex;justify-content:flex-end;position:absolute;right:0;top:0;width:100%;background:inherit;color:var(--synxGray);font-size:10px;padding:0 10px;z-index:2;line-height:30px} .pre:not(.tb).html::before{content:'.html'} .pre:not(.tb).css::before{content:'.css'} .pre:not(.tb).js::before{content:'.js'} pre, .cmC i[rel=pre]{display:block;position:relative;font-family:var(--fontC);font-size:13px;line-height:1.6em;border-radius:3px;background:var(--synxBg);color:var(--synxC);padding:30px 20px 20px;margin:1.7em auto; -moz-tab-size:2;tab-size:2;-webkit-hyphens:none;-moz-hyphens:none;-ms-hyphens:none;hyphens:none; overflow:auto;direction:ltr;white-space:pre} pre i{color:var(--synxBlue);font-style:normal} pre i.block{color:#fff;background:var(--synxBlue)} pre i.green{color:var(--synxGreen)} pre i.gray{color:var(--synxGray)} pre i.red{color:var(--synxOrange)} pre i.blue{color:var(--synxBlue)} code{display:inline;padding:5px;font-size:14px;border-radius:3px;line-height:inherit;color:var(--synxC);background:#f2f3f5;font-family:var(--fontC)} /* Multi syntax */ .pre.tb{border-radius:10px} .pre.tb pre{margin:0;background:inherit} .pre.tb .preH{font-size:13px;border-color:rgba(0,0,0,.05);margin:0} .pre.tb .preH >*{padding:13px 20px} .pre.tb .preH::after{content:'</>';font-size:10px;font-family:var(--fontC);color:var(--synxGray);padding:15px;margin-left:auto} .pre.tb >:not(.preH){display:none} .pS input[id*="1"]:checked ~ div[class*="C-1"], .pS input[id*="2"]:checked ~ div[class*="C-2"], .pS input[id*="3"]:checked ~ div[class*="C-3"], .pS input[id*="4"]:checked ~ div[class*="C-4"]{display:block} /* ToC */ .pS details summary{list-style:none;outline:none} .pS details summary::-webkit-details-marker{display:none} details.sp{background: var(--contentB); box-shadow: 0 5px 35px rgb(0 0 0 / 7%); border: 0; border-radius: 10px;padding:20px 15px} details.sp summary{display:flex;justify-content:space-between;align-items:baseline} details.sp summary::after{content:attr(data-show);font-size:12px; opacity:.7;cursor:pointer} details.sp[open] summary::after{content:attr(data-hide)} details.toc a:hover{text-decoration:underline} details.toc ol, details.toc ul{padding:0 20px; list-style-type:decimal} details.toc li ol, details.toc li ul{margin:5px 0 10px; list-style-type:lower-alpha} /* Accordion */ .showH{background: var(--contentB); box-shadow: 0 5px 35px rgb(0 0 0 / 7%);padding: 16px 20px; border: 0; border-radius: 10px;margin:1.7em 0;font-size:.93rem;font-family:var(--fontB);line-height:1.7em} details.ac{padding:18px 0;border-bottom:1px solid var(--contentL)} details.ac summary{font-weight:700;cursor:default; display:flex;align-items:baseline; transition:var(--trans-1)} details.ac summary::before{content:'\203A'; flex:0 0 25px;display:flex;align-items:center;justify-content:flex-start;padding:0 5px; font-weight:400;font-size:1.33rem;color:inherit} details.ac[open] summary{color:var(--linkC)} details.ac:not(.alt)[open] summary::before{transform:rotate(90deg);padding:0 0 0 5px;justify-content:center} details.ac.alt summary::before{content:'\002B'; padding:0 2px} details.ac.alt[open] summary::before{content:'\2212'} details.ac .aC{padding:0 25px;opacity:.9} /* Tabs */ .tbHd{display:flex; border-bottom:1px solid var(--contentL);margin-bottom:30px;font-size:14px;font-family:var(--fontB);line-height:1.6em; overflow-x:scroll;overflow-y:hidden;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .tbHd >*{padding:12px 15px; border-bottom:1px solid transparent; transition:var(--trans-1);opacity:.6;white-space:nowrap; scroll-snap-align:start} .tbHd >*::before{content:attr(data-text)} .tbCn >*{display:none;width:100%} .tbCn >* p:first-child{margin-top:0} .pS input[id*="1"]:checked ~ .tbHd label[for*="1"], .pS input[id*="2"]:checked ~ .tbHd label[for*="2"], .pS input[id*="3"]:checked ~ .tbHd label[for*="3"], .pS input[id*="4"]:checked ~ .tbHd label[for*="4"]{border-color:var(--linkB);opacity:1} .pS input[id*="1"]:checked ~ .tbCn div[class*="Text-1"], .pS input[id*="2"]:checked ~ .tbCn div[class*="Text-2"], .pS input[id*="3"]:checked ~ .tbCn div[class*="Text-3"], .pS input[id*="4"]:checked ~ .tbCn div[class*="Text-4"]{display:block} .tbHd.stick{position:-webkit-sticky;position:sticky;top:var(--headerH);background:var(--bodyB)} /* Split */ .ps .blogPg{font-size:13px; justify-content:center; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .ps .blogPg >*{padding:8px 15px;margin:0 4px 8px} /* Youtube fullpage */ .videoYt{position:relative;padding-bottom:56.25%; overflow:hidden;border-radius:10px} .videoYt iframe{position:absolute;width:100%;height:100%;left:0;right:0} /* Lazy Youtube */ .lazyYt{background:var(--synxBg);position:relative;overflow:hidden;padding-top:56.25%;border-radius:10px} .lazyYt img{width:100%;top:-16.84%;left:0;opacity:.95} .lazyYt img, .lazyYt iframe, .lazyYt .play{position:absolute} .lazyYt iframe{width:100%;height:100%;bottom:0;right:0} .lazyYt .play{top:50%;left:50%; transform:translate3d(-50%,-50%,0); transition:all .5s ease;display:block;width:70px;height:70px;z-index:1} .lazyYt .play svg{width:inherit;height:inherit; fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;stroke-width:8} .lazyYt .play .c{stroke:rgba(255,255,255,.85);stroke-dasharray:650;stroke-dashoffset:650; transition:all .4s ease-in-out; opacity:.3} .lazyYt .play .t{stroke:rgba(255,255,255,.75);stroke-dasharray:240;stroke-dashoffset:480; transition:all .6s ease-in-out; transform:translateY(0)} .lazyYt .play:hover .t{animation:nudge .6s ease-in-out;-webkit-animation:nudge .6s ease-in-out} .lazyYt .play:hover .t, .lazyYt .play:hover .c{stroke-dashoffset:0; opacity:.7;stroke:#FF0000} .nAmp .lazyYt{display:none} /* Button */ .button{display:inline-flex;align-items:center; margin:10px 0;padding:12px 15px;outline:0;border:0; border-radius:20px;line-height:20px; color:#fffdfc; background:var(--linkB); font-size:14px;font-family:var(--fontB); white-space:nowrap;overflow:hidden;max-width:320px} .button.ln{color:inherit;background:transparent; border:1px solid var(--bodyCa)} .button.ln:hover{border-color:var(--linkB);box-shadow:0 0 0 1px var(--linkB) inset} .btnF{display:flex;justify-content:center; margin:10px 0;width:calc(100% + 12px);left:-6px;right:-6px;position:relative} .btnF >*{margin:0 6px} /* Download btn */ .dlBox{max-width:500px;background: var(--contentB); box-shadow: 0 5px 35px rgb(0 0 0 / 7%); border-radius: 10px;padding:12px;margin:1.7em 0; display:flex;align-items:center; font-size:14px} .dlBox .fT{flex-shrink:0;display:flex;align-items:center;justify-content:center; width:45px;height:45px; padding:10px; background:rgba(0,0,0,.1);border-radius:5px} .dlBox .fT::before{content:attr(data-text);opacity:.7} .dlBox a{flex-shrink:0;margin:0;padding:10px 12px;border-radius:20px;font-size:13px} .dlBox a::after{content:attr(aria-label)} .dlBox .fN{flex-grow:1; width:calc(100% - 200px);padding:0 15px} .dlBox .fN >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .dlBox .fS{line-height:16px;font-size:12px;opacity:.8} /* Icon btn */ .icon{flex-shrink:0;display:inline-flex} .icon::before{content:'';width:18px;height:18px;background-size:18px;background-repeat:no-repeat;background-position:center} .icon::after{content:'';padding:0 6px} .icon.dl::before, .drK .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")} .icon.demo::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><path d='M7.39999 6.32003L15.89 3.49003C19.7 2.22003 21.77 4.30003 20.51 8.11003L17.68 16.6C15.78 22.31 12.66 22.31 10.76 16.6L9.91999 14.08L7.39999 13.24C1.68999 11.34 1.68999 8.23003 7.39999 6.32003Z'/><path d='M10.11 13.6501L13.69 10.0601'/></svg>")} .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2308102b' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")} /* Lightbox image */ .zmImg.s{position:fixed;top:0;left:0;bottom:0;right:0;width:100%;margin:0;background:rgba(0,0,0,.75); display:flex;align-items:center;justify-content:center;z-index:999; -webkit-backdrop-filter:saturate(180%) blur(15px); backdrop-filter:saturate(180%) blur(15px)} .zmImg.s img{display:block;max-width:92%;max-height:92%;width:auto;margin:auto;border-radius:10px;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .zmImg.s img.full{left:auto;right:auto;border-radius:10px;width:auto} .zmImg::after{content:'\2715';line-height:16px;font-size:14px;color:#fffdfc;background:var(--linkB); position:fixed;bottom:-20px;right:-20px; display:flex;align-items:center;justify-content:center;width:45px;height:45px;border-radius:50%; transition:var(--trans-1);opacity:0;visibility:hidden} .zmImg.s::after{bottom:20px;right:20px;opacity:1;visibility:visible;cursor:pointer}

/* Article Style Responsive */ @media screen and (max-width: 640px){.pS img.full{width:calc(100% + 40px);left:-20px;right:-20px; border-radius:0} .note{font-size:13px} .scImg{flex-wrap:nowrap;justify-content:flex-start;position:relative;width:calc(100% + 40px);left:-20px;right:-20px;padding:0 13px; overflow-y:hidden;overflow-x:scroll;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .scImg >*{flex:0 0 80%;scroll-snap-align:center} .ps .table{position:relative; width:calc(100% + 40px);left:-20px;right:-20px;padding:0 20px; display:flex}} @media screen and (max-width:500px){.hdImg{width:100%;left:0;right:0} .hdImg >*, .shImg >*{width:100%;margin:0 0 16px} .ps .tr-caption, .psCaption, figcaption{font-size:13px} .btnF >*{flex-grow:1;justify-content:center}.btnF >*:first-child{flex:0 0 auto} .dlBox a{width:42px;height:42px;justify-content:center} .dlBox a::after, .dlBox .icon::after{display:none}}

/* Author profile */ .admPs{display:flex; max-width:480px;margin:30px 0; padding:12px 12px 15px; background:var(--contentBa);border-radius:8px; box-shadow:0 10px 25px -3px rgba(0,0,0,.1)} .admIm{flex-shrink:0; padding:5px 0 0} .admIm .im{width:34px;height:34px} .admI{flex-grow:1; width:calc(100% - 34px);padding:0 12px} .admN::before{content:attr(data-write) ' '; opacity:.7;font-size:90%} .admN::after{content:attr(data-text)} .admA{margin:5px 0 0; font-size:90%; opacity:.9;line-height:1.5em; /*display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden*/} /* Share btn */ .pSh{margin:15px 0;padding:18px 0;border-bottom:1px solid rgba(0,0,0,.05)} .pShc{display:flex;align-items:center;flex-wrap:wrap; position:relative;width:calc(100% + 18px);left:-9px;right:-9px;font-size:13px} .pShc::before{content:attr(data-text);margin:0 9px;flex-shrink:0} .pShc >*{margin: 0 5px;display: flex;align-items: center;color: inherit;padding: 12px;border-radius: 20px;background: #f1f1f0;} .pShc .c{color:#fffdfc} .pShc .c svg{fill:#fffdfc} .pShc .c::after{content:attr(aria-label)} .pShc .fb{background:#1778F2} .pShc .wa{background:#128C7E} .pShc .tw{background:#1DA1F2} .pShc a::after{content:attr(data-text);margin:0 3px} .pShc svg, .cpL svg{width:18px;height:18px; margin:0 3px} .shL{position:relative;width:calc(100% + 20px);left:-10px;right:-10px;/*margin-bottom:20px;*/display:flex;flex-wrap:wrap;justify-content:center} .shL >*{margin:0 10px 20px;text-align:center} .shL >*::after{content:attr(data-text);font-size:90%;opacity:.7;display:block} .shL a{display:flex;align-items:center;justify-content:center;flex-wrap:wrap; width:65px;height:65px; color:inherit;margin:0 auto 5px;padding:8px;border-radius:26px;background:#f1f1f0} .shL svg{opacity:.8} .cpL{padding-bottom:15px} .cpL::before{content:attr(data-text);display:block;margin:0 0 15px;opacity:.8} .cpL svg{margin:0 4px;opacity:.7} .cpL input{border:0;outline:0; background:transparent;color:rgba(8,16,43,.4); padding:18px 8px;flex-grow:1} .cpL label{display:flex;align-items:center;flex-shrink:0;padding:2px 8px;border-radius:15px}.cpLb{display:flex;align-items:center;position:relative;background:#f1f1f0;border-radius:10px; padding:0 8px} .cpLb:hover{border-color:rgba(0,0,0,.42);background:#ececec} .cpLn span{display:block;padding:5px 14px 0;font-size:90%;color:#2e7b32; transition:var(--trans-1);animation:fadein 2s ease forwards; opacity:0;height:22px} /* Comments */ .pCmnts{margin-top:50px} .cmDis{text-align:center;margin-top:20px;opacity:.7} .cmMs{margin-bottom:20px} .cm iframe{width:100%} .cm:not(.cmBr) .cmBrs{background:transparent;position:relative;padding:60px 20px 0;width:calc(100% + 40px);left:-20px;right:-20px} .cmH h3.title{margin:0;flex-grow:1;padding:16px 10px} .cmH .s{margin:0 14px} .cmH .s::before{content:attr(data-text);margin:0 6px;opacity:.7;font-size:90%} .cmH .s::after{content:'\296E';line-height:18px;font-size:17px} .cmAv .im{width:35px;height:35px;border-radius:50%;position:relative} .cmBd.del .cmCo{font-style:italic;font-size:90%;line-height:normal;border:1px dashed rgba(0,0,0,.2);border-radius:3px;margin:.5em 0;padding:15px;opacity:.7; overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .cmHr{line-height:24px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .cmHr .d{font-size:90%;opacity:.7} .cmHr .d::before{content:'\00B7';margin:0 7px} .cmHr.a .n{display:inline-flex;align-items:center} .cmHr.a .n::after{content:'\2714';display:flex;align-items:center;justify-content:center;width:14px;height:14px;font-size:8px;background:#519bd6;color:#fefefe;border-radius:50%;margin:0 3px} .cmCo{line-height:1.6em;opacity:.9} .cmC i[rel=image]{font-size:90%; display:block;position:relative; min-height:50px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap; margin:1em auto} .cmC i[rel=image]::before{content:'This feature isn\0027t available!';border:1px dashed rgba(0,0,0,.2);border-radius:3px;padding:10px;display:flex;align-items:center;justify-content:center;position:absolute;top:0;left:0;bottom:0;right:0;background:var(--contentB)} .cmC i[rel=pre], .cmC i[rel=quote]{margin-top:1em;margin-bottom:1em; font-style:normal;line-height:inherit;padding:20px} .cmC i[rel=pre]::before{display:block;width:auto} .cmC i[rel=quote]{display:block;font-style:italic;font-size:inherit;padding:5px 15px} .cmCo img{margin-top:1em;margin-bottom:1em} .cmAc{margin-top:10px} .cmAc a{font-size:90%;color:inherit;opacity:.7;display:inline-flex} .cmAc a::before{content:'\2934';line-height:18px;font-size:16px;transform:rotate(90deg)} .cmAc a::after{content:attr(data-text);margin:0 6px} .cmR{margin:10px 40px 0} .cmRp ~ .cmAc, .cmBd.del ~ .cmAc, .onItm:not(.Rtl) .cmHr .date{display:none} .cmRi:checked ~ .cmRp .thTg{margin-bottom:0} .cmRi:checked ~ .cmRp .thTg::after{content:attr(aria-label)} .cmRi:checked ~ .cmRp .thCh, .cmRi:checked ~ .cmRp .cmR{display:none} .cmAl:checked ~ .cm .cmH .s::before{content:attr(data-new)} .cmAl:checked ~ .cm .cmCn >ol{flex-direction:column-reverse} .thTg{display:inline-flex;align-items:center;margin:15px 0 18px;font-size:90%} .thTg::before{content:'';width:28px;border-bottom:1px solid var(--widgetTac);opacity:.5} .thTg::after{content:attr(data-text);margin:0 12px;opacity:.7} .cmCn ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column} .cmCn li{margin-bottom:18px;position:relative} .cmCn li .cmRbox{margin-top:20px} .cmCn li li{display:flex;flex-wrap:wrap;width:calc(100% + 12px);left:-6px;right:-6px} .cmCn li li:last-child{margin-bottom:0} .cmCn li li .cmAv{flex:0 0 28px;margin:0 6px} .cmCn li li .cmAv .im{width:28px;height:28px} .cmCn li li .cmIn{width:calc(100% - 52px);margin:0 6px} .cmHl >li{padding-left:17.5px} .cmHl >li >.cmAv{position:absolute;left:0;top:12px} .cmHl >li >.cmIn{padding:12px 15px 12px 28px;box-shadow:0 5px 35px rgb(0 0 0 / 7%);border-radius:12px} /* Comments Show/Hide */ #comment:target{margin:0;padding-top:60px} .cmSh:checked ~ .cmShw, .cmShw ~ .cm:not(.cmBr), #comment:target .cmShw, #comment:target .cmSh:checked ~ .cm:not(.cmBr){display:none} .cmSh:checked ~ .cm:not(.cmBr), #comment:target .cm:not(.cmBr), #comment:target .cmSh:checked ~ .cmShw{display:block} .cmBtn{display:block;padding:20px;text-align:center;max-width:100%} .cmBtn.ln:hover{color:var(--linkB)} /* Comments Pop-up */ #comment:target .cmSh:checked ~ .cm.cmBr{bottom:-100%;opacity:0;visibility:hidden} #comment:target .cmSh:checked ~ .cm.cmBr .fCls{opacity:0;visibility:hidden}

/* Widget Style */ .widget .imgThm{display:block;position:absolute;top:50%;left:50%;max-width:none;max-height:108%; font-size:12px;text-align:center; transform:translate(-50%, -50%)} .widget .title{margin:0 0 25px; font-size:var(--widgetT);font-weight:var(--widgetTw);position:relative;margin-top:20px} .widget .title::after{content:'';display:inline-block;vertical-align:middle; width:var(--widgetTa); margin:0 10px;border-bottom:1px solid var(--widgetTac); opacity:.5} .widget input[type=text]:focus, .widget input[type=email]:focus, .widget textarea:focus, .widget input[data-text=fl], .widget textarea[data-text=fl]{border-color:var(--linkB);background:#ececec} .widget input[type=button], .widget input[type=submit]{display:inline-flex;align-items:center; padding:12px 30px; outline:0;border:0;border-radius:4px; color:#fffdfc; background:var(--linkB); font-size:14px; white-space:nowrap;overflow:hidden;max-width:100%} .widget input[type=button]:hover, .widget input[type=submit]:hover{opacity:.7} /* Widget BlogSearch */ .BlogSearch{position:fixed;top:0;left:0;right:0;z-index:12} .BlogSearch form{position:relative;min-width:320px} .BlogSearch input{position:relative;display:block;background:var(--srchB);border:0;outline:0;margin-top:-100%;padding:10px 55px;width:100%;height:72px;transition:var(--trans-1);z-index:2;border-radius:0 0 12px 12px} .BlogSearch input:focus{margin-top:0;box-shadow:0 10px 40px rgba(0,0,0,.2)} .BlogSearch input:focus ~ button.sb{opacity:.9} .BlogSearch .sb{position:absolute;left:0;top:0;display:flex;align-items:center;padding:0 20px;z-index:3;opacity:.7;height:100%;background:transparent;border:0;outline:0} .BlogSearch .sb svg{width:18px;height:18px;stroke:var(--srchI)} .BlogSearch button.sb{left:auto;right:0;opacity:0;font-size:13px} .BlogSearch button.sb::before{content:'\2715'} @media screen and (min-width:897px){header .BlogSearch{position:static;z-index:1} header .BlogSearch input{margin-top:0;padding:12px 42px;height:auto;font-size:13px;border-radius:20px;background:var(--transB); width:calc(100% + 26px);left:-13px;right:-13px;transition:var(--trans-2)} header .BlogSearch input:hover{background:var(--transB)} header .BlogSearch input:focus{box-shadow:none;margin-top:0; background:var(--transB)} header .BlogSearch .sb{padding:0} header .BlogSearch .fCls{display:none}} /* Widget Profile */ .prfI:checked ~ .mainWrp .wPrf{top:0;opacity:1;visibility:visible} .prfI:checked ~ .mainWrp .wPrf ~ .fCls{z-index:3;opacity:1;visibility:visible} .wPrf{display:flex;position:absolute;top:-5px;right:0;background:var(--contentB);border-radius:16px 5px 16px 16px;width:260px;max-height:400px;box-shadow:0 10px 25px -3px rgba(0,0,0,.1);transition:var(--trans-1);z-index:4;opacity:0;visibility:hidden;overflow:hidden} .wPrf .prfS{background:inherit} .wPrf.tm .im{width:39px;height:39px;flex-shrink:0} .wPrf.sl .im{width:60px;height:60px;border-radius:26px;margin:0 auto} .wPrf.sl .prfC{text-align:center} .prfH .c{display:none} .prfL{display:flex;align-items:center;position:relative;width:calc(100% + 16px);left:-8px;right:-8px;border-radius:8px;padding:8px 0;transition:var(--trans-1)} .prfL::after{content:attr(data-text);margin:0 2px} .prfL >*{margin:0 8px;flex-shrink:0} a.prfL:hover{background:var(--transB)} .sInf{margin-bottom:0} .sInf .sDt .l{display:inline-flex;align-items:center} .sInf .sTxt{margin:5px auto 0;max-width:320px;font-size:93%;opacity:.9;line-height:1.5em} .sInf .sTxt a{text-decoration:underline} .sInf .lc{display:flex;justify-content:center;margin:10px 0 0;opacity:.8;font-size:90%} .sInf .lc svg{width:16px;height:16px} .sInf .lc::after{content:attr(data-text);margin:0 4px} /* Widget FeaturedPost */ @media screen and (min-width:501px){.FeaturedPost .itemFt{position:relative;overflow:hidden;padding:10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .drK .FeaturedPost .itemFt{background:var(--darkBa)} .FeaturedPost .itemFt::after{content:'';position: absolute;right:0;top:0;width:40px;height:15px;}} .itemFt .itm >*{flex:0 0 310px;width:310px} .itemFt .itm >*:last-child{flex:1 0 calc(100% - 310px - 40px);width:calc(100% - 310px - 40px)} /* Widget ToC */ .tocL{position:fixed;top:0;bottom:5%;right:-280px;width:280px;transition:var(--trans-1);z-index:5} .tocLi{width:100%;height:100%;position:relative;background:var(--contentB);box-shadow:0 5px 30px 0 rgba(0,0,0,.05);z-index:2;border-radius:20px 0 0 20px} .tocLs{position:relative;top:20px;background:inherit} .tocIn{padding:60px 0 0;overflow-y:scroll;overflow-x:hidden;width:100%;height:calc(100vh - var(--headerH))} .tocC{position:absolute;left:-45px;top:105px;transition:var(--trans-1)} .tocC span{display:flex;align-items:center;justify-content:center;width:45px;height:40px;border-radius:20px 0 0 20px;background:var(--contentB);transition:inherit;z-index:1;box-shadow:0 5px 20px 0 rgba(0,0,0,.1)} .tocL svg.rad{width:20px;height:20px;position:absolute;right:-2px;top:-19px;fill:var(--contentB);transform:rotate(92deg);transition:inherit} .tocL svg.rad.in{top:auto;bottom:-19px;transform:rotate(-2deg)} .tocC span svg{opacity:.8;animation:wiggle 3s infinite} .tocT{display:flex;width:100%} .tocL ol{margin:0;padding-inline-start:35px;line-height:1.6em} .tocL li ol{margin:5px 0 10px;list-style:lower-roman} .tocL a{color:inherit;opacity:.8} .tocL a:hover{text-decoration:underline} .tocI:checked ~ .tocL{right:0;z-index:10} .tocI:checked ~ .tocL .tocC{opacity:0;visibility:hidden} .tocI:checked ~ .tocL .fCls{background:rgba(0,0,0,.25);opacity:1;visibility:visible}  /* Widget PopularPosts */.PopularPosts{padding:17px 20px 30px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .itemPp{counter-reset:p-cnt} .itemPp .iCtnt{display:flex} .itemPp >*:not(:last-child){margin-bottom:25px} .itemPp .iCtnt::before{flex-shrink:0;content:'0' counter(p-cnt);counter-increment:p-cnt;width:25px;opacity:.6;font-size:85%;line-height:1.8em} .iInr{flex:1 0;width:calc(100% - 25px)} .iTtl{font-size:.95rem;font-weight:700;line-height:1.5em} .iTtmp{display:none} .iTtmp::after{content:'\2014';margin:0 5px; color:var(--widgetTac);opacity:.7} .iInf{margin:0 25px 8px; overflow:hidden;white-space:nowrap;text-overflow:ellipsis} .iInf .pLbls >*{color:#fefefe;display:inline;margin-right:5px;border-radius: 20px;background:#06D7A0;height:24px;padding:0 10px}.iInf .pLbls >*:hover{text-decoration:none;color:#0b57cf;background:rgba(0,0,0,.05);font-weight:normal}.iInf .pLbls a:nth-child(1){background:var(--linkB)}.iInf .pLbls a:nth-child(2){background:var(--darkU)}.iInf .pLbls a:nth-child(3){background:var(--linkC)}
/* Widget Label */ /* List Label */ .Label{padding:20px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .wL ul{display:flex;flex-wrap:wrap; list-style:none;margin:0;padding:0; position:relative;width:calc(100% + 30px);left:-15px;right:-15px; font-size:13px} .wL li{width:calc(50% - 10px); margin:0 5px} .wL li >*{display:flex;align-items:baseline;justify-content:space-between; color:var(--bodyC);width:100%; padding:8px 10px;border-radius:35px;line-height:20px} .wL li >* svg{width:18px;height:18px;opacity:.8} .wL li >*:hover svg, .wL li >div svg{/*fill:var(--linkC) !important;*/stroke:var(--linkC)} .wL li >*:hover .lbC, .wL li >div .lbC{color:var(--linkC)} .wL .lbR{display:inline-flex;align-items:center} .wL .lbR .lbC{margin:0 5px} .wL .lbAl{max-height:0; overflow:hidden; transition:var(--trans-4)} .wL .lbM{display:inline-block; margin-top:10px;line-height:20px; color:var(--linkC)} .wL .lbM::before{content:attr(data-show)} .wL .lbM::after, .wL .lbC::after{content:attr(data-text)} .wL .lbM::after{margin:0 8px} .wL .lbT{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.7} .wL .lbC, .wL .lbM::after{flex-shrink:0;font-size:12px;opacity:.7} .lbIn:checked ~ .lbAl{max-height:1000vh} .lbIn:checked ~ .lbM::before{content:attr(data-hide)} .lbIn:checked ~ .lbM::after{visibility:hidden} .wL.bg ul{width:calc(100% + 10px);left:-5px;right:-5px} .wL.bg li{margin-bottom:10px} .wL.bg li >*{background:#f6f6f6} /* Cloud Label */ .wL.cl{display:flex;flex-wrap:wrap} .wL.cl >*, .wL.cl .lbAl >*{display:block;max-width:100%} .wL.cl .lbAl{display:flex;flex-wrap:wrap} .wL.cl .lbC::before{content:'';margin:0 4px;flex:0 0} .wL.cl .lbN{display:flex;justify-content:space-between; margin:0 0 8px;padding:9px 13px; border:1px solid var(--contentL);border-radius:20px; color:inherit;line-height:20px} .wL.cl .lbN:hover .lbC, .wL.cl div.lbN .lbC{color:var(--linkB); opacity:1} .wL.cl .lbN:not(div):hover, .wL.cl div.lbN{border-color:var(--linkB)} .wL.cl .lbSz{display:flex} .wL.cl .lbSz::after{content:'';margin:0 4px;flex:0 0}/* Widget ContactForm */ .ContactForm{max-width:500px; font-family:var(--fontB);font-size:14px} .cArea:not(:last-child){margin-bottom:25px} .cArea label{display:block;position:relative} .cArea label .n{display:block;position:absolute;left:0;right:0;top:0; color:rgba(8,16,43,.4);line-height:1.6em;padding:15px 16px 0;border-radius:4px 4px 0 0;transition:var(--trans-1)} .cArea label .n.req::after{content:'*';font-size:85%} .cArea textarea{height:100px} .cArea textarea:focus, .cArea textarea[data-text=fl]{height:200px} .cArea input:focus ~ .n, .cArea textarea:focus ~ .n, .cArea input[data-text=fl] ~ .n, .cArea textarea[data-text=fl] ~ .n{padding-top:5px;color:rgba(8,16,43,.7);font-size:90%;background:#ececec} .cArea .h{display:block;font-size:90%;padding:5px 16px 0;opacity:.7;line-height:normal} .nArea .contact-form-error-message-with-border{color:#d32f2f} .nArea .contact-form-success-message-with-border{color:#2e7b32} /* Widget Sliders */ .sldO{position:relative;display:flex;overflow-y:hidden;overflow-x:scroll; scroll-behavior:smooth;scroll-snap-type:x mandatory;list-style:none;margin:0;padding:0; -ms-overflow-style: none} .sldO.no-items{display:none} .sldO.no-items + .section{margin-top:0} .sldO .widget:not(:first-child){margin-top:0} .sldO .widget{position:relative;flex:0 0 100%;width:100%;background:transparent; outline:0;border:0} .sldC{position:relative} .sldS{position:absolute;top:0;left:0;width:100%;height:100%;scroll-snap-align:center;z-index:-1} .sldIm{background-repeat:no-repeat;background-size:cover;background-position:center;background-color:var(--transB);display:block;padding-top:40%;border-radius:3px;color:#fffdfc;font-size:13px} .sldT{position:absolute;bottom:0;left:0;right:0;display:block;padding:20px; background:linear-gradient(0deg, rgba(30,30,30,.1) 0%, rgba(30,30,30,.05) 60%, rgba(30,30,30,0) 100%); border-radius:0 0 3px 3px} .sldS{animation-name:tonext, snap;animation-timing-function:ease;animation-duration:4s;animation-iteration-count:infinite} .sldO .widget:last-child .sldS{animation-name:tostart, snap} .Rtl .sldS{animation-name:tonext-rev, snap} .Rtl .sldO .widget:last-child .sldS{animation-name:tostart-rev, snap} .sldO:hover .widget .sldS, .Rtl .sldO:hover .widget .sldS, .sldO:focus-within .widget .sldS, .Rtl .sldO:focus-within .widget .sldS{animation-name:none} @media (prefers-reduced-motion:reduce){.sldS, .Rtl .sldS{animation-name:none}} @media screen and (max-width:640px){.sldO{width:calc(100% + 40px);left:-20px;right:-20px;padding:0 12.5px 10px} .sldO .widget{flex:0 0 90%;width:90%;margin:0 7.5px; box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%)} .sldT{padding:10px 15px} .sldIm{font-size:12px}}

/* Sticky Ad */ .ancrA{position:fixed;bottom:0;left:0;right:0;min-height:70px;max-height:200px;padding:5px;box-shadow:0 -6px 18px 0 rgba(9,32,76,.1); transition:var(--trans-1);display:flex;align-items:center;justify-content:center;background:#fffdfc;z-index:50;border-top:1px solid var(--contentL)} .ancrC{width:40px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:12px 0 0;border:1px solid var(--contentL);border-bottom:0;border-right:0;position:absolute;right:0;top:-30px;background:inherit} .ancrC::after{content:'\2715';line-height:18px;font-size:14px} .ancrCn{flex-grow:1;overflow:hidden;display:block;position:relative} .ancrI:checked ~ .ancrA{padding:0;min-height:0} .ancrI:checked ~ .ancrA .ancrCn{display:none} /* Error Page */ .erroP{display:flex;align-items:center;justify-content:center;height:100vh;text-align:center;padding:0;background-image:url('https://j.gifs.com/5y8xPR.gif');} .erroC{width:calc(100% - 40px);max-width:450px;margin:auto;font-family:var(--fontBa)} .erroC h3{font-size:1.414rem;font-family:inherit} .erroC h3 span{display:block;font-size:140px;line-height:.8;color:#ebebf0} .erroC p{margin:30px 5%;line-height:1.6em;opacity:.7} .erroC .button{margin:0;padding-left:2em;padding-right:2em;font-size:14px}

/* Responsive */
@media screen and (min-width:897px){/* mainIn */ .mainIn, .blogM{display:flex} .blogMn{width:var(--navW);flex-shrink:0;position:relative;transition:var(--trans-1);z-index:1} .blogCont{padding-top:30px} .blogCont::before{content:'';position:absolute;top:var(--headerHi);left:0;height:calc(100% + var(--headerH));border-right:var(--navL) solid var(--contentL)} .blogCont{width:calc(100% - var(--navW))} .blogCont .secIn{padding-left:25px;padding-right:25px} .mainbar{flex:1 0 calc(100% - var(--sideW) - 25px);width:calc(100% - var(--sideW) - 25px)} .sidebar{display:flex;flex:0 0 calc(var(--sideW) + 25px);width:calc(var(--sideW) + 25px); margin:0} .sidebar::before{content:'';flex:0 0 25px} .sidebar .sideIn{width:calc(100% - 25px)} /* mainNav */ .mnBr{position:sticky;position:-webkit-sticky;top:var(--headerH)} .mnBrs{display:flex;height:calc(100vh - var(--headerH));font-size:13px;position:relative; border-radius:10px} .mnBrs >*:not(.mnMob){width:100%} .mnMen{padding:20px;overflow-y:hidden;overflow-x:hidden} .mnMen:hover{overflow-y:scroll} .mnMob{position:fixed;width:var(--navW)} .mnH, .mobMn{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .blogMn, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob, .hdMn .navI:not(:checked) ~ .mainWrp .blogMn, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob{width:75px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn a:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn a:hover{opacity:1;color:inherit} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .a, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .a{max-width:40px; border-radius:15px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .drp.mr, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn svg.d, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .PageList, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mSoc, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .drp.mr, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn svg.d, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .PageList, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mSoc{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mNav, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mNav{display:flex} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn >li.br::after, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn >li.br::after{max-width:20px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen:hover{overflow-y:visible;overflow-x:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{position:absolute;left:35px;top:3px;margin:0 5px;padding:8px 10px;border-radius:5px 16px 16px 16px;max-width:160px;background:var(--contentB);color:var(--bodyC);opacity:0;visibility:hidden;box-shadow:0 5px 20px 0 rgba(0,0,0,.1);z-index:1} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{padding:0 5px;margin:0;overflow:hidden;display:block} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):last-child ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):last-child ul{top:auto;bottom:3px;border-radius:16px 16px 16px 5px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):hover ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):hover ul{opacity:1;visibility:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn ul li >*, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn ul li >*{border-radius:0} /* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} .onIndx.onMlt .blogPts >*{flex:0 0 calc(25% - 20px);width:calc(25% - 20px)} /* Widget ToC */ .tocL{position:absolute;z-index:2} .tocLi::before{content:'';border-left:1px solid var(--contentL);position:absolute;top:0;bottom:0;left:0;z-index:1} .tocLs{position:-webkit-sticky;position:sticky;top:var(--headerH)} .tocC{top:40px} .tocI:checked ~ .tocL{z-index:2} .tocI:checked ~ .tocL .fCls{background:transparent}}
@media screen and (min-width:768px){::-webkit-scrollbar{-webkit-appearance:none;width:8px;height:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--scrlC);border-radius:10px}::-webkit-scrollbar-thumb:hover{background:var(--scrlC)}::-webkit-scrollbar-thumb:active{background:var(--scrlC)}}
@media screen and (max-width:1100px){/* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} .onIndx.onMlt .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} /* Widget */ .itemFt .itm >*, .itemFt .itm >*:last-child{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} .itemFt .itm >*:last-child{flex-grow:1} .itemFt .pSnpt{display:none}}
@media screen and (max-width:896px){/* Header */ .ntfC{padding-left:20px;padding-right:20px} .headI .headS{margin:0} /* mainNav */ .blogMn{display:flex;justify-content:flex-start;position:fixed;left:0;top:0;bottom:0;margin-left:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%} .mnBr{width:80%;top:2%;left:10%;bottom:2%;max-width:480px;height:96%;border-radius:10px 10px 10px 10px;transition:var(--trans2);z-index:3;overflow:hidden;position:relative;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .mnBrs{padding:60px 0 0;overflow-y:scroll;overflow-x:hidden;width:100%;height:100%} .mnH{padding:0 15px} .mnH label{padding:15px 10px} .mnH .c::after{margin:0 13px} .mnMen{padding-top:0} .navI:checked ~ .mainWrp .blogMn{margin-left:0} .navI:checked ~ .mainWrp .blogMn .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} /* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} /* Widget */ .itemFt .pSnpt{display:-webkit-box} .mobMn:not(.no-items) + footer{padding-bottom:calc(20px + 20px)}}
@media screen and (max-width:768px){/* Article */ .onIndx.onHm .blogPts >*, .onIndx.onMlt .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)}}
@media screen and (max-width:640px){/* Header */ .headCn{height:var(--headerHm)} /* Pop-up */ .fixL{align-items:flex-end} .fixL .fixLi, .fixL .cmBri{border-radius:12px 12px 0 0; max-width:680px} .fixL .cmBri:not(.mty){border-radius:0;height:100%;max-height:100%}}
@media screen and (max-width:500px){/* Font and Blog */ .iFxd, .crdtIn{font-size:12px} .brdCmb{font-size:13px} .pDesc{font-size:14px} .pEnt{font-size:var(--postFm)} .pTtl.itm{font-size:var(--postTm)} .pInf.ps .pTtmp::after{content:attr(data-time)} .pInf.ps .pDr{font-size:12px} /* Article */ .onIndx:not(.oneGrd) .blogPts{width:calc(100% + 15px);left:-7.5px;right:-7.5px} .onIndx:not(.oneGrd) .blogPts >*{flex:0 0 calc(50% - 15px);width:calc(50% - 15px);margin-left:7.5px;margin-right:7.5px} .onIndx:not(.oneGrd) .blogPts div.ntry{flex:0 0 calc(100% - 15px)} .onIndx:not(.oneGrd) .ntry .pSml{font-size:12px} .onIndx:not(.oneGrd) .ntry .pTtl{font-size:.9rem} .onIndx:not(.oneGrd) .ntry:not(.pTag) .pSnpt, .onIndx:not(.oneGrd) .ntry .pInf:not(.nSpr) .pJmp, .onIndx:not(.oneGrd) .ntry .iFxd .spnr{display:none} .onIndx:not(.oneGrd) .ntry .iFxd{padding:8px 3px} .onIndx:not(.oneGrd) .ntry .iFxd .cmnt{padding:3px} .onIndx:not(.oneGrd) .ntry .iFxd >* svg{padding:1px} .onIndx.oneGrd .blogPts >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)} /* Share */ .pShc{width:calc(100% + 10px);left:-5px;right:-5px} .pShc::before{width:calc(100% - 10px);margin:0 5px 12px} .pShc .wa::after, .pShc .tw::after{display:none} /* Widget */ .prfI:checked ~ .mainWrp .wPrf{top:auto;bottom:0} .prfI:checked ~ .mainWrp .Profile .fCls{background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .prfH .c{display:flex} .wPrf{position:fixed;top:auto;left:0;right:0;bottom:-100%;width:100%;max-height:calc(100% - var(--headerH));border-radius:12px 12px 0 0} .itemFt .itm{padding-bottom:80px} .itemFt .itm >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)} .itemFt .itm .iCtnt{flex:0 0 calc(100% - 42px);width:calc(100% - 42px);margin:0 auto;position:absolute;left:0;right:0;bottom:0;padding:13px;background:rgba(255,253,252,.92);border-radius:10px;box-shadow:0 10px 20px -5px rgba(0,0,0,.1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .itemFt .pTtl{font-size:1rem} .itemFt .pSnpt{font-size:93%}
}

/* Keyframes Animation */ @keyframes shimmer{100%{transform:translateX(100%)}} @keyframes fadein{50%{opacity:1}80%{opacity:1;padding-top:5px;height:22px}100%{opacity:0;padding-top:0;height:0}} @keyframes nudge{0%{transform:translateX(0)}30%{transform:translateX(-5px)}50%{transform:translateX(5px)}70%{transform:translateX(-2px)}100%{transform:translateX(0)}} @keyframes tonext{ 75%{left:0} 95%{left:100%} 98%{left:100%} 99%{left:0}} @keyframes tostart{ 75%{left:0} 95%{left:-300%} 98%{left:-300%} 99%{left:0}} @keyframes tonext-rev{ 75%{right:0} 95%{right:100%} 98%{right:100%} 99%{right:0}} @keyframes tostart-rev{ 75%{right:0} 95%{right:-300%} 98%{right:-300%} 99%{right:0}} @keyframes snap{ 96%{scroll-snap-align:center} 97%{scroll-snap-align:none} 99%{scroll-snap-align:none} 100%{scroll-snap-align:center}} @-webkit-keyframes fadein{50%{opacity:1}80%{opacity:1;padding-top:5px;height:22px}100%{opacity:0;padding-top:0;height:0}} @-webkit-keyframes nudge{0%{transform:translateX(0)}30%{transform:translateX(-5px)}50%{transform:translateX(5px)}70%{transform:translateX(-2px)}100%{transform:translateX(0)}} @-webkit-keyframes tonext{ 75%{left:0} 95%{left:100%} 98%{left:100%} 99%{left:0}} @-webkit-keyframes tostart{ 75%{left:0} 95%{left:-300%} 98%{left:-300%} 99%{left:0}} @-webkit-keyframes tonext-rev{ 75%{right:0} 95%{right:100%} 98%{right:100%} 99%{right:0}} @-webkit-keyframes tostart-rev{ 75%{right:0} 95%{right:-300%} 98%{right:-300%} 99%{right:0}} @-webkit-keyframes snap{ 96%{scroll-snap-align:center} 97%{scroll-snap-align:none} 99%{scroll-snap-align:none} 100%{scroll-snap-align:center}}

/* Noscript Option */ .lazy:not([lazied]){display:none} .noJs{display:flex;justify-content:flex-end;align-items:center;position:fixed;top:20px;left:20px;right:20px;z-index:99;max-width:640px;border-radius:12px;margin:auto;padding:10px 5px;background:#ffdfdf;font-size:13px;box-shadow:0 10px 20px -10px rgba(0,0,0,.1);color:#48525c} .noJs::before{content:attr(data-text);padding:0 10px;flex-grow:1} .noJs label{flex-shrink:0;padding:10px} .noJs label::after{content:'\2715';line-height:18px;font-size:14px} .nJs:checked ~ .noJs{display:none}

/* Hide Scroll */ .scrlH::-webkit-scrollbar{width:0;height:0} .scrlH::-webkit-scrollbar-track{background:transparent} .scrlH::-webkit-scrollbar-thumb{background:transparent;border:none}

/* --- Remove to reduce CSS size or if you aren't using RTL --- */

.adB{position:relative;display:flex;align-items:center;justify-content:center;min-height:100px;padding:15px;border-radius:15px;color:#969896;font-size:10px;font-family:var(--fontB);background: var(--contentB);box-shadow: 0 5px 35px rgb(0 0 0 / 7%);border: 0} .adB:before{content:'Sample Ad' !important}  .drK .adB{border-color:rgba(255,255,255,.1)} .drK .adB:after{background-color:rgba(255,255,255,.1)} .drK .adB{background:var(--darkBa)}

/* RTL Mode */ .Rtl #dateNow {text-align: left}.Rtl #dateNow{margin-left:0;margin-right:5px}.Rtl .pLbL {text-align: right;} .Rtl .pLbL > a{margin-right:0;margin-left:5px}.Rtl .ntfT{padding:0 0 0 15px} .Rtl .headL{padding:0 20px 0 0} .Rtl .headL .headN{padding:0 5px 0 0} .Rtl .BlogSearch .sb{left:auto;right:0} .Rtl .BlogSearch button.sb{left:0;right:auto} .Rtl .wPrf{right:auto;left:0;border-radius:5px 16px 16px 16px} .Rtl .toTopF{right:auto;left:18px} .Rtl .cmAc a::before{content:'\2935'} .Rtl .cmHl >li{padding:0 17.5px 0 0} .Rtl .cmHl >li >.cmAv{left:auto;right:0} .Rtl .cmHl >li >.cmIn{padding:12px 28px 12px 15px} .Rtl .mnMn li:not(.mr) ul{padding-left:0;padding-right:30px} .Rtl .tocL{right:auto;left:-280px} .Rtl .tocLi{border-radius:0 12px 12px 0} .Rtl .tocLi::before{left:auto;right:0} .Rtl .tocC{left:auto;right:-45px} .Rtl .tocC span{border-radius:0 20px 20px 0} .Rtl .tocL svg.rad{right:auto;left:-2px;transform:rotate(176deg)} .Rtl .tocL svg.rad.in{transform:rotate(-86deg)} .Rtl .tocI:checked ~ .tocL{right:auto;left:0} @media screen and (min-width:897px){.Rtl .blogCont::before{left:auto;right:0} .Rtl:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .Rtl:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .Rtl.hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .Rtl.hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{left:auto;right:35px;border-radius:16px 5px 16px 16px} .Rtl:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):last-child ul, .Rtl.hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):last-child ul{border-radius:16px 16px 5px 16px}} @media screen and (max-width:896px){.Rtl .headR{padding:0 0 0 20px} .Rtl .headL{padding:0 15px 0 0} .Rtl .blogMn{left:auto;right:0;margin-right:-100%} .Rtl .mnBr{right:2%;border-radius:20px 20px 20px 20px} .Rtl .navI:checked ~ .mainWrp .blogMn{margin-left:auto;margin-right:0}} @media screen and (max-width:500px){.Rtl .wPrf{right:0;border-radius:12px 12px 0 0}}
/* Basic Layout */ @media screen and (min-width:897px){.LS-2 header, .LS-2 .tocLi::before, .LS-3 header{border:0} .LS-2, .LS-2 .headCn, .LS-2 .mnBrs, .LS-3 .mnBrs, .LS-3 .headL{background:#fafafc} .LS-2 .blogCont::before{border:0;top:0;right:0;bottom:0;height:100%;z-index:-1;background:var(--contentB);border-radius:15px 0 0 0} .LS-3 .headCn{background:transparent} .LS-3 .headR{background:var(--headerB)} .LS-3 .blogCont::before{z-index:10} .LS-3 .blogMn{z-index:11} .LS-3 .tocL{top:var(--headerHi);z-index:10} .LS-3 .tocI:checked ~ .tocL{z-index:10} .LS-3:not(.hdMn) .navI:checked ~ .mainWrp .headN, .LS-3.hdMn .navI:not(:checked) ~ .mainWrp .headN{display:none} .LS-3:not(.hdMn) .navI:checked ~ .mainWrp .headL, .LS-3 .navI:not(:checked) ~ .mainWrp .headL{width:75px}}



/* Pay box and Changelog */.changeLog{position:fixed;bottom:0;left:0;right:0;margin:0;padding:40px 0;width:100%;height:100%;background-color:#fefefe;font-family:'Noto Sans', sans-serif;font-size:15px;z-index:22;-webkit-transition:all .1s ease;transition:all .1s ease;overflow-y:auto;opacity:0;visibility:hidden}.changeLog .logClose{display:flex;align-items:center;height:22px;position:absolute;top:20px;right:25px}.changeLog .logClose:before{content:'Close';font-size:11px;padding-right:8px;font-family:'Noto Sans', sans-serif}.changeLog .logContent{width:100%;max-width:820px;padding:0 20px;margin-left:auto;margin-right:auto;font-family:'Noto Sans', sans-serif}.changeLog .logContent h2{margin-top:10px;font-family:'Noto Sans', sans-serif}.changeLog .logContent ol,.changeLog .logContent ul{padding-left:30px}.logInput:checked ~ .changeLog{opacity:1;visibility:visible}.I{color:inherit;text-decoration:underline;font-family:var(--fontBa);line-height:20px}-webkit-backdrop-filter:blur(5px);backdrop-filter:blur(5px);display:flex;align-items:center;justify-content:center;padding:0;overflow:hidden}.purchaseContent{width:calc(100% - 40px);max-width:780px;max-height:calc(100% - 40px);overflow-y:auto;position:relative;background-color:#fefefe;display:flex;flex-wrap:wrap;border-radius:2px;margin-top:-100%;-webkit-transition:all .1s ease;transition:all .1s ease;z-index:3}.purchaseDetail{width:55%;flex-shrink:0;background-color:#f1f1f0;padding:50px 25px 20px}.purchaseMethod{width:45%;flex-shrink:0;padding:50px 25px 20px}.purchaseContent .purchaseTitle{margin-top:0;margin-bottom:30px;font-size:1.3rem;font-family:var(--fontBa)}.purchaseName, .purchasePrice{font-weight:900;margin-bottom:20px;color:var(--headC)}.purchaseName:before, .purchasePrice:before{content:attr(data-text);font-size:12px;display:block;font-weight:400;color:var(--bodyC)}.purchasePrice{font-size:2rem} .purchasePrice span{font-size:15px}.purchasePrice .Paypal:before{content:'/ $'}.purchasePrice i{font-style:normal}.purchasePrice i:before, .purchasePrice span.Paypal:after{content:attr(data-text)}.purchaseName:after{content:attr(data-title)}.purchaseInfo{font-size:13px;line-height:1.7em;margin-top:40px}.purchaseLink .button{display:flex;margin-right:0;padding:12px 20px}.purchaseLink .button svg{margin-right:12px}.purchaseLink .button svg.line{fill:none;stroke-width:1.8}.purchaseLink .transfer svg{height:18px;stroke:#05275b}.purchaseLink .paypal svg{fill:#0079C1}.purchaseLink .gumroad svg{height:18px;fill:#1d1d1d}.purchaseLink .themeforest{}.purchaseConfirm{font-size:13px;text-align:right;margin-top:35px}.purchaseInput:checked ~ .purchase .purchaseContent{margin-top:0}@media screen and (max-width:480px){.purchaseContent{display:block}.purchaseDetail{width:100%;background-color:transparent;padding-top:16px}.purchaseMethod{width:100%;background-color:#f1f1f0;border-radius:5px 5px 0 0;padding-top:25px}.purchaseName{display:none}.purchaseInfo{margin-top:0;font-size:12px}.purchaseContent .purchaseDetail .purchaseTitle{margin-bottom:20px}.Blog .post .purchaseDetail .purchaseTitle{margin-bottom:10px}}.onHome .purchase .purchaseName:before{margin-bottom:8px}.drK .purchaseDetail, .drK .purchaseContent{background-color:var(--darkB)}.drK .purchaseMethod{background-color:var(--darkBs)}.drK .purchaseMethod, .drK .purchaseName, .drK .purchasePrice, .drK .purchaseName:before, .drK .purchasePrice:before, .drK .purchaseContent{color:var(--darkT)}.drK.purchaseLink .transfer svg{stroke:var(--darkT)}.drK .purchaseLink .paypal svg, .drK .purchaseLink .gumroad svg{fill:var(--darkT)}.drK .changeLog{background-color:var(--darkB)}.drK .logContent{background-color:var(--darkB)}.pay{display:flex;justify-content:center;flex-wrap:wrap; font-family:var(--fontB);font-size:14px}.pay > *{transition:transform .15s ease;-webkit-transition:transform .15s ease}.pay > *:hover{-webkit-transform:scale(1.05,1.05);transform:scale(1.05,1.05)}.pyM{min-width:250px;max-width:300px;display:block;position:relative;background:#fff;border-radius:3px;box-shadow:0 10px 40px rgba(149,157,165,.2);padding:0 0 74px;text-align:center;margin:0 10px 30px}.pyM.disc::before{content:'-30%'; display:block;font-weight:700;font-size:13px;width:50px;height:50px;padding:15px 0 10px;background:#ebeced;border-radius:5px 5px 50px 50px;position:absolute;top:-5px;right:10px}.pyM.disc.ds-40::before{content:'-40%'}.pyM i.strike{display:block;font-size:15px;font-style:normal;text-decoration:line-through}.pyM ol.pyI{list-style:none;margin:30px 0;padding:0 30px;font-size:13px;line-height:1.8em;opacity:.8}.pyH{padding:20px;text-transform:uppercase}.pyP{font-size:55px;line-height:normal;color:var(--linkC);font-weight:700}.pyP::before, .pyP::after{content:attr(data-currency);font-size:16px;font-weight:400}.pyP::after{content:attr(data-text)}.pyB{position:absolute;bottom:0;left:0;right:0}.pyB .button{margin:0 0 30px}.drK .pyM{background:var(--darkBs);box-shadow:0 10px 40px rgba(0,0,0,.2)} .drK .pyP{color:var(--darkU)} .drK.pyM.disc::before{background:var(--darkU)}





/* Standar CSS */ ::selection{color:#fff;background:var(--linkB)} .drK ::selection{background:var(--darkU)} *, ::after, ::before{-webkit-box-sizing:border-box;box-sizing:border-box} *{-webkit-tap-highlight-color:transparent} h1, h2, h3, h4, h5, h6{margin:0;font-weight:700;font-family:var(--fontH);color:var(--headC)} h1{font-size:1.9rem} h2{font-size:1.7rem} h3{font-size:1.5rem} h4{font-size:1.4rem} h5{font-size:1.3rem} h6{font-size:1.2rem} a{color:var(--linkC);text-decoration:none} a:hover{opacity:.9;transition:opacity .1s} table{border-spacing:0} iframe{max-width:100%;border:0;margin-left:auto;margin-right:auto} input, button, select, textarea{font:inherit;font-size:100%;color:inherit;line-height:normal} input::placeholder{color:rgba(0,0,0,.5)} img{display:block;position:relative;max-width:100%;height:auto} svg{width:22px;height:22px;fill:var(--iconC)} svg.line, svg .line{fill:none!important;stroke:var(--iconC);stroke-linecap:round;stroke-linejoin:round; stroke-width:1} svg.c-1{fill:var(--iconCa)} svg.c-2{fill:var(--iconCs); opacity:.4} .hidden{display:none} .invisible{visibility:hidden} .clear{width:100%;display:block;margin:0;padding:0;float:none;clear:both} .fCls{display:block;position:fixed;top:-50%;left:-50%;right:-50%;bottom:-50%;z-index:1;transition:var(--trans-1);background:transparent;opacity:0;visibility:hidden} .free::after, .new::after{display:inline-block;content:'Free!';color:var(--linkC);font-size:12px;font-weight:400;margin:0 5px} .new::after{content:'New!'} svg .svgC{fill:var(--linkC)} svg.line .svgC{fill:none;stroke:var(--linkC)} .drK svg .svgC{fill:var(--darkU)} .drK svg.line .svgC{fill:none;stroke:var(--darkU)}  .blog-admin, .bD .bmPs, .pInf .pIc .bmPs, .bmPs>svg .d, .isBkm, .cBkPs, .ckW, .tocL, .headR .headM .themeBtn, .cusW{display:none}
/* Unfilled Ads */ ins.adsbygoogle[data-ad-status="unfilled"]{display:none !important}
/* Main Element */ html{scroll-behavior:smooth;overflow-x:hidden} body{-webkit-font-smoothing:antialiased;position:relative;top:0 !important;margin:0;padding:0!important;width:100%;font-family:var(--fontB);font-size:14px;color:var(--bodyC);background:var(--bodyB);-webkit-font-smoothing:antialiased} .secIn{margin:0 auto;padding-left:20px;padding-right:20px;max-width:var(--contentW)}
/* Notif Section */ .ntfC{display:flex;align-items:center;position:relative;min-height:var(--notifH);background:var(--notifU);color:var(--notifC);padding:10px 15px; font-size:13px; transition:var(--trans-1);overflow:hidden;border-radius:10px;margin-bottom:20px} .ntfC::before{content:'';width:60px;height:60px;background:rgba(0,0,0,.15);display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .Rtl .ntfC::before{left:unset;right:-12px} .ntfC .secIn{width:100%;position:relative} .ntfC .c{display:flex;align-items:center} .ntfT{width:100%; padding-right:15px; text-align:center} .ntfT a{color:var(--linkC);font-weight:700} .ntfI:checked ~ .ntfC{height:0;min-height:0;margin:0;padding:0;opacity:0;visibility:hidden} .ntfA{display:inline-flex;align-items:center;justify-content:center;text-align:initial} .ntfA >a{flex-shrink:0;white-space:nowrap;display:inline-block; margin-left:10px;padding:8px 12px;border-radius:var(--buttonR);background:#fffdfc;color:var(--notifC);font-size:12px;font-weight:400;box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%);text-decoration:none} .drK .ntfA >a{background:var(--darkU);color:#fffdfc}
/* Fixed/Pop-up Element */ .fixL{display:flex;align-items:center;position:fixed;left:0;right:0;bottom:0;margin-bottom:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%;opacity:0;visibility:hidden} .fixLi, .fixL .cmBri{width:100%;max-width:680px;max-height:calc(100% - 60px);border-radius:12px;transition:inherit;z-index:3;display:flex;overflow:hidden;position:relative;margin:0 auto;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .fixLs{padding:60px 20px 20px;overflow-y:scroll;overflow-x:hidden;width:100%;background:var(--contentB)} .fixH, .mnH{display:flex;background:inherit;position:absolute;top:0;left:0;right:0;padding:0 10px;z-index:2} .fixH .cl{padding:0 10px;display:flex;align-items:center;justify-content:flex-end;position:relative;flex-shrink:0;min-width:40px} .fixH .c::after, .ntfC .c::after, .mnH .c::before{content:'\2715';line-height:18px;font-size:14px} .fixT::before{content:attr(data-text);flex-grow:1;padding:16px 10px;font-size:90%;opacity:.7} .fixT .c::before, .mnH .c::after{content:attr(aria-label);font-size:11px;margin:0 8px;opacity:.6} .fixi:checked ~ .fixL, #comment:target .fixL{margin-bottom:0;opacity:1;visibility:visible} .fixi:checked ~ .fixL .fCls, #comment:target .fixL .fCls, .BlogSearch input:focus ~ .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .shBri{max-width:520px} /* display:flex */ .headI, .bIc{display:flex;align-items:center}

/* mainIn Section */ .mainWrp:after{content:'';display:block;position:absolute;top:0;right:0;width:170px;height:170px;border-radius:0 0 0 200px;background:rgba(0,0,0,.02);z-index:-1} .drK .mainWrp:after{background:rgba(0,0,0,.10)} .blogCont{flex-grow:1;padding:20px 0 0;position:relative;transition:var(--trans-1)} .blogCont .section:not(.no-items), .blogCont .widget:not(:first-child){margin-top:40px} .blogCont .section:first-child, .blogCont footer .section:not(:first-child), .blogCont footer .widget:not(:first-child), .blogCont .section.mobMn, #notif-widget .widget:not(:first-child){margin-top:0} .blogAd .section:not(.no-items){margin-bottom:40px} #notif-widget .widget:first-child{margin-bottom:20px} .blogM{flex-wrap:wrap;justify-content:center;padding-bottom:40px} .sidebar{max-width:500px;margin:50px auto 0} .sideSticky{position:-webkit-sticky;position:sticky;top:calc(var(--headerH) + 10px)} .onPs .blogM .mainbar{max-width:var(--pageW)} .onPg .blogM .mainbar{max-width:var(--pageW)}
/* mainNav */ .mnBrs{background:var(--contentB)} .mnBr a{color:inherit} .mnBr ul{list-style:none;margin:0;padding:0} .mnMob{align-self:flex-end;background:inherit;border-top:1px solid var(--contentL);bottom:0;left:0;padding:15px 20px 20px;position:absolute;right:0;text-align:center;z-index:1} .mnMob .mSoc{display:flex;justify-content:center;left:-7px;margin-top:5px;position:relative;right:-7px;width:calc(100% + 14px)} .mnMob:not(.no-items) + .mnMen{padding-bottom:100px} .mnMen{padding:20px 15px} .mMenu{margin-bottom:10px} .mMenu >*{display:inline} .mMenu >*:not(:last-child)::after{content:'\00B7';font-size:90%;opacity:.6} .mMenu a:hover{text-decoration:underline} .mSoc >*{position:relative} .mSoc svg{z-index:1} .mSoc svg, .mnMn svg{width:20px;height:20px;opacity:.8} .mSoc span, .mMenu span{opacity:.7} .mNav{display:none;position:relative;max-width:30px} .mNav svg{height:18px;opacity:.7;z-index:1} .mnMn >li{position:relative} .mnMn >li.br::after{content:'';display:block;border-bottom:1px solid var(--contentL);margin:12px 5px} .mnMn li:not(.mr) .a:hover, .mnMn ul li >*:hover{background:var(--transB)} .mnMn li:not(.mr) .a:hover, .mnMn ul li a:hover{color:var(--linkC)} .mnMn li:not(.mr) ul{padding-left:30px} .mnMn li ul{display:none;opacity:0;visibility:hidden} .mnMn ul li >*, .mnMn .a{display:flex;align-items:center;padding:10px 5px;position:relative;width:calc(100% + 10px);left:-5px;right:-5px;border-radius:8px;transition:var(--trans-1)} .mnMn ul li >*{padding:10px} .mnMn li li a >*{-webkit-box-orient:vertical;-webkit-line-clamp:1;display:flex;line-height:20px;overflow:hidden} .mnMn li li a >* svg{margin-right:5px} .mnMn .a >*{margin:0 5px} .mnMn .a:hover svg:not(.d){fill:var(--linkC)} .mnMn .a:hover svg.line:not(.d){fill:none;stroke:var(--linkC)} .mnMn .n, .mnMn ul li >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1 0 calc(100% - 64px)} .mnMn svg{flex-shrink:0} .mnMn svg.d{width:14px;height:14px} .mnMn .drp.mr .a{font-size:13px;padding-bottom:0;opacity:.7} .mnMn .drp.mr svg.d{display:none} .mnMn .drpI:checked ~ .a svg.d{transform:rotate(180deg)} .mnMn .drpI:checked ~ ul{display:block;position:relative;opacity:1;visibility:visible} @media screen and (min-width:897px){.bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*, .hdMn .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:5px;overflow:visible;width:calc(100% + 5px)} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul::before{border-left:1px solid;content:'';display:block;height:calc(100% - 20px);left:15px;opacity:.2;position:absolute;width:1px} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul li a::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul li a::before{border-bottom:1px solid;content:'';display:block;height:1px;left:-15px;opacity:.2;position:absolute;top:17.5px;width:13px} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul.s li a::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul.s li a::before{top:20px} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul:not(.s)::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul:not(.s)::before{height:calc(100% - 18.5px)} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg, .hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--linkC)} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg.line, .hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--linkC)} .drK:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg, .drK.hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--darkU)} .drK:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg.line, .drK.hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--darkU)} .Rtl:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp ul:before, .Rtl.hdMn .navI:checked ~ .mainWrp .blogMn .drp ul:before{left:unset;right:15px} .Rtl:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*, .Rtl.hdMn .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:0;margin-right:5px} .Rtl:not(.hdMn) .navI:not(checked) ~ .mainWrp .blogMn .drp ul li a:before, .Rtl.hdMn .navI:checked ~ .mainWrp .blogMn .drp ul li a:before{left:unset;right:-15px}} @media screen and (max-width:896px){.bD .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:5px;overflow:visible;width:calc(100% + 5px)} .bD .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul::before{border-left:1px solid;content:'';display:block;height:calc(100% - 20px);left:15px;opacity:.2;position:absolute;width:1px} .bD .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul li a::before{border-bottom:1px solid;content:'';display:block;height:1px;left:-15px;opacity:.2;position:absolute;top:17.5px;width:13px} .bD .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul.s li a::before{top:20px} .bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--linkC)} .bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--linkC)} .drK.bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--darkU)} .drK.bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--darkU)} .Rtl .navI:checked ~ .mainWrp .blogMn .drp ul:before{left:unset;right:15px} .Rtl .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:0;margin-right:5px} .Rtl .navI:checked ~ .mainWrp .blogMn .drp ul li a:before{left:unset;right:-15px}}
/* Mobile Menu */ .mobMn{position:fixed;left:0;right:0;bottom:0; border-top:1px solid var(--mobL);border-radius:var(--mobBr) var(--mobBr) 0 0;background:var(--mobB);color:var(--mobT);padding:0 20px;box-shadow:0 -10px 25px -5px rgba(0,0,0,.1);z-index:2;font-size:12px} .mobMn svg.line{stroke:var(--mobT);opacity:.8} .mobMn ul{height:55px;display:flex;align-items:center;justify-content:center;list-style:none;margin:0;padding:0} .mobMn li{display:flex;justify-content:center;flex:1 0 20%} .mobMn li >*{display:inline-flex;align-items:center;justify-content:center;min-width:35px;height:35px;border-radius:20px;padding:0 8px;transition:var(--trans-1);color:inherit} .mobMn li svg{margin:0 3px;flex-shrink:0} .mobMn li >*::after{content:attr(data-text);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:0;margin:0;transition:inherit;opacity:.7} .mobMn li >*:hover::after{max-width:70px;margin:0 3px} .mobMn .nmH{opacity:.7} .mobMn li >*:hover{background:var(--mobHv)} .mobMn li >*:hover svg.line{fill:var(--mobT) !important;opacity:.5} .mobMn li >*:hover svg.line .svgC{fill:var(--linkB) !important;stroke:var(--linkB)} /* Style 2 */ .MN-2 .mobMn{font-size:10px} .mobS .mobMn li >*{flex-direction:column;position:relative} .mobS .mobMn li >*:hover{background:transparent} .MN-2 .mobMn li >*::after{max-width:none} /* Style 3 */ .MN-3 .mobMn li >*::after, .MN-4 .mobMn li >*::after{content:'';width:4px;height:4px;border-radius:50%;position:absolute;bottom:-2px;opacity:0} .MN-3 .mobMn li >*:hover::after,  .MN-4 .mobMn li >*:hover::after{background:var(--linkB);opacity:.7} .MN-3 .mobMn li >*:hover svg.line, .MN-4 .mobMn li >*:hover svg.line{stroke:var(--linkB);fill:var(--linkB) !important;opacity:.7} /* Style 4 */ .MN-4 .mobMn{left:15px;right:15px;bottom:15px;padding:0 10px;border-radius:var(--headerR);box-shadow: 0 5px 35px rgba(0,0,0,.1);transition:bottom 1.2s ease;-webkit-transition:bottom 1.2s ease} .MN-4 .mobMn.slide{bottom:-150px;transition:bottom 1.5s ease;-webkit-transition:bottom 1.5s ease}

/* Navbar */ .navbar{z-index:3;padding-top:10px;background:var(--navB);box-shadow:0 5px 35px rgba(0,0,0,.07);height:var(--navH);color:var(--navT);overflow:hidden} .navR .section{justify-content:flex-end} .navIn svg, header svg{width:20px;height:20px;fill:var(--navI); opacity:.8} .navIn svg.line{fill:none;stroke:var(--navI)} .navIn .section{display:flex;align-items:center;height:100%;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .navIn .section >*{margin:0 7px} .navIn .a{color:inherit} .navIn ul{list-style:none;margin:0;padding:0} .mLang{align-items:baseline;font-size:13px} .mLang, .mSocc{display:flex;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .mLang .a{width:30px;height:30px;display:flex;align-items:center;justify-content:center} .mLang .a::before{content:attr(data-text)} .mLang li.u{font-size:12px;text-transform:uppercase} .mLang li:not(:last-child){display:flex;align-items:center} .mLang li:not(:last-child)::after{content:'';height:14px; border-left:1px solid #999; margin:0 5px;opacity:.7; flex:0 0} .mLang span, .mSocc span{opacity:.5} .mSocc >*{position:relative} .mSocc svg{z-index:1} .mSocc svg{width:19px;height:19px;opacity:.8}#dateNow{right: 10px;position: absolute;top: 5px;opacity: 0.7;}
.drK .navbar{background:var(--darkB);color:var(--darkT)}

/* Back to Top */ .toTopB{display:flex;align-items:center;justify-content:center;position:fixed;right:20px;bottom:20px;width:45px;height:45px;border-radius:50%;cursor:pointer;visibility:hidden;opacity:0;z-index:5;transform:scale(0);transition:transform .3s ease, opacity .3s ease,visibility .3s ease,margin-bottom 1s ease} .toTopB.vsbl{visibility:visible;opacity:1;transform:scale(1)} .MN-4 .toTopB{bottom:20px} .toTopB:hover{opacity:.8} .toTopB svg{height:100%;width:100%;-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg);stroke-width:1.5;cursor:pointer} .toTopB svg .b{fill:#fff;stroke:#e6e6e6;opacity:.9} .toTopB svg .c{fill:none;stroke:var(--linkC);stroke-dasharray:100 100;stroke-dashoffset:100;stroke-linecap:round} .toTopB svg .d{fill:none;stroke:var(--iconC)} .drK .toTopB svg .b{fill:var(--darkBa);stroke:#404045} .drK .toTopB svg .c{stroke:var(--darkU)} .drK .toTopB svg .d{stroke:var(--darkT)}




/* Standar CSS */ ::selection{color:#fff;background:var(--linkB)} .drK ::selection{background:var(--darkU)} *, ::after, ::before{-webkit-box-sizing:border-box;box-sizing:border-box} *{-webkit-tap-highlight-color:transparent} h1, h2, h3, h4, h5, h6{margin:0;font-weight:700;font-family:var(--fontH);color:var(--headC)} h1{font-size:1.9rem} h2{font-size:1.7rem} h3{font-size:1.5rem} h4{font-size:1.4rem} h5{font-size:1.3rem} h6{font-size:1.2rem}  a{color:var(--linkC);text-decoration:none} a:hover{opacity:.9;transition:opacity .1s} table{border-spacing:0} iframe{max-width:100%;border:0;margin-left:auto;margin-right:auto} input, button, select, textarea{font:inherit;font-size:100%;color:inherit;line-height:normal} input::placeholder{color:rgba(0,0,0,.5)} img{display:block;position:relative;max-width:100%;height:auto} svg{width:22px;height:22px;fill:var(--iconC)} svg.line, svg .line{fill:none!important;stroke:var(--iconC);stroke-linecap:round;stroke-linejoin:round; stroke-width:1} svg.c-1{fill:var(--iconCa)} svg.c-2{fill:var(--iconCs); opacity:.4} .hidden{display:none} .invisible{visibility:hidden} .clear{width:100%;display:block;margin:0;padding:0;float:none;clear:both} .fCls{display:block;position:fixed;top:-50%;left:-50%;right:-50%;bottom:-50%;z-index:1;transition:var(--trans-1);background:transparent;opacity:0;visibility:hidden} .free::after, .new::after{display:inline-block;content:'Free!';color:var(--linkC);font-size:12px;font-weight:400;margin:0 5px} .new::after{content:'New!'}.soon::after{content:'Coming Soon!'}svg .svgC{fill:var(--linkC)} svg.line .svgC{fill:none;stroke:var(--linkC)} .drK svg .svgC{fill:var(--darkU)} .drK svg.line .svgC{fill:none;stroke:var(--darkU)}
/* Font Body and Alternative */ @font-face{font-family:'Google Sans Text';font-style:normal;font-weight:400;font-display:swap;src:local('Google Sans Text'),local('Google-Sans-Text'),url(https://fonts.gstatic.com/s/googlesanstext/v16/5aUu9-KzpRiLCAt4Unrc-xIKmCU5qEp2iw.woff2) format('woff2')} 
/* Font Heading */ @font-face{font-family:'Google Sans Text';font-style:normal;font-weight:700;font-display:swap;src:local('Google Sans Text'),local('Google-Sans-Text'),url(https://fonts.gstatic.com/s/googlesanstext/v16/5aUp9-KzpRiLCAt4Unrc-xIKmCU5oPFTnmhjtg.woff2) format('woff2')}
/* Source Code Font */ @font-face{font-family:'Google Sans Mono';font-style:normal;font-weight:400;font-display:swap;src:local('Google Sans Mono'),local('Google-Sans-Mono'),url(https://fonts.gstatic.com/s/googlesansmono/v4/P5sUzYWFYtnZ_Cg-t0Uq_rfivrdYH4RE8-pZ5gQ1abT53wVQGrk.woff2) format('woff2')}
/* Scroll Custom */
::-webkit-scrollbar{-webkit-appearance:none;width:5px;height:5px}::-webkit-scrollbar-track{background-color:transparent}::-webkit-scrollbar-thumb{background-color:rgba(0,0,0,.15);border-radius:10px}::-webkit-scrollbar-thumb:hover{background-color:rgba(0,0,0,.25)}::-webkit-scrollbar-thumb:active{background-color:rgba(0,0,0,.25)}
/* Custom Bg */
.yzB{position:relative;padding:15px;border-radius:20px;background:#fff;box-shadow:0 10px 25px -3px rgb(0 0 0 / 10%);margin-top:25px}
.yzB::before{content:'';display:block;position:absolute;top:0;left:0;width:115px;height:115px;background:rgba(155,170,175,0.12);background-repeat:no-repeat;border-radius:20px 0 120px;transition:opacity .3s;opacity:1}
.yzB::after{content:'';display:block;position:absolute;bottom:0;right:0;width:115px;height:115px;background:rgba(155,170,175,0.12);background-repeat:no-repeat;border-radius:120px 0 20px;transition:opacity .3s;opacity:1}.drK .yzB{background:var(--darkBs)}#license-code,#myIdBlog{display:none}



/* Main Element */ html{scroll-behavior:smooth;overflow-x:hidden} body{position:relative;margin:0;padding:0!important;width:100%;font-family:var(--fontB);font-size:14px;color:var(--bodyC);background:var(--bodyB);-webkit-font-smoothing: antialiased;} .secIn{margin:0 auto;padding-left:20px;padding-right:20px;max-width:var(--contentW)} /* Notif Section */ .ntfC{display:flex;align-items:center;position:relative;min-height:var(--notifH);background:var(--notifU);color:var(--notifC);padding:10px 15px; font-size:13px; transition:var(--trans-1);overflow:hidden;border-radius:10px;margin-bottom:20px} .ntfC::before{content:'';width:60px;height:60px;background:rgba(0,0,0,.15);display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .Rtl .ntfC::before{left:unset;right:-12px} .ntfC .secIn{width:100%;position:relative} .ntfC .c{display:flex;align-items:center} .ntfT{width:100%; padding-right:15px; text-align:center} .ntfT a{color:var(--linkC);font-weight:700} .ntfI:checked ~ .ntfC{height:0;min-height:0;margin:0;padding:0;opacity:0;visibility:hidden} .ntfA{display:inline-flex;align-items:center;justify-content:center;text-align:initial} .ntfA >a{flex-shrink:0;white-space:nowrap;display:inline-block; margin-left:10px;padding:8px 12px;border-radius:20px;background:var(--linkB);color:#fff;font-size:12px;font-weight:400;box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%);text-decoration:none} .drK .ntfA >a{background:var(--darkU);color:#fffdfc}
/* Fixed/Pop-up Element */ .fixL{display:flex;align-items:center;position:fixed;left:0;right:0;bottom:0;margin-bottom:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%;opacity:0;visibility:hidden} .fixLi, .fixL .cmBri{width:100%;max-width:680px;max-height:calc(100% - 60px);border-radius:12px;transition:inherit;z-index:3;display:flex;overflow:hidden;position:relative;margin:0 auto;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .fixLs{padding:60px 20px 20px;overflow-y:scroll;overflow-x:hidden;width:100%;background:var(--contentB)} .fixH, .mnH{display:flex;background:inherit;position:absolute;top:0;left:0;right:0;padding:0 10px;z-index:2} .fixH .cl{padding:0 10px;display:flex;align-items:center;justify-content:flex-end;position:relative;flex-shrink:0;min-width:40px} .fixH .c::after, .ntfC .c::after, .mnH .c::before{content:'\2715';line-height:18px;font-size:14px} .fixT::before{content:attr(data-text);flex-grow:1;padding:16px 10px;font-size:90%;opacity:.7} .fixT .c::before, .mnH .c::after{content:attr(aria-label);font-size:11px;margin:0 8px;opacity:.6} .fixi:checked ~ .fixL, #comment:target .fixL{margin-bottom:0;opacity:1;visibility:visible} .fixi:checked ~ .fixL .fCls, #comment:target .fixL .fCls, .BlogSearch input:focus ~ .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .shBri{max-width:520px} /* display:flex */ .headI, .bIc{display:flex;align-items:center}

/* mainIn Section */ .mainWrp:after{content:'';display:block;position:absolute;top:0;right:0;width:170px;height:170px;border-radius:0 0 0 200px;background:rgba(0,0,0,.02);z-index:-1} .drK .mainWrp:after{background:rgba(0,0,0,.10)} .blogCont{flex-grow:1;padding:20px 0 0;position:relative;transition:var(--trans-1)} .blogCont .section:not(.no-items), .blogCont .widget:not(:first-child){margin-top:40px} .blogCont .section:first-child, .blogCont footer .section:not(:first-child), .blogCont footer .widget:not(:first-child), .blogCont .section.mobMn, #notif-widget .widget:not(:first-child){margin-top:0} .blogAd .section:not(.no-items){margin-bottom:40px} #notif-widget .widget:first-child{margin-bottom:20px} .blogM{flex-wrap:wrap;justify-content:center;padding-bottom:40px} .sidebar{max-width:500px;margin:50px auto 0} .sideSticky{position:-webkit-sticky;position:sticky;top:calc(var(--headerH) + 10px)} .onPs .blogM .mainbar{max-width:var(--pageW)} .onPg .blogM .mainbar{max-width:var(--pageW)}
/* mainNav */ .mnBrs{background:var(--contentB)} .mnBr a{color:inherit} .mnBr ul{list-style:none;margin:0;padding:0} .mnMob{align-self:flex-end;background:inherit;border-top:1px solid var(--contentL);bottom:0;left:0;padding:15px 20px 20px;position:absolute;right:0;text-align:center;z-index:1} .mnMob .mSoc{display:flex;justify-content:center;left:-7px;margin-top:5px;position:relative;right:-7px;width:calc(100% + 14px)} .mnMob:not(.no-items) + .mnMen{padding-bottom:100px} .mnMen{padding:20px 15px} .mMenu{margin-bottom:10px} .mMenu >*{display:inline} .mMenu >*:not(:last-child)::after{content:'\00B7';font-size:90%;opacity:.6} .mMenu a:hover{text-decoration:underline} .mSoc >*{position:relative} .mSoc svg{z-index:1} .mSoc svg, .mnMn svg{width:20px;height:20px;opacity:.8} .mSoc span, .mMenu span{opacity:.7} .mNav{display:none;position:relative;max-width:30px} .mNav svg{height:18px;opacity:.7;z-index:1} .mnMn >li{position:relative} .mnMn >li.br::after{content:'';display:block;border-bottom:1px solid var(--contentL);margin:12px 5px} .mnMn li:not(.mr) .a:hover, .mnMn ul li >*:hover{background:var(--transB)} .mnMn li:not(.mr) .a:hover, .mnMn ul li a:hover{color:var(--linkC)} .mnMn li:not(.mr) ul{padding-left:30px} .mnMn li ul{display:none;opacity:0;visibility:hidden} .mnMn ul li >*, .mnMn .a{display:flex;align-items:center;padding:10px 5px;position:relative;width:calc(100% + 10px);left:-5px;right:-5px;border-radius:var(--tIbR);transition:var(--trans-1)} .mnMn ul li >*{padding:10px} .mnMn li li a >*{-webkit-box-orient:vertical;-webkit-line-clamp:1;display:flex;line-height:20px;overflow:hidden} .mnMn li li a >* svg{margin-right:5px} .mnMn .a >*{margin:0 5px} .mnMn .a:hover svg:not(.d){fill:var(--linkC)} .mnMn .a:hover svg.line:not(.d){fill:none;stroke:var(--linkC)} .mnMn .n, .mnMn ul li >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1 0 calc(100% - 64px)} .mnMn svg{flex-shrink:0} .mnMn svg.d{width:14px;height:14px} .mnMn .drp.mr .a{font-size:13px;padding-bottom:0;opacity:.7} .mnMn .drp.mr svg.d{display:none} .mnMn .drpI:checked ~ .a svg.d{transform:rotate(180deg)} .mnMn .drpI:checked ~ ul{display:block;position:relative;opacity:1;visibility:visible} @media screen and (min-width:897px){.bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*, .hdMn .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:5px;overflow:visible;width:calc(100% + 5px)} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul::before{border-left:1px solid;content:'';display:block;height:calc(100% - 20px);left:15px;opacity:.2;position:absolute;width:1px} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul li a::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul li a::before{border-bottom:1px solid;content:'';display:block;height:1px;left:-15px;opacity:.2;position:absolute;top:17.5px;width:13px} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul.s li a::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul.s li a::before{top:20px} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp:not(.mr) ul:not(.s)::before, .hdMn .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul:not(.s)::before{height:calc(100% - 18.5px)} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg, .hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--linkC)} .bD:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg.line, .hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--linkC)} .drK:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg, .drK.hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--darkU)} .drK:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn li li a:hover svg.line, .drK.hdMn .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--darkU)} .Rtl:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .drp ul:before, .Rtl.hdMn .navI:checked ~ .mainWrp .blogMn .drp ul:before{left:unset;right:15px} .Rtl:not(.hdMn) .navI:not(:checked) ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*, .Rtl.hdMn .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:0;margin-right:5px} .Rtl:not(.hdMn) .navI:not(checked) ~ .mainWrp .blogMn .drp ul li a:before, .Rtl.hdMn .navI:checked ~ .mainWrp .blogMn .drp ul li a:before{left:unset;right:-15px}} @media screen and (max-width:896px){.bD .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:5px;overflow:visible;width:calc(100% + 5px)} .bD .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul::before{border-left:1px solid;content:'';display:block;height:calc(100% - 20px);left:15px;opacity:.2;position:absolute;width:1px} .bD .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul li a::before{border-bottom:1px solid;content:'';display:block;height:1px;left:-15px;opacity:.2;position:absolute;top:17.5px;width:13px} .bD .navI:checked ~ .mainWrp .blogMn .drp:not(.mr) ul.s li a::before{top:20px} .bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--linkC)} .bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--linkC)} .drK.bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg{fill:var(--darkU)} .drK.bD .navI:checked ~ .mainWrp .blogMn .mnMn li li a:hover svg.line{fill:none;stroke:var(--darkU)} .Rtl .navI:checked ~ .mainWrp .blogMn .drp ul:before{left:unset;right:15px} .Rtl .navI:checked ~ .mainWrp .blogMn .mnMn :not(.mr) ul li >*{margin-left:0;margin-right:5px} .Rtl .navI:checked ~ .mainWrp .blogMn .drp ul li a:before{left:unset;right:-15px}}
/* Mobile Menu */ .mobMn{position:fixed;left:0;right:0;bottom:0; border-top:1px solid var(--mobL);border-radius:var(--mobBr) var(--mobBr) 0 0;background:var(--mobB);color:var(--mobT);padding:0 20px;box-shadow:0 -10px 25px -5px rgba(0,0,0,.1);z-index:2;font-size:12px} .mobMn svg.line{stroke:var(--mobT);opacity:.8} .mobMn ul{height:55px;display:flex;align-items:center;justify-content:center;list-style:none;margin:0;padding:0} .mobMn li{display:flex;justify-content:center;flex:1 0 20%} .mobMn li >*{display:inline-flex;align-items:center;justify-content:center;min-width:35px;height:35px;border-radius:20px;padding:0 8px;transition:var(--trans-1);color:inherit} .mobMn li svg{margin:0 3px;flex-shrink:0} .mobMn li >*::after{content:attr(data-text);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:0;margin:0;transition:inherit;opacity:.7} .mobMn li >*:hover::after{max-width:70px;margin:0 3px} .mobMn .nmH{opacity:.7} .mobMn li >*:hover{background:var(--mobHv)} .mobMn li >*:hover svg.line{fill:var(--mobT) !important;opacity:.5} .mobMn li >*:hover svg.line .svgC{fill:var(--linkB) !important;stroke:var(--linkB)} /* Style 2 */ .MN-2 .mobMn{font-size:10px} .mobS .mobMn li >*{flex-direction:column;position:relative} .mobS .mobMn li >*:hover{background:transparent} .MN-2 .mobMn li >*::after{max-width:none} /* Style 3 */ .MN-3 .mobMn li >*::after, .MN-4 .mobMn li >*::after{content:'';width:4px;height:4px;border-radius:50%;position:absolute;bottom:-2px;opacity:0} .MN-3 .mobMn li >*:hover::after,  .MN-4 .mobMn li >*:hover::after{background:var(--linkB);opacity:.7} .MN-3 .mobMn li >*:hover svg.line, .MN-4 .mobMn li >*:hover svg.line{stroke:var(--linkB);fill:var(--linkB) !important;opacity:.7} /* Style 4 */ .MN-4 .mobMn{left:15px;right:15px;bottom:15px;padding:0 10px;border-radius:50px;box-shadow: 0 5px 35px rgba(0,0,0,.1);transition:bottom 1.2s ease;-webkit-transition:bottom 1.2s ease;/*background:rgba(255, 255, 255, 0.75);-webkit-backdrop-filter: blur(3px);backdrop-filter: blur(5px)*/background:var(--mobB);} .MN-4 .mobMn.slide{bottom:-170px;transition:bottom 1.5s ease;-webkit-transition:bottom 1.5s ease}
/* Main  */.mainInner{border-bottom: 1px solid var(--content-border);border-bottom-left-radius: 15px;} .blogContent .mainbar > *:not(:last-child){border-bottom:none;}
/* Widget FollowByEmail */.FollowByEmail form{display:flex;max-width:320px;margin-top:20px}.FollowByEmail input[type=email]{margin:0 10px 0 0}.FollowByEmail input[type=submit]{margin:1px 0;flex-shrink:0}

/* Back to Top By YazidTips*/ .yzTtop{display:flex;align-items:center;justify-content:center;position:fixed;right:20px;bottom:70px;width:45px;height:45px;border-radius:50%;cursor:pointer;visibility:hidden;opacity:0;z-index:5;transform:scale(0);transition:transform .3s ease, opacity .3s ease,visibility .3s ease,margin-bottom 1s ease} .yzTtop.vsbl{visibility:visible;opacity:1;transform:scale(1)} .MN-4 .yzTtop{bottom:80px} .yzTtop:hover{opacity:.8} .yzTtop svg{height:100% !important;width:100% !important;-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg);stroke-width:1.5;cursor:pointer} .yzTtop svg .b{fill:#fff;stroke:#e6e6e6;opacity:.9} .yzTtop svg .c{fill:none;stroke:var(--linkC);stroke-dasharray:100 100;stroke-dashoffset:100;stroke-linecap:round} .yzTtop svg .d{fill:none;stroke:var(--iconC)} .drK .yzTtop svg .b{fill:var(--darkBa);stroke:#404045} .drK .yzTtop svg .c{stroke:var(--darkU)} .drK .yzTtop svg .d{stroke:var(--darkT)}

/* Widget Input */.widget input[type=text], .widget input[type=password], .widget input[type=number], .widget input[type=email], .widget textarea{display:block;width:100%;border:1px solid rgba(0,0,0,.05);outline:0;padding:15px 15px;margin-bottom:15px;margin-top:5px}.widget input[type=text]:focus, .widget input[type=email]:focus, .widget textarea:focus{border-color:var(--bodyC)}.widget input[type=button], .widget input[type=submit]{display:inline-flex;align-items:center;margin:0 0 15px;padding:10px 20px;outline:0;border:0;border-radius:2px;color:#fefefe;background-color:#204ecf;font-size:14px;font-family:var(--fontB);white-space:nowrap;overflow:hidden;max-width:100%}.widget input[type=button]:hover, .widget input[type=submit]:hover{opacity:.7}
/* Article Section */ .onIndx .blogPts, .itemFt .itm{display:flex;flex-wrap:wrap;align-items:center;position:relative; width:calc(100% + 20px);left:-10px;right:-10px} .onIndx .blogPts >*, .itemFt .itm >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px); margin-bottom:0;margin-left:10px;margin-right:10px}
.blogPts .ntry:not(.post):before{content: '';display: block;position: absolute;bottom: 0;right: 0;width: 100%;height: 110px;background: rgba(155,170,175,0.12);background-repeat: no-repeat;transition: opacity .3s;opacity: 0.8;border-radius: 100% 100% 17px 17px}
.onIndx .blogPts >*{background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px;margin-bottom:20px;padding:10px 10px 45px;position:relative} .onIndx .blogPts .pTag{padding-bottom:0} .onIndx .pTag .pInf{display:none} .onIndx .blogPts .pInf{position:absolute;bottom:15px;left:15px;right:15px} .onIndx .blogPts{align-items:stretch} .onIndx .blogPts.mty{display:block;width:100%;left:0;right:0} .onIndx .blogPts.mty .noPosts{width:100%;margin:0} .onIndx .blogPts div.ntry{padding-bottom:0;flex:0 0 calc(100% - 20px)} .blogPts .ntry.noAd .widget, .Blog ~ .HTML{display:none} 
/* Blog title */ .blogTtl{font-size:14px; margin:0 0 30px;width:calc(100% + 16px);display:flex;justify-content:space-between;position:relative;left:-8px;right:-8px} .blogTtl .t, .blogTtl.hm .title{margin:0 8px;flex-grow:1;margin-top:20px;} .blogTtl .t span{font-weight:400;font-size:90%; opacity:.7} .blogTtl .t span::before{content:attr(data-text)} .blogTtl .t span::after{content:''; margin:0 4px} .blogTtl .t span.hm::after{content:'/'; margin:0 8px} /* Thumbnail */ .pThmb{flex:0 0 calc(50% - 12.5px);overflow:hidden;position:relative;border-radius:3px; margin-bottom:20px; background:var(--transB)} .pThmb .thmb{display:block;position:relative;padding-top:52.335%; color:inherit; transition:var(--trans-1)} .pThmb .thmb amp-img{position:absolute;top:50%;left:50%;min-width:100%;min-height:100%;max-height:108%;text-align:center;transform:translate(-50%, -50%)} .pThmb div.thmb span::before{content:attr(data-text); opacity:.7; white-space:nowrap} .pThmb:not(.nul)::before{position:absolute;top:0;right:0;bottom:0;left:0; transform:translateX(-100%); background-image:linear-gradient(90deg, rgba(255,255,255,0) 0, rgba(255,255,255,.3) 20%, rgba(255,255,255,.6) 60%, rgba(255,255,255, 0)); animation:shimmer 2s infinite;content:''} .pThmb.iyt:not(.nul) .thmb::after{content:'';position:absolute;top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,.4) url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'><path d='M4 11.9999V8.43989C4 4.01989 7.13 2.2099 10.96 4.4199L14.05 6.1999L17.14 7.9799C20.97 10.1899 20.97 13.8099 17.14 16.0199L14.05 17.7999L10.96 19.5799C7.13 21.7899 4 19.9799 4 15.5599V11.9999Z'/></svg>") center / 35px no-repeat; opacity:0;transition:var(--trans-1)} .pThmb.iyt:not(.nul):hover .thmb::after{opacity:1}
/* Sponsored */ .iFxd{display:flex;justify-content:flex-end;position:absolute;top:0;left:0;right:0;padding:10px 6px;font-size:13px;line-height:16px} .iFxd.l{right:auto} .Rtl .iFxd.l{right:0;left:auto} .iFxd >*{display:flex;align-items:center;margin:0 5px;padding:5px 2.5px;border-radius:var(--iFbR);background:var(--contentB);color:inherit;box-shadow:0 8px 25px 0 rgba(0,0,0,.1)} .iFxd >* svg{width:16px;height:16px;stroke-width:1.5;margin:0 2.5px;opacity:.7} .iFxd .cmnt{padding:5px;color:var(--bodyC)} .iFxd .cmnt::after{content:attr(data-text);margin:0 2.5px;opacity:.8} .drK .iFxd >* svg.line{stroke:var(--iconC)}
/* Label .pLbls::before, .pLbls >*::before{content:attr(data-text)} .pLbls::before{opacity:.7} .pLbls a:hover{text-decoration:underline} .pLbls >*{color:inherit;display:inline} .pLbls >*:not(:last-child)::after{content:'/'}*/
/* Label Custom */.pLbls::before, .pLbls >*::before{content:attr(data-text)} .pLbls::before{opacity:.8;margin-right: 5px} .pLbls a:hover{text-decoration:underline;font-weight:bold}.pLbls >*{color:inherit;display:inline}.pLbls >*:not(:last-child)::after{content:''}
/* Label Bot in the post */
.pLbL > a{padding: 9px 12px;background:#fffdfc;color:#08102b;font-size: 13px;border-radius:50px;box-shadow: 3px 6px 15px rgba(0,0,0,.07);margin-right: 5px;}
.pLbL{display: block;direction: ltr;text-align: left;margin-bottom: 25px;}
.pLbL > a::before {content: '#';font-size: 15px;}
.drK .pLbL > a{background:var(--darkBa)}
/* Label Custom in Homepage */.pHdr .pLbls >*{color:#fefefe;display:inline;margin-right:5px;border-radius: 20px;background:#06D7A0;height:24px;padding:0 10px}.pHdr .pLbls >*:hover{text-decoration:none;color:#0b57cf;background:rgba(0,0,0,.05);font-weight:normal}.pHdr .pLbls a:nth-child(1){background:var(--linkB)}.pHdr .pLbls a:nth-child(2){background:var(--darkU)}.pHdr .pLbls a:nth-child(3){background:var(--linkC)}
/* Profile Images and Name */ .im{width:35px;height:35px;border-radius:16px; background-color:var(--transB);background-size:100%;background-position:center;background-repeat:no-repeat;display:flex;align-items:center;justify-content:center} .im svg{width:18px;height:18px;opacity:.4} .nm::after{content:attr(data-text)} /* Title and Entry */ .pTtl{font-size:1.1rem;line-height:1.5em} .pTtl.sml{font-size:1rem} .pTtl.itm{font-size:var(--postT);font-family:var(--fontBa);font-weight:900; line-height:1.3em} .pTtl.itm.nSpr{margin-bottom:30px} .aTtl a:hover{color:var(--linkC)} .aTtl a, .pSnpt{color:var(--fontC); display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden} .pEnt{margin-top:40px; font-size:var(--postF);font-family:var(--fontBa); line-height:1.8em} /* Snippet, Description, Headers and Info */ .pHdr{margin-bottom:8px} .pHdr .pLbls{white-space:nowrap;overflow:hidden;text-overflow:ellipsis; opacity:.8} .pSml{font-size:93%} .pSnpt{-webkit-line-clamp:2;margin:12px 0 0;font-family:var(--fontBa);font-size:14px;line-height:1.5em; opacity:.8} .pSnpt.nTag{color:var(--linkC);opacity:1} .pDesc{font-size:16px;line-height:1.5em;margin:8px 0 25px;opacity:.7} .pInf{display:flex;align-items:baseline;justify-content:space-between; margin-top:15px} .pInf.nTm{margin:0} .pInf.nSpr .pJmp{opacity:1} .pInf.nSpr .pJmp::before{content:attr(aria-label)} .pInf.ps{padding:10px 10px 10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px;justify-content:flex-start;align-items:center; margin-top:25px; position:relative;left:-4px;right:-4px;width:calc(100% + 8px)} .pInf.ps .pTtmp{opacity:1} .pInf.ps .pTtmp::before{content:attr(data-date) ' '} .pInf.ps .pTtmp::after{display:inline} .pInf.ps.nul{display:none} .pInf .pIm{flex-shrink:0; margin:0 4px} .pInf .pNm{flex-grow:1;width:calc(100% - 108px);display:inline-flex;flex-wrap:wrap;align-items:baseline} .pInf .pNm.l{display:none} .pInf .pCm{flex-shrink:0;max-width:24px;margin:0 2px} .pInf .pCm.l{max-width:58px} .pInf .pIc{display:inline-flex;justify-content:flex-end;position:relative;width:calc(100% + 10px);left:-5px;right:-5px} .pInf .pIc >*{display:flex;align-items:center;justify-content:center;width:30px;height:30px;position:relative;margin:0 2px;color:inherit} .pInf .pIc svg{width:20px;height:20px;opacity:.8;z-index:1} .pInf .pIc .cmnt::before{content:attr(data-text);font-size:11px;line-height:18px;padding:0 5px;border-radius:10px;background:#e6e6e6;color:var(--bodyC);position:absolute;top:-5px;right:0;z-index:2} .pInf .pDr{opacity:.7;display:inline-block;margin:0 4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:100%} .pInf .pDr >*:not(:first-child)::before{content:'\00B7';margin:0 5px} .pInf .pIn{display:inline} .pInf .nm{margin:0 4px} .pInf .n .nm::before{content:attr(data-write) ' ';opacity:.7} .pInf .im{width:28px;height:28px} .aTtmp{opacity:.8} .pTtmp::after, .pJmp::before, .iTtmp::before{content:attr(data-text); display:block;line-height:18px; white-space:nowrap;text-overflow:ellipsis;overflow:hidden} .pJmp{display:inline-flex;align-items:center;border: 1px solid var(--linkC);padding: 3px 10px;}.pJmp:hover{background:var(--linkC);color:white;transition:.2s}.pJmp::before{content:attr(aria-label)} .pJmp svg{height:18px;width:18px;stroke:var(--linkC); flex-shrink:0} .ntry:hover .pJmp, .itm:hover .pJmp{opacity:1} /* Product view */ .pTag .pPad{padding:10px 0} .pTag .pPric{font-size:20px;color:var(--linkC);padding-top:20px} .pTag .pPric::before, .pTag .pInfo small{content:attr(data-text);font-size:small;opacity:.8;display:block;line-height:1.5em;color:var(--bodyC)} .pTag .pInfo{font-size:14px;line-height:1.6em} .pTag .pInfo:not(.o){position:relative;width:calc(100% + 20px);left:-10px;right:-10px;display:flex} .pTag .pInfo:not(.o) >*{width:50%;padding:0 10px} .pTag .pMart{margin:10px 0 12px;display:flex;flex-wrap:wrap;line-height:1.6em; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .pTag .pMart >*{margin:0 4px} .pTag .pMart small{width:calc(100% - 8px);margin-bottom:10px} .pTag .pMart a{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border:1px solid var(--contentL);border-radius:12px;margin-bottom:8px} .pTag .pMart img{width:20px;display:block}/* Blog pager */ .blogPg{display:flex;display:flex;align-items:center;flex-wrap:wrap;justify-content:space-between; font-size:90%;font-family:var(--fontB);line-height:20px; color:#fffdfc; margin:30px 0 50px; max-width:100%} .blogPg >*{display:flex;align-items:center; padding:10px 13px;margin-bottom:10px; color:inherit;background:var(--linkB); border-radius:35px} .blogPg >* svg{width:18px;height:18px; stroke:var(--darkT); stroke-width:1.5} .blogPg >*::before{content:attr(data-text)} .blogPg .jsLd{margin-left:auto;margin-right:auto} .blogPg .nwLnk::before, .blogPg .jsLd::before{display:none} .blogPg .nwLnk::after, .blogPg .jsLd::after{content:attr(data-text); margin:0 8px} .blogPg .olLnk::before{margin:0 8px} .blogPg .nPst, .blogPg .current{background:var(--contentL); color:var(--bodyCa)} .blogPg .nPst.jsLd svg{fill:var(--darkTa);stroke:var(--darkTa)} .blogPg .nPst svg.line{stroke:var(--darkTa)} /* Breadcrumb */ .brdCmb{margin-bottom:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .brdCmb a{color:var(--fontC)} .brdCmb >*:not(:last-child)::after{content:'/'; margin:0 4px;font-size:90%;opacity:.6} .brdCmb >*{display:inline} .brdCmb .tl::before{content:attr(data-text)} .brdCmb .hm a{font-size:90%;opacity:.7}
/* Article Style */ .pS h1, .pS h2, .pS h3, .pS h4, .pS h5, .pS h6{margin:1.5em 0 18px; font-family:var(--fontBa);font-weight:900; line-height:1.5em} .pS h1:target, .pS h2:target, .pS h3:target, .pS h4:target, .pS h5:target, .pS h6:target{padding-top:var(--headerH);margin-top:0} /* Paragraph */ .pS p{margin:1.7em 0} .pIndent{text-indent:2.5rem} .onItm:not(.Rtl) .dropCap{float:left;margin:4px 8px 0 0; font-size:55px;line-height:45px;opacity:.8} .pS hr{margin:3em 0; border:0} .pS hr::before{content:'\2027 \2027 \2027'; display:block;text-align:center; font-size:24px;letter-spacing:0.6em;text-indent:0.6em;opacity:.8;clear:both} .pRef{display:block;font-size:14px;line-height:1.5em; opacity:.7; word-break:break-word} /* Img and Ad */ .pS img{display:inline-block;border-radius:8px;height:auto !important} .pS img.full{display:block !important; margin-bottom:10px; position:relative; width:100%;max-width:none} .pS .widget, .ps .pAd >*{margin:40px 0} /* Note */ .note{position:relative;padding:16px 20px 16px 50px; background:#e1f5fe;color:#3c4043; font-size:.85rem;font-family:var(--fontB);line-height:1.6em;border-radius:10px;overflow:hidden} .note::before{content:'';width:60px;height:60px;background:#81b4dc;display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .note::after{content:'\002A';position:absolute;left:18px;top:16px; font-size:20px; min-width:15px;text-align:center} .note.wr{background:#ffdfdf;color:#48525c} .note.wr::before{background:#e65151} .note.wr::after{content:'\0021'} /* Ext link */ .extL::after{content:''; width:14px;height:14px; display:inline-block;margin:0 5px; background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23989b9f' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M13 11L21.2 2.80005'/><path d='M22 6.8V2H17.2'/><path d='M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13'/></svg>") center / 14px no-repeat} /* Scroll img */ .psImg{display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:center; margin:2em 0; position:relative;left:-7px;right:-7px; width:calc(100% + 14px)} .psImg >*{width:calc(50% - 14px); margin:0 7px 14px; position:relative} .psImg img{display:block} .scImg >*{width:calc(33.3% - 14px); margin:0 7px} .btImg label{position:absolute;top:0;left:0;right:0;bottom:0; border-radius:3px; display:flex;align-items:center;justify-content:center; background:rgba(0,0,0,.6); transition:var(--trans-1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px); color:var(--darkT); font-size:13px;font-family:var(--fontB)} .hdImg .shImg{width:100%;margin:0; left:0;right:0; transition:var(--trans-1); max-height:0;opacity:0;visibility:hidden} .inImg:checked ~ .hdImg .shImg{max-height:1000vh;opacity:1;visibility:visible} .inImg:checked ~ .hdImg .btImg label{opacity:0;visibility:hidden} /* Post related */ .pRelate{margin:40px 0;padding:20px 0; border:1px solid #989b9f;border-left:0;border-right:0; font-size:14px;line-height:1.8em} .pRelate b{font-weight:400; margin:0;opacity:.8} .pRelate ul, .pRelate ol{margin:8px 0 0;padding:0 20px} /* Blockquote */ blockquote, .cmC i[rel=quote]{position:relative;font-size:.97rem; opacity:.8;line-height:1.6em;margin-left:0;margin-right:0;padding:5px 20px;border-left:2px solid var(--contentL)} blockquote.s-1, details.sp{font-size:.93rem; padding:25px 25px 25px 45px; border:1px solid #989b9f;border-left:0;border-right:0;line-height:1.7em} blockquote.s-1::before{content:'\201D';position:absolute;top:10px;left:0; font-size:60px;line-height:normal;opacity:.5}
/* Table */ .ps table{margin:0 auto; font-size:14px;font-family:var(--fontB)} .ps table:not(.tr-caption-container){min-width:90%;border:1px solid var(--contentL);border-radius:3px;overflow:hidden} .ps table:not(.tr-caption-container) td{padding:16px} .ps table:not(.tr-caption-container) tr:not(:last-child) td{border-bottom:1px solid var(--contentL)} .ps table:not(.tr-caption-container) tr:nth-child(2n+1) td{background:rgba(0,0,0,.01)} .ps table th{padding:16px; text-align:inherit; border-bottom:1px solid var(--contentL)} .ps .table{display:block; overflow-y:hidden;overflow-x:auto;scroll-behavior:smooth}/* Img caption */ figure{margin-left:0;margin-right:0} .ps .tr-caption, .psCaption, figcaption{display:block; font-size:14px;line-height:1.6em; font-family:var(--fontB);opacity:.7} /* Syntax */ .pre{background:var(--synxBg);color:var(--synxC); direction: ltr} .pre:not(.tb){position:relative;border-radius:3px;overflow:hidden;margin:1.7em auto;font-family:var(--fontC)} .pre pre{margin:0;color:inherit;background:inherit} .pre:not(.tb)::before, .cmC i[rel=pre]::before{content:'</>';display:flex;justify-content:flex-end;position:absolute;right:0;top:0;width:100%;background:inherit;color:var(--synxGray);font-size:10px;padding:0 10px;z-index:2;line-height:30px} .pre:not(.tb).html::before{content:'.html'} .pre:not(.tb).css::before{content:'.css'} .pre:not(.tb).js::before{content:'.js'} pre, .cmC i[rel=pre]{display:block;position:relative;font-family:var(--fontC);font-size:13px;line-height:1.6em;border-radius:3px;background:var(--synxBg);color:var(--synxC);padding:30px 20px 20px;margin:1.7em auto; -moz-tab-size:2;tab-size:2;-webkit-hyphens:none;-moz-hyphens:none;-ms-hyphens:none;hyphens:none; overflow:auto;direction:ltr;white-space:pre} pre i{color:var(--synxBlue);font-style:normal} pre i.block{color:#fff;background:var(--synxBlue)} pre i.green{color:var(--synxGreen)} pre i.gray{color:var(--synxGray)} pre i.red{color:var(--synxOrange)} pre i.blue{color:var(--synxBlue)} code{display:inline;padding:5px;font-size:14px;border-radius:3px;line-height:inherit;color:var(--synxC);background:#f2f3f5;font-family:var(--fontC)} /* Multi syntax */ .pre.tb{border-radius:5px} .pre.tb pre{margin:0;background:inherit} .pre.tb .preH{font-size:13px;border-color:rgba(0,0,0,.05);margin:0} .pre.tb .preH >*{padding:13px 20px} .pre.tb .preH::after{content:'</>';font-size:10px;font-family:var(--fontC);color:var(--synxGray);padding:15px;margin-left:auto} .pre.tb >:not(.preH){display:none} .pS input[id*="1"]:checked ~ div[class*="C-1"], .pS input[id*="2"]:checked ~ div[class*="C-2"], .pS input[id*="3"]:checked ~ div[class*="C-3"], .pS input[id*="4"]:checked ~ div[class*="C-4"]{display:block}
 

 



/* Accordion */ .showH{margin:1.7em 0;font-size:.93rem;font-family:var(--fontB);line-height:1.7em} details.ac{padding:18px 15px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);margin:20px 0;border-radius:10px} details.ac summary{font-weight:700;cursor:default; display:flex;align-items:baseline; transition:var(--trans-1);cursor:pointer} details.ac summary::before{content:'\203A'; flex:0 0 25px;display:flex;align-items:center;justify-content:flex-start;padding:0 5px; font-weight:400;font-size:1.33rem;color:inherit} details.ac[open] summary{color:var(--linkC)} details.ac:not(.alt)[open] summary::before{transform:rotate(90deg);padding:0 0 0 5px;justify-content:center} details.ac.alt summary::before{content:'\002B'; padding:0 2px} details.ac.alt[open] summary::before{content:'\2212'} details.ac .aC{padding:0 15px;opacity:.9} .drK details.sp, .drK details.ac{background:var(--darkBa)} .drK details.sp summary::after{background:var(--darkU)} /* Tabs */ .tbHd{display:flex; border-bottom:1px solid var(--contentL);margin-bottom:30px;font-size:14px;font-family:var(--fontB);line-height:1.6em; overflow-x:scroll;overflow-y:hidden;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .tbHd >*{padding:12px 15px; border-bottom:1px solid transparent; transition:var(--trans-1);opacity:.6;white-space:nowrap; scroll-snap-align:start} .tbHd >*::before{content:attr(data-text)} .tbCn >*{display:none;width:100%} .tbCn >* p:first-child{margin-top:0} .pS input[id*="1"]:checked ~ .tbHd label[for*="1"], .pS input[id*="2"]:checked ~ .tbHd label[for*="2"], .pS input[id*="3"]:checked ~ .tbHd label[for*="3"], .pS input[id*="4"]:checked ~ .tbHd label[for*="4"]{border-color:var(--linkB);opacity:1} .pS input[id*="1"]:checked ~ .tbCn div[class*="Text-1"], .pS input[id*="2"]:checked ~ .tbCn div[class*="Text-2"], .pS input[id*="3"]:checked ~ .tbCn div[class*="Text-3"], .pS input[id*="4"]:checked ~ .tbCn div[class*="Text-4"]{display:block} .tbHd.stick{position:-webkit-sticky;position:sticky;top:var(--headerH);background:var(--bodyB)} /* Split */ .ps .blogPg{font-size:13px; justify-content:center; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .ps .blogPg >*{padding:8px 15px;margin:0 4px 8px} /* Youtube fullpage */ .videoYt{position:relative;padding-bottom:56.25%; overflow:hidden;border-radius:5px} .videoYt iframe{position:absolute;width:100%;height:100%;left:0;right:0} /* Lazy Youtube */ .lazyYt{background:var(--synxBg);position:relative;overflow:hidden;padding-top:56.25%;border-radius:5px} .lazyYt img{width:100%;top:-16.84%;left:0;opacity:.95} .lazyYt img, .lazyYt iframe, .lazyYt .play{position:absolute} .lazyYt iframe{width:100%;height:100%;bottom:0;right:0} .lazyYt .play{top:50%;left:50%; transform:translate3d(-50%,-50%,0); transition:all .5s ease;display:block;width:70px;height:70px;z-index:1} .lazyYt .play svg{width:inherit;height:inherit; fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;stroke-width:8} .lazyYt .play .c{stroke:rgba(255,255,255,.85);stroke-dasharray:650;stroke-dashoffset:650; transition:all .4s ease-in-out; opacity:.3} .lazyYt .play .t{stroke:rgba(255,255,255,.75);stroke-dasharray:240;stroke-dashoffset:480; transition:all .6s ease-in-out; transform:translateY(0)} .lazyYt .play:hover .t{animation:nudge .6s ease-in-out;-webkit-animation:nudge .6s ease-in-out} .lazyYt .play:hover .t, .lazyYt .play:hover .c{stroke-dashoffset:0; opacity:.7;stroke:#FF0000} .nAmp .lazyYt{display:none} /* Button */ .button{display:inline-flex;align-items:center; margin:10px 0;padding:12px 15px;outline:0;border:0; border-radius:var(--buttonR);line-height:20px; color:#fffdfc; background:var(--linkB); font-size:14px;font-family:var(--fontB); white-space:nowrap;overflow:hidden;max-width:320px} .button.ln{color:inherit;background:transparent; border:1px solid var(--bodyCa)} .button.ln:hover{border-color:var(--linkB);box-shadow:0 0 0 1px var(--linkB) inset} .btnF{display:flex;justify-content:center; margin:10px 0;width:calc(100% + 12px);left:-6px;right:-6px;position:relative} .btnF >*{margin:0 6px} /* Download btn */ .dlBox{max-width:500px;background:#f1f1f0;border-radius:10px;padding:12px;margin:1.7em 0; display:flex;align-items:center; font-size:14px} .dlBox .fT{flex-shrink:0;display:flex;align-items:center;justify-content:center; width:45px;height:45px; padding:10px; background:rgba(0,0,0,.1);border-radius:5px} .dlBox .fT::before{content:attr(data-text);opacity:.7} .dlBox a{flex-shrink:0;margin:0;padding:10px 12px;border-radius:20px;font-size:13px} .dlBox a::after{content:attr(aria-label)} .dlBox .fN{flex-grow:1; width:calc(100% - 200px);padding:0 15px} .dlBox .fN >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .dlBox .fS{line-height:16px;font-size:12px;opacity:.8} /* Icon btn */ .icon{flex-shrink:0;display:inline-flex} .icon::before{content:'';width:18px;height:18px;background-size:18px;background-repeat:no-repeat;background-position:center} .icon::after{content:'';padding:0 6px} .icon.dl::before, .drK .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")} .icon.demo::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><path d='M7.39999 6.32003L15.89 3.49003C19.7 2.22003 21.77 4.30003 20.51 8.11003L17.68 16.6C15.78 22.31 12.66 22.31 10.76 16.6L9.91999 14.08L7.39999 13.24C1.68999 11.34 1.68999 8.23003 7.39999 6.32003Z'/><path d='M10.11 13.6501L13.69 10.0601'/></svg>")} .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2308102b' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")} /* Lightbox image */ .zmImg.s{position:fixed;top:0;left:0;bottom:0;right:0;width:100%;margin:0;background:rgba(0,0,0,.75); display:flex;align-items:center;justify-content:center;z-index:999; -webkit-backdrop-filter:saturate(180%) blur(15px); backdrop-filter:saturate(180%) blur(15px)} .zmImg.s img{display:block;max-width:92%;max-height:92%;width:auto;margin:auto;border-radius:10px;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .zmImg.s img.full{left:auto;right:auto;border-radius:10px;width:auto} .zmImg::after{content:'\2715';line-height:16px;font-size:14px;color:#fffdfc;background:var(--linkB); position:fixed;bottom:-20px;right:-20px; display:flex;align-items:center;justify-content:center;width:45px;height:45px;border-radius:50%; transition:var(--trans-1);opacity:0;visibility:hidden} .zmImg.s::after{bottom:20px;right:20px;opacity:1;visibility:visible;cursor:pointer}



/* Author profile */ .admPs{display:flex; max-width:480px;margin:30px 0; padding:12px 12px 15px; background:var(--contentBa);border-radius:8px; box-shadow:0 10px 25px -3px rgba(0,0,0,.1)} .admIm{flex-shrink:0; padding:5px 0 0} .admIm .im{width:34px;height:34px} .admI{flex-grow:1; width:calc(100% - 34px);padding:0 12px} .admN::before{content:attr(data-write) ' '; opacity:.7;font-size:90%} .admN::after{content:attr(data-text)} .admA{margin:5px 0 0; font-size:90%; opacity:.9;line-height:1.5em; /*display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden*/} /* Share btn */ .pSh{margin:15px 0;padding:18px 0;border-bottom:1px solid rgba(0,0,0,.05)} .pShc{display:flex;align-items:center;flex-wrap:wrap; position:relative;width:calc(100% + 18px);left:-9px;right:-9px;font-size:13px} .pShc::before{content:attr(data-text);margin:0 9px;flex-shrink:0} .pShc >*{margin: 0 5px;display: flex;align-items: center;color: inherit;padding: 12px;border-radius: 20px;background: #f1f1f0;} .pShc .c{color:#fffdfc} .pShc .c svg{fill:#fffdfc} .pShc .c::after{content:attr(aria-label)} .pShc .fb{background:#1778F2} .pShc .wa{background:#128C7E} .pShc .tw{background:#1DA1F2} .pShc a::after{content:attr(data-text);margin:0 3px} .pShc svg, .cpL svg{width:18px;height:18px; margin:0 3px} .shL{position:relative;width:calc(100% + 20px);left:-10px;right:-10px;/*margin-bottom:20px;*/display:flex;flex-wrap:wrap;justify-content:center} .shL >*{margin:0 10px 20px;text-align:center} .shL >*::after{content:attr(data-text);font-size:90%;opacity:.7;display:block} .shL a{display:flex;align-items:center;justify-content:center;flex-wrap:wrap; width:65px;height:65px; color:inherit;margin:0 auto 5px;padding:8px;border-radius:26px;background:#f1f1f0} .shL svg{opacity:.8} .cpL{padding-bottom:15px} .cpL::before{content:attr(data-text);display:block;margin:0 0 15px;opacity:.8} .cpL svg{margin:0 4px;opacity:.7} .cpL input{border:0;outline:0; background:transparent;color:rgba(8,16,43,.4); padding:18px 8px;flex-grow:1} .cpL label{display:flex;align-items:center;flex-shrink:0;padding:2px 8px;border-radius:15px}.cpLb{display:flex;align-items:center;position:relative;background:#f1f1f0;border-radius:10px; padding:0 8px} .cpLb:hover{border-color:rgba(0,0,0,.42);background:#ececec} .cpLn span{display:block;padding:5px 14px 0;font-size:90%;color:#2e7b32; transition:var(--trans-1);animation:fadein 2s ease forwards; opacity:0;height:22px} /* Comments */ .pCmnts{margin-top:50px} .cmDis{text-align:center;margin-top:20px;opacity:.7} .cmMs{margin-bottom:20px} .cm iframe{width:100%} .cm:not(.cmBr) .cmBrs{background:transparent;position:relative;padding:60px 20px 0;width:calc(100% + 40px);left:-20px;right:-20px} .cmH h3.title{margin:0;flex-grow:1;padding:16px 10px} .cmH .s{margin:0 14px} .cmH .s::before{content:attr(data-text);margin:0 6px;opacity:.7;font-size:90%} .cmH .s::after{content:'\296E';line-height:18px;font-size:17px} .cmAv .im{width:35px;height:35px;border-radius:50%;position:relative} .cmBd.del .cmCo{font-style:italic;font-size:90%;line-height:normal;border:1px dashed rgba(0,0,0,.2);border-radius:3px;margin:.5em 0;padding:15px;opacity:.7; overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .cmHr{line-height:24px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .cmHr .d{font-size:90%;opacity:.7} .cmHr .d::before{content:'\00B7';margin:0 7px} .cmHr.a .n{display:inline-flex;align-items:center} .cmHr.a .n::after{content:'\2714';display:flex;align-items:center;justify-content:center;width:14px;height:14px;font-size:8px;background:#519bd6;color:#fefefe;border-radius:50%;margin:0 3px} .cmCo{line-height:1.6em;opacity:.9} .cmC i[rel=image]{font-size:90%; display:block;position:relative; min-height:50px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap; margin:1em auto} .cmC i[rel=image]::before{content:'This feature isn\0027t available!';border:1px dashed rgba(0,0,0,.2);border-radius:3px;padding:10px;display:flex;align-items:center;justify-content:center;position:absolute;top:0;left:0;bottom:0;right:0;background:var(--contentB)} .cmC i[rel=pre], .cmC i[rel=quote]{margin-top:1em;margin-bottom:1em; font-style:normal;line-height:inherit;padding:20px} .cmC i[rel=pre]::before{display:block;width:auto} .cmC i[rel=quote]{display:block;font-style:italic;font-size:inherit;padding:5px 15px} .cmCo img{margin-top:1em;margin-bottom:1em} .cmAc{margin-top:10px} .cmAc a{font-size:90%;color:inherit;opacity:.7;display:inline-flex} .cmAc a::before{content:'\2934';line-height:18px;font-size:16px;transform:rotate(90deg)} .cmAc a::after{content:attr(data-text);margin:0 6px} .cmR{margin:10px 40px 0} .cmRp ~ .cmAc, .cmBd.del ~ .cmAc, .onItm:not(.Rtl) .cmHr .date{display:none} .cmRi:checked ~ .cmRp .thTg{margin-bottom:0} .cmRi:checked ~ .cmRp .thTg::after{content:attr(aria-label)} .cmRi:checked ~ .cmRp .thCh, .cmRi:checked ~ .cmRp .cmR{display:none} .cmAl:checked ~ .cm .cmH .s::before{content:attr(data-new)} .cmAl:checked ~ .cm .cmCn >ol{flex-direction:column-reverse} .thTg{display:inline-flex;align-items:center;margin:15px 0 18px;font-size:90%} .thTg::before{content:'';width:28px;border-bottom:1px solid var(--widgetTac);opacity:.5} .thTg::after{content:attr(data-text);margin:0 12px;opacity:.7} .cmCn ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column} .cmCn li{margin-bottom:18px;position:relative} .cmCn li .cmRbox{margin-top:20px} .cmCn li li{display:flex;flex-wrap:wrap;width:calc(100% + 12px);left:-6px;right:-6px} .cmCn li li:last-child{margin-bottom:0} .cmCn li li .cmAv{flex:0 0 28px;margin:0 6px} .cmCn li li .cmAv .im{width:28px;height:28px} .cmCn li li .cmIn{width:calc(100% - 52px);margin:0 6px} .cmHl >li{padding-left:17.5px} .cmHl >li >.cmAv{position:absolute;left:0;top:12px} .cmHl >li >.cmIn{padding:12px 15px 12px 28px;border:1px solid var(--contentL);border-radius:12px;box-shadow:0 10px 8px -10px rgba(0,0,0,.1)} /* Comments Show/Hide */ #comment:target{margin:0;padding-top:60px} .cmSh:checked ~ .cmShw, .cmShw ~ .cm:not(.cmBr), #comment:target .cmShw, #comment:target .cmSh:checked ~ .cm:not(.cmBr){display:none} .cmSh:checked ~ .cm:not(.cmBr), #comment:target .cm:not(.cmBr), #comment:target .cmSh:checked ~ .cmShw{display:block} .cmBtn{display:block;padding:20px;text-align:center;max-width:100%} .cmBtn.ln:hover{color:var(--linkB)} /* Comments Pop-up */ #comment:target .cmSh:checked ~ .cm.cmBr{bottom:-100%;opacity:0;visibility:hidden} #comment:target .cmSh:checked ~ .cm.cmBr .fCls{opacity:0;visibility:hidden}
/* Widget Style */ .widget .imgThm{display:block;position:absolute;top:50%;left:50%;max-width:none;max-height:108%; font-size:12px;text-align:center; transform:translate(-50%, -50%)} .widget .title{margin:0 0 25px; font-size:var(--widgetT);font-weight:var(--widgetTw);position:relative;/*margin-top:20px*/}.widget .title.dt::before{position:absolute;top:0;right:0;content:'';width:20px;height:20px;display:inline-block;opacity:.3;background:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 276.167 276.167' fill='%23989b9f'><path d='M33.144,2.471C15.336,2.471,0.85,16.958,0.85,34.765s14.48,32.293,32.294,32.293s32.294-14.486,32.294-32.293 S50.951,2.471,33.144,2.471z'/><path d='M137.663,2.471c-17.807,0-32.294,14.487-32.294,32.294s14.487,32.293,32.294,32.293c17.808,0,32.297-14.486,32.297-32.293 S155.477,2.471,137.663,2.471z'/><path d='M243.873,67.059c17.804,0,32.294-14.486,32.294-32.293S261.689,2.471,243.873,2.471s-32.294,14.487-32.294,32.294 S226.068,67.059,243.873,67.059z'/><path d='M243.038,170.539c17.811,0,32.294-14.483,32.294-32.293c0-17.811-14.483-32.297-32.294-32.297 s-32.306,14.486-32.306,32.297C210.732,156.056,225.222,170.539,243.038,170.539z'/><path d='M136.819,170.539c17.804,0,32.294-14.483,32.294-32.293c0-17.811-14.478-32.297-32.294-32.297 c-17.813,0-32.294,14.486-32.294,32.297C104.525,156.056,119.012,170.539,136.819,170.539z'/><path d='M243.771,209.108c-17.804,0-32.294,14.483-32.294,32.294c0,17.804,14.49,32.293,32.294,32.293 c17.811,0,32.294-14.482,32.294-32.293S261.575,209.108,243.771,209.108z'/></svg>") center / 20px no-repeat} .Rtl .widget .title::before{right:auto;left:0;transform:rotate(-90deg);-webkit-transform:rotate(-90deg)} .widget .title::after{content:'';display:inline-block;vertical-align:middle; width:var(--widgetTa); margin:0 10px;border-bottom:1px solid var(--widgetTac); opacity:.5} .widget input[type=text]:focus, .widget input[type=email]:focus, .widget input[type=password]:focus, .widget input[type=number]:focus, .widget textarea:focus, .widget input[data-text=fl], .widget textarea[data-text=fl]{border-color:var(--linkB);background:#ececec} .widget input[type=button], .widget input[type=submit]{display:inline-flex;align-items:center; padding:12px 30px; outline:0;border:0;border-radius:4px; color:#fffdfc; background:var(--linkB); font-size:14px; white-space:nowrap;overflow:hidden;max-width:100%} .widget input[type=button]:hover, .widget input[type=submit]:hover{opacity:.7}/* Widget BlogSearch */ .BlogSearch{position:fixed;top:0;left:0;right:0;z-index:12} .BlogSearch form{position:relative;min-width:320px} .BlogSearch input{position:relative;display:block;background:var(--srchB);border:0;outline:0;margin-top:-100%;padding:10px 55px;width:100%;height:72px;transition:var(--trans-1);z-index:2;border-radius:0 0 12px 12px} .BlogSearch input:focus{margin-top:0;box-shadow:0 10px 40px rgba(0,0,0,.2)} .BlogSearch input:focus ~ button.sb{opacity:.9} .BlogSearch .sb{position:absolute;left:0;top:0;display:flex;align-items:center;padding:0 20px;z-index:3;opacity:.7;height:100%;background:transparent;border:0;outline:0} .BlogSearch .sb svg{width:18px;height:18px;stroke:var(--srchI)} .BlogSearch button.sb{left:auto;right:0;opacity:0;font-size:13px} .BlogSearch button.sb::before{content:'\2715'} @media screen and (min-width:897px){header .BlogSearch{position:static;z-index:1} header .BlogSearch input{margin-top:0;padding:12px 42px;height:auto;font-size:13px;border-radius:20px;background:var(--transB); width:calc(100% + 26px);left:-13px;right:-13px;transition:var(--trans-2)} header .BlogSearch input:hover{background:var(--transB)} header .BlogSearch input:focus{box-shadow:none;margin-top:0; background:var(--transB)} header .BlogSearch .sb{padding:0} header .BlogSearch .fCls{display:none}}/* Widget Profile */ .prfI:checked ~ .mainWrp .wPrf{top:0;opacity:1;visibility:visible} .prfI:checked ~ .mainWrp .wPrf ~ .fCls{z-index:3;opacity:1;visibility:visible} .wPrf{display:flex;position:absolute;top:-5px;right:0;background:var(--contentB);border-radius:16px 5px 16px 16px;width:260px;max-height:400px;box-shadow:0 10px 25px -3px rgba(0,0,0,.1);transition:var(--trans-1);z-index:4;opacity:0;visibility:hidden;overflow:hidden} .wPrf .prfS{background:inherit} .wPrf.tm .im{width:39px;height:39px;flex-shrink:0} .wPrf.sl .im{width:60px;height:60px;border-radius:26px;margin:0 auto} .wPrf.sl .prfC{text-align:center} .prfH .c{display:none} .prfL{display:flex;align-items:center;position:relative;width:calc(100% + 16px);left:-8px;right:-8px;border-radius:8px;padding:8px 0;transition:var(--trans-1)} .prfL::after{content:attr(data-text);margin:0 2px} .prfL >*{margin:0 8px;flex-shrink:0} a.prfL:hover{background:var(--transB)} .sInf{margin-bottom:0} .sInf .sDt .l{display:inline-flex;align-items:center} .sInf .sTxt{margin:5px auto 0;max-width:320px;font-size:93%;opacity:.9;line-height:1.5em} .sInf .sTxt a{text-decoration:underline} .sInf .lc{display:flex;justify-content:center;margin:10px 0 0;opacity:.8;font-size:90%} .sInf .lc svg{width:16px;height:16px} .sInf .lc::after{content:attr(data-text);margin:0 4px} /* Widget FeaturedPost */ @media screen and (min-width:501px){.FeaturedPost .itemFt{position:relative;overflow:hidden;padding:10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .drK .FeaturedPost .itemFt{background:var(--darkBa)} .FeaturedPost .itemFt::after{content:'';position: absolute;right:0;top:0;width:40px;height:15px;}} .itemFt .itm >*{flex:0 0 310px;width:310px} .itemFt .itm >*:last-child{flex:1 0 calc(100% - 310px - 40px);width:calc(100% - 310px - 40px)} .drK .FeaturedPost .itemFt::after{background:var(--darkU);} 

  

/* Widget PopularPosts */ .PopularPosts{padding:17px 20px 30px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .itemPp{counter-reset:p-cnt} .itemPp .iCtnt{display:flex} .itemPp >*:not(:last-child){margin-bottom:25px} .itemPp .iCtnt::before{flex-shrink:0;content:'0' counter(p-cnt);counter-increment:p-cnt;width:25px;opacity:.6;font-size:85%;line-height:1.8em} .iInr{flex:1 0;width:calc(100% - 25px)} .iTtl{font-size:.95rem;font-weight:700;line-height:1.5em} .iTtmp{display:none} .iTtmp::after{content:'\2014';margin:0 5px; color:var(--widgetTac);opacity:.7} .iInf{margin:0 25px 8px; overflow:hidden;white-space:nowrap;text-overflow:ellipsis} .iInf .pLbls >*{color:#fefefe;display:inline;margin-right:5px;border-radius: 20px;background:#06D7A0;height:24px;padding:0 10px}.iInf .pLbls >*:hover{text-decoration:none;color:#0b57cf;background:rgba(0,0,0,.05);font-weight:normal}.iInf .pLbls a:nth-child(1){background:var(--linkB)}.iInf .pLbls a:nth-child(2){background:var(--darkU)}.iInf .pLbls a:nth-child(3){background:var(--linkC)}
/* Widget Label */ /* List Label */ .Label{padding:20px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .wL ul{display:flex;flex-wrap:wrap; list-style:none;margin:0;padding:0; position:relative;width:calc(100% + 30px);left:-15px;right:-15px; font-size:13px} .wL li{width:calc(50% - 10px); margin:0 5px} .wL li >*{display:flex;align-items:baseline;justify-content:space-between; color:var(--bodyC);width:100%; padding:8px 10px;border-radius:35px;line-height:20px} .wL li >* svg{width:18px;height:18px;opacity:.8} .wL li >*:hover svg, .wL li >div svg{/*fill:var(--linkC) !important;*/stroke:var(--linkC)} .wL li >*:hover .lbC, .wL li >div .lbC{color:var(--linkC)} .wL .lbR{display:inline-flex;align-items:center} .wL .lbR .lbC{margin:0 5px} .wL .lbAl{max-height:0; overflow:hidden; transition:var(--trans-4)} .wL .lbM{display:inline-block; margin-top:10px;line-height:20px; color:var(--linkC)} .wL .lbM::before{content:attr(data-show)} .wL .lbM::after, .wL .lbC::after{content:attr(data-text)} .wL .lbM::after{margin:0 8px} .wL .lbT{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.7} .wL .lbC, .wL .lbM::after{flex-shrink:0;font-size:12px;opacity:.7} .lbIn:checked ~ .lbAl{max-height:1000vh} .lbIn:checked ~ .lbM::before{content:attr(data-hide)} .lbIn:checked ~ .lbM::after{visibility:hidden} .wL.bg ul{width:calc(100% + 10px);left:-5px;right:-5px} .wL.bg li{margin-bottom:10px} .wL.bg li >*{background:#f6f6f6} /* Cloud Label */ .wL.cl{display:flex;flex-wrap:wrap} .wL.cl >*, .wL.cl .lbAl >*{display:block;max-width:100%} .wL.cl .lbAl{display:flex;flex-wrap:wrap} .wL.cl .lbC::before{content:'';margin:0 4px;flex:0 0} .wL.cl .lbN{display:flex;justify-content:space-between; margin:0 0 8px;padding:9px 13px; border:1px solid var(--contentL);border-radius:20px; color:inherit;line-height:20px} .wL.cl .lbN:hover .lbC, .wL.cl div.lbN .lbC{color:var(--linkB); opacity:1} .wL.cl .lbN:not(div):hover, .wL.cl div.lbN{border-color:var(--linkB)} .wL.cl .lbSz{display:flex} .wL.cl .lbSz::after{content:'';margin:0 4px;flex:0 0}/* Widget ContactForm */ .ContactForm{max-width:500px; font-family:var(--fontB);font-size:14px} .cArea:not(:last-child){margin-bottom:25px} .cArea label{display:block;position:relative} .cArea label .n{display:block;position:absolute;left:0;right:0;top:0; color:rgba(8,16,43,.4);line-height:1.6em;padding:15px 16px 0;border-radius:4px 4px 0 0;transition:var(--trans-1)} .cArea label .n.req::after{content:'*';font-size:85%} .cArea textarea{height:100px} .cArea textarea:focus, .cArea textarea[data-text=fl]{height:200px} .cArea input:focus ~ .n, .cArea textarea:focus ~ .n, .cArea input[data-text=fl] ~ .n, .cArea textarea[data-text=fl] ~ .n{padding-top:5px;color:rgba(8,16,43,.7);font-size:90%;background:#ececec} .cArea .h{display:block;font-size:90%;padding:5px 16px 0;opacity:.7;line-height:normal} .nArea .contact-form-error-message-with-border{color:#d32f2f} .nArea .contact-form-success-message-with-border{color:#2e7b32} /* Widget Sliders */ .sldO{position:relative;display:flex;overflow-y:hidden;overflow-x:scroll; scroll-behavior:smooth;scroll-snap-type:x mandatory;list-style:none;margin:0;padding:0; -ms-overflow-style: none} .sldO.no-items{display:none} .sldO.no-items + .section{margin-top:0} .sldO .widget:not(:first-child){margin-top:0} .sldO .widget{position:relative;flex:0 0 100%;width:100%;background:transparent; outline:0;border:0} .sldC{position:relative} .sldS{position:absolute;top:0;left:0;width:100%;height:100%;scroll-snap-align:center;z-index:-1} .sldIm{background-repeat:no-repeat;background-size:cover;background-position:center;background-color:var(--transB);display:block;padding-top:40%;border-radius:3px;color:#fffdfc;font-size:13px} .sldT{position:absolute;bottom:0;left:0;right:0;display:block;padding:20px; background:linear-gradient(0deg, rgba(30,30,30,.1) 0%, rgba(30,30,30,.05) 60%, rgba(30,30,30,0) 100%); border-radius:0 0 3px 3px} .sldS{animation-name:tonext, snap;animation-timing-function:ease;animation-duration:4s;animation-iteration-count:infinite} .sldO .widget:last-child .sldS{animation-name:tostart, snap} .Rtl .sldS{animation-name:tonext-rev, snap} .Rtl .sldO .widget:last-child .sldS{animation-name:tostart-rev, snap} .sldO:hover .widget .sldS, .Rtl .sldO:hover .widget .sldS, .sldO:focus-within .widget .sldS, .Rtl .sldO:focus-within .widget .sldS{animation-name:none} @media (prefers-reduced-motion:reduce){.sldS, .Rtl .sldS{animation-name:none}} @media screen and (max-width:640px){.sldO{width:calc(100% + 40px);left:-20px;right:-20px;padding:0 12.5px 10px} .sldO .widget{flex:0 0 90%;width:90%;margin:0 7.5px; box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%)} .sldT{padding:10px 15px} .sldIm{font-size:12px}}
/* Responsive */
@media screen and (min-width:768px){::-webkit-scrollbar{-webkit-appearance:none;width:8px;height:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--scrlC);border-radius:10px}::-webkit-scrollbar-thumb:hover{background:var(--scrlC)}::-webkit-scrollbar-thumb:active{background:var(--scrlC)}}
@media screen and (min-width:897px){/* mainIn */ .mainIn, .blogM{display:flex} .blogMn{width:var(--navW);flex-shrink:0;position:relative;transition:var(--trans-1);z-index:1} .blogCont{padding-top:30px} .blogCont::before{content:'';position:absolute;top:var(--headerHi);left:0;height:calc(100% + var(--headerH));border-right:var(--navL) solid var(--contentL)} .blogCont{width:calc(100% - var(--navW))} .blogCont .secIn{padding-left:25px;padding-right:25px} .mainbar{flex:1 0 calc(100% - var(--sideW) - 25px);width:calc(100% - var(--sideW) - 25px)} .sidebar{display:flex;flex:0 0 calc(var(--sideW) + 25px);width:calc(var(--sideW) + 25px); margin:0} .sidebar::before{content:'';flex:0 0 25px} .sidebar .sideIn{width:calc(100% - 25px)} /* mainNav */ .mnBr{position:sticky;position:-webkit-sticky;top:var(--headerH)} .mnBrs{display:flex;height:calc(100vh - var(--headerH));font-size:13px;position:relative} .mnBrs >*:not(.mnMob){width:100%} .mnMen{padding:20px;overflow-y:hidden;overflow-x:hidden} .mnMen:hover{overflow-y:scroll} .mnMob{position:fixed;width:var(--navW)} .mnH, .mobMn{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .blogMn, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob, .hdMn .navI:not(:checked) ~ .mainWrp .blogMn, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob{width:75px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn a:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn a:hover{opacity:1;color:inherit} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .a, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .a{max-width:40px; border-radius:15px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .drp.mr, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn svg.d, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .PageList, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mSoc, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .drp.mr, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn svg.d, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .PageList, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mSoc{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mNav, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mNav{display:flex} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn >li.br::after, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn >li.br::after{max-width:20px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen:hover{overflow-y:visible;overflow-x:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{position:absolute;left:35px;top:3px;margin:0 5px;padding:8px 10px;border-radius:5px 16px 16px 16px;max-width:160px;background:var(--contentB);color:var(--bodyC);opacity:0;visibility:hidden;box-shadow:0 5px 20px 0 rgba(0,0,0,.1);z-index:1} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{padding:0 5px;margin:0;overflow:hidden;display:block} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):last-child ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):last-child ul{top:auto;bottom:3px;border-radius:16px 16px 16px 5px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):hover ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):hover ul{opacity:1;visibility:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn ul li >*, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn ul li >*{border-radius:0} /* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} .onIndx.onMlt .blogPts >*{flex:0 0 calc(25% - 20px);width:calc(25% - 20px)} /* Widget ToC */ .tocL{position:absolute;z-index:2} .tocLi::before{content:'';border-left:1px solid var(--contentL);position:absolute;top:0;bottom:0;left:0;z-index:1} .tocLs{position:-webkit-sticky;position:sticky;top:var(--headerH)} .tocC{top:40px} .tocI:checked ~ .tocL{z-index:2} .tocI:checked ~ .tocL .fCls{background:transparent}}
@media screen and (min-width:768px){::-webkit-scrollbar{-webkit-appearance:none;width:4px;height:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:10px}::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.35)}::-webkit-scrollbar-thumb:active{background:rgba(0,0,0,.35)}}
@media screen and (max-width:1100px){
/* Article */ .onIndx.onHm .blogPts >*, .onIndx.onBlg .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} 
/* Widget */ .itemFt .itm >*, .itemFt .itm >*:last-child{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} .itemFt .itm >*:last-child{flex-grow:1} .itemFt .pSnpt{display:none}
/* Footer */  .fotIn >*, .fotIn >*:first-child{width:calc(50% - 30px)}}
@media screen and (max-width:896px){/* Header */ .ntfC{padding-left:20px;padding-right:20px} .headI .headS{margin:0} /* mainNav */ .blogMn{display:flex;justify-content:flex-start;position:fixed;left:0;top:0;bottom:0;margin-left:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%} .mnBr{width:80%;top:2%;left:3%;bottom:2%;max-width:480px;height:96%;border-radius:15px 15px 15px 15px;transition:var(--trans2);z-index:3;overflow:hidden;position:relative;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .mnBrs{padding:60px 0 0;overflow-y:scroll;overflow-x:hidden;width:100%;height:100%} .mnH{padding:0 15px} .mnH label{padding:15px 10px} .mnH .c::after{margin:0 13px} .mnMen{padding-top:0} .navI:checked ~ .mainWrp .blogMn{margin-left:0} .navI:checked ~ .mainWrp .blogMn .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} /* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} /* Widget */ .itemFt .pSnpt{display:-webkit-box} .mobMn:not(.no-items) + footer{padding-bottom:calc(55px + 20px)}}
@media screen and (max-width:768px){/* Article */ .onIndx.onHm .blogPts >*, .onIndx.onMlt .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)}}
@media screen and (max-width:640px){/* Header */.headCn{height:var(--headerHm)}/* Footer */ footer{padding-top:30px} /* Pop-up */ .fixL{align-items:flex-end} .fixL .fixLi, .fixL .cmBri{border-radius:12px 12px 0 0; max-width:680px} .fixL .cmBri:not(.mty){border-radius:0;height:100%;max-height:100%}}
@media screen and (max-width:500px){/* Font and Blog */ .iFxd, .crdtIn{font-size:12px} .brdCmb{font-size:13px} .pDesc{font-size:14px} .pEnt{font-size:var(--postFm)} .pTtl.itm{font-size:var(--postTm)} .pInf.ps .pTtmp::after{content:attr(data-time)} .pInf.ps .pDr{font-size:12px} .pInf .pNm, .pInf .pDr{display:flex;flex-direction:column} .pInf .pDr >*:not(:first-child)::before{display:none}
/* Article */ .onIndx:not(.oneGrd) .blogPts{width:calc(100% + 15px);left:-7.5px;right:-7.5px} .onIndx:not(.oneGrd) .blogPts >*{flex:0 0 calc(50% - 15px);width:calc(50% - 15px);margin-left:7.5px;margin-right:7.5px} .onIndx:not(.oneGrd) .blogPts div.ntry{flex:0 0 calc(100% - 15px)} .onIndx:not(.oneGrd) .ntry .pSml{font-size:12px} .onIndx:not(.oneGrd) .ntry .pTtl{font-size:.9rem} .onIndx:not(.oneGrd) .ntry:not(.pTag) .pSnpt, .onIndx:not(.oneGrd) .ntry .pInf:not(.nSpr) .pJmp, .onIndx:not(.oneGrd) .ntry .iFxd .spnr{display:none} .onIndx:not(.oneGrd) .ntry .iFxd{padding:8px 3px} .onIndx:not(.oneGrd) .ntry .iFxd .cmnt{padding:3px} .onIndx:not(.oneGrd) .ntry .iFxd >* svg{padding:1px} .onIndx.oneGrd .blogPts >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)} /* Share */ .pShc{width:calc(100% + 10px);left:-5px;right:-5px} .pShc::before{width:calc(100% - 10px);margin:0 5px 12px} .pShc .wa::after, .pShc .tw::after{display:none} /* Widget */ .prfI:checked ~ .mainWrp .wPrf{top:auto;bottom:0} .prfI:checked ~ .mainWrp .Profile .fCls{background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .prfH .c{display:flex} .wPrf{position:fixed;top:auto;left:0;right:0;bottom:-100%;width:100%;max-height:calc(100% - var(--headerH));border-radius:12px 12px 0 0} .itemFt .itm{padding-bottom:80px} .itemFt .itm >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)} .itemFt .itm .iCtnt{flex:0 0 calc(100% - 42px);width:calc(100% - 42px);margin:0 auto;position:absolute;left:0;right:0;bottom:0;padding:13px;background:rgba(255,253,252,.92);border-radius:10px;box-shadow:0 10px 20px -5px rgba(0,0,0,.1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .itemFt .pTtl{font-size:1rem} .itemFt .pSnpt{font-size:93%}/* Footer */ .fotIn >*, .fotIn >*:first-child{width:calc(100% - 30px)}}

/* Noscript Option */ .lazy:not([lazied]){display:none} .noJs{display:flex;justify-content:flex-end;align-items:center;position:fixed;top:20px;left:20px;right:20px;z-index:99;max-width:640px;border-radius:12px;margin:auto;padding:10px 5px;background:#ffdfdf;font-size:13px;box-shadow:0 10px 20px -10px rgba(0,0,0,.1);color:#48525c} .noJs::before{content:attr(data-text);padding:0 10px;flex-grow:1} .noJs label{flex-shrink:0;padding:10px} .noJs label::after{content:'\2715';line-height:18px;font-size:14px} .nJs:checked ~ .noJs{display:none}
/* Hide Scroll */ .scrlH::-webkit-scrollbar{width:0;height:0} .scrlH::-webkit-scrollbar-track{background:transparent} .scrlH::-webkit-scrollbar-thumb{background:transparent;border:none}


svg{width:16px;height:16px;margin-right:6px}
#greeting .greeting{font-size:14px}
.greeting{display:inline-flex;align-items:center;margin:10px 0;padding:12px 15px;outline:0;border:0;border-radius:20px;line-height:20px;font-size:14px;white-space:nowrap;overflow:hidden;max-width:320px;box-shadow:-6px -6px 14px rgba(255,255,255,.7),-6px -6px 10px rgba(255,255,255,.5),6px 6px 8px rgba(255,255,255,.075),6px 6px 10px rgba(0,0,0,.15)}
.drK  .greeting{box-shadow:0 10px 40px rgba(0,0,0,.2);color:#fefefe}
  

/* Change Mode */ .headR .headM{display:block;position:absolute;top:0;right:0;padding:10px 0;width:150px;background:var(--contentB);font-size:13px;border-radius:10px 5px 10px 10px;box-shadow:0 0 15px rgba(0,0,0,.07);-webkit-transition:var(--trans-2);transition:var(--trans-2);overflow:hidden;z-index:18;opacity:0;visibility:hidden} .headR .headM:before{content:attr(data-text);display:block;padding:0 15px 10px;width:100%;font-size:11px;opacity:.7} .headR .headM >*{display:block;padding:9px 15px;width:100%;cursor:pointer} .headR .headM >*:before{content:attr(aria-label);opacity:.9} .headR .headM >*:hover{background:rgba(0,0,0,.05)} .navM:checked ~ .mainWrp .headM{visibility:visible;opacity:1} .navM:checked ~ .mainWrp .headM + .fCls{visibility:visible;opacity:1;z-index:17} .headR .headM .sydB{display:none} .bD:not(.drK):not(.syD) .headR .headM .lgtB{background-color:rgba(0,0,0,.1)} .drK:not(.syD) .headR .headM .drkB{background-color:rgba(0,0,0,.1)} .syD .headR .headM .sydB{background-color:rgba(0,0,0,.1)} .drK .headR .headM{background:var(--darkBs)} .Rtl .headR .headM{right:auto;left:0;border-radius:5px 10px 10px 10px}
/* Author No Image */ .aFl{position:relative;width:28px;height:28px;display:flex;align-items:center;justify-content:center;border-radius:50%;overflow:hidden} .admPs .aFl{width:34px;height:34px} .aFl::before{content:'';position:absolute;z-index:0;top:0;right:0;bottom:0;left:0;background:var(--linkB);opacity:.8} .aFl >span{position:absolute;z-index:1;font-size:0;color:transparent;padding-top:1.5px;} .admPs .aFl >span{padding-top:2px} .aFl >span:first-letter{color:#fffdfc;font-size:13px} .admPs .aFl >span:first-letter{font-size:16px} .drK .aFl::before{background:var(--darkU);opacity:1}
/* Dark Mode */ .drK.onIndx .blogPts >*, .drK .rPst, .drK .PopularPosts, .drK .Label{background:var(--darkBa)} .drK .tDL .d2{display:block} .drK .tDL::after{content:attr(data-light)} .drK .tDL svg .f{stroke:none;fill:var(--darkT)}  .drK .pThmb:not(.nul)::before{background-image:linear-gradient(90deg, rgba(0,0,0,0) 0, rgba(0,0,0,.07) 20%, rgba(0,0,0,.1) 60%, rgba(0,0,0,0))} .drK input::placeholder, .drK .cpL input, .drK .cArea label .n{color:rgba(255,255,255,.25)} .drK .erroC h3 span.e{color:var(--darkBa)} .drK .nArea .contact-form-error-message-with-border{color:#f94f4f} .drK .cmC i[rel=image]::before, .drK .widget input[type=text], .drK .widget input[type=email], .drK .widget textarea{background:var(--darkBs);border-color:rgba(255,255,255,.15)} .drK svg, .drK svg.c-1{fill:var(--darkT)} .drK svg.line, .drK .ancrC svg{fill:none;stroke:var(--darkT)} .drK svg.c-2{fill:var(--darkTa); opacity:.4} .drK, .drK .headCn, .drK .mnBrs{background:var(--darkB);color:var(--darkT)} .drK .ntfC, .drK .mobMn{background:var(--darkBa);color:var(--darkTa)} .drK .ntfC{color:rgba(255,255,255,.9)} .drK header, .drK .mnMn >li.br::after, .drK .blogCont::before, .drK .tbHd, .drK .cmHl >li >.cmIn, .drK .pTag .pMart a, .drK .pRelate, .drK blockquote, .drK .cmC i[rel=quote], .drK blockquote.s-1, .drK details.sp, .drK .ps table:not(.tr-caption-container), .drK .ps table th, .drK .ps table:not(.tr-caption-container) tr:not(:last-child) td, .drK .pre.tb .preH, .drK details.ac, .drK .ancrA, .drK .ancrC, .drK .mnMob{border-color:rgba(255,255,255,.15)} .drK .pre{background:var(--darkBs);color:var(--darkT)} .drK .footer{background:var(--darkBs)} .drK .mnMn li:not(.mr) .a:hover, .drK .mnMn ul li >*:hover, .drK .wL.bg li >*, .drK .mobMn li >*:hover, .drK .shL a, .drK .cpLb{background:rgba(0,0,0,.15)} .drK .tIc::after{background:var(--darkBs)} .drK .wPrf{background:var(--darkBa);box-shadow:0 10px 40px rgba(0,0,0,.2)} .drK header a, .drK h1, .drK h2, .drK h3, .drK h4, .drK h5, .drK h6, .drK footer, .drK .button{color:var(--darkT)} .drK .dlBox, .drK .fixLs, .drK .cArea input:focus ~ .n, .drK .cArea textarea:focus ~ .n, .drK .cArea input[data-text=fl] ~ .n, .drK .cArea textarea[data-text=fl] ~ .n{background:var(--darkBs)} .drK .tocLi{background:var(--darkB)} .drK .admPs, .drK .tocC span, .drK .pShc >*:not(.c), .drK .ancrA, .drK .BlogSearch input, .drK .cmHl >li >.cmIn{background:var(--darkBa)} .drK .tocC span::before{background:var(--darkBa)} .drK .tocC span::after{background:var(--darkU)} .drK .tocL svg.rad{fill:var(--darkBa)} .drK .mobMn li >*:hover svg.line{fill:var(--darkT) !important} .drK .mobMn li >*:hover svg.line .svgC{fill:var(--darkU) !important;stroke:var(--darkU)} .drK.mobS .mobMn li >*:hover, .drK .button.ln{background:transparent} .drK .pTag .pPric::before, .drK .pTag .pInfo small{color:var(--darkTa)} .drK::selection, .drK a, .drK .free::after, .drK .new::after, .drK .mnMn li:not(.mr) .a:hover, .drK .mnMn ul li a:hover, .drK .aTtl a:hover, .drK .pSnpt.nTag, .drK .pTag .pPric, .drK details.ac[open] summary, .drK .cpL label, .drK .wL li >*:hover .lbC, .drK .wL li >div .lbC, .drK .wL .lbM, .drK .cmBtn.ln:hover, .drK .wL.cl .lbN:hover .lbC, .drK .wL.cl div.lbN .lbC{color:var(--darkU)} .drK .mnMn .a:hover svg:not(.d){fill:var(--darkU)} .drK .mnMn .a:hover svg.line:not(.d), .drK .pJmp svg{fill:none;stroke:var(--darkU)} .drK .wL li >*:hover svg, .drK .wL li >div svg{stroke:var(--darkU)} .drK.MN-3 .mobMn li >*:hover::after, .drK.MN-4 .mobMn li >*:hover::after, .drK .toTopF, .drK .blogPg >*, .drK .button, .drK .zmImg::after, .drK .widget input[type=button], .drK .widget input[type=submit]{background:var(--darkU)} .drK.MN-3 .mobMn li >*:hover svg.line, .drK.MN-4 .mobMn li >*:hover svg.line{stroke:var(--darkU);fill:var(--darkU) !important} .drK.MN-3 .mobMn li >*:hover svg .f, .drK.MN-4 .mobMn li >*:hover svg .f, .drK footer .credit a svg{fill:var(--darkU)} .drK .pS input[id*="1"]:checked ~ .tbHd label[for*="1"], .drK .pS input[id*="2"]:checked ~ .tbHd label[for*="2"], .drK .pS input[id*="3"]:checked ~ .tbHd label[for*="3"], .drK .pS input[id*="4"]:checked ~ .tbHd label[for*="4"], .drK .widget input[type=text]:focus, .drK .widget input[type=email]:focus, .drK .widget textarea:focus, .drK .widget input[data-text=fl], .drK .widget textarea[data-text=fl], .drK .wL.cl .lbN:not(div):hover, .drK .wL.cl div.lbN{border-color:var(--darkU)} .drK .button.ln:hover{border-color:var(--darkU);box-shadow:0 0 0 1px var(--darkU) inset} .drK .mnBr a, .drK .pLbls >*, .drK .aTtl a, .drK .blogPg >*, .drK .brdCmb a, .drK .wL li >*, .drK .mobMn li >*, .drK .cmAc a{color:var(--darkT)} .drK .blogPg .nPst, .drK .blogPg .current{background:var(--contentL);color:var(--bodyCa)} .drK .FeaturedPost .itemFt::after{background:var(--darkTa)} @media screen and (min-width:897px){.drK header .BlogSearch input{background:var(--darkBs)} .drK header .BlogSearch input:focus, .drK header .BlogSearch input:hover{background:var(--darkBa)} .drK.bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .drK.bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .drK.hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .drK.hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{background:var(--darkBa);box-shadow:0 10px 40px rgba(0,0,0,.2);color:var(--darkTa)} .drK.LS-2 .blogCont::before{background:var(--darkBs)} .drK.LS-3 .headCn{background:transparent} .drK.LS-3 .headL, .drK.LS-3 .mnBrs{background:var(--darkBs)} .drK.LS-3 .headR{background:var(--darkB)} .drK .tocLi::before{border-color:rgba(255,255,255,.15)}} @media screen and (min-width:897px){.drK header{border-bottom:var(--headerL) solid rgba(255,255,255,.15);box-shadow:none} .drK .blogCont::before{border-right:1px solid rgba(255,255,255,.15)} .drK .mnBrs{box-shadow:none}} @media screen and (min-width:641px){.drK .ftMn a:hover{color:var(--darkU)}} @media screen and (max-width:640px){.drK .ftMn{background:var(--darkBa)}} @media screen and (max-width:500px){.drK .itemFt .itm .iCtnt{background:var(--darkBa)}}


/* Introduction */
.yzWlc{position:relative}.yzTl{font-family:var(--font-bodyAlt);text-align:center;font-weight:600}
.yzDcs{font-family:var(--font-bodyAlt);text-align:center;font-size:13px;padding-bottom:0px;line-height:1.6em;}.yzDcs:after{content:'';width:0px;display:block;position:relative;bottom:-6px;border-bottom:1.5px solid #989b9f;margin:3px auto;animation:animatebord 3s infinite;-webkit-animation:animatebord 3s infinite}
@-webkit-keyframes animatebord{0%{width:20px}50%{width:100px}100%{width:20px}}@keyframes animatebord{0%{width:20px}50%{width:100px}100%{width:20px}}
/* Hljs */ .hljs-comment{color:#656e77}.hljs-attr,.hljs-doctag,.hljs-keyword,.hljs-meta,.hljs-meta-keyword,.hljs-section,.hljs-selector-class,.hljs-selector-pseudo,.hljs-selector-tag{color:#015692}.hljs-attribute{color:#803378}.hljs-built_in,.hljs-literal,.hljs-name,.hljs-number,.hljs-quote,.hljs-selector-id,.hljs-template-tag,.hljs-title,.hljs-type{color:#b75501}.hljs-link,.hljs-meta-string,.hljs-regexp,.hljs-selector-attr,.hljs-string,.hljs-symbol,.hljs-template-variable,.hljs-variable{color:#54790d}.hljs-bullet,.hljs-code{color:#535a60}.hljs-deletion{color:#c02d2e}.hljs-addition{color:#2f6f44}.hljs-emphasis{font-style:italic}.hljs-strong{font-weight:700}.drK .hljs-name,.drK .hljs-strong{font-weight:bold}.drK .hljs-code,.drK .hljs-emphasis{font-style:italic}.drK .hljs-tag{color:#62c8f3}.drK .hljs-variable,.drK .hljs-template-variable,.drK .hljs-selector-id,.drK .hljs-selector-class{color:#ade5fc}.drK .hljs-string,.drK .hljs-bullet{color:#a2fca2}.drK .hljs-type,.drK .hljs-title,.hljs-section,.drK .hljs-attribute,.drK .hljs-quote,.drK .hljs-built_in,.drK .hljs-builtin-name{color:#ffa}.hljs-number,.drK .hljs-symbol,.drK .hljs-bullet{color:#d36363}.drK .hljs-keyword,.drK .hljs-selector-tag,.drK .hljs-literal{color:#fcc28c}.drK .hljs-comment,.drK .hljs-deletion,.drK .hljs-code{color:#888}.hljs-regexp,.drK .hljs-link{color:#c6b4f0}.drK .hljs-meta{color:#fc9b9b}.drK .hljs-deletion{background-color:#fc9b9b;color:#333}.drK .hljs-addition{background-color:#a2fca2;color:#333}.drK .hljs a{color:inherit}.drK .hljs a:focus,.drK .hljs a:hover{color:inherit;text-decoration:underline}mark{padding:1px 6px;border-radius:2px;font-size:15px}code mark{font-size:13px;margin:2px;display:inline-block}pre mark{font-size:13px;margin:2px;display:inline-block}
/*wiggle animation*/ .animated-wigle{animation: wiggle 2s infinite} @keyframes wiggle{0%{transform:rotate(0) scale(1)}60%{transform:rotate(0) scale(1)}75%{transform:rotate(0) scale(1.12)}80%{transform:rotate(0) scale(1.1)}84%{transform:rotate(-10deg) scale(1.1)}88%{transform:rotate(10deg) scale(1.1)}92%{transform:rotate(-10deg) scale(1.1)}96%{transform:rotate(10deg) scale(1.1)}100%{transform:rotate(0) scale(1)}}
/* Back to Top */ .toTopB{display:flex;align-items:center;justify-content:center;position:fixed;right:20px;bottom:70px;width:45px;height:45px;border-radius:50%;cursor:pointer;visibility:hidden;opacity:0;z-index:5;transform:scale(0);transition:transform .3s ease, opacity .3s ease,visibility .3s ease,margin-bottom 1s ease} .toTopB.vsbl{visibility:visible;opacity:1;transform:scale(1)} .MN-4 .toTopB{bottom:80px} .toTopB:hover{opacity:.8} .toTopB svg{height:100% !important;width:100% !important;-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg);stroke-width:1.5;cursor:pointer} .toTopB svg .b{fill:#fff;stroke:#e6e6e6;opacity:.9} .toTopB svg .c{fill:none;stroke:var(--linkC);stroke-dasharray:100 100;stroke-dashoffset:100;stroke-linecap:round} .toTopB svg .d{fill:none;stroke:var(--iconC)} .drK .toTopB svg .b{fill:var(--darkBa);stroke:#404045} .drK .toTopB svg .c{stroke:var(--darkU)} .drK .toTopB svg .d{stroke:var(--darkT)}
/* Pop-up */ .lxPo{position:fixed;top:-50%;bottom:-50%;top:-50%;left:-50%;right:-50%;z-index:70;background:rgba(0,0,0,.4);visibility:hidden;opacity:0;transition:all .6s ease;-webkit-transition:all .6s ease} .lxPo.visible{visibility:visible;opacity:1} .lxPoW{position:fixed;top:0;bottom:0;top:0;left:0;right:0;z-index:71;padding:20px;display:flex;flex-direction:column;justify-content:center;align-items:center} .lxPoC{position:relative;background:#fffdfc;width:100%;max-width:500px;padding:20px 25px 25px;border-radius:20px} .lxPoCl::after{content:'\2715';line-height:16px;font-size:12px;color:#fffdfc;position:absolute;top:-15px;right:15px;background:var(--linkC);display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;transition:var(--trans-1);-webkit-transition:var(--trans-1);cursor:pointer} .lxPoCl:hover::after{transform:scale(1.03);-webkit-transform:scale(1.03)} .lxPoS{display:block;text-align:center;margin-bottom:5px} .lxPoS svg.line{stroke-width:1;width:50px;height:50px} .lxPoH{font-size:1.2rem;font-weight:700;font-family:var(--fontBa);margin-bottom:10px;text-align:center} .lxPoD{line-height:1.7em;font-size:15px} .lxPoB{text-align:center;margin-top:20px} .lxPoB .btn{width:45px;height:45px;outline:none;border:none;display:inline-flex;align-items:center;justify-content:center;background:var(--linkC);border-radius:50%} .lxPoB .btn:hover{opacity:.8} .lxPoB .btn svg{stroke:#fffdfc} .drK .lxPoC{background:var(--darkBs)} .drK .lxPoCl::after, .drK .lxPoB .btn{background:var(--darkU)}

/* Scroll Menu */ .navI{background-color:var(--navB); overflow-y:hidden;overflow-x:scroll;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch; display:flex;padding:2px;} .navI ul{display:flex;list-style:none;margin:0;padding:0;white-space:nowrap} .navI li{margin:0 15px;padding:10px 0;position:relative; scroll-snap-align: start} .navI li:first-child{margin-left:auto} .navI li:last-child{margin-right:auto} .navI .l{display:block;color:#fff;padding:8px 0;background:rgba(0,185,184,1);box-shadow: rgba(23,43,99,.3) 0 1px 2px;border-radius:20px;padding: 5px 7px;} .navI .l::before{content:attr(data-text)} .navI .l::after{content:'';height:1px;border-radius:2px 2px 0 0;background:var(--linkC);position:absolute;bottom:0;left:0;right:0;opacity:0} .navI span.l{opacity:.7} .navI a.l:hover, .navI .l.a{color:var(--linkC)}

/* Music Tracker */
.TrackW{justify-content:center;display:flex;align-items:center;flex-direction:column;border-radius:20px;background:#fff;position:relative;overflow:hidden;background:var(--TrBg);-webkit-box-shadow:0 10px 25px -3px rgb(0 0 0 / 10%)}.TrackW::before{content:'';display:block;position:relative;bottom:0;right:0;width:100%;height:100px;background:var(--bTopMT);background-repeat:no-repeat;border-radius:120px 0 0;transition:opacity .3s;opacity:1;border-radius:20px 20px 100% 100%}.TrackI{transition:1s;transform:scale(.9);transition:.7s;position:absolute;height:150px;width:150px;top:20px;border-radius:25px;background:var(--TrBg);background-size:cover;background-position:center;-webkit-box-shadow:3px 3px 6px rgba(0,0,0,.2);box-shadow:3px 3px 6px rgba(0,0,0,.2)}.TrackN{position:relative;margin-top:80px;font-size:20px;font-weight:800}.PSP{display:flex;flex-direction:row;align-items:center;margin-bottom:20px}.PSP svg{fill:var(--svgStr);margin:0 10px;height:50px;width:50px;padding:10px;background:var(--mtBtn);border-radius:100%}.PSP .nTrack svg,.PSP .pTrack svg{width:40px;height:40px}.cTm,.tDr{padding:20px}.pR{position:relative;text-align:center;background:rgba(155,170,175,.12);height:7px;border-radius:20px;cursor:pointer;width:100%}.pRh{position:absolute;background-color:var(--pRsB);height:16px;width:16px;top:0;left:0;transform:translate(-50%,-32%);border-radius:100%;-webkit-transition:.2s;transition:opacity .2s}.audio-pR{display:flex;justify-content:center;align-items:center;width:100%}.pRb{position:relative;background-color:var(--pRs);height:7px;width:0%;border-radius:.8rem}.drK .TrackW{background:var(--darkBs)}.drK .TrackI{background:var(--darkB);background-size:cover;background-position:center;transition:1s}.drK .TrackW::before{background:var(--darkBa)}.drK .PSP svg{fill:#6D6D74;background:var(--darkBa)}.drK .pRb,.drK .pRh{background:#6d6d74}
/* Greetings */ .pGV{display:flex;justify-content:space-between;position:relative;font-size:13px;padding-top:6px;padding-bottom:20px;} .pGV >*{padding:10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:var(--greetR);display:flex;align-items:center;justify-content:center} .pGV >*:first-child{margin-right:5px} .pGV >*:last-child{margin-left:5px} .Rtl .pGV >*:first-child{margin-right:0;margin-left:5px} .Rtl .pGV >*:last-child{margin-left:0;margin-right:5px} .pGV .pVws.hidden{display:none} .pGV .pGrt::after{content:attr(data-text)} .pGV .pVws::after{content:attr(data-text) ' views'} .pGV svg{width:15px;height:15px;margin-right:6px} .pGV svg.line{stroke-width:1.5} .Rtl .pGV svg{margin-right:0;margin-left:6px} .drK .pGV >*{background:var(--darkBa)}
/* Preloader */
.pLdW{position:fixed;top:0;left:0;bottom:0;right:0;z-index:990;display:flex;background:rgba(255,255,255,.1);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);justify-content:center;align-items:center}.drK .pLdW{background:rgba(0,0,0,.1)}.sKw{position:relative;width:210px;height:224px}.sK{transform:rotate(90deg);width:200px;height:200px;position:absolute;left:100px;margin-left:-100px;top:100px;margin-top:-100px}.hC{background:var(--linkC);width:30px;height:17px;position:absolute;top:5px}.drK .hC{background:var(--darkU)}.h2{transform:rotate(60deg)}.h3{transform:rotate(-60deg)}.gel{height:30px;width:30px;position:absolute;top:50%;left:50%}.C-gel{margin-left:-15px;margin-top:-15px;-webkit-animation-name:pulse;-webkit-animation-duration:2s;-webkit-animation-iteration-count:infinite}.r1{-webkit-animation-name:pulse;-webkit-animation-duration:2s;-webkit-animation-iteration-count:infinite;-webkit-animation-delay:.1s}.r2{-webkit-animation-name:pulse;-webkit-animation-duration:2s;-webkit-animation-iteration-count:infinite;-webkit-animation-delay:.3s}.r3{-webkit-animation-name:pulse;-webkit-animation-duration:2s;-webkit-animation-iteration-count:infinite;-webkit-animation-delay:.6s}.c1{margin-left:-47px;margin-top:-15px}.c2{margin-left:-31px;margin-top:-43px}.c3{margin-left:1px;margin-top:-43px}.c4{margin-left:17px;margin-top:-15px}.c5{margin-left:-31px;margin-top:13px}.c6{margin-left:1px;margin-top:13px}.c7{margin-left:-63px;margin-top:-43px}.c8{margin-left:33px;margin-top:-43px}.c9{margin-left:-15px;margin-top:41px}.c10{margin-left:-63px;margin-top:13px}.c11{margin-left:33px;margin-top:13px}.c12{margin-left:-15px;margin-top:-71px}.c13{margin-left:-47px;margin-top:-71px}.c14{margin-left:17px;margin-top:-71px}.c15{margin-left:-47px;margin-top:41px}.c16{margin-left:17px;margin-top:41px}.c17{margin-left:-79px;margin-top:-15px}.c18{margin-left:49px;margin-top:-15px}@keyframes pulse{0%{transform:scale(1)}50%{transform:scale(.01)}100%{transform:scale(1)}}.r1{opacity:.7}.r2{opacity:.5}.r3{opacity:.3}
/* Widget Scroll Menu */ .navS{box-shadow:0 0 25px rgba(0,0,0,.07);background:var(--navSc);overflow-y:hidden;overflow-x:scroll;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch; display:flex;padding:0;border-radius:10px} .navS ul{display:flex;list-style:none;margin:0;padding:0;white-space:nowrap} .navS li{margin:0 15px;padding:10px 0;position:relative;scroll-snap-align:start} .navS li:first-child{margin-left:auto} .navS li:last-child{margin-right:auto} .navS .l{display:block;color:var(--bodyC);padding:8px 0} .navS .l::before{content:attr(data-text)} .navS .l::after{content:'';height:1px;border-radius:2px 2px 0 0;background:var(--linkC);position:absolute;bottom:0;left:0;right:0;opacity:0} .navS span.l{opacity:.7} .navS a.l:hover, .navS .l.a{color:var(--linkC)} @media screen and (max-width:896px){.navS .secIn{padding:0} .navS li{margin:0;padding:8px 0;display:flex} .navS li::before{content:'';padding:10px} .navS ul::after{content:'';display:block;padding:10px;scroll-snap-align:start} .navS .l{position:relative} .navS .l::after{bottom:-8px} .navS a.l:hover::after, .navS .l.a::after{opacity:1}} @media screen and (max-width:500px){.navS{font-size:13px}} .drK .navS{background:var(--darkBs)} .drK .navS .l{color:var(--darkC)} .drK .navS a.l:hover, .drK .navS .l.a{color:var(--darkU)} .drK .navS .l::after{background:var(--darkU)}
/* Change Mode */ .headR .headM{display:block;position:absolute;top:0;right:0;padding:10px 0;width:150px;background:var(--contentB);font-size:13px;border-radius:10px 5px 10px 10px;box-shadow:0 0 15px rgba(0,0,0,.07);-webkit-transition:var(--trans-2);transition:var(--trans-2);overflow:hidden;z-index:18;opacity:0;visibility:hidden} .headR .headM:before{content:attr(data-text);display:block;padding:0 15px 10px;width:100%;font-size:11px;opacity:.7} .headR .headM >*{display:block;padding:9px 15px;width:100%;cursor:pointer} .headR .headM >*:before{content:attr(aria-label);opacity:.9} .headR .headM >*:hover{background:rgba(0,0,0,.05)} .navM:checked ~ .mainWrp .headM{visibility:visible;opacity:1} .navM:checked ~ .mainWrp .headM + .fCls{visibility:visible;opacity:1;z-index:17} .headR .headM .sydB{display:none} .bD:not(.drK):not(.syD) .headR .headM .lgtB{background-color:rgba(0,0,0,.1)} .drK:not(.syD) .headR .headM .drkB{background-color:rgba(0,0,0,.1)} .syD .headR .headM .sydB{background-color:rgba(0,0,0,.1)} .drK .headR .headM{background:var(--darkBs)} .Rtl .headR .headM{right:auto;left:0;border-radius:5px 10px 10px 10px}
/* Menu */ .headR .headM{display:block;position:absolute;top:0;right:0;padding:10px 0;width:150px;background:var(--contentB);font-size:13px;border-radius:10px 5px 10px 10px;box-shadow:0 0 15px rgba(0,0,0,.07);-webkit-transition:var(--trans-2);transition:var(--trans-2);overflow:hidden;z-index:18;opacity:0;visibility:hidden} .headR .headM:before{content:attr(data-text);display:block;padding:0 15px 10px;width:100%;font-size:11px;opacity:.7} .headR .headM >*{display:block;padding:9px 15px;width:100%;cursor:pointer} .headR .headM >*:before{content:attr(aria-label);opacity:.9} .headR .headM >*:hover{background:rgba(0,0,0,.05)} .navM:checked ~ .mainWrp .headM{visibility:visible;opacity:1} .navM:checked ~ .mainWrp .headM + .fCls{visibility:visible;opacity:1;z-index:17} .headR .headM .sydB{display:true} .bD:not(.drK):not(.syD) .headR .headM .lgtB{background-color:rgba(0,0,0,.1)} .drK:not(.syD) .headR .headM .drK{background-color:rgba(0,0,0,.1)} .syD .headR .headM .sydB{background-color:rgba(0,0,0,.1)} .drK .headR .headM{background:var(--darkBs)} .Rtl .headR .headM{right:auto;left:0;border-radius:5px 10px 10px 10px}
/* Custom Color */.headR .headM .themeBtn{display:block} .cusW{visibility:hidden; opacity:0;position:fixed;right:20px;left:20px;bottom:0;display:block;transition:var(--trans-1);-webkit-transition:var(--trans-1);z-index:21;background:var(--contentB);border-radius:10px;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .cusH{width:100%;padding:20px 20px 15px;display:flex;align-items:center;justify-content:space-between} .cusHi::after{content:attr(data-text);font-size:13px;opacity:.8} .cusCl{cursor:pointer} .cusCl::after{content:'\2715';font-size:14px} .cusI:checked ~ .cusW{visibility:visible;opacity:1;bottom:20px} .cusI:checked ~ .cusW + .fCls{background:rgba(0,0,0,.25);opacity:1;visibility:visible;z-index:19} .cusP{width:100%;padding:0 20px 20px} @media screen and (min-width:501px){.cusW{position:absolute;width:280px;top:-5px;bottom:auto;right:0;left:auto;border-radius:15px 5px 15px 15px} .cusP{padding:0 17px 20px} .cusI:checked ~ .cusW{top:0;right:0;bottom:auto} .Rtl .cusW{right:auto;left:0;border-radius:5px 15px 15px 15px} .Rtl .cusI:checked ~ .cusW{right:auto;bottom:auto;left:0} .cusI:checked ~ .cusW + .fCls{background:transparent}} .tPkr{position:relative;width:26px;height:26px;outline:none;border:none;display:inline-flex;align-items:center;justify-content:center;margin:2px 4.5px;background:var(--pkrC);border-radius:50%;transition:all .3s ease;-webkit-transition:all .3s ease;cursor:pointer} .tPkr::after{content:'';position:absolute;top:-3px; bottom:-3px;right:-3px;left:-3px;border-radius:50%;border:1.5px solid var(--pkrC);opacity:0;transition:all .3s ease;-webkit-transition:all .3s ease} .tPkr:hover{opacity:.8} .tPkr:hover::after{opacity:1} .tPkr.thB0::before{position:absolute;content:'\2715';line-height:18px;font-size:12px} .theme0 .thB0::after, .theme1 .thB1::after, .theme2 .thB2::after, .theme3 .thB3::after, .theme4 .thB4::after, .theme5 .thB5::after, .theme6 .thB6::after, .theme7 .thB7::after, .theme8 .thB8::after, .theme9 .thB9::after, .theme10 .thB10::after{opacity:1} .drK .cusW{background:var(--darkBs)} .drK .tPkr.thB0{background:var(--darkBa)} .drK .tPkr.thB0::after{border-color:var(--darkBa)}
/* Cookie Consent */ .ckW{position:fixed;top:auto;left:40px;right:auto;bottom:-600px;z-index:10;display:none;padding:20px;background:rgba(255,255,255,.8);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-radius:15px;box-shadow:0 0 40px rgba(0,0,0,.1);animation:ckUpD 2.5s forwards;-webkit-animation:ckUpD 2.5s forwards;animation-delay:1s;-webkit-animation-delay:1s;max-width:400px} .ckW.v{display:block} .ckW.a{animation:ckDnD 2.5s backwards;-webkit-animation:ckDnD 2.5s backwards;animation-delay:.3s;-webkit-animation-delay:.3s} .ckH{margin-bottom:10px;font-size:1.1rem;font-weight:700;font-family:var(--fontBa)}.ckH::after{content:'';display:inline-block;vertical-align:middle;width:var(--widgetTa);margin:0 10px;border-bottom:1px solid var(--widgetTac);opacity:.5} .ckD{font-size:14px;line-height:1.4rem;font-family:var(--fontBa)} .ckF{margin-top:15px;display:flex;justify-content:center} .ckF >*{flex-grow:1;justify-content:center} .ckF >*:first-child{margin-right:10px;background:#9C27B0;color:white;} .ckF >*:last-child{flex:0 0 auto} .ckB{display:inline-flex;align-items:center;cursor:pointer;padding:10px 15px;outline:0;border:0;border-radius:3px;line-height:20px;color:rgba(0,0,0,.8);background:#e9e9e9;font-size:14px;font-family:var(--fontB);white-space:nowrap;overflow:hidden;border-radius: 20px;} .ckB:hover{opacity:.8} .Rtl .ckW{left:auto;right:40px} .Rtl .ckF >*:first-child{margin-right:0} .Rtl .ckF >*:last-child{margin-right:10px} @media screen and (max-width:768px){.ckW{left:20px;right:20px;animation:ckUpM 2.5s forwards;-webkit-animation:ckUpM 2.5s forwards} .ckW.a{animation:ckDnM 2.5s backwards;animation-delay:.3s;-webkit-animation:ckDnM 2.5s backwards;-webkit-animation-delay:.3s} .Rtl .ckW{left:20px;right:20px}} @keyframes ckUpD{100%{bottom:40px}} @keyframes ckUpM {100%{bottom:20px}} @keyframes ckDnD{0%{bottom:40px}100%{bottom:-600px}} @keyframes ckDnM{0%{bottom:20px}100%{bottom:-600px}} @-webkit-keyframes ckUpD{100%{bottom:40px}} @-webkit-keyframes ckUpM {100%{bottom:20px}} @-webkit-keyframes ckDnD{0%{bottom:40px}100%{bottom:-600px}} @-webkit-keyframes ckDnM{0%{bottom:20px}100%{bottom:-600px}} .drK .ckW{background:rgba(55,55,55,.8)} .drK .ckF >*:first-child{background:var(--darkU)} .drK .ckF >*:last-child{background:var(--darkBa);color:rgba(255,255,255,.8)}
/* Wave Animation */ .wvC{position:absolute;bottom:0;width:100%;z-index:-1} .wvS{position:relative} .wvS .waves{position:absolute;bottom:0;width:100%;height:60px;min-height:100px;max-height:150px} .wvH{position:relative;height:0;background:var(--waveB);animation:waveHd 7s infinite} .plx > use{fill:var(--waveB);animation:waveMove 25s cubic-bezier(.55,.5,.45,.5) infinite} .plx > use:nth-child(1){opacity:.7;animation-delay:-2s;animation-duration:7s} .plx > use:nth-child(2){opacity:.5;animation-delay:-3s;animation-duration:10s} .plx > use:nth-child(3){opacity:.3;animation-delay:-4s;animation-duration:13s} .plx > use:nth-child(4){opacity:1;animation-delay:-5s;animation-duration:20s} @media (max-width:896px){.wvH{animation:waveHm 7s infinite}} .drK .wvH{background:var(--darkW)} .drK .plx > use{fill:var(--darkW)} @keyframes waveMove{0%{transform: translate3d(-90px,0,0)}100%{transform: translate3d(85px,0,0)}} @keyframes waveHm{0%{height:0}35%,65%{height:200px}100%{height:0}} @keyframes waveHd{0%{height:0}35%,65%{height:100px}100%{height:0}}
/* TOC indicator */
.drK .tocC::after,.drK .tocC::before{background:var(--darkBa);border: 2px solid var(--darkBa)}.tocC::after{content:'';display:block;width:13px;height:13px;background-color:var(--bodyB);border-radius:50%;position:absolute;top:5px;left:12px}.tocC::before{content:'';display:block;width:13px;height:13px;background-color:var(--linkC);border:2px solid var(--bodyB);border-radius:50%;position:absolute;top:5px;left:12px;animation:indicator 1s ease infinite;-webkit-animation:indicator 1s ease infinite;z-index:1}@-webkit-keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}@keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}.drK .tocC:before{background-color:var(--darkU)}
/* Progress Bar */
@keyframes AnPr{from{background-position:1rem 0}to{background-position:0 0}}.drK .pRs{border:1px solid var(--darkBa);background:var(--darkBs)}.pRs{border: 0.1px solid var(--contentL);top:0;left:0;z-index:999;height:6px;display:-webkit-box;display:-ms-flexbox;display:flex;background:#e9ecef}.pBar{top:0;left:0;z-index:2;border-radius:.25rem;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:center;-ms-flex-pack:center;justify-content;background:var(--linkC);transition:width .6s ease}.pSt{background-image:linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent);background-size:50px 50px}.pAn{animation:AnPr 2s linear infinite;}.pSt1{background-image:linear-gradient(45deg,rgba(204,204,204,.15) 25%,transparent 25%,transparent 50%,rgba(204,204,204,.15) 50%,rgba(204,204,204,.15) 75%,transparent 75%,transparent);background-size:50px 50px}.drK .pBar{background:var(--darkU)}.drK .pSt{background-image:linear-gradient(45deg,rgba(255,0,0,.15) 25%,transparent 25%,transparent 50%,rgba(255,0,0,.15) 50%,rgba(255,0,0,.15) 75%,transparent 75%,transparent);background-size:50px 50px}
/* Thumbnail hover effect */
article .pThmb a:hover, article .iThmb a:hover{transform:scale(1.025)}
/* Toast Notif */ .tNtf span{position:fixed;left:24px;bottom:-70px;display:inline-flex;align-items:center;text-align:center;justify-content:center;margin-bottom:20px;z-index:99981;background:#323232;color:rgba(255,255,255,.8);font-size:14px;font-family:inherit;border-radius:3px;padding:13px 24px; box-shadow:0 5px 35px rgba(149,157,165,.3);opacity:0;transition:all .1s ease;animation:slideinwards 2s ease forwards;-webkit-animation:slideinwards 2s ease forwards}
@media screen and (max-width:500px){.tNtf span{margin-bottom:20px;left:20px;right:20px;font-size:13px}}
@keyframes slideinwards{0%{opacity:0}20%{opacity:1;bottom:0}50%{opacity:1;bottom:0}80%{opacity:1;bottom:0}100%{opacity:0;bottom:-70px;visibility:hidden}}
@-webkit-keyframes slideinwards{0%{opacity:0}20%{opacity:1;bottom:0}50%{opacity:1;bottom:0}80%{opacity:1;bottom:0}100%{opacity:0;bottom:-70px;visibility:hidden}} .tNtf span i{content:''; width:14px;height:14px; display:inline-block;margin:0 5px;opacity:.8} .tNtf span i.check{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M22 11.08V12a10 10 0 1 1-5.93-9.14'/><polyline points='22 4 12 14.01 9 11.01'/></svg>") center / 14px no-repeat} .tNtf span i.warn{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><g transform='translate(2.500000, 3.000000)'><path d='M9.5,18 C3.00557739,18 0.456662548,17.5386801 0.0435259337,15.2033146 C-0.36961068,12.8679491 2.27382642,8.47741935 3.08841712,7.02846996 C5.81256986,2.18407813 7.66371927,0 9.5,0 C11.3362807,0 13.1874301,2.18407813 15.9115829,7.02846996 C16.7261736,8.47741935 19.3696107,12.8679491 18.9564741,15.2033146 C18.5443995,17.5386801 15.9944226,18 9.5,18 Z'/><line x1='9.5' y1='5.5' x2='9.5' y2='9.395'/><line x1='9.4957' y1='12.895' x2='9.5047' y2='12.895'/></g></svg>") center / 14px no-repeat} .tNtf span i.copy{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><rect x='9' y='9' width='13' height='13' rx='2' ry='2'/><path d='M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1'/></svg>") center / 14px no-repeat} .tNtf span i.clipboard{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2'/><rect x='8' y='2' width='8' height='4' rx='1' ry='1'/></svg>") center / 14px no-repeat} .tNtf span i.onCloud{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z'/></svg>") center / 14px no-repeat} .tNtf span i.offCloud{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M22.61 16.95A5 5 0 0 0 18 10h-1.26a8 8 0 0 0-7.05-6M5 5a8 8 0 0 0 4 15h9a5 5 0 0 0 1.7-.3'/><line x1='1' y1='1' x2='23' y2='23'/></svg>") center / 14px no-repeat} .tNtf span i.onWifi{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M5 12.55a11 11 0 0 1 14.08 0'/><path d='M1.42 9a16 16 0 0 1 21.16 0'/><path d='M8.53 16.11a6 6 0 0 1 6.95 0'/><line x1='12' y1='20' x2='12.01' y2='20'/></svg>") center / 14px no-repeat} .tNtf span i.offWifi{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><line x1='1' y1='1' x2='23' y2='23'/><path d='M16.72 11.06A10.94 10.94 0 0 1 19 12.55'/><path d='M5 12.55a10.94 10.94 0 0 1 5.17-2.39'/><path d='M10.71 5.05A16 16 0 0 1 22.58 9'/><path d='M1.42 9a15.91 15.91 0 0 1 4.7-2.88'/><path d='M8.53 16.11a6 6 0 0 1 6.95 0'/><line x1='12' y1='20' x2='12.01' y2='20'/></svg>") center / 14px no-repeat} .tNtf span i.del{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><g transform='translate(3.500000, 2.000000)'><path d='M15.3891429,7.55409524 C15.3891429,15.5731429 16.5434286,19.1979048 8.77961905,19.1979048 C1.01485714,19.1979048 2.19295238,15.5731429 2.19295238,7.55409524'/><line x1='16.8651429' y1='4.47980952' x2='0.714666667' y2='4.47980952'/><path d='M12.2148571,4.47980952 C12.2148571,4.47980952 12.7434286,0.714095238 8.78914286,0.714095238 C4.83580952,0.714095238 5.36438095,4.47980952 5.36438095,4.47980952'/></g></svg>") center / 14px no-repeat} .Rtl .tNtf span{left:auto;right:24px} @media screen and (max-width:896px){.tNtf span{margin-bottom:50px}} @media screen and (max-width:500px){.tNtf span{left:20px;right:20px;font-size:13px}  .tNtf.alt span, .Rtl .tNtf.alt span{left:0;right:0;margin-bottom:-25px;justify-content:left;text-align:left;font-size:15px;padding:15px 24px;border-radius:0} .Rtl .tNtf.alt span{justify-content:right;text-align:right} .Rtl .tNtf span{left:20px;right:20px}} .drK .tNtf span{box-shadow:0 10px 40px rgba(0,0,0,.2)} .MN-4 .tNtf span{margin-bottom:0;animation-duration:2s;-webkit-animation-duration:2s}
/* Google Translate */body{top:0px!important}.goog-te-banner-frame.skiptranslate, .goog-te-gadget-simple img, img.goog-te-gadget-icon, .goog-te-menu-value span, #goog-gt-tt, .goog-tooltip, .goog-tooltip:hover, .goog-logo-link, .goog-te-balloon-frame{display:none!important} .goog-text-highlight{background-color: transparent !important;box-shadow:none !important;-webkit-box-shadow:none !important} .goog-te-menu-frame{box-shadow:none!important} .goog-te-gadget-simple{background-color:transparent!important;border:none!important;outline:0 !important;-ms-touch-action:manipulation;touch-action:manipulation;-webkit-user-select:none !important;-moz-user-select:none !important;-ms-user-select:none !important;user-select:none !important} #google_translate_element{position:absolute !important;z-index:2 !important;overflow:hidden !important} #google_translate_element, .skiptranslate.goog-te-gadget, .goog-te-gadget-simple{width:40px !important;height:40px !important;padding:0 !important;margin:0 !important;border-radius:50% !important}.goog-te-banner-frame.skiptranslate,.goog-te-gadget-simple img,img.goog-te-gadget-icon,.goog-te-menu-value span{display:none!important}.goog-te-menu-frame{box-shadow:none!important}.goog-te-gadget-simple{background-color:transparent!important;border-left:none!important;border-top:none!important;border-bottom:none!important;border-right:none!important;border-radius:4px}
/* RGB Effect */.stwRainbow,.stwBlurRainbow{position:fixed;width:100%;bottom:0;left:0;right:0;height:3px;z-indfex:23;background:linear-gradient(-45deg, #4086F4, #31A952, #FBBE01, #EB4132,#4086F4, #31A952, #FBBE01, #EB4132);background-size:200%;-webkit-animation:animeBar 5s linear infinite;animation:animeBar 5s linear infinite}.stwBlurRainbow{height:10px;z-index:22;filter:blur(10px);opacity:.7}@-webkit-keyframes animeBar{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}@keyframes animeBar{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
/* Double click to copy hover text */.pre:not(.tb):hover::before{content:'Double click to copy | </>'}
.pre:not(.tb).html:hover::before{content:'Double click to copy | .html'}
.pre:not(.tb).css:hover::before{content:'Double click to copy | .css'}
.pre:not(.tb).js:hover::before{content:'Double click to copy | .js'}
/* Navbar */ .navbar{z-index:3;padding-top:10px;background:var(--navB);box-shadow:0 5px 35px rgba(0,0,0,.07);height:var(--navH);color:var(--navT);overflow:hidden} .navR .section{justify-content:flex-end} .navIn svg, header svg{width:20px;height:20px;fill:var(--navI); opacity:.8} .navIn svg.line{fill:none;stroke:var(--navI)} .navIn .section{display:flex;align-items:center;height:100%;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .navIn .section >*{margin:0 7px} .navIn .a{color:inherit} .navIn ul{list-style:none;margin:0;padding:0} .mLang{align-items:baseline;font-size:13px} .mLang, .mSocc{display:flex;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .mLang .a{width:30px;height:30px;display:flex;align-items:center;justify-content:center} .mLang .a::before{content:attr(data-text)} .mLang li.u{font-size:12px;text-transform:uppercase} .mLang li:not(:last-child){display:flex;align-items:center} .mLang li:not(:last-child)::after{content:'';height:14px; border-left:1px solid #999; margin:0 5px;opacity:.7; flex:0 0} .mLang span, .mSocc span{opacity:.5} .mSocc >*{position:relative} .mSocc svg{z-index:1} .mSocc svg{width:19px;height:19px;opacity:.8}#dateNow{right: 10px;position: absolute;top: 5px;opacity: 0.7;}
.drK .navbar{background:var(--darkB);color:var(--darkT)}



/* Wave Animation */ .wvC{position:absolute;bottom:0;width:100%;z-index:-1} .wvS{position:relative} .wvS .waves{position:absolute;bottom:0;width:100%;height:60px;min-height:100px;max-height:150px} .wvH{position:relative;height:60px;background:var(--waveB)} .plx > use{fill:var(--waveB);animation:waveMove 25s cubic-bezier(.55,.5,.45,.5) infinite} .plx > use:nth-child(1){opacity:.7;animation-delay:-2s;animation-duration:7s} .plx > use:nth-child(2){opacity:.5;animation-delay:-3s;animation-duration:10s} .plx > use:nth-child(3){opacity:.3;animation-delay:-4s;animation-duration:13s} .plx > use:nth-child(4){opacity:1;animation-delay:-5s;animation-duration:20s} @media (max-width: 896px){.wvS .waves{height:40px;min-height:50px;} .wvC .wvH{height:100px}} @keyframes waveMove{0%{transform: translate3d(-90px,0,0)}100%{transform: translate3d(85px,0,0)}} .drK .wvH{background:var(--darkW)} .drK .plx > use{fill:var(--darkW)}
/* Article Section */ .onIndx .blogPts, .itemFt .itm{display:flex;flex-wrap:wrap;align-items:center;position:relative; width:calc(100% + 20px);left:-10px;right:-10px} .onIndx .blogPts >*, .itemFt .itm >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px); margin-bottom:0;margin-left:10px;margin-right:10px} .onIndx .blogPts >*{background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px;margin-bottom:20px;padding:10px 10px 45px;position:relative} .onIndx .blogPts .pTag{padding-bottom:0} .onIndx .pTag .pInf{display:none} .onIndx .blogPts .pInf{position:absolute;bottom:15px;left:15px;right:15px} .onIndx .blogPts{align-items:stretch} .onIndx .blogPts.mty{display:block;width:100%;left:0;right:0} .onIndx .blogPts.mty .noPosts{width:100%;margin:0} .onIndx .blogPts div.ntry{padding-bottom:0;flex:0 0 calc(100% - 20px)} .blogPts .ntry.noAd .widget/*, .Blog ~ .HTML*/{display:none} .cPst .pLbls >*{padding:16px 3px} .cPst .pLbls >*:not(:last-child){padding-right:0} .cPst .pLbls >*:not(:last-child)::after{padding-left:3px} .ctgry article{animation:ctgryFade 1.5s;-webkit-animation:ctgryFade 1.5s} @keyframes ctgryFade{from{opacity:0}to{opacity:1}} @-webkit-keyframes ctgryFade{from{opacity:0}to{opacity:1}}
/* Blog title */ .blogTtl{font-size:14px; margin:0 0 30px;width:calc(100% + 16px);display:flex;justify-content:space-between;position:relative;left:-8px;right:-8px} .blogTtl .t, .blogTtl.hm .title{margin:0 8px;flex-grow:1} .blogTtl .t span{font-weight:400;font-size:90%; opacity:.7} .blogTtl .t span::before{content:attr(data-text)} .blogTtl .t span::after{content:''; margin:0 4px} .blogTtl .t span.hm::after{content:'/'; margin:0 8px}
/* No Post */ .blogPts .noPosts{min-height:120px;display:flex;align-items:center;justify-content:center;padding-top:40px}
/* Thumbnail */ .pThmb{flex:0 0 calc(50% - 12.5px);overflow:hidden;position:relative;border-radius:5px; margin-bottom:20px;background:var(--transB)} .pThmb .thmb{display:block;position:relative;padding-top:52.335%;color:inherit;transition:var(--trans-4);-webkit-transition:var(--trans-4)} article:hover .thmb{transform:scale(1.03);-webkit-transform:scale(1.03)} .pThmb .thmb amp-img{position:absolute;top:50%;left:50%;min-width:100%;min-height:100%;max-height:108%;text-align:center;transform:translate(-50%, -50%)} .pThmb div.thmb span::before{content:attr(data-text); opacity:.7; white-space:nowrap} .pThmb:not(.nul)::before{position:absolute;top:0;right:0;bottom:0;left:0; transform:translateX(-100%); background-image:linear-gradient(90deg, rgba(255,255,255,0) 0, rgba(255,255,255,.3) 20%, rgba(255,255,255,.6) 60%, rgba(255,255,255, 0)); animation:shimmer 2s infinite;content:''} .pThmb.iyt:not(.nul) .thmb::after{content:'';position:absolute;top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,.4) url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'><path d='M4 11.9999V8.43989C4 4.01989 7.13 2.2099 10.96 4.4199L14.05 6.1999L17.14 7.9799C20.97 10.1899 20.97 13.8099 17.14 16.0199L14.05 17.7999L10.96 19.5799C7.13 21.7899 4 19.9799 4 15.5599V11.9999Z'/></svg>") center / 35px no-repeat; opacity:0;transition:var(--trans-1)} .pThmb.iyt:not(.nul):hover .thmb::after{opacity:1}
/* Sponsored */ .iFxd{display:flex;justify-content:flex-end;position:absolute;top:0;left:0;right:0;padding:10px 6px;font-size:13px;line-height:16px} .iFxd.l{right:auto} .Rtl .iFxd.l{right:0;left:auto} .iFxd >*{display:flex;align-items:center;margin:0 5px;padding:5px 2.5px;border-radius:var(--thumbEr);background:var(--contentB);color:inherit;box-shadow:0 8px 25px 0 rgba(0,0,0,.1)} .iFxd >* svg{width:16px;height:16px;stroke-width:1.5;margin:0 2.5px;opacity:.7} .iFxd .cmnt, .iFxd .pV{padding:5px;color:var(--bodyC)} .iFxd .bM{cursor:pointer} .iFxd .bM:hover{opacity:.8} .iFxd .pV.hidden{display:none} .iFxd .cmnt::after, .iFxd .pV::after{content:attr(data-text);margin:0 2.5px;opacity:.8} .drK .iFxd >* svg.line{stroke:var(--iconC)}
/* Label */ .pLbls::before, .pLbls >*::before{content:attr(data-text)} .pLbls::before{opacity:.7} .pLbls a:hover{text-decoration:underline} .pLbls >*{color:inherit;display:inline;padding:16px 0} .pLbls >*:not(:last-child)::after{content:'/'}
/* Profile Images and Name */ .im{width:35px;height:35px;border-radius:16px; background-color:var(--transB);background-size:100%;background-position:center;background-repeat:no-repeat;display:flex;align-items:center;justify-content:center} .im svg{width:18px;height:18px;opacity:.4} .nm::after{content:attr(data-text)}
/* Title and Entry */ .pTtl{font-size:1.1rem;line-height:1.5em} .pTtl.sml{font-size:1rem} .pTtl.itm{font-size:var(--postT);font-family:var(--fontBa);font-weight:700; line-height:1.3em} .pTtl.itm.nSpr{margin-bottom:30px} .aTtl a:hover{color:var(--linkC)} .aTtl a, .pSnpt{color:inherit; display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden} .pEnt{margin-top:40px; font-size:var(--postF);font-family:var(--fontBa); line-height:1.8em}
/* Snippet, Description, Headers and Info */ .onIndx .pCntn{padding:0 5px} .pHdr{margin-bottom:8px} .pHdr .pLbls{white-space:nowrap;overflow:hidden;text-overflow:ellipsis; opacity:.8} .pSml{font-size:93%} .pSnpt{-webkit-line-clamp:2;margin:12px 0 0;font-family:var(--fontB);font-size:14px;line-height:1.5em; opacity:.8} .pSnpt.nTag{color:var(--linkC);opacity:1;margin-bottom:10px} .pDesc{font-size:16px;line-height:1.5em;margin:8px 0 25px;opacity:.7} .pInf{display:flex;align-items:baseline;justify-content:space-between; margin-top:15px} .pInf.nTm{margin:0} .pInf.nSpr .pJmp{opacity:1} .pInf.nSpr .pJmp::before{content:attr(aria-label)} .pInf.ps{background:var(--contentB);box-shadow:0 0 25px rgba(0,0,0,.07);padding:15px;border-radius:10px;justify-content:flex-start;align-items:center;margin-top:25px;position:relative;width:100%} .drK .pInf.ps{background:var(--darkBa)} .pInf.ps .pTtmp{opacity:1} .pInf.ps .pTtmp::before{content:attr(data-date) ' '} .pInf.ps .pTtmp::after{display:inline} .pInf.ps.nul{display:none} .pInf .pIm{flex-shrink:0;margin-right:8px} .Rtl .pInf .pIm{margin-right:0;margin-left:8px} .pInf .pNm{flex-grow:1;width:calc(100% - 160px);display:inline-flex;flex-wrap:wrap;align-items:baseline} .pInf .pNm.l{display:none} .pInf .pCm{flex-shrink:0;max-width:58px;margin:0 2px} .pInf .pCm.l{max-width:95px} .pInf .pIc{display:inline-flex;justify-content:flex-end;position:relative;width:calc(100% + 10px);left:-5px;right:-5px} .pInf .pIc >*{display:flex;align-items:center;justify-content:center;width:30px;height:30px;position:relative;margin:0 2px;color:inherit} .pInf .pIc svg{width:20px;height:20px;opacity:.8;z-index:1} .pInf .pIc .cmnt::before{content:attr(data-text);font-size:11px;line-height:18px;padding:0 5px;border-radius:10px;background:#e6e6e6;color:var(--bodyC);position:absolute;top:-5px;right:0;z-index:2} .pInf .pDr{opacity:.7;display:inline-block;margin:0 4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:100%} .pInf .pDr >*:not(:first-child)::before{content:'\00B7';margin:0 5px} .pInf a.nm{color:var(--bodyC)} .pInf a.nm:hover::after{text-decoration:underline} .drK .pInf a.nm{color:var(--darkT)} .pInf .pIn{display:inline} .pInf .nm{margin:0 4px} /*.pInf .n .nm::before{content:attr(data-write) ' ';opacity:.7}*/ .pInf .im{width:28px;height:28px} .aTtmp{opacity:.8} .aTtmp, .pJmp{overflow:hidden} .pTtmp::after, .pJmp::before, .iTtmp::before{content:attr(data-text); display:block;line-height:18px; white-space:nowrap;text-overflow:ellipsis;overflow:hidden} .pJmp{display:inline-flex;align-items:center; opacity:0; transition:var(--trans-2)} .pJmp::before{content:attr(aria-label)} .pJmp svg{height:18px;width:18px;stroke:var(--linkC); flex-shrink:0} .ntry:hover .pJmp, .itm:hover .pJmp{opacity:1} .ntry:not(.noAd) .pJmp, .itemFt .itm .pJmp{animation:indicator 2s 3s infinite} .ntry:not(.noAd):hover .pJmp, .itemFt:hover .itm .pJmp{animation:none}
/* Product view */ .pTag .pPad{padding:10px 0} .pTag .pPric{font-size:20px;color:var(--linkC);padding-top:20px} .pTag .pPric::before, .pTag .pInfo small{content:attr(data-text);font-size:small;opacity:.8;display:block;line-height:1.5em;color:var(--bodyC)} .pTag .pInfo{font-size:14px;line-height:1.6em} .pTag .pInfo:not(.o){position:relative;width:calc(100% + 20px);left:-10px;right:-10px;display:flex} .pTag .pInfo:not(.o) >*{width:50%;padding:0 10px} .pTag .pMart{margin:10px 0 12px;display:flex;flex-wrap:wrap;line-height:1.6em; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .pTag .pMart >*{margin:0 4px} .pTag .pMart small{width:calc(100% - 8px);margin-bottom:10px} .pTag .pMart a{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border:1px solid var(--contentL);border-radius:12px;margin-bottom:8px} .pTag .pMart img{width:20px;display:block}
/* Blog pager */ .blogPg{display:flex;flex-wrap:wrap;justify-content:center;font-size:90%;font-family:var(--fontB);line-height:20px;color:#fffdfc;margin:25px 0 50px;max-width:100%} .blogPg >*{display:flex;justify-content:center;align-items:center;min-width:40px;padding:10px 13px;margin:5px;color:inherit;background:var(--linkB);border-radius:var(--buttonR);box-shadow:rgba(100, 100, 111, 0.2) 0px 7px 29px 0px} .blogPg >* svg{width:18px;height:18px; stroke:var(--darkT); stroke-width:1.5} .blogPg >*::before{content:attr(data-text)} .blogPg .jsLd{margin-left:auto;margin-right:auto} .blogPg .nwLnk::before, .blogPg .jsLd::before{display:none} .blogPg .nwLnk::after, .blogPg .jsLd::after{content:attr(data-text); margin:0 8px} .blogPg .olLnk::before{margin:0 8px} .blogPg .nPst, .blogPg .current{background:var(--contentL); color:var(--bodyCa)} .blogPg .nPst.jsLd svg{fill:var(--darkTa);stroke:var(--darkTa)} .blogPg .nPst svg.line{stroke:var(--darkTa)}
/* Breadcrumb */ .brdCmb{margin-bottom:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .brdCmb a{color:var(--bodyC)} .brdCmb >*:not(:last-child)::after{content:'/'; margin:0 4px;font-size:90%;opacity:.6} .brdCmb >*{display:inline} .brdCmb .tl::before{content:attr(data-text)} .brdCmb .hm a{font-size:90%;opacity:.7}
/* Article Style */ .pS h1, .pS h2, .pS h3, .pS h4, .pS h5, .pS h6{margin:1.5em 0 18px; font-family:var(--fontBa);font-weight:700; line-height:1.5em} .pS h1:target, .pS h2:target, .pS h3:target, .pS h4:target, .pS h5:target, .pS h6:target{padding-top:var(--headerH);margin-top:0}
/* Paragraph */ .pS p{margin:1.7em 0} .pIndent{text-indent:2.5rem} .onItm:not(.Rtl) .dropCap{float:left;margin:4px 8px 0 0; font-size:55px;line-height:45px;opacity:.8} .pS hr{margin:3em 0; border:0} .pS hr::before{content:'\2027 \2027 \2027'; display:block;text-align:center; font-size:24px;letter-spacing:0.6em;text-indent:0.6em;opacity:.8;clear:both} .pRef{display:block;font-size:14px;line-height:1.5em; opacity:.7; word-break:break-word}
/* Img and Ad */ .pS img{display:inline-block;border-radius:5px;height:auto !important} .pS img.full{display:block !important; margin-bottom:10px; position:relative; width:100%;max-width:none} .pS .widget, .ps .pAd >*{margin:40px 0}
/* Note */ .note{position:relative;padding:16px 20px 16px 50px;background:var(--notifU);color:#3c4043; font-size:.85rem;font-family:var(--fontB);line-height:1.6em;border-radius:10px;overflow:hidden} .note::before{content:'';width:60px;height:60px;background:rgba(0,0,0,.4);display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .note::after{content:'\002A';position:absolute;left:18px;top:16px; font-size:20px; min-width:15px;text-align:center} .note.wr{background:#ffdfdf;color:#48525c} .note.wr::after{content:'\0021'} .drK .note{background:var(--darkBs);color:rgba(255,255,255,.9)}
/* Ext link */ .extL{display:inline-flex;align-items:center} .extL::after{content:''; width:14px;height:14px; display:inline-block;margin:0 5px; background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23989b9f' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M13 11L21.2 2.80005'/><path d='M22 6.8V2H17.2'/><path d='M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13'/></svg>") center / 14px no-repeat} .extL.alt::after{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23989b9f' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M15 7h3a5 5 0 0 1 5 5 5 5 0 0 1-5 5h-3m-6 0H6a5 5 0 0 1-5-5 5 5 0 0 1 5-5h3'/><line x1='8' y1='12' x2='16' y2='12'/></svg>")}
/* Scroll img */ .psImg{display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:center; margin:2em 0; position:relative;left:-7px;right:-7px; width:calc(100% + 14px)} .psImg >*{width:calc(50% - 14px); margin:0 7px 14px; position:relative} .psImg img{display:block} .scImg >*{width:calc(33.3% - 14px); margin:0 7px} .btImg label{position:absolute;top:0;left:0;right:0;bottom:0; border-radius:5px; display:flex;align-items:center;justify-content:center; background:rgba(0,0,0,.6); transition:var(--trans-1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px); color:var(--darkT); font-size:13px;font-family:var(--fontB)} .hdImg .shImg{width:100%;margin:0; left:0;right:0; transition:var(--trans-1); max-height:0;opacity:0;visibility:hidden} .inImg:checked ~ .hdImg .shImg{max-height:1000vh;opacity:1;visibility:visible} .inImg:checked ~ .hdImg .btImg label{opacity:0;visibility:hidden}
/* Post related */ .pRelate{margin:40px 0;padding:20px 0; border:1px solid #989b9f;border-left:0;border-right:0; font-size:14px;line-height:1.8em} .pRelate a, .drK .pRelate a{color:inherit} .pRelate a:hover{text-decoration:underline} .pRelate b{font-weight:400; margin:0;opacity:.8} .pRelate ul, .pRelate ol{margin:8px 0 0;padding:0 20px}
/* Blockquote */ blockquote, .cmC i[rel=quote]{position:relative;font-size:.97rem; opacity:.8;line-height:1.6em;margin-left:0;margin-right:0;padding:5px 20px;border-left:2px solid var(--contentL)} blockquote.s-1, details.sp{font-size:.93rem; padding:25px 25px 25px 45px; border:1px solid #989b9f;border-left:0;border-right:0;line-height:1.7em} blockquote.s-1::before{content:'\201D';position:absolute;top:10px;left:0; font-size:60px;line-height:normal;opacity:.5}
/* Table */ .ps table{margin:0 auto; font-size:14px;font-family:var(--fontB)} .ps table:not(.tr-caption-container){min-width:90%;border:1px solid var(--contentL);border-radius:3px;overflow:hidden} .ps table:not(.tr-caption-container) td{padding:16px} .ps table:not(.tr-caption-container) tr:not(:last-child) td{border-bottom:1px solid var(--contentL)} .ps table:not(.tr-caption-container) tr:nth-child(2n+1) td{background:rgba(0,0,0,.01)} .ps table th{padding:16px; text-align:inherit; border-bottom:1px solid var(--contentL)} .ps .table{display:block; overflow-y:hidden;overflow-x:auto;scroll-behavior:smooth}
/* Img caption */ figure{margin-left:0;margin-right:0} .ps .tr-caption, .psCaption, figcaption{display:block; font-size:14px;line-height:1.6em; font-family:var(--fontB);opacity:.7}
/* Syntax */ .pre{background:var(--synxBg);color:var(--synxC); direction: ltr} .pre:not(.tb){position:relative;border-radius:3px;overflow:hidden;margin:1.7em auto;font-family:var(--fontC)} .pre pre{margin:0;color:inherit;background:inherit} .pre:not(.tb)::before, .cmC i[rel=pre]::before{content:'</>';display:flex;justify-content:flex-end;position:absolute;right:0;top:0;width:100%;background:inherit;color:var(--synxGray);font-size:10px;padding:0 10px;z-index:2;line-height:30px} .pre:not(.tb).html::before{content:'.html'} .pre:not(.tb).css::before{content:'.css'} .pre:not(.tb).js::before{content:'.js'} .pre:not(.tb):hover::before{content:'Double click to copy | </>'} .pre:not(.tb).html:hover::before{content:'Double click to copy | .html'} .pre:not(.tb).css:hover::before{content:'Double click to copy | .css'} .pre:not(.tb).js:hover::before{content:'Double click to copy | .js'} .pre[data-text]:not([data-text='']):not(.tb)::before{content:attr(data-text)} .pre[data-text]:not([data-text='']):not(.tb):hover::before{content:'Double Click to Copy | ' attr(data-text)} pre, .cmC i[rel=pre]{display:block;position:relative;font-family:var(--fontC);font-size:13px;line-height:1.6em;border-radius:3px;background:var(--synxBg);color:var(--synxC);padding:30px 20px 20px;margin:1.7em auto; -moz-tab-size:2;tab-size:2;-webkit-hyphens:none;-moz-hyphens:none;-ms-hyphens:none;hyphens:none; overflow:auto;direction:ltr;white-space:pre} pre i{font-style:normal} pre i.block{color:#fff;background:var(--synxBlue)} pre i.green{color:var(--synxGreen)} pre i.gray{color:var(--synxGray)} pre i.red{color:var(--synxOrange)} pre i.blue{color:var(--synxBlue)} code{display:inline;padding:5px;font-size:14px;border-radius:3px;line-height:inherit;color:var(--synxC);background:#f2f3f5;font-family:var(--fontC)}
/* Multi syntax */ .pre.tb{border-radius:5px} .pre.tb pre{margin:0;background:inherit} .pre.tb .preH{font-size:13px;border-color:rgba(0,0,0,.05);margin:0} .pre.tb .preH >*{padding:13px 20px} .pre.tb .preH::after{content:'</>';font-size:10px;font-family:var(--fontC);color:var(--synxGray);padding:15px;margin-left:auto} .pre.tb >:not(.preH){display:none} .pS input[id*="1"]:checked ~ div[class*="C-1"], .pS input[id*="2"]:checked ~ div[class*="C-2"], .pS input[id*="3"]:checked ~ div[class*="C-3"], .pS input[id*="4"]:checked ~ div[class*="C-4"]{display:block}
/* ToC */ .pS details summary{list-style:none;outline:none} .pS details summary::-webkit-details-marker{display:none} details.sp{padding:16px 20px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border:0;border-radius:10px;} details.sp summary{display:flex;justify-content:space-between;align-items:baseline} details.sp summary::after{content:attr(data-show);padding:4px 10px;background:var(--linkB);color:#fffdfc;font-size:12px;border-radius:var(--buttonR);cursor:pointer} details.sp[open] summary::after{content:attr(data-hide)} details.toc a:hover{text-decoration:underline} details.toc a{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;color:inherit} details.toc ol, details.toc ul{padding:0 20px; list-style-type:decimal} details.toc li ol, details.toc li ul{margin:5px 0 10px; list-style-type:lower-alpha}
/* Accordion */ .showH{margin:1.7em 0;font-size:.93rem;font-family:var(--fontB);line-height:1.7em} details.ac{padding:18px 15px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);margin:20px 0;border-radius:10px} details.ac summary{font-weight:700;cursor:default; display:flex;align-items:baseline; transition:var(--trans-1);cursor:pointer} details.ac summary::before{content:'\203A'; flex:0 0 25px;display:flex;align-items:center;justify-content:flex-start;padding:0 5px; font-weight:400;font-size:1.33rem;color:inherit} details.ac[open] summary{color:var(--linkC)} details.ac:not(.alt)[open] summary::before{transform:rotate(90deg);padding:0 0 0 5px;justify-content:center} details.ac.alt summary::before{content:'\002B'; padding:0 2px} details.ac.alt[open] summary::before{content:'\2212'} details.ac .aC{padding:0 15px;opacity:.9} .drK details.sp, .drK details.ac{background:var(--darkBs)} .drK details.sp summary::after{background:var(--darkU)}
/* Tabs */ .tbHd{display:flex; border-bottom:1px solid var(--contentL);margin-bottom:30px;font-size:14px;font-family:var(--fontB);line-height:1.6em; overflow-x:scroll;overflow-y:hidden;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .tbHd >*{padding:12px 15px; border-bottom:1px solid transparent; transition:var(--trans-1);opacity:.6;white-space:nowrap; scroll-snap-align:start} .tbHd >*::before{content:attr(data-text)} .tbCn >*{display:none;width:100%} .tbCn >* p:first-child{margin-top:0} .pS input[id*="1"]:checked ~ .tbHd label[for*="1"], .pS input[id*="2"]:checked ~ .tbHd label[for*="2"], .pS input[id*="3"]:checked ~ .tbHd label[for*="3"], .pS input[id*="4"]:checked ~ .tbHd label[for*="4"]{border-color:var(--linkB);opacity:1} .pS input[id*="1"]:checked ~ .tbCn div[class*="Text-1"], .pS input[id*="2"]:checked ~ .tbCn div[class*="Text-2"], .pS input[id*="3"]:checked ~ .tbCn div[class*="Text-3"], .pS input[id*="4"]:checked ~ .tbCn div[class*="Text-4"]{display:block} .tbHd.stick{position:-webkit-sticky;position:sticky;top:var(--headerH);background:var(--bodyB)}
/* Split */ .ps .blogPg{font-size:13px; justify-content:center; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .ps .blogPg >*{padding:8px 15px;margin:0 4px 8px}
/* Button */ .button{display:inline-flex;align-items:center; margin:10px 0;padding:12px 15px;outline:0;border:0; border-radius:var(--buttonR);line-height:20px; color:#fffdfc; background:var(--linkB); font-size:14px;font-family:var(--fontB); white-space:nowrap;overflow:hidden;max-width:320px} .button.ln{color:inherit;background:transparent; border:1px solid var(--bodyCa)} .button.ln:hover{border-color:var(--linkB);box-shadow:0 0 0 1px var(--linkB) inset} .btnF{display:flex;justify-content:center; margin:10px 0;width:calc(100% + 12px);left:-6px;right:-6px;position:relative} .btnF >*{margin:0 6px}
/* Download btn */ .dlBox{max-width:500px;background:#f1f1f0;border-radius:10px;padding:12px;margin:1.7em 0; display:flex;align-items:center; font-size:14px} .dlBox .fT{flex-shrink:0;display:flex;align-items:center;justify-content:center; width:45px;height:45px; padding:10px; background:rgba(0,0,0,.1);border-radius:var(--buttonR)} .dlBox .fT::before{content:attr(data-text);opacity:.7} .dlBox .fT.lazy{background-size:cover;background-position:center;background-repeat:no-repeat} .dlBox .fT.lazy::before{display:none} .dlBox a{flex-shrink:0;margin:0;padding:10px 12px;border-radius:var(--buttonR);font-size:13px} .dlBox a::after{content:attr(aria-label)} .dlBox .fN{flex-grow:1; width:calc(100% - 200px);padding:0 15px} .dlBox .fN >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .dlBox .fS{line-height:16px;font-size:12px;opacity:.8} .dldCo{display:flex;align-items:center;justify-content:center;max-width:480px;background:rgba(0,0,0,.03);border-radius:10px;margin:30px 0;transition:margin .6s ease;-webkit-transition:margin .6s ease} .dldCo::before{content:'Generating Download Link...';position:absolute;z-index:1;font-size:13px;font-family:var(--fontB);opacity:.8} .dldBx{visibility:hidden;opacity:0;transition:opacity .3s ease;-webkit-transition:opacity .3s ease} .dldSl{visibility:hidden;opacity:0;transition:opacity .3s ease,bottom .6s ease;-webkit-transition:opacity .3s ease,bottom .6s ease} .drK .dldCo{background:var(--darkBa)}
/* Icon btn */ .icon{flex-shrink:0;display:inline-flex} .icon::before{content:'';width:18px;height:18px;background-size:18px;background-repeat:no-repeat;background-position:center} .icon::after{content:'';padding:0 6px} .icon.dl::before, .drK .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")} .icon.demo::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><path d='M7.39999 6.32003L15.89 3.49003C19.7 2.22003 21.77 4.30003 20.51 8.11003L17.68 16.6C15.78 22.31 12.66 22.31 10.76 16.6L9.91999 14.08L7.39999 13.24C1.68999 11.34 1.68999 8.23003 7.39999 6.32003Z'/><path d='M10.11 13.6501L13.69 10.0601'/></svg>")} .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2308102b' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")}
/* Article Style Responsive */ @media screen and (max-width: 640px){.pS img.full{width:calc(100% + 40px);left:-20px;right:-20px; border-radius:0} .note{font-size:13px} .scImg{flex-wrap:nowrap;justify-content:flex-start;position:relative;width:calc(100% + 40px);left:-20px;right:-20px;padding:0 13px; overflow-y:hidden;overflow-x:scroll;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .scImg >*{flex:0 0 80%;scroll-snap-align:center} .ps .table{position:relative; width:calc(100% + 40px);left:-20px;right:-20px;padding:0 20px; display:flex}} @media screen and (max-width:500px){.hdImg{width:100%;left:0;right:0} .hdImg >*, .shImg >*{width:100%;margin:0 0 16px} .ps .tr-caption, .psCaption, figcaption{font-size:13px} .btnF >*{flex-grow:1;justify-content:center}.btnF >*:first-child{flex:0 0 auto} .dlBox a{width:42px;height:42px;justify-content:center} .dlBox a::after, .dlBox .icon::after{display:none}}
/* Author profile */ .admAbt{padding-top:30px} .admPs{display:flex; max-width:480px;margin:30px 0; padding:12px 12px 15px; background:var(--contentB);border-radius:8px; box-shadow:0 10px 25px -3px rgba(0,0,0,.1)} .admIm{flex-shrink:0; padding:5px 0 0} .admIm .im{width:34px;height:34px} .admI{flex-grow:1; width:calc(100% - 34px);padding:0 12px} .admN::before{content:attr(data-write) ' '; opacity:.7;font-size:90%} .admN::after{content:attr(data-text)} .admA{margin:5px 0 0; font-size:90%; opacity:.9;line-height:1.5em; /*display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden*/}
/* Share btn */ .pSh{margin:15px 0;padding:18px 0;border-bottom:1px solid rgba(0,0,0,.05)} .pShc{display:flex;align-items:center;flex-wrap:wrap; position:relative;width:calc(100% + 18px);left:-9px;right:-9px;font-size:13px} .pShc::before{content:attr(data-text);margin:0 9px;flex-shrink:0} .pShc >*{margin:0 5px; display:flex;align-items:center; color:inherit;padding:12px;border-radius:var(--buttonR);background:#f1f1f0} .pShc .c{color:#fffdfc} .pShc .c svg{fill:#fffdfc} .pShc .c::after{content:attr(aria-label)} .pShc .fb{background:#1778F2} .pShc .wa{background:#128C7E} .pShc .tw{background:#1DA1F2} .pShc a::after{content:attr(data-text);margin:0 3px} .pShc svg, .cpL svg{width:18px;height:18px; margin:0 3px} .shL{position:relative;width:calc(100% + 20px);left:-10px;right:-10px;margin-bottom:20px;display:flex;flex-wrap:wrap;justify-content:center} .shL >*{margin:0 10px 20px;text-align:center} .shL >*::after{content:attr(data-text);font-size:90%;opacity:.7;display:block} .shL a{display:flex;align-items:center;justify-content:center;flex-wrap:wrap; width:65px;height:65px; color:inherit;margin:0 auto 5px;padding:8px;border-radius:26px;background:#f1f1f0} .shL svg{opacity:.8} .cpL{padding-bottom:15px} .cpL::before{content:attr(data-text);display:block;margin:0 0 15px;opacity:.8} .cpL svg{margin:0 4px;opacity:.7} .cpL input{border:0;outline:0; background:transparent;color:rgba(8,16,43,.4); padding:18px 8px;flex-grow:1} .cpL label{color:var(--linkC);display:flex;align-items:center;align-self:stretch; flex-shrink:0;padding:0 8px} .cpLb{display:flex;align-items:center;position:relative;background:#f1f1f0;border-radius:4px 4px 0 0;border-bottom:1px solid rgba(0,0,0,.25); padding:0 8px} .cpLb:hover{border-color:rgba(0,0,0,.42);background:#ececec} .cpLn span{display:block;padding:5px 14px 0;font-size:90%;color:#2e7b32; transition:var(--trans-1);animation:fadein 2s ease forwards; opacity:0;height:22px} /* Label Hashtags */ .lbHt{position:relative;display:block;width:calc(100% + 40px);right:-20px;left:-20px;padding:8px 17px 20px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .lbHt >*{color:var(--bodyC);padding:9px 12px;background:var(--contentB);font-family:var(--fontVa);font-size:13px;border-radius:var(--greetR);box-shadow:3px 6px 15px rgba(0,0,0,.07);display:inline-flex;margin:0 3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;opacity:.8} .drK .lbHt >*{background:var(--darkBa);color:var(--darkT)} .Rtl .lbHt{text-align:right} .Rtl .lbHt{margin-right:0;margin-left:5px}
/* Widget Style */ .widget .imgThm{display:block;position:absolute;top:50%;left:50%;max-width:none;max-height:108%; font-size:12px;text-align:center; transform:translate(-50%, -50%)} .widget .title{margin:0 0 25px; font-size:var(--widgetT);font-weight:var(--widgetTw);position:relative} .widget .title.dt::before{position:absolute;top:0;right:0;content:'';width:20px;height:20px;display:inline-block;opacity:.3;background:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 276.167 276.167' fill='%23989b9f'><path d='M33.144,2.471C15.336,2.471,0.85,16.958,0.85,34.765s14.48,32.293,32.294,32.293s32.294-14.486,32.294-32.293 S50.951,2.471,33.144,2.471z'/><path d='M137.663,2.471c-17.807,0-32.294,14.487-32.294,32.294s14.487,32.293,32.294,32.293c17.808,0,32.297-14.486,32.297-32.293 S155.477,2.471,137.663,2.471z'/><path d='M243.873,67.059c17.804,0,32.294-14.486,32.294-32.293S261.689,2.471,243.873,2.471s-32.294,14.487-32.294,32.294 S226.068,67.059,243.873,67.059z'/><path d='M243.038,170.539c17.811,0,32.294-14.483,32.294-32.293c0-17.811-14.483-32.297-32.294-32.297 s-32.306,14.486-32.306,32.297C210.732,156.056,225.222,170.539,243.038,170.539z'/><path d='M136.819,170.539c17.804,0,32.294-14.483,32.294-32.293c0-17.811-14.478-32.297-32.294-32.297 c-17.813,0-32.294,14.486-32.294,32.297C104.525,156.056,119.012,170.539,136.819,170.539z'/><path d='M243.771,209.108c-17.804,0-32.294,14.483-32.294,32.294c0,17.804,14.49,32.293,32.294,32.293 c17.811,0,32.294-14.482,32.294-32.293S261.575,209.108,243.771,209.108z'/></svg>") center / 20px no-repeat} .Rtl .widget .title::before{right:auto;left:0;transform:rotate(-90deg);-webkit-transform:rotate(-90deg)} .widget .title::after{content:'';display:inline-block;vertical-align:middle; width:var(--widgetTa); margin:0 10px;border-bottom:1px solid var(--widgetTac); opacity:.5} .widget input[type=text], .widget input[type=email], .widget textarea{display:block;width:100%;outline:0;border:0;border-bottom:1px solid rgba(0,0,0,.25);border-radius:4px 4px 0 0;background:#f3f3f4; padding:25px 16px 8px 16px; line-height:1.6em; transition:var(--trans-1)} .widget input[type=text]:hover, .widget input[type=email]:hover, .widget textarea:hover{border-color:rgba(0,0,0,.42);background:#ececec} .widget input[type=text]:focus, .widget input[type=email]:focus, .widget textarea:focus, .widget input[data-text=fl], .widget textarea[data-text=fl]{border-color:var(--linkB);background:#ececec} .widget input[type=button], .widget input[type=submit]{display:inline-flex;align-items:center; padding:12px 30px; outline:0;border:0;border-radius:4px; color:#fffdfc; background:var(--linkB); font-size:14px; white-space:nowrap;overflow:hidden;max-width:100%} .widget input[type=button]:hover, .widget input[type=submit]:hover{opacity:.7}
/* Widget BlogSearch */ .BlogSearch{position:fixed;top:0;left:0;right:0;z-index:12} .BlogSearch form{position:relative;min-width:320px} .BlogSearch input{position:relative;display:block;background:var(--srchB);border:0;outline:0;margin-top:-100%;padding:10px 55px;width:100%;height:72px;transition:var(--trans-1);z-index:2;border-radius:0 0 var(--srchMr) var(--srchMr)} .BlogSearch input:focus{margin-top:0;box-shadow:0 10px 40px rgba(0,0,0,.2)} .BlogSearch input:focus ~ button.sb{opacity:.9} .BlogSearch .sb{position:absolute;left:0;top:0;display:flex;align-items:center;padding:0 20px;z-index:3;opacity:.7;height:100%;background:transparent;border:0;outline:0} .BlogSearch .sb svg{width:18px;height:18px;stroke:var(--srchI)} .BlogSearch button.sb{left:auto;right:0;opacity:0;font-size:13px} .BlogSearch button.sb::before{content:'\2715'} @media screen and (min-width:897px){header .BlogSearch{position:static;z-index:1} header .BlogSearch input{margin-top:0;padding:12px 42px;height:auto;font-size:13px;border-radius:var(--srchDr);background:rgba(0,0,0,.03); width:calc(100% + 26px);left:-13px;right:-13px;transition:var(--trans-2)} header .BlogSearch input:hover{background:var(--transB)} header .BlogSearch input:focus{box-shadow:none;margin-top:0; background:var(--transB)} header .BlogSearch .sb{padding:0} header .BlogSearch .fCls{display:none}}
/* Widget Profile */ .prfI:checked ~ .mainWrp .wPrf{top:0;opacity:1;visibility:visible} .prfI:checked ~ .mainWrp .wPrf ~ .fCls{z-index:3;opacity:1;visibility:visible} .wPrf{display:flex;position:absolute;top:-5px;right:0;background:var(--contentB);border-radius:16px 5px 16px 16px;width:260px;max-height:400px;box-shadow:0 10px 25px -3px rgba(0,0,0,.1);transition:var(--trans-1);z-index:4;opacity:0;visibility:hidden;overflow:hidden} .wPrf .prfS{background:inherit} .wPrf.tm .im{width:39px;height:39px;flex-shrink:0} .wPrf.sl .im{width:60px;height:60px;border-radius:26px;margin:0 auto} .wPrf.sl .prfC{text-align:center} .prfH .c{display:none} .prfL{display:flex;align-items:center;position:relative;width:calc(100% + 16px);left:-8px;right:-8px;border-radius:8px;padding:8px 0;transition:var(--trans-1)} .prfL::after{content:attr(data-text);margin:0 2px} .prfL >*{margin:0 8px;flex-shrink:0} a.prfL:hover{background:var(--transB)} .sInf{margin-bottom:0} .sInf .sDt .l{display:inline-flex;align-items:center} .sInf .sTxt{margin:5px auto 0;max-width:320px;font-size:93%;opacity:.9;line-height:1.5em} .sInf .sTxt a{text-decoration:underline} .sInf .lc{display:flex;justify-content:center;margin:10px 0 0;opacity:.8;font-size:90%} .sInf .lc svg{width:16px;height:16px} .sInf .lc::after{content:attr(data-text);margin:0 4px}
/* Widget Scroll Menu */ .navS{background:var(--navB);overflow-y:hidden;overflow-x:scroll;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch; display:flex;padding:0;border-radius:10px} .navS ul{display:flex;list-style:none;margin:0;padding:0;white-space:nowrap} .navS li{margin:0 15px;padding:10px 0;position:relative;scroll-snap-align:start} .navS li:first-child{margin-left:auto} .navS li:last-child{margin-right:auto} .navS .l{display:block;color:var(--bodyC);padding:8px 0} .navS .l::before{content:attr(data-text)} .navS .l::after{content:'';height:1px;border-radius:2px 2px 0 0;background:var(--linkC);position:absolute;bottom:0;left:0;right:0;opacity:0} .navS span.l{opacity:.7} .navS a.l:hover, .navS .l.a{color:var(--linkC)} @media screen and (max-width:896px){.navS .secIn{padding:0} .navS li{margin:0;padding:8px 0;display:flex} .navS li::before{content:'';padding:10px} .navS ul::after{content:'';display:block;padding:10px;scroll-snap-align:start} .navS .l{position:relative} .navS .l::after{bottom:-8px} .navS a.l:hover::after, .navS .l.a::after{opacity:1}} @media screen and (max-width:500px){.navS{font-size:13px}} .drK .navS{background:var(--darkBs)} .drK .navS .l{color:var(--darkC)} .drK .navS a.l:hover, .drK .navS .l.a{color:var(--darkU)} .drK .navS .l::after{background:var(--darkU)}
/* Widget FeaturedPost */ @media screen and (min-width:501px){.FeaturedPost .itemFt{position:relative;overflow:hidden;padding:10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .drK .FeaturedPost .itemFt{background:var(--darkBa)} .FeaturedPost .itemFt::after{content:'';position: absolute;right:0;top:0;width:40px;height:15px;background:var(--linkB);border-radius:0 0 0 20px;opacity:.2}} .itemFt .itm >*{flex:0 0 310px;width:310px} .itemFt .itm >*:last-child{flex:1 0 calc(100% - 310px - 40px);width:calc(100% - 310px - 40px)}
/* Widget PopularPosts */ .PopularPosts{padding:20px 20px 30px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .itemPp{counter-reset:p-cnt} .itemPp .iCtnt{display:flex} .itemPp >*:not(:last-child){margin-bottom:25px} .itemPp .iCtnt::before{flex-shrink:0;content:'0' counter(p-cnt);counter-increment:p-cnt;width:25px;opacity:.6;font-size:85%;line-height:1.8em} .iInr{flex:1 0;width:calc(100% - 25px)} .iTtl{font-size:.95rem;font-weight:700;line-height:1.5em} .iTtmp{display:inline-flex} .iTtmp::after{content:'\2014';margin:0 5px; color:var(--widgetTac);opacity:.7} .iInf{margin:0 25px 8px; overflow:hidden;white-space:nowrap;text-overflow:ellipsis} .iInf .pLbls{display:inline;opacity:.8}
/* Widget Label */ /* List Label */ .Label{padding:20px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .wL ul{display:flex;flex-wrap:wrap; list-style:none;margin:0;padding:0; position:relative;width:calc(100% + 30px);left:-15px;right:-15px; font-size:13px} .wL li{width:calc(50% - 10px); margin:0 5px} .wL li >*{display:flex;align-items:baseline;justify-content:space-between; color:var(--bodyC);width:100%; padding:8px 10px;border-radius:4px;line-height:20px} .wL li >* svg{width:18px;height:18px;opacity:.8} .wL li >*:hover svg, .wL li >div svg{/*fill:var(--linkC) !important;*/stroke:var(--linkC)} .wL li >*:hover .lbC, .wL li >div .lbC{color:var(--linkC)} .wL .lbR{display:inline-flex;align-items:center} .wL .lbR .lbC{margin:0 5px} .wL .lbAl{max-height:0; overflow:hidden; transition:var(--trans-4)} .wL .lbM{display:inline-block; margin-top:10px;line-height:20px; color:var(--linkC);cursor:pointer} .wL .lbM::before{content:attr(data-show)} .wL .lbM::after, .wL .lbC::after{content:attr(data-text)} .wL .lbM::after{margin:0 8px} .wL .lbT{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.7} .wL .lbC, .wL .lbM::after{flex-shrink:0;font-size:12px;opacity:.7} .lbIn:checked ~ .lbAl{max-height:1000vh} .lbIn:checked ~ .lbM::before{content:attr(data-hide)} .lbIn:checked ~ .lbM::after{visibility:hidden} .wL.bg ul{width:calc(100% + 10px);left:-5px;right:-5px} .wL.bg li{margin-bottom:10px} .wL.bg li >*{background:#f6f6f6} /* Cloud Label */ .wL.cl{display:flex;flex-wrap:wrap} .wL.cl >*, .wL.cl .lbAl >*{display:block;max-width:100%} .wL.cl .lbAl{display:flex;flex-wrap:wrap} .wL.cl .lbC::before{content:'';margin:0 4px;flex:0 0} .wL.cl .lbN{display:flex;justify-content:space-between; margin:0 0 8px;padding:9px 13px; border:1px solid var(--contentL);border-radius:3px; color:inherit;line-height:20px} .wL.cl .lbN:hover .lbC, .wL.cl div.lbN .lbC{color:var(--linkB); opacity:1} .wL.cl .lbN:not(div):hover, .wL.cl div.lbN{border-color:var(--linkB)} .wL.cl .lbSz{display:flex} .wL.cl .lbSz::after{content:'';margin:0 4px;flex:0 0}
/* Widget ContactForm */ .ContactForm{max-width:500px; font-family:var(--fontB);font-size:14px} .cArea:not(:last-child){margin-bottom:25px} .cArea label{display:block;position:relative} .cArea label .n{display:block;position:absolute;left:0;right:0;top:0; color:rgba(8,16,43,.4);line-height:1.6em;padding:15px 16px 0;border-radius:4px 4px 0 0;transition:var(--trans-1)} .cArea label .n.req::after{content:'*';font-size:85%} .cArea textarea{height:100px} .cArea textarea:focus, .cArea textarea[data-text=fl]{height:200px} .cArea input:focus ~ .n, .cArea textarea:focus ~ .n, .cArea input[data-text=fl] ~ .n, .cArea textarea[data-text=fl] ~ .n{padding-top:5px;color:rgba(8,16,43,.7);font-size:90%;background:#ececec} .cArea .h{display:block;font-size:90%;padding:5px 16px 0;opacity:.7;line-height:normal} .nArea .contact-form-error-message-with-border{color:#d32f2f} .nArea .contact-form-success-message-with-border{color:#2e7b32} .tNtf img.contact-form-cross{display:none}
/* Widget Sliders */ .sldO{position:relative;display:flex;overflow-y:hidden;overflow-x:scroll; scroll-behavior:smooth;scroll-snap-type:x mandatory;list-style:none;margin:0;padding:0;border-radius:5px; -ms-overflow-style: none} .sldO.no-items{display:none} .sldO.no-items + .section{margin-top:0} .sldO .widget:not(:first-child){margin-top:0} .sldO .widget{position:relative;flex:0 0 100%;width:100%;background:transparent; outline:0;border:0} .sldC{position:relative} .sldS{position:absolute;top:0;left:0;width:100%;height:100%;scroll-snap-align:center;z-index:-1} .sldIm{background-repeat:no-repeat;background-size:cover;background-position:center;background-color:var(--transB);display:block;padding-top:40%;border-radius:5px;color:#fffdfc;font-size:13px} .sldT{position:absolute;bottom:0;left:0;right:0;display:block;padding:20px; background:linear-gradient(0deg, rgba(30,30,30,.1) 0%, rgba(30,30,30,.05) 60%, rgba(30,30,30,0) 100%); border-radius:0 0 3px 3px} .sldS{animation-name:tonext, snap;animation-timing-function:ease;animation-duration:4s;animation-iteration-count:infinite} .sldO .widget:last-child .sldS{animation-name:tostart, snap} .Rtl .sldS{animation-name:tonext-rev, snap} .Rtl .sldO .widget:last-child .sldS{animation-name:tostart-rev, snap} .sldO:hover .widget .sldS, .Rtl .sldO:hover .widget .sldS, .sldO:focus-within .widget .sldS, .Rtl .sldO:focus-within .widget .sldS{animation-name:none} @media (prefers-reduced-motion:reduce){.sldS, .Rtl .sldS{animation-name:none}} @media screen and (max-width:640px){.sldO{width:calc(100% + 40px);left:-20px;right:-20px;padding:0 12.5px 10px;border-radius:0} .sldO .widget{flex:0 0 90%;width:90%;margin:0 7.5px; box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%)} .sldT{padding:10px 15px} .sldIm{font-size:12px}}
/* Google Transalte */ .goog-te-banner-frame.skiptranslate, .goog-te-gadget-simple img, img.goog-te-gadget-icon, .goog-te-menu-value span, #goog-gt-tt, .goog-tooltip, .goog-tooltip:hover, .goog-logo-link, .goog-te-balloon-frame{display:none!important} .goog-text-highlight{background-color: transparent !important;box-shadow:none !important;-webkit-box-shadow:none !important} .goog-te-menu-frame{box-shadow:none!important} .goog-te-gadget-simple{background-color:transparent!important;border:none!important;outline:0 !important;-ms-touch-action:manipulation;touch-action:manipulation;-webkit-user-select:none !important;-moz-user-select:none !important;-ms-user-select:none !important;user-select:none !important} #google_translate_element{position:absolute !important;z-index:2 !important;overflow:hidden !important} #google_translate_element, .skiptranslate.goog-te-gadget, .goog-te-gadget-simple{width:40px !important;height:40px !important;padding:0 !important;margin:0 !important;border-radius:50% !important}
/* Widget Music Player */ #musicPlayer{position:relative;direction:ltr;width:100%;min-height:200px;max-width:480px;margin:20px 0;background:rgba(0,0,0,.03);border-radius:20px;display:flex;align-items:center;justify-content:center} #musicPlayer::before{content:'Loading Tracks...';position:absolute;color:inherit;font-size:13px;font-family:var(--fontB);opacity:.8} .drK #musicPlayer{background:var(--darkBs)}
/* Pop-up */ .fxPu{position:fixed;top:-50%;bottom:-50%;top:-50%;left:-50%;right:-50%;z-index:70;background:rgba(0,0,0,.4);visibility:hidden;opacity:0;transition:all .6s ease;-webkit-transition:all .6s ease} .fxPu.visible{visibility:visible;opacity:1} .fxPuW{position:fixed;top:0;bottom:0;top:0;left:0;right:0;z-index:71;padding:20px;display:flex;flex-direction:column;justify-content:center;align-items:center} .fxPuC{position:relative;background:#fffdfc;width:100%;max-width:500px;padding:20px 25px 25px;border-radius:20px} .fxPuCl::after{content:'\2715';line-height:16px;font-size:12px;color:#fffdfc;position:absolute;top:-15px;right:15px;background:var(--linkC);display:flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;transition:var(--trans-1);-webkit-transition:var(--trans-1);cursor:pointer} .fxPuCl:hover::after{transform:scale(1.03);-webkit-transform:scale(1.03)} .fxPuS{display:block;text-align:center;margin-bottom:5px} .fxPuS svg.line{stroke-width:1;width:50px;height:50px} .fxPuH{font-size:1.2rem;font-weight:700;font-family:var(--fontBa);margin-bottom:10px;text-align:center} .fxPuD{line-height:1.7em;font-size:15px} .fxPuB{text-align:center;margin-top:20px} .fxPuB .btn{width:45px;height:45px;outline:none;border:none;display:inline-flex;align-items:center;justify-content:center;background:var(--linkC);border-radius:50%} .fxPuB .btn:hover{opacity:.8} .fxPuB .btn svg{stroke:#fffdfc} .drK .fxPuC{background:var(--darkBs)} .drK .fxPuCl::after, .drK .fxPuB .btn{background:var(--darkU)}
/* Toast Notif */ .tNtf span{position:fixed;left:24px;bottom:-70px;display:inline-flex;align-items:center;text-align:center;justify-content:center;z-index:997;background:#323232;color:rgba(255,255,255,.8);font-size:14px;font-family:var(--fontB);border-radius:3px;padding:13px 24px;box-shadow:0 5px 35px rgba(149,157,165,.3);opacity:0;transition:var(--trans-1);animation:slidein 2.3s ease forwards;-webkit-animation:slidein 2.3s ease forwards} .tNtf span i{content:''; width:14px;height:14px; display:inline-block;margin:0 5px;opacity:.8} .tNtf span i.check{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M22 11.08V12a10 10 0 1 1-5.93-9.14'/><polyline points='22 4 12 14.01 9 11.01'/></svg>") center / 14px no-repeat} .tNtf span i.warn{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><g transform='translate(2.500000, 3.000000)'><path d='M9.5,18 C3.00557739,18 0.456662548,17.5386801 0.0435259337,15.2033146 C-0.36961068,12.8679491 2.27382642,8.47741935 3.08841712,7.02846996 C5.81256986,2.18407813 7.66371927,0 9.5,0 C11.3362807,0 13.1874301,2.18407813 15.9115829,7.02846996 C16.7261736,8.47741935 19.3696107,12.8679491 18.9564741,15.2033146 C18.5443995,17.5386801 15.9944226,18 9.5,18 Z'/><line x1='9.5' y1='5.5' x2='9.5' y2='9.395'/><line x1='9.4957' y1='12.895' x2='9.5047' y2='12.895'/></g></svg>") center / 14px no-repeat} .tNtf span i.copy{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><rect x='9' y='9' width='13' height='13' rx='2' ry='2'/><path d='M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1'/></svg>") center / 14px no-repeat} .tNtf span i.clipboard{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2'/><rect x='8' y='2' width='8' height='4' rx='1' ry='1'/></svg>") center / 14px no-repeat} .tNtf span i.onCloud{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z'/></svg>") center / 14px no-repeat} .tNtf span i.offCloud{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M22.61 16.95A5 5 0 0 0 18 10h-1.26a8 8 0 0 0-7.05-6M5 5a8 8 0 0 0 4 15h9a5 5 0 0 0 1.7-.3'/><line x1='1' y1='1' x2='23' y2='23'/></svg>") center / 14px no-repeat} .tNtf span i.onWifi{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M5 12.55a11 11 0 0 1 14.08 0'/><path d='M1.42 9a16 16 0 0 1 21.16 0'/><path d='M8.53 16.11a6 6 0 0 1 6.95 0'/><line x1='12' y1='20' x2='12.01' y2='20'/></svg>") center / 14px no-repeat} .tNtf span i.offWifi{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><line x1='1' y1='1' x2='23' y2='23'/><path d='M16.72 11.06A10.94 10.94 0 0 1 19 12.55'/><path d='M5 12.55a10.94 10.94 0 0 1 5.17-2.39'/><path d='M10.71 5.05A16 16 0 0 1 22.58 9'/><path d='M1.42 9a15.91 15.91 0 0 1 4.7-2.88'/><path d='M8.53 16.11a6 6 0 0 1 6.95 0'/><line x1='12' y1='20' x2='12.01' y2='20'/></svg>") center / 14px no-repeat} .tNtf span i.del{background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><g transform='translate(3.500000, 2.000000)'><path d='M15.3891429,7.55409524 C15.3891429,15.5731429 16.5434286,19.1979048 8.77961905,19.1979048 C1.01485714,19.1979048 2.19295238,15.5731429 2.19295238,7.55409524'/><line x1='16.8651429' y1='4.47980952' x2='0.714666667' y2='4.47980952'/><path d='M12.2148571,4.47980952 C12.2148571,4.47980952 12.7434286,0.714095238 8.78914286,0.714095238 C4.83580952,0.714095238 5.36438095,4.47980952 5.36438095,4.47980952'/></g></svg>") center / 14px no-repeat} .Rtl .tNtf span{left:auto;right:24px} @media screen and (max-width:896px){.tNtf span{margin-bottom:50px}} @media screen and (max-width:500px){.tNtf span{left:20px;right:20px;font-size:13px}  .tNtf.alt span, .Rtl .tNtf.alt span{left:0;right:0;margin-bottom:-25px;justify-content:left;text-align:left;font-size:15px;padding:15px 24px;border-radius:0} .Rtl .tNtf.alt span{justify-content:right;text-align:right} .Rtl .tNtf span{left:20px;right:20px}} .drK .tNtf span{box-shadow:0 10px 40px rgba(0,0,0,.2)} .MN-4 .tNtf span{margin-bottom:0;animation-duration:2s;-webkit-animation-duration:2s}
/* Neon Lighting */ .nLght::before, .nLght::after{content:'';position:fixed;width:100%;bottom:0;left:0;right:0;height:3px;z-index:55;background:linear-gradient(-45deg, #4086F4, #31A952, #FBBE01, #EB4132,#4086F4, #31A952, #FBBE01, #EB4132);background-size:200%;-webkit-animation:animeNeon 5s linear infinite;animation:animeNeon 5s linear infinite;visibility:none;opacity:0;transition:all 1s ease} .nLght::after{height:10px;filter:blur(10px)} .nLght.vsbl::before, .nLght.vsbl::after{visibility:visible;opacity:.7} @-webkit-keyframes animeNeon{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}} @keyframes animeNeon{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
/* Maintenance Mode */ .mtm{position:fixed;left:0;right:0;top:-35%;bottom:-35%;display:flex;align-items:center;justify-content:center;background:var(--bodyB);transition:all .5s ease;-webkit-transition:all .5s ease;visibility:visible;opacity:1;z-index:499} .mtm.hdn{visibility:hidden;opacity:0} .mtmC{max-width:450px;padding:20px;text-align:center} .mtmH{font-weight:700;font-size:1.5rem;font-family:var(--fontBa);margin-bottom:10px} .mtmD{margin-bottom:10px} .mtm .clock{width:100%;font-size:25px;text-align:center;font-family:var(--fontBa);font-weight:400;position:relative;left:0;right:0} .mtm .tBox{width:65px;height:65px;margin:3px;padding-top:8px;background-color:#f4efff;border-radius:20px;display:inline-block} .mtm .unit{display:block;font-size:10px;margin:auto;font-family:var(--fontB);opacity:0.8} .drK .mtm{background:var(--darkB)} .drK .mtm .tBox{background:var(--darkBa)}

/* bookmark widget By Tech & Fun Zone*/
.pop-area::-webkit-scrollbar{display:none}
.pop-area{display:flex!important;width:100%;height:100%;position:fixed;top:0;left:0;background:rgb(0 0 0 / 51%);visibility:hidden;opacity:0;transition: var(--trans-2);z-index:999999;overflow-y:scroll}
.pop-area.open{opacity:1;visibility:visible}
.pop-area .pop-html{background:#fff;padding-bottom:10px;display:block;margin:auto auto;width:calc(100% - 20px);max-width:500px;visibility:hidden;opacity:0;overflow:hidden;transition: var(--trans-2);transform:scale(.5);border-radius:7px;box-shadow:0 9px 46px 8px rgba(0,0,0,.14),0 11px 15px -7px rgba(0,0,0,.12),0 24px 38px 3px rgba(0,0,0,.2)}
.pop-area.open .pop-html{opacity:1;transform:scale(1);visibility:visible}
.pop-area .head-pop{width:-webkit-fill-available;padding:12px 30px;overflow:hidden;/*background:#d3f6f3*/border-bottom: 1px solid #e6e6e6;}
.pop-area .close-btn{float:right;cursor:pointer;fill:#7e7e7e}
.pop-area .buka-tutup svg {width: 20px;height: 20px;fill: none!important;stroke: #08102b;stroke-linecap: round;stroke-linejoin: round;stroke-width: 1px;}
.pop-area .body-content{padding:10px}
.pop-area .text-center{display:grid;text-align:center;grid-gap:15px}
.pop-area .text-center svg{margin:0 auto}
.pop-area .btn.btn-outline-info{width:fit-content;margin:0 auto;text-decoration:none}
.pop-area .table{width:100%;border: 1px solid #e6e6e6;border-radius:7px;margin:5px 0;padding:5px}
.pop-area .table img{border-radius:4px;width:auto;background: var(--mobHv);}
.pop-area .table a{text-decoration:none;color: var(--fotT);}
.pop-area .table:hover{border-color:var(--linkC)}
.pop-area .img-left{width:140px;height:60px}
.pop-area .item-left{/*vertical-align:-webkit-baseline-middle;*/padding-right:10px}
.pop-area .btn-remove{cursor:pointer}
.pop-area .btn-remove svg{fill:none!important;stroke:var(--iconC);stroke-linecap:round;stroke-linejoin:round;stroke-width:1;}
.show-bookmark{font-size:11px;line-height:18px;padding:0 5px;border-radius:10px;background:#e6e6e6;color:var(--bodyC);position:absolute;top:-5px;right:0;z-index:2;animation:indicator 4s ease infinite;-webkit-animation:indicator 1s ease infinite;z-index:1}@-webkit-keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}@keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}
.counterStat{color:white;font-size:16px}
.pop-area .head-pop b::after{content:'';display:inline-block;vertical-align:middle;width:var(--widgetTa);margin:0 10px;border-bottom:1px solid var(--widgetTac);opacity:.5}
.pop-area .head-pop b{margin:0 0 25px;font-size:var(--widgetT);font-weight:var(--widgetTw);position:relative}
.pop-area .table img::before{content:'No image';display:block;position:absolute;top:50%;left:50%;max-width:none;max-height:100%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);font-size:12px;opacity:.7;white-space:nowrap;}
/*dark mode adjust if the class is different*/
.drK.pop-area .pop-html{background:var(--darkB);color:var(--darkT)}
.drK.pop-area .buka-tutup svg,.drK .btn-remove svg{stroke:var(--darkT)}
.drK.pop-area .table img {background: var(--darkTa);}
.drK.pop-area .table a {color: var(--darkT)}

/* Sticky Ad */ .ancrA{position:fixed;bottom:0;left:0;right:0;max-height:200px;padding:5px;box-shadow:0 -6px 18px 0 rgba(9,32,76,.1); transition:var(--trans-1);display:flex;align-items:center;justify-content:center;background:#fffdfc;z-index:50;border-top:1px solid var(--contentL)} .ancrC{width:40px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:12px 0 0;border:1px solid var(--contentL);border-bottom:0;border-right:0;position:absolute;right:0;top:-30px;background:inherit} .ancrC svg{width:18px;height:18px;fill:none!important;stroke:var(--iconC);stroke-linecap:round;stroke-linejoin:round;stroke-width:1.4} .ancrCn{flex-grow:1;overflow:hidden;display:block;position:relative} .ancrI:checked ~ .ancrA{padding:0;min-height:0} .ancrI:checked ~ .ancrA .ancrCn{display:none} .ancrI:checked ~ .ancrA .ancrC svg{-webkit-transform:rotate(180deg);transform:rotate(180deg)}
/* Error Page */ .erroP{display:flex;align-items:center;justify-content:center;height:100vh;text-align:center;padding:0} .erroC{width:calc(100% - 40px);max-width:450px;margin:auto;font-family:var(--fontBa)} .erroC h3{font-size:1.414rem;font-family:inherit} .erroC h3 span:not(.e){position:relative} .erroC h3 span.e{display:block;font-size:140px;line-height:.8;margin-bottom:-1rem;color:#ebebf0} .erroC h3 span.e{animation:glitch 1s linear infinite} .erroC h3 span.e::before, .erroC h3 span.e::after{content:attr(title);position:absolute;left:0;right:0} .erroC h3 span.e::before{animation:glitchTop 1s linear infinite;clip-path:polygon(0 0, 100% 0, 100% 33%, 0 33%);-webkit-clip-path:polygon(0 0, 100% 0, 100% 33%, 0 33%)} .erroC h3 span.e::after{animation:glitchBotom 1.5s linear infinite;clip-path:polygon(0 67%, 100% 67%, 100% 100%, 0 100%);-webkit-clip-path:polygon(0 67%, 100% 67%, 100% 100%, 0 100%)} .erroC p{margin:30px 5%;line-height:1.6em;opacity:.7} .erroC .button{margin:0;padding-left:2em;padding-right:2em;font-size:14px}
/* Responsive */
@media screen and (min-width:897px){
/* mainIn */ .mainIn, .blogM{display:flex} .blogMn{width:var(--navW);flex-shrink:0;position:relative;transition:var(--trans-1);z-index:1} .blogCont{padding-top:30px} .blogCont::before{content:'';position:absolute;top:var(--headerHi);left:0;height:calc(100% + var(--headerH))} .blogCont{width:calc(100% - var(--navW))} .mnBrs{box-shadow:0 0 15px rgba(0,0,0,.07)} .blogCont .secIn{padding-left:25px;padding-right:25px} .mainbar{flex:1 0 calc(100% - var(--sideW) - 25px);width:calc(100% - var(--sideW) - 25px)} .sidebar{display:flex;flex:0 0 calc(var(--sideW) + 25px);width:calc(var(--sideW) + 25px); margin:0} .sidebar::before{content:'';flex:0 0 25px} .sidebar .sideIn{width:calc(100% - 25px)}
/* mainNav */ .mnBr{position:sticky;position:-webkit-sticky;top:var(--headerH)} .mnBrs{display:flex;height:calc(100vh - var(--headerH));font-size:13px;position:relative} .mnBrs >*:not(.mnMob){width:100%} .mnMen{padding:20px;overflow-y:hidden;overflow-x:hidden} .mnMen:hover{overflow-y:scroll} .mnMob{position:fixed;width:var(--navW)} .mnH, .mobMn{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .blogMn, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob, .hdMn .navI:not(:checked) ~ .mainWrp .blogMn, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob{width:75px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn a:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn a:hover{opacity:1;color:inherit} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .a, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .a{max-width:40px; border-radius:15px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .drp.mr, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn svg.d, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .PageList, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mSoc, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .drp.mr, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn svg.d, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .PageList, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mSoc{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mNav, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mNav{display:flex} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn >li.br::after, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn >li.br::after{max-width:20px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen:hover{overflow-y:visible;overflow-x:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{position:absolute;left:35px;top:3px;margin:0 5px;padding:8px 10px;border-radius:5px 16px 16px 16px;max-width:160px;background:var(--contentB);color:var(--bodyC);opacity:0;visibility:hidden;box-shadow:0 5px 20px 0 rgba(0,0,0,.1);z-index:1} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{padding:0 5px;margin:0;overflow:hidden;display:block} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):last-child ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):last-child ul{top:auto;bottom:3px;border-radius:16px 16px 16px 5px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):hover ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):hover ul{opacity:1;visibility:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn ul li >*, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn ul li >*{border-radius:0}
/* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} .onIndx.onMlt .blogPts >*{flex:0 0 calc(25% - 20px);width:calc(25% - 20px)}
}
@media screen and (min-width:768px){
::-webkit-scrollbar{-webkit-appearance:none;width:8px;height:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:10px}::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.35)}::-webkit-scrollbar-thumb:active{background:rgba(0,0,0,.35)}
}
@media screen and (max-width:1600px){
/* Quick Edit */ .nBtm.qEdit .qeBtn{margin-bottom:85px}
/* Back to Top */ .nBtm.toTopB{margin-bottom:80px}
}
@media screen and (max-width:1100px){
/* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} .onIndx.onMlt .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)}
/* Widget */ .itemFt .itm >*, .itemFt .itm >*:last-child{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} .itemFt .itm >*:last-child{flex-grow:1} .itemFt .pSnpt{display:none}
}
/* mainNav */ .blogMn{display:flex;justify-content:flex-start;position:fixed;left:0;top:0;bottom:0;margin-left:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%} .flT .blogMn{left:15px;top:15px;bottom:15px;height:auto} .flT .mnBr{border-radius:20px;width:80%} .Rtl.flT .blogMn{left:auto;right:15px} .mnBr{width:85%;max-width:480px;height:100%;border-radius:0 12px 12px 0;transition:inherit;z-index:3;overflow:hidden;position:relative;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .mnBrs{padding:60px 0 0;overflow-y:scroll;overflow-x:hidden;width:100%;height:100%} .mnH{padding:0 15px} .mnH label{padding:15px 10px} .mnH .c::after{margin:0 13px} .mnMen{padding-top:0} .navI:checked ~ .mainWrp .blogMn{margin-left:0} .navI:checked ~ .mainWrp .blogMn .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)}
/* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)}
/* Widget */ .itemFt .pSnpt{display:-webkit-box} .bD:not(.MN-4) .mobMn:not(.no-items) + footer{padding-bottom:calc(55px + 30px)} .bD:not(.MN-4) .wvH{height:calc(100px + 60px)}
/* Widget Scroll Menu */ .HD-2 .navS{box-shadow:0 0 25px rgba(0,0,0,.07)}
/* Back To Top */ .bD:not(.MN-4) .toTopB{margin-bottom:45px} .bD:not(.MN-4) .nBtm.toTopB{margin-bottom:145px} .MN-4 .nBtm.toTopB{margin-bottom:80px}
}
@media screen and (max-width:768px){
/* Article */ .onIndx.onHm .blogPts >*, .onIndx.onMlt .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)}
}
/* Pop-up */ .fixL{align-items:flex-end} .fixL .fixLi, .fixL .cmBri{border-radius:12px 12px 0 0; max-width:680px} .fixL .cmBri:not(.mty){border-radius:0;height:100%;max-height:100%}
/* Footer */ footer{padding-top:30px}
}
@media screen and (max-width:500px){
/* Font and Blog */ .iFxd, .crdtIn{font-size:12px} .brdCmb{font-size:13px} .pDesc{font-size:14px} .pEnt{font-size:var(--postFm)} .pTtl.itm{font-size:var(--postTm)} .pInf.ps .pTtmp::after{content:attr(data-time)} .pInf.ps .pDr{font-size:12px} .pInf .pNm, .pInf .pDr{display:flex;flex-direction:column} .pInf .pDr >*:not(:first-child)::before{display:none}
/* Article */ .onIndx:not(.oneGrd) .blogPts{width:calc(100% + 10px);left:-5px;right:-5px} .onIndx:not(.oneGrd) .blogPts >*{padding:8px 8px 40px;flex:0 0 calc(50% - 10px);width:calc(50% - 10px);margin-left:5px;margin-right:5px;margin-bottom:10px} .onIndx:not(.oneGrd) .blogPts .pTag{padding-bottom:5px} .onIndx:not(.oneGrd) .blogPts div.ntry{flex:0 0 calc(100% - 10px)} .onIndx:not(.oneGrd) .pCntn{padding:0} .onIndx:not(.oneGrd) .ntry .pSml{font-size:12px} .onIndx:not(.oneGrd) .blogPts .pInf{bottom:10px;left:8px;right:8px} .onIndx:not(.oneGrd) .ntry .iFxd{font-size:10px} .onIndx:not(.oneGrd) .ntry .iFxd:not(.l) >*{margin-left:0} .Rtl.onIndx:not(.oneGrd) .ntry .iFxd:not(.l) >*{margin-left:5px;margin-right:0} .onIndx:not(.oneGrd) .ntry .iFxd:not(.l) >* svg{width:14px;height:14px;stroke-width:1.7} .onIndx:not(.oneGrd) .ntry .iFxd:not(.l) >* svg{margin:0 1.5px} .onIndx:not(.oneGrd) .ntry .iFxd.l .edit{padding:5px} .onIndx:not(.oneGrd) .ntry .iFxd.l >* svg{margin:0px} .onIndx:not(.oneGrd) .ntry .pTtl{font-size:.8rem;font-weight:600} .onIndx:not(.oneGrd) .ntry:not(.pTag) .pSnpt, .onIndx:not(.oneGrd) .ntry .pInf:not(.nSpr) .pJmp, .onIndx:not(.oneGrd) .ntry .iFxd .spnr, .onIndx:not(.oneGrd) .iFxd .bM{display:none} .onIndx:not(.oneGrd) .ntry .iFxd{padding:8px 3px} .onIndx:not(.oneGrd) .ntry .iFxd.l{top:auto;bottom:0;right:0} .Rtl.onIndx:not(.oneGrd) .ntry .iFxd.l{right:auto;left:0} .onIndx:not(.oneGrd) .ntry .iFxd .cmnt, .onIndx:not(.oneGrd) .ntry .iFxd .pV{padding:3.5px} .onIndx:not(.oneGrd) .ntry .iFxd >* svg{padding:1px} .onIndx.oneGrd .blogPts >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)}
/* Share */ .pShc{width:calc(100% + 10px);left:-5px;right:-5px} .pShc::before{width:calc(100% - 10px);margin:0 5px 12px} .pShc .wa::after, .pShc .tw::after{display:none}
/* Widget */ .prfI:checked ~ .mainWrp .wPrf{top:auto;bottom:0} .prfI:checked ~ .mainWrp .Profile .fCls{background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .prfH .c{display:flex} .wPrf{position:fixed;top:auto;left:0;right:0;bottom:-100%;width:100%;max-height:calc(100% - var(--headerH));border-radius:12px 12px 0 0} .itemFt .itm{padding-bottom:80px} .itemFt .itm >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)} .itemFt .itm .iCtnt{flex:0 0 calc(100% - 42px);width:calc(100% - 42px);margin:0 auto;position:absolute;left:0;right:0;bottom:0;padding:13px;background:rgba(255,253,252,.92);border-radius:10px;box-shadow:0 10px 20px -5px rgba(0,0,0,.1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .itemFt .pTtl{font-size:1rem} .itemFt .pSnpt{font-size:93%}
}
/* Keyframes Animation */ @keyframes shimmer{100%{transform:translateX(100%)}} @keyframes slidein{0%{opacity:0}20%{opacity:1;bottom:24px}50%{opacity:1;bottom:24px}80%{opacity:1;bottom:24px}100%{opacity:0;bottom:-70px;visibility:hidden}} @keyframes fadein{50%{opacity:1}80%{opacity:1;padding-top:5px;height:22px}100%{opacity:0;padding-top:0;height:0}} @keyframes nudge{0%{transform:translateX(0)}30%{transform:translateX(-5px)}50%{transform:translateX(5px)}70%{transform:translateX(-2px)}100%{transform:translateX(0)}} @keyframes tonext{ 75%{left:0} 95%{left:100%} 98%{left:100%} 99%{left:0}} @keyframes tostart{ 75%{left:0} 95%{left:-300%} 98%{left:-300%} 99%{left:0}} @keyframes tonext-rev{ 75%{right:0} 95%{right:100%} 98%{right:100%} 99%{right:0}} @keyframes tostart-rev{ 75%{right:0} 95%{right:-300%} 98%{right:-300%} 99%{right:0}} @keyframes snap{ 96%{scroll-snap-align:center} 97%{scroll-snap-align:none} 99%{scroll-snap-align:none} 100%{scroll-snap-align:center}} @keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}} @-webkit-keyframes fadein{50%{opacity:1}80%{opacity:1;padding-top:5px;height:22px}100%{opacity:0;padding-top:0;height:0}} @-webkit-keyframes slidein{0%{opacity:0}20%{opacity:1;bottom:24px}50%{opacity:1;bottom:24px}80%{opacity:1;bottom:24px}100%{opacity:0;bottom:-70px;visibility:hidden}} @-webkit-keyframes nudge{0%{transform:translateX(0)}30%{transform:translateX(-5px)}50%{transform:translateX(5px)}70%{transform:translateX(-2px)}100%{transform:translateX(0)}} @-webkit-keyframes tonext{ 75%{left:0} 95%{left:100%} 98%{left:100%} 99%{left:0}} @-webkit-keyframes tostart{ 75%{left:0} 95%{left:-300%} 98%{left:-300%} 99%{left:0}} @-webkit-keyframes tonext-rev{ 75%{right:0} 95%{right:100%} 98%{right:100%} 99%{right:0}} @-webkit-keyframes tostart-rev{ 75%{right:0} 95%{right:-300%} 98%{right:-300%} 99%{right:0}} @-webkit-keyframes snap{ 96%{scroll-snap-align:center} 97%{scroll-snap-align:none} 99%{scroll-snap-align:none} 100%{scroll-snap-align:center}} @-webkit-keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}} @-moz-keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}} @keyframes glitch{2%,64%{transform:translate(2px,0) skew(0deg)} 4%,60%{transform:translate(-2px,0) skew(0deg)} 62%{transform:translate(0,0) skew(5deg)}} @keyframes glitchTop{2%,64%{transform:translate(2px,-2px)} 4%,60%{transform:translate(-2px,2px)} 62%{transform:translate(13px,-1px) skew(-13deg)}} @keyframes glitchBotom{2%,64%{transform:translate(-2px,0)} 4%,60%{transform:translate(-2px,0)} 62%{transform:translate(-22px,5px) skew(21deg)}}
/* Noscript Option */ .lazy:not([lazied]){display:none} .bD .pS img.lazy:not([lazied]){display:none !important} .noJs{display:flex;justify-content:flex-end;align-items:center;position:fixed;top:20px;left:20px;right:20px;z-index:99;max-width:640px;border-radius:12px;margin:auto;padding:10px 5px;background:#ffdfdf;font-size:13px;box-shadow:0 10px 20px -10px rgba(0,0,0,.1);color:#48525c} .noJs::before{content:attr(data-text);padding:0 10px;flex-grow:1} .noJs label{flex-shrink:0;padding:10px} .noJs label::after{content:'\2715';line-height:18px;font-size:14px} .nJs:checked ~ .noJs{display:none}
/* Hide Scroll */ .scrlH::-webkit-scrollbar{width:0;height:0} .scrlH::-webkit-scrollbar-track{background:transparent} .scrlH::-webkit-scrollbar-thumb{background:transparent;border:none}







/* SVG Icon Color */svg{width:22px;height:22px;vertical-align:middle;fill:#161617}
svg .svg-c{fill:var(--linkC)}
svg.line .svg-c{fill:none;stroke:var(--linkC)}
svg.line, svg .line{fill:none;stroke:#161617;stroke-linecap:round;stroke-linejoin:round;stroke-width:1}
.hidden, .replaced{display:none} .invisible{visibility:hidden} .clear{width:100%;display:block;margin:0;padding:0;float:none;clear:both}
.full-close{display:block;position:fixed;top:0;left:0;width:100%;height:100%;z-index:2;-webkit-transition:all .2s ease-in;transition:all .2s ease-in;background:transparent;opacity:0;visibility:hidden} .drK svg .svg-c {fill:none;stroke:var(--darkU)}

/* Pop-Up Box by Fineshop */.popSc{position:fixed;z-index:99999;top:0;bottom:0;left:0;right:0;padding:20px;background:#f3f5fe;display:flex;justify-content:center;align-items:center}
.popSc.hidden{display:none}
.popSc .popBo{position:relative;background:#fff;max-width:400px;display:flex;justify-content:center;align-items:center;flex-direction:column;padding:30px;border-radius:30px}
.popSc .popBo svg{display:block;width:50px;height:50px;fill:none !important;stroke:#08102b;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5}
.popSc .popBo h2{margin:10px 0 15px 0;font-size:1.2rem;font-weight:800;color:#08102b}
.popSc .popBo p{margin:0;line-height:1.7em;font-size:0.9rem;color:#08102b}

/* Dark Mode */ .drK.onIndx .blogPts >*, .drK .rPst, .drK .PopularPosts, .drK .Label{background:var(--darkBa)} .drK .tDL .d2{display:block} .drK .tDL::after{content:attr(data-light)} .drK .tDL svg .f{stroke:none;fill:var(--darkT)}  .drK .pThmb:not(.nul)::before{background-image:linear-gradient(90deg, rgba(0,0,0,0) 0, rgba(0,0,0,.07) 20%, rgba(0,0,0,.1) 60%, rgba(0,0,0,0))} .drK input::placeholder, .drK .cpL input, .drK .cArea label .n{color:rgba(255,255,255,.25)} .drK .erroC h3 span.e{color:var(--darkBa)} .drK .nArea .contact-form-error-message-with-border{color:#f94f4f} .drK .cmC i[rel=image]::before, .drK .widget input[type=text], .drK .widget input[type=email], .drK .widget textarea{background:var(--darkBs);border-color:rgba(255,255,255,.15)} .drK svg, .drK svg.c-1{fill:var(--darkT)} .drK svg.line, .drK .ancrC svg{fill:none;stroke:var(--darkT)} .drK svg.c-2{fill:var(--darkTa); opacity:.4} .drK, .drK .headCn, .drK .mnBrs{background:var(--darkB);color:var(--darkT)} .drK .ntfC, .drK .mobMn{background:var(--darkBa);color:var(--darkTa)} .drK .ntfC{color:rgba(255,255,255,.9)} .drK header, .drK .mnMn >li.br::after, .drK .blogCont::before, .drK .tbHd, .drK .cmHl >li >.cmIn, .drK .pTag .pMart a, .drK .pRelate, .drK blockquote, .drK .cmC i[rel=quote], .drK blockquote.s-1, .drK details.sp, .drK .ps table:not(.tr-caption-container), .drK .ps table th, .drK .ps table:not(.tr-caption-container) tr:not(:last-child) td, .drK .pre.tb .preH, .drK details.ac, .drK .ancrA, .drK .ancrC, .drK .mnMob{border-color:rgba(255,255,255,.15)} .drK .pre{background:var(--darkBs);color:var(--darkT)} .drK .footer{background:var(--darkBs)} .drK .mnMn li:not(.mr) .a:hover, .drK .mnMn ul li >*:hover, .drK .wL.bg li >*, .drK .mobMn li >*:hover, .drK .shL a, .drK .cpLb{background:rgba(0,0,0,.15)} .drK .tIc::after{background:var(--darkBs)} .drK .wPrf{background:var(--darkBa);box-shadow:0 10px 40px rgba(0,0,0,.2)} .drK header a, .drK h1, .drK h2, .drK h3, .drK h4, .drK h5, .drK h6, .drK footer, .drK .button{color:var(--darkT)} .drK .dlBox, .drK .fixLs, .drK .cArea input:focus ~ .n, .drK .cArea textarea:focus ~ .n, .drK .cArea input[data-text=fl] ~ .n, .drK .cArea textarea[data-text=fl] ~ .n{background:var(--darkBs)} .drK .tocLi{background:var(--darkB)} .drK .admPs, .drK .tocC span, .drK .pShc >*:not(.c), .drK .ancrA, .drK .BlogSearch input, .drK .cmHl >li >.cmIn{background:var(--darkBa)} .drK .tocC span::before{background:var(--darkBa)} .drK .tocC span::after{background:var(--darkU)} .drK .tocL svg.rad{fill:var(--darkBa)} .drK .mobMn li >*:hover svg.line{fill:var(--darkT) !important} .drK .mobMn li >*:hover svg.line .svgC{fill:var(--darkU) !important;stroke:var(--darkU)} .drK.mobS .mobMn li >*:hover, .drK .button.ln{background:transparent} .drK .pTag .pPric::before, .drK .pTag .pInfo small{color:var(--darkTa)} .drK::selection, .drK a, .drK .free::after, .drK .new::after, .drK .mnMn li:not(.mr) .a:hover, .drK .mnMn ul li a:hover, .drK .aTtl a:hover, .drK .pSnpt.nTag, .drK .pTag .pPric, .drK details.ac[open] summary, .drK .cpL label, .drK .wL li >*:hover .lbC, .drK .wL li >div .lbC, .drK .wL .lbM, .drK .cmBtn.ln:hover, .drK .wL.cl .lbN:hover .lbC, .drK .wL.cl div.lbN .lbC{color:var(--darkU)} .drK .mnMn .a:hover svg:not(.d){fill:var(--darkU)} .drK .mnMn .a:hover svg.line:not(.d), .drK .pJmp svg{fill:none;stroke:var(--darkU)} .drK .wL li >*:hover svg, .drK .wL li >div svg{stroke:var(--darkU)} .drK.MN-3 .mobMn li >*:hover::after, .drK.MN-4 .mobMn li >*:hover::after, .drK .toTopF, .drK .blogPg >*, .drK .button, .drK .zmImg::after, .drK .widget input[type=button], .drK .widget input[type=submit]{background:var(--darkU)} .drK.MN-3 .mobMn li >*:hover svg.line, .drK.MN-4 .mobMn li >*:hover svg.line{stroke:var(--darkU);fill:var(--darkU) !important} .drK.MN-3 .mobMn li >*:hover svg .f, .drK.MN-4 .mobMn li >*:hover svg .f, .drK footer .credit a svg{fill:var(--darkU)} .drK .pS input[id*="1"]:checked ~ .tbHd label[for*="1"], .drK .pS input[id*="2"]:checked ~ .tbHd label[for*="2"], .drK .pS input[id*="3"]:checked ~ .tbHd label[for*="3"], .drK .pS input[id*="4"]:checked ~ .tbHd label[for*="4"], .drK .widget input[type=text]:focus, .drK .widget input[type=email]:focus, .drK .widget textarea:focus, .drK .widget input[data-text=fl], .drK .widget textarea[data-text=fl], .drK .wL.cl .lbN:not(div):hover, .drK .wL.cl div.lbN{border-color:var(--darkU)} .drK .button.ln:hover{border-color:var(--darkU);box-shadow:0 0 0 1px var(--darkU) inset} .drK .mnBr a, .drK .pLbls >*, .drK .aTtl a, .drK .blogPg >*, .drK .brdCmb a, .drK .wL li >*, .drK .mobMn li >*, .drK .cmAc a{color:var(--darkT)} .drK .blogPg .nPst, .drK .blogPg .current{background:var(--contentL);color:var(--bodyCa)} .drK .FeaturedPost .itemFt::after{background:var(--darkTa)} @media screen and (min-width:897px){.drK header .BlogSearch input{background:var(--darkBs)} .drK header .BlogSearch input:focus, .drK header .BlogSearch input:hover{background:var(--darkBa)} .drK.bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .drK.bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .drK.hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .drK.hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{background:var(--darkBa);box-shadow:0 10px 40px rgba(0,0,0,.2);color:var(--darkTa)} .drK.LS-2 .blogCont::before{background:var(--darkBs)} .drK.LS-3 .headCn{background:transparent} .drK.LS-3 .headL, .drK.LS-3 .mnBrs{background:var(--darkBs)} .drK.LS-3 .headR{background:var(--darkB)} .drK .tocLi::before{border-color:rgba(255,255,255,.15)}} @media screen and (min-width:897px){.drK header{border-bottom:var(--headerL) solid rgba(255,255,255,.15);box-shadow:none} .drK .blogCont::before{border-right:1px solid rgba(255,255,255,.15)} .drK .mnBrs{box-shadow:none}} @media screen and (min-width:641px){.drK .ftMn a:hover{color:var(--darkU)}} @media screen and (max-width:640px){.drK .ftMn{background:var(--darkBa)}} @media screen and (max-width:500px){.drK .itemFt .itm .iCtnt{background:var(--darkBa)}}


/* TOC indicator */
.tocC:before{content:'';display:block;width:12px;height:12px;background-color:var(--linkC);border:2px solid var(--bodyB);border-radius:50%;position:absolute;top:5px;left:12px;animation:indicator 1s ease infinite;-webkit-animation:indicator 1s ease infinite;z-index:1}@-webkit-keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}@keyframes indicator{0%{opacity:0}50%{opacity:1}100%{opacity:0}}.drK .tocC:before{background-color:var(--darkU)}

/* Thumbnail hover effect */
article .pThmb a:hover, article .iThmb a:hover{transform:scale(1.025)}

/* Menu */ .headR .headM{display:block;position:absolute;top:0;right:0;padding:10px 0;width:150px;background:var(--contentB);font-size:13px;border-radius:10px 5px 10px 10px;box-shadow:0 0 15px rgba(0,0,0,.07);-webkit-transition:var(--trans-2);transition:var(--trans-2);overflow:hidden;z-index:18;opacity:0;visibility:hidden} .headR .headM:before{content:attr(data-text);display:block;padding:0 15px 10px;width:100%;font-size:11px;opacity:.7} .headR .headM >*{display:block;padding:9px 15px;width:100%;cursor:pointer} .headR .headM >*:before{content:attr(aria-label);opacity:.9} .headR .headM >*:hover{background:rgba(0,0,0,.05)} .navM:checked ~ .mainWrp .headM{visibility:visible;opacity:1} .navM:checked ~ .mainWrp .headM + .fCls{visibility:visible;opacity:1;z-index:17} .headR .headM .sydB{display:true} .bD:not(.drK):not(.syD) .headR .headM .lgtB{background-color:rgba(0,0,0,.1)} .drK:not(.syD) .headR .headM .drK{background-color:rgba(0,0,0,.1)} .syD .headR .headM .sydB{background-color:rgba(0,0,0,.1)} .drK .headR .headM{background:var(--darkBs)} .Rtl .headR .headM{right:auto;left:0;border-radius:5px 10px 10px 10px}

/* Toast Notification */.tNtf span{position:fixed;left:24px;bottom:-70px;display:inline-flex;align-items:center;text-align:center;justify-content:center;margin-bottom:20px;z-index:99981;background:#323232;color:rgba(255,255,255,.8);font-size:14px;font-family:inherit;border-radius:3px;padding:13px 24px; box-shadow:0 5px 35px rgba(149,157,165,.3);opacity:0;transition:all .1s ease;animation:slideinwards 2s ease forwards;-webkit-animation:slideinwards 2s ease forwards}
@media screen and (max-width:500px){.tNtf span{margin-bottom:20px;left:20px;right:20px;font-size:13px}}
@keyframes slideinwards{0%{opacity:0}20%{opacity:1;bottom:0}50%{opacity:1;bottom:0}80%{opacity:1;bottom:0}100%{opacity:0;bottom:-70px;visibility:hidden}}
@-webkit-keyframes slideinwards{0%{opacity:0}20%{opacity:1;bottom:0}50%{opacity:1;bottom:0}80%{opacity:1;bottom:0}100%{opacity:0;bottom:-70px;visibility:hidden}}

/* Google Translate */body{top:0px!important}.goog-te-banner-frame.skiptranslate, .goog-te-gadget-simple img, img.goog-te-gadget-icon, .goog-te-menu-value span, #goog-gt-tt, .goog-tooltip, .goog-tooltip:hover, .goog-logo-link, .goog-te-balloon-frame{display:none!important} .goog-text-highlight{background-color: transparent !important;box-shadow:none !important;-webkit-box-shadow:none !important} .goog-te-menu-frame{box-shadow:none!important} .goog-te-gadget-simple{background-color:transparent!important;border:none!important;outline:0 !important;-ms-touch-action:manipulation;touch-action:manipulation;-webkit-user-select:none !important;-moz-user-select:none !important;-ms-user-select:none !important;user-select:none !important} #google_translate_element{position:absolute !important;z-index:2 !important;overflow:hidden !important} #google_translate_element, .skiptranslate.goog-te-gadget, .goog-te-gadget-simple{width:40px !important;height:40px !important;padding:0 !important;margin:0 !important;border-radius:50% !important}.goog-te-banner-frame.skiptranslate,.goog-te-gadget-simple img,img.goog-te-gadget-icon,.goog-te-menu-value span{display:none!important}.goog-te-menu-frame{box-shadow:none!important}.goog-te-gadget-simple{background-color:transparent!important;border-left:none!important;border-top:none!important;border-bottom:none!important;border-right:none!important;border-radius:4px}

/* Reading progress bar */ .progB{position:fixed;top:0;left:0;width:0;height:3px;z-index:97;background-color:var(--linkC)}.drK .progB{background-color:var(--darkU)}

/* RGB Effect */.stwRainbow,.stwBlurRainbow{position:fixed;width:100%;bottom:0;left:0;right:0;height:3px;z-index:23;background:linear-gradient(-45deg, #4086F4, #31A952, #FBBE01, #EB4132,#4086F4, #31A952, #FBBE01, #EB4132);background-size:200%;-webkit-animation:animeBar 5s linear infinite;animation:animeBar 5s linear infinite}.stwBlurRainbow{height:10px;z-index:22;filter:blur(10px);opacity:.7}@-webkit-keyframes animeBar{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}@keyframes animeBar{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

/* Music player */.player-STLH{transform:translate(0%,0%);width:330px;height:500px;border-radius:15px;background-color:var(--contentB);box-shadow:0 15px 20px 0 #dadada;}.player-STLH input[type=range]{-webkit-appearance:none!important;margin:0px;padding:0px;background:#e7e8ff;height:5px;width:150px;outline:none;cursor:pointer;overflow:hidden;border-radius:5px;}.player-STLH input[type=range]::-ms-fill-lower{background:var(--linkB);opacity:.2}.player-STLH input[type=range]::-ms-fill-upper{background:var(--linkB);opacity:.2}.player-STLH input[type=range]::-moz-range-track{border:none;background:var(--linkB);opacity:.2}.player-STLH input[type=range]::-webkit-slider-thumb{-webkit-appearance:none!important;background:var(--linkB);height:5px;width:5px;border-radius:50%;box-shadow:-100vw 0 0 100vw var(--linkB);}.player-STLH input[type=range]::-moz-range-thumb{background:var(--linkB);height:8px;width:8px;border-radius:100%;}.player-STLH input[type=range]::-ms-thumb{-webkit-appearance:none!important;background:var(--linkB);height:8px;width:8px;border-radius:100%;}.player-STLH .cover-PS{width:150px;height:150px;border-radius:50%;overflow:hidden;position:absolute;left:50%;top:50px;transform:translateX(-50%)}.player-STLH .cover-PS img{width:100%;height:100%;object-fit:cover-PS;}.player-STLH .info-MS{position:absolute;left:50%;top:240px;transform:translateX(-50%);text-align:center;}.player-STLH .info-MS .title-MS{font-size:20px;font-weight:700;margin-bottom:2px;}.player-STLH .info-MS .singer-MS{font-size:12px;}.player-STLH .btn-box{position:absolute;top:330px;width:100%;display:flex;justify-content:center;}.player-STLH .btn-box i{font-size:24px;color:#72646f;margin:0 30px;cursor:pointer;}.player-STLH .btn-box i.active{color:var(--linkB);}.player-STLH .volume-box{display:none;position:absolute;left:50%;top:295px;transform:translateX(-50%);z-index:1;padding:0 20px;}.player-STLH .volume-box .volume-down{position:absolute;left:-15px;top:50%;transform:translateY(-50%);cursor:pointer;color:#72646f;}.player-STLH .volume-box .volume-up{position:absolute;right:-15px;top:50%;transform:translateY(-50%);cursor:pointer;color:#72646f;}.player-STLH .volume-box .volume-up::selection{background-color:unset;}.player-STLH .volume-box input[type=range]{height:5px;width:150px;margin:0 0 15px 0;}.player-STLH .volume-box.active{display:block;}.player-STLH .music-box{position:absolute;left:50%;top:385px;transform:translateX(-50%);}.player-STLH .music-box input[type=range]{height:5px;width:230px;margin:0 0 10px 0;}.player-STLH .music-box input[type=range]::-webkit-slider-thumb{height:5px;width:7px;}.player-STLH .music-box .current-time{position:absolute;left:-35px;top:50%;transform:translateY(-50%);font-size:12px}.player-STLH .music-box .duration{position:absolute;right:-35px;top:50%;transform:translateY(-50%);font-size:12px}.player-STLH .music-box .play,.player-STLH .music-box .pause{position:absolute;left:50%;top:55px;transform:translateX(-50%);width:50px;height:50px;border-radius:50px;background-color:var(--linkB);cursor:pointer;transition:all 0.4s;}.player-STLH .music-box .play i,.player-STLH .music-box .pause i{font-size:36px;color:#fff;position:absolute;left:50%;top:50%;transform:translate(-48%,-50%);}.player-STLH .music-box .pause i{font-size:32px;transform:translate(-50%,-50%);}.drK .player-STLH{background:var(--darkBa); box-shadow:none} .drK .player-STLH .music-box .play,.drK .player-STLH .music-box .pause {background-color:var(--darkU)}.drK.player-STLH input[type=range]::-ms-fill-lower{background:var(--darkU);opacity:.2}.drK .player-STLH input[type=range]::-ms-fill-upper{background:var(--darkU);opacity:.2}.drK .player-STLH input[type=range]::-moz-range-track{border:none;background:var(--darkU);opacity:.2}.drK .player-STLH input[type=range]::-webkit-slider-thumb{-webkit-appearance:none!important;background:var(--darkU);height:5px;width:5px;border-radius:50%;box-shadow:-100vw 0 0 100vw var(--darkU);}.drK.player-STLH input[type=range]::-moz-range-thumb{background:var(--darkU);height:8px;width:8px;border-radius:100%;}.drK.player-STLH input[type=range]::-ms-thumb{-webkit-appearance:none!important;background:var(--darkU);height:8px;width:8px;border-radius:100%;}.drK .player-STLH .btn-box i.active{color:var(--darkU);}.drK.player-STLH input[type=range]::-ms-thumb{-webkit-appearance:none!important;background:var(--darkU);height:8px;width:8px;border-radius:100%;}

/* Double click to copy hover text */.pre:not(.tb):hover::before{content:'Double click to copy | </>'}
.pre:not(.tb).html:hover::before{content:'Double click to copy | .html'}
.pre:not(.tb).css:hover::before{content:'Double click to copy | .css'}
.pre:not(.tb).js:hover::before{content:'Double click to copy | .js'}

/* Source Code Font */ @font-face {font-family: 'Fira Mono';font-style: normal;font-weight: 400;font-display: swap;src: local('Fira Mono Regular'), local('FiraMono-Regular'), url(https://fonts.gstatic.com/s/firamono/v9/N0bX2SlFPv1weGeLZDtQIg.woff) format('woff'), url(https://fonts.gstatic.com/s/firamono/v9/N0bX2SlFPv1weGeLZDtgJv7S.woff2) format('woff2')}

/* Standar CSS */ ::selection{color:#fff;background:var(--linkC)} *, ::after, ::before{-webkit-box-sizing:border-box;box-sizing:border-box} h1, h2, h3, h4, h5, h6{margin:0;font-weight:700;font-family:var(--fontH);color:var(--headC)} h1{font-size:1.9rem} h2{font-size:1.7rem} h3{font-size:1.5rem} h4{font-size:1.4rem} h5{font-size:1.3rem} h6{font-size:1.2rem} a{color:var(--linkC);text-decoration:none} a:hover{opacity:.9;transition:opacity .1s} table{border-spacing:0} iframe{max-width:100%;border:0;margin-left:auto;margin-right:auto} input, button, select, textarea{font:inherit;font-size:100%;color:inherit;line-height:normal} input::placeholder{color:rgba(0,0,0,.5)} img{display:block;position:relative;max-width:100%;height:auto} svg{width:22px;height:22px;fill:var(--iconC)} svg.line, svg .line{fill:none!important;stroke:var(--iconC);stroke-linecap:round;stroke-linejoin:round; stroke-width:1} svg.c-1{fill:var(--iconCa)} svg.c-2{fill:var(--iconCs); opacity:.4} .hidden{display:none} .invisible{visibility:hidden} .clear{width:100%;display:block;margin:0;padding:0;float:none;clear:both} .fCls{display:block;position:fixed;top:0;left:0;right:0;bottom:0;z-index:1;transition:var(--trans-1);background:transparent;opacity:0;visibility:hidden} .free::after, .soon::after, .new::after{display:inline-block;content:'Free!';color:var(--linkC);font-size:12px;font-weight:400;margin:0 5px} .new::after{content:'New!'}.soon::after{content:'Coming Soon!'}

/* Navbar */ .navbar{z-index:3;padding-top:10px;background:var(--navB);box-shadow:0 5px 35px rgba(0,0,0,.07);height:var(--navH);color:var(--navT);overflow:hidden} .navR .section{justify-content:flex-end} .navIn svg, header svg{width:20px;height:20px;fill:var(--navI); opacity:.8} .navIn svg.line{fill:none;stroke:var(--navI)} .navIn .section{display:flex;align-items:center;height:100%;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .navIn .section >*{margin:0 7px} .navIn .a{color:inherit} .navIn ul{list-style:none;margin:0;padding:0} .mLang{align-items:baseline;font-size:13px} .mLang, .mSocc{display:flex;position:relative;width:calc(100% + 14px);left:-7px;right:-7px} .mLang .a{width:30px;height:30px;display:flex;align-items:center;justify-content:center} .mLang .a::before{content:attr(data-text)} .mLang li.u{font-size:12px;text-transform:uppercase} .mLang li:not(:last-child){display:flex;align-items:center} .mLang li:not(:last-child)::after{content:'';height:14px; border-left:1px solid #999; margin:0 5px;opacity:.7; flex:0 0} .mLang span, .mSocc span{opacity:.5} .mSocc >*{position:relative} .mSocc svg{z-index:1} .mSocc svg{width:19px;height:19px;opacity:.8}#dateNow{right: 10px;position: absolute;top: 5px;opacity: 0.7;}
.drK .navbar{background:var(--darkB);color:var(--darkT)}

/* Main Element */ html{scroll-behavior:smooth;overflow-x:hidden} body{position:relative;margin:0;padding:0!important;width:100%;font-family:var(--fontB);font-size:14px;color:var(--bodyC);background:var(--bodyB);-webkit-font-smoothing: antialiased;} .secIn{margin:0 auto;padding-left:20px;padding-right:20px;max-width:var(--contentW)} /* Notif Section */ .ntfC{display:flex;align-items:center;position:relative;min-height:var(--notifH);background:var(--notifU);color:var(--notifC);padding:10px 15px; font-size:13px; transition:var(--trans-1);overflow:hidden;border-radius:10px;margin-bottom:20px} .ntfC::before{content:'';width:60px;height:60px;background:rgba(0,0,0,.15);display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .Rtl .ntfC::before{left:unset;right:-12px} .ntfC .secIn{width:100%;position:relative} .ntfC .c{display:flex;align-items:center} .ntfT{width:100%; padding-right:15px; text-align:center} .ntfT a{color:var(--linkC);font-weight:700} .ntfI:checked ~ .ntfC{height:0;min-height:0;margin:0;padding:0;opacity:0;visibility:hidden} .ntfA{display:inline-flex;align-items:center;justify-content:center;text-align:initial} .ntfA >a{flex-shrink:0;white-space:nowrap;display:inline-block; margin-left:10px;padding:8px 12px;border-radius:20px;background:var(--notifL);color:#fff;font-size:12px;font-weight:400;box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%);text-decoration:none} .drK .ntfA >a{background:var(--darkU);color:#fffdfc}/* Fixed/Pop-up Element */ .fixL{display:flex;align-items:center;position:fixed;left:0;right:0;bottom:0;margin-bottom:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%;opacity:0;visibility:hidden} .fixLi, .fixL .cmBri{width:100%;max-width:680px;max-height:calc(100% - 60px);border-radius:12px;transition:inherit;z-index:3;display:flex;overflow:hidden;position:relative;margin:0 auto;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .fixLs{padding:60px 20px 20px;overflow-y:scroll;overflow-x:hidden;width:100%;background:var(--contentB)} .fixH, .mnH{display:flex;background:inherit;position:absolute;top:0;left:0;right:0;padding:0 10px;z-index:2} .fixH .cl{padding:0 10px;display:flex;align-items:center;justify-content:flex-end;position:relative;flex-shrink:0;min-width:40px} .fixH .c::after, .ntfC .c::after, .mnH .c::before{content:'\2715';line-height:18px;font-size:14px} .fixT::before{content:attr(data-text);flex-grow:1;padding:16px 10px;font-size:90%;opacity:.7} .fixT .c::before, .mnH .c::after{content:attr(aria-label);font-size:11px;margin:0 8px;opacity:.6} .fixi:checked ~ .fixL, #comment:target .fixL{margin-bottom:0;opacity:1;visibility:visible} .fixi:checked ~ .fixL .fCls, #comment:target .fixL .fCls, .BlogSearch input:focus ~ .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .shBri{max-width:520px} /* display:flex */ .headI, .bIc{display:flex;align-items:center}

/* Header Section */ header{width:100%;z-index:10; position:-webkit-sticky;position:sticky;top:0;} header a{display:block;color:inherit} header svg{width:20px;height:20px;fill:var(--headerI); opacity:.8} header svg.line{fill:none;stroke:var(--headerI)} .headCn{position:relative;height:var(--headerH);color:var(--headerC);background:var(--headerB);border-radius:0 0 2.20rem 2.20rem;box-shadow:0 0.125rem 0.5rem 0 rgb(0 0 0 / 3%), 0 0.125rem 2rem -0.5rem rgb(23 43 61 / 20%); display:flex} .headL{display:flex;align-items:center;width: var(--navW) ; /* change var(--navW) to increase header title width */ padding:0 0 0 20px; transition:var(--trans-1)} .headL .headIc{flex:0 0 30px} .headL .headN{width:calc(100% - 30px); padding:0 0 0 5px} .headR{padding:0 25px; flex-grow:1; transition:var(--trans-1)} .headI .headP{display:flex;justify-content:flex-end;position:relative} .headI .headS{} .headI{height:100%; justify-content:space-between; position:relative;width:calc(100% + 15px);left:-7.5px;right:-7.5px} .headI >*{margin:0 7.5px} .headIc{font-size:11px;display:flex;list-style:none;margin:0;padding:0} .headIc >*{position:relative} .headIc svg{z-index:1} .headIc .isSrh{display:none} ul.headIc{position:relative;width:calc(100% + 14px);left:-7px;right:-7px;justify-content:flex-end} ul.headIc li{margin:0 2px} .Header{background-repeat:no-repeat;background-size:100%;background-position:center} .Header img{max-width:160px;max-height:45px} .Header .headH{display:block;color:inherit;font-size:var(--headerT); font-weight:var(--headerW)} .Header .headTtl{overflow:hidden;white-space:nowrap;text-overflow:ellipsis; display:block}  .Header .headSub{margin:0 5px;font:400 11px var(--fontB); white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:60px;opacity:.6} .Header .headSub::before{content:attr(data-text)}/* Icon */ .tIc{width:30px;height:30px;justify-content:center} .tIc::after{content:'';background:var(--transB);border-radius:var(--tIbR);position:absolute;left:0;right:0;top:0;bottom:0;transition:var(--trans-1);opacity:0;visibility:hidden} .tIc:hover::after{opacity:1;visibility:visible;transform:scale(1.3,1.3)} .tDL .d2, .drK .tDL .d1{display:none} /* mainIn Section */ .shC{background:var(--navB);padding:10px;padding-top:15px;border-radius:20px}.drK .shC{background:var(--darkBa)}.mainWrp:after{content:'';display:block;position:absolute;top:0;right:0;width:170px;height:170px;border-radius:0 0 0 200px;background:rgba(0,0,0,.02);z-index:-1} .drK .mainWrp:after{background:rgba(0,0,0,.10)} .blogCont{flex-grow:1;padding:20px 0 0;position:relative;transition:var(--trans-1)} .blogCont .section:not(.no-items), .blogCont .widget:not(:first-child){margin-top:10px} .blogCont .section:first-child, .blogCont footer .widget:not(:first-child), .blogCont .section.mobMn{margin-top:0} .blogAd .section:not(.no-items){margin-bottom:40px} .blogM{flex-wrap:wrap;justify-content:center;padding-bottom:40px} .sidebar{max-width:500px;margin:50px auto 0} .sideSticky{position:-webkit-sticky;position:sticky;top:calc(var(--headerH) + 10px)} .onPs .blogM .mainbar{max-width:var(--pageW)} .onPg .blogM .mainbar{max-width:var(--pageW)}

/* mainNav */.mnBrs{background:var(--contentB)} .mnBr a{color:inherit} .mnBr ul{list-style:none;margin:0;padding:0} .mnMob{align-self:flex-end;position:absolute;left:0;right:0;bottom:0;background:inherit;padding:15px 20px 20px;z-index:1} .mnMob .mSoc{display:flex;position:relative;width:calc(100% + 14px);left:-7px;right:-7px;margin-top:5px} .mnMob:not(.no-items) + .mnMen{padding-bottom:100px} .mnMen{padding:20px 15px} .mMenu{margin-bottom:10px} .mMenu >*{display:inline} .mMenu >*:not(:last-child)::after{content:'\00B7';font-size:90%;opacity:.6} .mMenu a:hover{text-decoration:underline} .mSoc >*{position:relative} .mSoc svg{z-index:1} .mSoc svg, .mnMn svg{width:20px;height:20px;opacity:.8} .mSoc span, .mMenu span{opacity:.7} .mNav{display:none;position:relative;max-width:30px} .mNav svg{height:18px;opacity:.7;z-index:1} .mnMn >li{position:relative} .mnMn >li.br::after{content:'';display:block;border-bottom:1px solid var(--contentL);margin:12px 5px} .mnMn li:not(.mr) .a:hover, .mnMn ul li >*:hover{background:var(--transB)} .mnMn li:not(.mr) .a:hover, .mnMn ul li a:hover{color:var(--linkC)} .mnMn li:not(.mr) ul{padding-left:30px} .mnMn li ul{display:none;opacity:0;visibility:hidden} .mnMn ul li >*, .mnMn .a{display:flex;align-items:center;padding:10px 5px;position:relative;width:calc(100% + 10px);left:-5px;right:-5px;border-radius:var(--tIbR);transition:var(--trans-1)} .mnMn ul li >*{padding:10px} .mnMn .a >*{margin:0 5px} .mnMn .a:hover svg:not(.d){fill:var(--linkC)} .mnMn .a:hover svg.line:not(.d){fill:none;stroke:var(--linkC)} .mnMn .n, .mnMn ul li >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1 0 calc(100% - 64px)} .mnMn svg{flex-shrink:0} .mnMn svg.d{width:14px;height:14px} .mnMn .drp.mr .a{font-size:13px;padding-bottom:0;opacity:.7} .mnMn .drp.mr svg.d{display:none} .mnMn .drpI:checked ~ .a svg.d{transform:rotate(180deg)} .mnMn .drpI:checked ~ ul{display:block;opacity:1;visibility:visible} /* Mobile Menu */ .mobMn{position:fixed;left:0;right:0;bottom:0; border-top:1px solid var(--mobL);border-radius:var(--mobBr) var(--mobBr) 0 0;background:var(--mobB);color:var(--mobT);padding:0 20px;box-shadow:0 -10px 25px -5px rgba(0,0,0,.1);z-index:2;font-size:12px} .mobMn svg.line{stroke:var(--mobT);opacity:.8} .mobMn ul{height:55px;display:flex;align-items:center;justify-content:center;list-style:none;margin:0;padding:0} .mobMn li{display:flex;justify-content:center;flex:1 0 20%} .mobMn li >*{display:inline-flex;align-items:center;justify-content:center;min-width:35px;height:35px;border-radius:20px;padding:0 8px;transition:var(--trans-1);color:inherit} .mobMn li svg{margin:0 3px;flex-shrink:0} .mobMn li >*::after{content:attr(data-text);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:0;margin:0;transition:inherit;opacity:.7} .mobMn li >*:hover::after{max-width:70px;margin:0 3px} .mobMn .nmH{opacity:.7} .mobMn li >*:hover{background:var(--mobHv)} .mobMn li >*:hover svg.line{fill:var(--mobT) !important;opacity:.5} /* Style 2 */ .MN-2 .mobMn{font-size:10px} .mobS .mobMn li >*{flex-direction:column;position:relative} .mobS .mobMn li >*:hover{background:transparent} .MN-2 .mobMn li >*::after{max-width:none} /* Style 3 */ .MN-3 .mobMn li >*::after{content:'';width:4px;height:4px;border-radius:50%;position:absolute;bottom:-2px;opacity:0} .MN-3 .mobMn li >*:hover::after{background:var(--linkB);opacity:.7} .MN-3 .mobMn li >*:hover svg.line{stroke:var(--linkB);fill:var(--linkB) !important;opacity:.7}

/* Main  */
.mainInner{border-bottom: 1px solid var(--content-border);border-bottom-left-radius: 15px;} 
.blogContent .mainbar > *:not(:last-child){border-bottom:none;}

/* Widget FollowByEmail */
.FollowByEmail form{display:flex;max-width:320px;margin-top:20px}
.FollowByEmail input[type=email]{margin:0 10px 0 0}
.FollowByEmail input[type=submit]{margin:1px 0;flex-shrink:0}

/* Footer */ footer{font-size:13px;line-height:1.8em;color:var(--fotT);padding:40px 0 20px} .footer{padding:20px;background:var(--fotB);box-shadow: 0 5px 35px rgba(0,0,0,.1);border-radius:10px} footer ul{list-style:none;margin:0;padding:0} footer a{color:var(--fotT)} .drK footer a{color:var(--darkT)} footer .credit a{display:inline-flex;align-items:center} footer .credit a svg{width:13px;height:13px;margin:0 3px} .cdtIn{display:flex;align-items:center;justify-content:space-between; position:relative;width:calc(100%);left:0;right:0} .cdtIn >*{margin:0 0} .cdtIn .HTML{overflow:hidden;white-space:nowrap;text-overflow:ellipsis} .cdtIn .PageList{flex-shrink:0;position:relative} .cdtIn .mSoc{display:flex;justify-content:flex-end} .fotCd{position:relative; display:inline} .fotCd .creator{opacity:0;position:absolute;left:0;bottom:-22px} .ftL{display:flex;align-items:center;justify-content:flex-end; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .ftL >*{margin-right:8px} .ftL svg{width:20px;height:20px;stroke:var(--fotT)} .ftL svg.u{width:14px;height:14px} @media screen and (min-width:641px){.ftL{display:none} .ftMn, .ftMn li{display:inline-flex;align-items:baseline} .ftMn >*:not(:last-child)::after{content:'\00B7';opacity:.7;margin:0 10px} .ftMn span{opacity:.6} .ftMn a{opacity:.8} .ftMn a:hover{color:var(--linkC)}} @media screen and (max-width:640px){.cdtIn{align-items:center} .cdtIn .PageList{margin-left:auto} .cdtIn .mSoc >*:nth-child(4){display:none} .ftMn{position:absolute;bottom:0;right:4px;width:180px;background:var(--contentB);box-shadow:0 5px 25px -3px rgba(0,0,0,.1);font-size:14px;transition:var(--trans-1);border-radius:16px 16px 5px 16px;z-index:2;opacity:0;visibility:hidden} .ftMn li >*{display:block;padding:8px 15px; overflow:hidden;text-overflow:ellipsis; opacity:.8; line-height:normal} .ftMn li:first-child >*{padding-top:15px} .ftMn li:last-child >*{padding-bottom:15px} .ftI:checked ~ .ftMn, .ftI:checked ~ .fCls{opacity:1;visibility:visible;z-index:12} .ftI:checked ~ .fCls{z-index:11}}
 

/* Widget Input */
.widget input[type=text], .widget input[type=email], .widget textarea{display:block;width:100%;border:1px solid rgba(0,0,0,.05);outline:0;padding:15px 15px;margin-bottom:15px;margin-top:5px}
.widget input[type=text]:focus, .widget input[type=email]:focus, .widget textarea:focus{border-color:var(--bodyC)}
.widget input[type=button], .widget input[type=submit]{display:inline-flex;align-items:center;margin:0 0 15px;padding:10px 20px;outline:0;border:0;border-radius:2px;color:#fefefe;background-color:#204ecf;font-size:14px;font-family:var(--fontB);white-space:nowrap;overflow:hidden;max-width:100%}
.widget input[type=button]:hover, .widget input[type=submit]:hover{opacity:.7}

/* Article Section */ .onIndx .blogPts, .itemFt .itm{display:flex;flex-wrap:wrap;align-items:center;position:relative; width:calc(100% + 20px);left:-10px;right:-10px} .onIndx .blogPts >*, .itemFt .itm >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px); margin-bottom:0;margin-left:10px;margin-right:10px} .onIndx .blogPts >*{background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px;margin-bottom:20px;padding:10px 10px 45px;position:relative} .onIndx .blogPts .pTag{padding-bottom:0} .onIndx .pTag .pInf{display:none} .onIndx .blogPts .pInf{position:absolute;bottom:15px;left:15px;right:15px} .onIndx .blogPts{align-items:stretch} .onIndx .blogPts.mty{display:block;width:100%;left:0;right:0} .onIndx .blogPts.mty .noPosts{width:100%;margin:0} .onIndx .blogPts div.ntry{padding-bottom:0;flex:0 0 calc(100% - 20px)} .blogPts .ntry.noAd .widget, .Blog ~ .HTML{display:none} 
/* Blog title */ .blogTtl{font-size:14px; margin:0 0 30px;width:calc(100% + 16px);display:flex;justify-content:space-between;position:relative;left:-8px;right:-8px} .blogTtl .t, .blogTtl.hm .title{margin:0 8px;flex-grow:1;margin-top:20px;} .blogTtl .t span{font-weight:400;font-size:90%; opacity:.7} .blogTtl .t span::before{content:attr(data-text)} .blogTtl .t span::after{content:''; margin:0 4px} .blogTtl .t span.hm::after{content:'/'; margin:0 8px} 
/*wiggle animation*/ 
.animated-wigle{animation: wiggle 2s infinite} @keyframes wiggle{0%{transform:rotate(0) scale(1)}60%{transform:rotate(0) scale(1)}75%{transform:rotate(0) scale(1.12)}80%{transform:rotate(0) scale(1.1)}84%{transform:rotate(-10deg) scale(1.1)}88%{transform:rotate(10deg) scale(1.1)}92%{transform:rotate(-10deg) scale(1.1)}96%{transform:rotate(10deg) scale(1.1)}100%{transform:rotate(0) scale(1)}} /* Thumbnail */ .pThmb{flex:0 0 calc(50% - 12.5px);overflow:hidden;position:relative;border-radius:3px; margin-bottom:20px; background:var(--transB)} .pThmb .thmb{display:block;position:relative;padding-top:52.335%; color:inherit; transition:var(--trans-1)} .pThmb .thmb amp-img{position:absolute;top:50%;left:50%;min-width:100%;min-height:100%;max-height:108%;text-align:center;transform:translate(-50%, -50%)} .pThmb div.thmb span::before{content:attr(data-text); opacity:.7; white-space:nowrap} .pThmb:not(.nul)::before{position:absolute;top:0;right:0;bottom:0;left:0; transform:translateX(-100%); background-image:linear-gradient(90deg, rgba(255,255,255,0) 0, rgba(255,255,255,.3) 20%, rgba(255,255,255,.6) 60%, rgba(255,255,255, 0)); animation:shimmer 2s infinite;content:''} .pThmb.iyt:not(.nul) .thmb::after{content:'';position:absolute;top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,.4) url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fff' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'><path d='M4 11.9999V8.43989C4 4.01989 7.13 2.2099 10.96 4.4199L14.05 6.1999L17.14 7.9799C20.97 10.1899 20.97 13.8099 17.14 16.0199L14.05 17.7999L10.96 19.5799C7.13 21.7899 4 19.9799 4 15.5599V11.9999Z'/></svg>") center / 35px no-repeat; opacity:0;transition:var(--trans-1)} .pThmb.iyt:not(.nul):hover .thmb::after{opacity:1}
 /* Sponsored */ .iFxd{display:flex;justify-content:flex-end;position:absolute;top:0;left:0;right:0;padding:10px 6px;font-size:13px;line-height:16px} .iFxd >*{display:flex;align-items:center;margin:0 5px;padding:5px 2.5px;border-radius:var(--iFbR);background:var(--contentB);color:inherit;box-shadow:0 8px 25px 0 rgba(0,0,0,.1)} .iFxd >* svg{width:16px;height:16px;stroke-width:1.5;margin:0 2.5px;opacity:.7} .iFxd .cmnt{padding:5px;color:var(--bodyC)} .iFxd .cmnt::after{content:attr(data-text);margin:0 2.5px;opacity:.7} .drK .iFxd >* svg.line{stroke:var(--iconC)} 
/* Label .pLbls::before, .pLbls >*::before{content:attr(data-text)} .pLbls::before{opacity:.7} .pLbls a:hover{text-decoration:underline} .pLbls >*{color:inherit;display:inline} .pLbls >*:not(:last-child)::after{content:'/'}*/
/* Label Custom */.pLbls::before, .pLbls >*::before{content:attr(data-text)} .pLbls::before{opacity:.8;margin-right: 5px} .pLbls a:hover{text-decoration:underline;font-weight:bold}.pLbls >*{color:inherit;display:inline}.pLbls >*:not(:last-child)::after{content:''}
/* Label Bot in the post */
.pLbL > a{padding: 9px 12px;background:#fffdfc;color:#08102b;font-size: 13px;border-radius:50px;box-shadow: 3px 6px 15px rgba(0,0,0,.07);margin-right: 5px;}
.pLbL{display: block;direction: ltr;text-align: left;margin-bottom: 25px;}
.pLbL > a::before {content: '#';font-size: 15px;}
.drK .pLbL > a{background:var(--darkBa)}
/* Label Custom in Homepage */.pHdr .pLbls >*{color:#fefefe;display:inline;margin-right:5px;border-radius: 20px;background:#06D7A0;height:24px;padding:0 10px}.pHdr .pLbls >*:hover{text-decoration:none;color:#0b57cf;background:rgba(0,0,0,.05);font-weight:normal}.pHdr .pLbls a:nth-child(1){background:var(--linkB)}.pHdr .pLbls a:nth-child(2){background:var(--darkU)}.pHdr .pLbls a:nth-child(3){background:var(--linkC)}
/* Profile Images and Name */ .im{width:35px;height:35px;border-radius:16px; background-color:var(--transB);background-size:100%;background-position:center;background-repeat:no-repeat;display:flex;align-items:center;justify-content:center} .im svg{width:18px;height:18px;opacity:.4} .nm::after{content:attr(data-text)} /* Title and Entry */ .pTtl{font-size:1.1rem;line-height:1.5em} .pTtl.sml{font-size:1rem} .pTtl.itm{font-size:var(--postT);font-family:var(--fontBa);font-weight:900; line-height:1.3em} .pTtl.itm.nSpr{margin-bottom:30px} .aTtl a:hover{color:var(--linkC)} .aTtl a, .pSnpt{color:var(--fontC); display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden} .pEnt{margin-top:40px; font-size:var(--postF);font-family:var(--fontBa); line-height:1.8em} /* Snippet, Description, Headers and Info */ .pHdr{margin-bottom:8px} .pHdr .pLbls{white-space:nowrap;overflow:hidden;text-overflow:ellipsis; opacity:.8} .pSml{font-size:93%} .pSnpt{-webkit-line-clamp:2;margin:12px 0 0;font-family:var(--fontBa);font-size:14px;line-height:1.5em; opacity:.8} .pSnpt.nTag{color:var(--linkC);opacity:1} .pDesc{font-size:16px;line-height:1.5em;margin:8px 0 25px;opacity:.7} .pInf{display:flex;align-items:baseline;justify-content:space-between; margin-top:15px} .pInf.nTm{margin:0} .pInf.nSpr .pJmp{opacity:1} .pInf.nSpr .pJmp::before{content:attr(aria-label)} .pInf.ps{padding:10px 10px 10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px;justify-content:flex-start;align-items:center; margin-top:25px; position:relative;left:-4px;right:-4px;width:calc(100% + 8px)} .pInf.ps .pTtmp{opacity:1} .pInf.ps .pTtmp::before{content:attr(data-date) ' '} .pInf.ps .pTtmp::after{display:inline} .pInf.ps.nul{display:none} .pInf .pIm{flex-shrink:0; margin:0 4px} .pInf .pNm{flex-grow:1;width:calc(100% - 108px);display:inline-flex;flex-wrap:wrap;align-items:baseline} .pInf .pNm.l{display:none} .pInf .pCm{flex-shrink:0;max-width:24px;margin:0 2px} .pInf .pCm.l{max-width:58px} .pInf .pIc{display:inline-flex;justify-content:flex-end;position:relative;width:calc(100% + 10px);left:-5px;right:-5px} .pInf .pIc >*{display:flex;align-items:center;justify-content:center;width:30px;height:30px;position:relative;margin:0 2px;color:inherit} .pInf .pIc svg{width:20px;height:20px;opacity:.8;z-index:1} .pInf .pIc .cmnt::before{content:attr(data-text);font-size:11px;line-height:18px;padding:0 5px;border-radius:10px;background:#e6e6e6;color:var(--bodyC);position:absolute;top:-5px;right:0;z-index:2} .pInf .pDr{opacity:.7;display:inline-block;margin:0 4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:100%} .pInf .pDr >*:not(:first-child)::before{content:'\00B7';margin:0 5px} .pInf .pIn{display:inline} .pInf .nm{margin:0 4px} .pInf .n .nm::before{content:attr(data-write) ' ';opacity:.7} .pInf .im{width:28px;height:28px} .aTtmp{opacity:.8} .aTtmp, .pJmp{overflow:hidden} .pTtmp::after, .pJmp::before, .iTtmp::before{content:attr(data-text); display:block;line-height:18px; white-space:nowrap;text-overflow:ellipsis;overflow:hidden} .pJmp{display:inline-flex;align-items:center; opacity:0; transition:var(--trans-2)} .pJmp::before{content:attr(aria-label)} .pJmp svg{height:18px;width:18px;stroke:var(--linkC); flex-shrink:0} .ntry:hover .pJmp, .itm:hover .pJmp{opacity:1} /* Product view */ .pTag .pPad{padding:10px 0} .pTag .pPric{font-size:20px;color:var(--linkC);padding-top:20px} .pTag .pPric::before, .pTag .pInfo small{content:attr(data-text);font-size:small;opacity:.8;display:block;line-height:1.5em;color:var(--bodyC)} .pTag .pInfo{font-size:14px;line-height:1.6em} .pTag .pInfo:not(.o){position:relative;width:calc(100% + 20px);left:-10px;right:-10px;display:flex} .pTag .pInfo:not(.o) >*{width:50%;padding:0 10px} .pTag .pMart{margin:10px 0 12px;display:flex;flex-wrap:wrap;line-height:1.6em; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .pTag .pMart >*{margin:0 4px} .pTag .pMart small{width:calc(100% - 8px);margin-bottom:10px} .pTag .pMart a{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border:1px solid var(--contentL);border-radius:12px;margin-bottom:8px} .pTag .pMart img{width:20px;display:block} /* Blog pager */ .blogPg{display:flex;display:flex;align-items:center;flex-wrap:wrap;justify-content:space-between; font-size:90%;font-family:var(--fontB);line-height:20px; color:#fffdfc; margin:30px 0 50px; max-width:100%} .blogPg >*{display:flex;align-items:center; padding:10px 13px;margin-bottom:10px; color:inherit;background:var(--linkB); border-radius:35px} .blogPg >* svg{width:18px;height:18px; stroke:var(--darkT); stroke-width:1.5} .blogPg >*::before{content:attr(data-text)} .blogPg .jsLd{margin-left:auto;margin-right:auto} .blogPg .nwLnk::before, .blogPg .jsLd::before{display:none} .blogPg .nwLnk::after, .blogPg .jsLd::after{content:attr(data-text); margin:0 8px} .blogPg .olLnk::before{margin:0 8px} .blogPg .nPst, .blogPg .current{background:var(--contentL); color:var(--bodyCa)} .blogPg .nPst.jsLd svg{fill:var(--darkTa);stroke:var(--darkTa)} .blogPg .nPst svg.line{stroke:var(--darkTa)} /* Breadcrumb */ .brdCmb{margin-bottom:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .brdCmb a{color:var(--fontC)} .brdCmb >*:not(:last-child)::after{content:'/'; margin:0 4px;font-size:90%;opacity:.6} .brdCmb >*{display:inline} .brdCmb .tl::before{content:attr(data-text)} .brdCmb .hm a{font-size:90%;opacity:.7}

/* Article Style */ .pS h1, .pS h2, .pS h3, .pS h4, .pS h5, .pS h6{margin:1.5em 0 18px; font-family:var(--fontBa);font-weight:900; line-height:1.5em} .pS h1:target, .pS h2:target, .pS h3:target, .pS h4:target, .pS h5:target, .pS h6:target{padding-top:var(--headerH);margin-top:0} /* Paragraph */ .pS p{margin:1.7em 0} .pIndent{text-indent:2.5rem} .onItm:not(.Rtl) .dropCap{float:left;margin:4px 8px 0 0; font-size:55px;line-height:45px;opacity:.8} .pS hr{margin:3em 0; border:0} .pS hr::before{content:'\2027 \2027 \2027'; display:block;text-align:center; font-size:24px;letter-spacing:0.6em;text-indent:0.6em;opacity:.8;clear:both} .pRef{display:block;font-size:14px;line-height:1.5em; opacity:.7; word-break:break-word} /* Img and Ad */ .pS img{display:inline-block;border-radius:8px;height:auto !important} .pS img.full{display:block !important; margin-bottom:10px; position:relative; width:100%;max-width:none} .pS .widget, .ps .pAd >*{margin:40px 0} /* Note */ .note{position:relative;padding:16px 20px 16px 50px; background:var(--notifU);color:#3c4043; font-size:.85rem;font-family:var(--fontB);line-height:1.6em;border-radius:10px;overflow:hidden} .note::before{content:'';width:60px;height:60px;background:rgba(0,0,0,.15);display:block;border-radius:50%;position:absolute;top:-12px;left:-12px;opacity:.1} .note::after{content:'\002A';position:absolute;left:18px;top:16px; font-size:20px; min-width:15px;text-align:center} .note.wr{background:#ffdfdf;color:#48525c} .note.wr::before{background:#e65151} .note.wr::after{content:'\0021'} /* Ext link */ .extL::after{content:''; width:14px;height:14px; display:inline-block;margin:0 5px; background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23989b9f' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M13 11L21.2 2.80005'/><path d='M22 6.8V2H17.2'/><path d='M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13'/></svg>") center / 14px no-repeat} /* Scroll img */ .psImg{display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:center; margin:2em 0; position:relative;left:-7px;right:-7px; width:calc(100% + 14px)} .psImg >*{width:calc(50% - 14px); margin:0 7px 14px; position:relative} .psImg img{display:block} .scImg >*{width:calc(33.3% - 14px); margin:0 7px} .btImg label{position:absolute;top:0;left:0;right:0;bottom:0; border-radius:3px; display:flex;align-items:center;justify-content:center; background:rgba(0,0,0,.6); transition:var(--trans-1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px); color:var(--darkT); font-size:13px;font-family:var(--fontB)} .hdImg .shImg{width:100%;margin:0; left:0;right:0; transition:var(--trans-1); max-height:0;opacity:0;visibility:hidden} .inImg:checked ~ .hdImg .shImg{max-height:1000vh;opacity:1;visibility:visible} .inImg:checked ~ .hdImg .btImg label{opacity:0;visibility:hidden} /* Post related */ .pRelate{margin:40px 0;padding:20px 0; border:1px solid #989b9f;border-left:0;border-right:0; font-size:14px;line-height:1.8em} .pRelate b{font-weight:400; margin:0;opacity:.8} .pRelate ul, .pRelate ol{margin:8px 0 0;padding:0 20px} /* Blockquote */ blockquote, .cmC i[rel=quote]{position:relative;font-size:.97rem; opacity:.8;line-height:1.6em;margin-left:0;margin-right:0;padding:5px 20px;border-left:2px solid var(--contentL)} blockquote.s-1, details.sp{font-size:.93rem; padding:25px 25px 25px 45px; border:1px solid #989b9f;border-left:0;border-right:0;line-height:1.7em} blockquote.s-1::before{content:'\201D';position:absolute;top:10px;left:0; font-size:60px;line-height:normal;opacity:.5} /* Table */ .ps table{margin:0 auto; font-size:14px;font-family:var(--fontB)} .ps table:not(.tr-caption-container){min-width:90%;border:1px solid var(--contentL);border-radius:3px;overflow:hidden} .ps table:not(.tr-caption-container) td{padding:16px} .ps table:not(.tr-caption-container) tr:not(:last-child) td{border-bottom:1px solid var(--contentL)} .ps table:not(.tr-caption-container) tr:nth-child(2n+1) td{background:rgba(0,0,0,.01)} .ps table th{padding:16px; text-align:inherit; border-bottom:1px solid var(--contentL)} .ps .table{display:block; overflow-y:hidden;overflow-x:auto;scroll-behavior:smooth} /* Img caption */ figure{margin-left:0;margin-right:0} .ps .tr-caption, .psCaption, figcaption{display:block; font-size:14px;line-height:1.6em; font-family:var(--fontB);opacity:.7} /* Syntax */ .pre{background:var(--synxBg);color:var(--synxC); direction: ltr} .pre:not(.tb){position:relative;border-radius:3px;overflow:hidden;margin:1.7em auto;font-family:var(--fontC)} .pre pre{margin:0;color:inherit;background:inherit} .pre:not(.tb)::before, .cmC i[rel=pre]::before{content:'</>';display:flex;justify-content:flex-end;position:absolute;right:0;top:0;width:100%;background:inherit;color:var(--synxGray);font-size:10px;padding:0 10px;z-index:2;line-height:30px} .pre:not(.tb).html::before{content:'.html'} .pre:not(.tb).css::before{content:'.css'} .pre:not(.tb).js::before{content:'.js'} pre, .cmC i[rel=pre]{display:block;position:relative;font-family:var(--fontC);font-size:13px;line-height:1.6em;border-radius:3px;background:var(--synxBg);color:var(--synxC);padding:30px 20px 20px;margin:1.7em auto; -moz-tab-size:2;tab-size:2;-webkit-hyphens:none;-moz-hyphens:none;-ms-hyphens:none;hyphens:none; overflow:auto;direction:ltr;white-space:pre} pre i{color:var(--synxBlue);font-style:normal} pre i.block{color:#fff;background:var(--synxBlue)} pre i.green{color:var(--synxGreen)} pre i.gray{color:var(--synxGray)} pre i.red{color:var(--synxOrange)} pre i.blue{color:var(--synxBlue)} code{display:inline;padding:5px;font-size:14px;border-radius:3px;line-height:inherit;color:var(--synxC);background:#f2f3f5;font-family:var(--fontC)} /* Multi syntax */ .pre.tb{border-radius:5px} .pre.tb pre{margin:0;background:inherit} .pre.tb .preH{font-size:13px;border-color:rgba(0,0,0,.05);margin:0} .pre.tb .preH >*{padding:13px 20px} .pre.tb .preH::after{content:'</>';font-size:10px;font-family:var(--fontC);color:var(--synxGray);padding:15px;margin-left:auto} .pre.tb >:not(.preH){display:none} .pS input[id*="1"]:checked ~ div[class*="C-1"], .pS input[id*="2"]:checked ~ div[class*="C-2"], .pS input[id*="3"]:checked ~ div[class*="C-3"], .pS input[id*="4"]:checked ~ div[class*="C-4"]{display:block} /* ToC */ .pS details summary{list-style:none;outline:none} .pS details summary::-webkit-details-marker{display:none} details.sp{padding:20px 15px} details.sp summary{display:flex;justify-content:space-between;align-items:baseline} details.sp summary::after{content:attr(data-show);font-size:12px; opacity:.7;cursor:pointer} details.sp[open] summary::after{content:attr(data-hide)} details.toc a:hover{text-decoration:underline} details.toc ol, details.toc ul{padding:0 20px; list-style-type:decimal} details.toc li ol, details.toc li ul{margin:5px 0 10px; list-style-type:lower-alpha} /* Accordion */ .showH{margin:1.7em 0;font-size:.93rem;font-family:var(--fontB);line-height:1.7em} details.ac{padding:18px 0;border-bottom:1px solid var(--contentL)} details.ac:first-child{border-top:1px solid var(--contentL)} details.ac summary{font-weight:700;cursor:default; display:flex;align-items:baseline; transition:var(--trans-1)} details.ac summary::before{content:'\203A'; flex:0 0 25px;display:flex;align-items:center;justify-content:flex-start;padding:0 5px; font-weight:400;font-size:1.33rem;color:inherit} details.ac[open] summary{color:var(--linkC)} details.ac:not(.alt)[open] summary::before{transform:rotate(90deg);padding:0 0 0 5px;justify-content:center} details.ac.alt summary::before{content:'\002B'; padding:0 2px} details.ac.alt[open] summary::before{content:'\2212'} details.ac .aC{padding:0 25px;opacity:.9} /* Tabs */ .tbHd{display:flex; border-bottom:1px solid var(--contentL);margin-bottom:30px;font-size:14px;font-family:var(--fontB);line-height:1.6em; overflow-x:scroll;overflow-y:hidden;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .tbHd >*{padding:12px 15px; border-bottom:1px solid transparent; transition:var(--trans-1);opacity:.6;white-space:nowrap; scroll-snap-align:start} .tbHd >*::before{content:attr(data-text)} .tbCn >*{display:none;width:100%} .tbCn >* p:first-child{margin-top:0} .pS input[id*="1"]:checked ~ .tbHd label[for*="1"], .pS input[id*="2"]:checked ~ .tbHd label[for*="2"], .pS input[id*="3"]:checked ~ .tbHd label[for*="3"], .pS input[id*="4"]:checked ~ .tbHd label[for*="4"]{border-color:var(--linkB);opacity:1} .pS input[id*="1"]:checked ~ .tbCn div[class*="Text-1"], .pS input[id*="2"]:checked ~ .tbCn div[class*="Text-2"], .pS input[id*="3"]:checked ~ .tbCn div[class*="Text-3"], .pS input[id*="4"]:checked ~ .tbCn div[class*="Text-4"]{display:block} .tbHd.stick{position:-webkit-sticky;position:sticky;top:var(--headerH);background:var(--bodyB)} /* Split */ .ps .blogPg{font-size:13px; justify-content:center; position:relative;width:calc(100% + 8px);left:-4px;right:-4px} .ps .blogPg >*{padding:8px 15px;margin:0 4px 8px} /* Youtube fullpage */ .videoYt{position:relative;padding-bottom:56.25%; overflow:hidden;border-radius:5px} .videoYt iframe{position:absolute;width:100%;height:100%;left:0;right:0} /* Lazy Youtube */ .lazyYt{background:var(--synxBg);position:relative;overflow:hidden;padding-top:56.25%;border-radius:5px} .lazyYt img{width:100%;top:-16.84%;left:0;opacity:.95} .lazyYt img, .lazyYt iframe, .lazyYt .play{position:absolute} .lazyYt iframe{width:100%;height:100%;bottom:0;right:0} .lazyYt .play{top:50%;left:50%; transform:translate3d(-50%,-50%,0); transition:all .5s ease;display:block;width:70px;height:70px;z-index:1} .lazyYt .play svg{width:inherit;height:inherit; fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;stroke-width:8} .lazyYt .play .c{stroke:rgba(255,255,255,.85);stroke-dasharray:650;stroke-dashoffset:650; transition:all .4s ease-in-out; opacity:.3} .lazyYt .play .t{stroke:rgba(255,255,255,.75);stroke-dasharray:240;stroke-dashoffset:480; transition:all .6s ease-in-out; transform:translateY(0)} .lazyYt .play:hover .t{animation:nudge .6s ease-in-out;-webkit-animation:nudge .6s ease-in-out} .lazyYt .play:hover .t, .lazyYt .play:hover .c{stroke-dashoffset:0; opacity:.7;stroke:#FF0000} .nAmp .lazyYt{display:none} /* Button */ .button{display:inline-flex;align-items:center; margin:10px 0;padding:12px 15px;outline:0;border:0; border-radius:20px;line-height:20px; color:#fffdfc; background:var(--linkB); font-size:14px;font-family:var(--fontB); white-space:nowrap;overflow:hidden;max-width:320px} .button.ln{color:inherit;background:transparent; border:1px solid var(--bodyCa)} .button.ln:hover{border-color:var(--linkB);box-shadow:0 0 0 1px var(--linkB) inset} .btnF{display:flex;justify-content:center; margin:10px 0;width:calc(100% + 12px);left:-6px;right:-6px;position:relative} .btnF >*{margin:0 6px} /* Download btn */ .dlBox{max-width:500px;background:#f1f1f0;border-radius:10px;padding:12px;margin:1.7em 0; display:flex;align-items:center; font-size:14px} .dlBox .fT{flex-shrink:0;display:flex;align-items:center;justify-content:center; width:45px;height:45px; padding:10px; background:rgba(0,0,0,.1);border-radius:5px} .dlBox .fT::before{content:attr(data-text);opacity:.7} .dlBox a{flex-shrink:0;margin:0;padding:10px 12px;border-radius:20px;font-size:13px} .dlBox a::after{content:attr(aria-label)} .dlBox .fN{flex-grow:1; width:calc(100% - 200px);padding:0 15px} .dlBox .fN >*{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .dlBox .fS{line-height:16px;font-size:12px;opacity:.8} /* Icon btn */ .icon{flex-shrink:0;display:inline-flex} .icon::before{content:'';width:18px;height:18px;background-size:18px;background-repeat:no-repeat;background-position:center} .icon::after{content:'';padding:0 6px} .icon.dl::before, .drK .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")} .icon.demo::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23fefefe' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><path d='M7.39999 6.32003L15.89 3.49003C19.7 2.22003 21.77 4.30003 20.51 8.11003L17.68 16.6C15.78 22.31 12.66 22.31 10.76 16.6L9.91999 14.08L7.39999 13.24C1.68999 11.34 1.68999 8.23003 7.39999 6.32003Z'/><path d='M10.11 13.6501L13.69 10.0601'/></svg>")} .button.ln .icon.dl::before{background-image:url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2308102b' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5'><polyline points='8 17 12 21 16 17'/><line x1='12' y1='12' x2='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>")} /* Lightbox image */ .zmImg.s{position:fixed;top:0;left:0;bottom:0;right:0;width:100%;margin:0;background:rgba(0,0,0,.75); display:flex;align-items:center;justify-content:center;z-index:999; -webkit-backdrop-filter:saturate(180%) blur(15px); backdrop-filter:saturate(180%) blur(15px)} .zmImg.s img{display:block;max-width:92%;max-height:92%;width:auto;margin:auto;border-radius:10px;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .zmImg.s img.full{left:auto;right:auto;border-radius:10px;width:auto} .zmImg::after{content:'\2715';line-height:16px;font-size:14px;color:#fffdfc;background:var(--linkB); position:fixed;bottom:-20px;right:-20px; display:flex;align-items:center;justify-content:center;width:45px;height:45px;border-radius:50%; transition:var(--trans-1);opacity:0;visibility:hidden} .zmImg.s::after{bottom:20px;right:20px;opacity:1;visibility:visible;cursor:pointer}

/* Article Style Responsive */ @media screen and (max-width: 640px){.pS img.full{width:calc(100% + 40px);left:-20px;right:-20px; border-radius:0} .note{font-size:13px} .scImg{flex-wrap:nowrap;justify-content:flex-start;position:relative;width:calc(100% + 40px);left:-20px;right:-20px;padding:0 13px; overflow-y:hidden;overflow-x:scroll;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .scImg >*{flex:0 0 80%;scroll-snap-align:center} .ps .table{position:relative; width:calc(100% + 40px);left:-20px;right:-20px;padding:0 20px; display:flex}} @media screen and (max-width:500px){.hdImg{width:100%;left:0;right:0} .hdImg >*, .shImg >*{width:100%;margin:0 0 16px} .ps .tr-caption, .psCaption, figcaption{font-size:13px} .btnF >*{flex-grow:1;justify-content:center}.btnF >*:first-child{flex:0 0 auto} .dlBox a{width:42px;height:42px;justify-content:center} .dlBox a::after, .dlBox .icon::after{display:none}}

/* Author profile */ .admPs{display:flex; max-width:480px;margin:30px 0; padding:12px 12px 15px; background:var(--contentBa);border-radius:8px; box-shadow:0 10px 25px -3px rgba(0,0,0,.1)} .admIm{flex-shrink:0; padding:5px 0 0} .admIm .im{width:34px;height:34px} .admI{flex-grow:1; width:calc(100% - 34px);padding:0 12px} .admN::before{content:attr(data-write) ' '; opacity:.7;font-size:90%} .admN::after{content:attr(data-text)} .admA{margin:5px 0 0; font-size:90%; opacity:.9;line-height:1.5em; /*display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden*/} /* Share btn */ .pSh{margin:15px 0;padding:18px 0;border-bottom:1px solid rgba(0,0,0,.05)} .pShc{display:flex;align-items:center;flex-wrap:wrap; position:relative;width:calc(100% + 18px);left:-9px;right:-9px;font-size:13px} .pShc::before{content:attr(data-text);margin:0 9px;flex-shrink:0} .pShc >*{margin: 0 5px;display: flex;align-items: center;color: inherit;padding: 12px;border-radius: 20px;background: #f1f1f0;} .pShc .c{color:#fffdfc} .pShc .c svg{fill:#fffdfc} .pShc .c::after{content:attr(aria-label)} .pShc .fb{background:#1778F2} .pShc .wa{background:#128C7E} .pShc .tw{background:#1DA1F2} .pShc a::after{content:attr(data-text);margin:0 3px} .pShc svg, .cpL svg{width:18px;height:18px; margin:0 3px} .shL{position:relative;width:calc(100% + 20px);left:-10px;right:-10px;/*margin-bottom:20px;*/display:flex;flex-wrap:wrap;justify-content:center} .shL >*{margin:0 10px 20px;text-align:center} .shL >*::after{content:attr(data-text);font-size:90%;opacity:.7;display:block} .shL a{display:flex;align-items:center;justify-content:center;flex-wrap:wrap; width:65px;height:65px; color:inherit;margin:0 auto 5px;padding:8px;border-radius:26px;background:#f1f1f0} .shL svg{opacity:.8} .cpL{padding-bottom:15px} .cpL::before{content:attr(data-text);display:block;margin:0 0 15px;opacity:.8} .cpL svg{margin:0 4px;opacity:.7} .cpL input{border:0;outline:0; background:transparent;color:rgba(8,16,43,.4); padding:18px 8px;flex-grow:1} .cpL label{display:flex;align-items:center;flex-shrink:0;padding:2px 8px;border-radius:15px}.cpLb{display:flex;align-items:center;position:relative;background:#f1f1f0;border-radius:10px; padding:0 8px} .cpLb:hover{border-color:rgba(0,0,0,.42);background:#ececec} .cpLn span{display:block;padding:5px 14px 0;font-size:90%;color:#2e7b32; transition:var(--trans-1);animation:fadein 2s ease forwards; opacity:0;height:22px} /* Comments */ .pCmnts{margin-top:50px} .cmDis{text-align:center;margin-top:20px;opacity:.7} .cmMs{margin-bottom:20px} .cm iframe{width:100%} .cm:not(.cmBr) .cmBrs{background:transparent;position:relative;padding:60px 20px 0;width:calc(100% + 40px);left:-20px;right:-20px} .cmH h3.title{margin:0;flex-grow:1;padding:16px 10px} .cmH .s{margin:0 14px} .cmH .s::before{content:attr(data-text);margin:0 6px;opacity:.7;font-size:90%} .cmH .s::after{content:'\296E';line-height:18px;font-size:17px} .cmAv .im{width:35px;height:35px;border-radius:50%;position:relative} .cmBd.del .cmCo{font-style:italic;font-size:90%;line-height:normal;border:1px dashed rgba(0,0,0,.2);border-radius:3px;margin:.5em 0;padding:15px;opacity:.7; overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .cmHr{line-height:24px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap} .cmHr .d{font-size:90%;opacity:.7} .cmHr .d::before{content:'\00B7';margin:0 7px} .cmHr.a .n{display:inline-flex;align-items:center} .cmHr.a .n::after{content:'\2714';display:flex;align-items:center;justify-content:center;width:14px;height:14px;font-size:8px;background:#519bd6;color:#fefefe;border-radius:50%;margin:0 3px} .cmCo{line-height:1.6em;opacity:.9} .cmC i[rel=image]{font-size:90%; display:block;position:relative; min-height:50px; overflow:hidden;text-overflow:ellipsis;white-space:nowrap; margin:1em auto} .cmC i[rel=image]::before{content:'This feature isn\0027t available!';border:1px dashed rgba(0,0,0,.2);border-radius:3px;padding:10px;display:flex;align-items:center;justify-content:center;position:absolute;top:0;left:0;bottom:0;right:0;background:var(--contentB)} .cmC i[rel=pre], .cmC i[rel=quote]{margin-top:1em;margin-bottom:1em; font-style:normal;line-height:inherit;padding:20px} .cmC i[rel=pre]::before{display:block;width:auto} .cmC i[rel=quote]{display:block;font-style:italic;font-size:inherit;padding:5px 15px} .cmCo img{margin-top:1em;margin-bottom:1em} .cmAc{margin-top:10px} .cmAc a{font-size:90%;color:inherit;opacity:.7;display:inline-flex} .cmAc a::before{content:'\2934';line-height:18px;font-size:16px;transform:rotate(90deg)} .cmAc a::after{content:attr(data-text);margin:0 6px} .cmR{margin:10px 40px 0} .cmRp ~ .cmAc, .cmBd.del ~ .cmAc, .onItm:not(.Rtl) .cmHr .date{display:none} .cmRi:checked ~ .cmRp .thTg{margin-bottom:0} .cmRi:checked ~ .cmRp .thTg::after{content:attr(aria-label)} .cmRi:checked ~ .cmRp .thCh, .cmRi:checked ~ .cmRp .cmR{display:none} .cmAl:checked ~ .cm .cmH .s::before{content:attr(data-new)} .cmAl:checked ~ .cm .cmCn >ol{flex-direction:column-reverse} .thTg{display:inline-flex;align-items:center;margin:15px 0 18px;font-size:90%} .thTg::before{content:'';width:28px;border-bottom:1px solid var(--widgetTac);opacity:.5} .thTg::after{content:attr(data-text);margin:0 12px;opacity:.7} .cmCn ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column} .cmCn li{margin-bottom:18px;position:relative} .cmCn li .cmRbox{margin-top:20px} .cmCn li li{display:flex;flex-wrap:wrap;width:calc(100% + 12px);left:-6px;right:-6px} .cmCn li li:last-child{margin-bottom:0} .cmCn li li .cmAv{flex:0 0 28px;margin:0 6px} .cmCn li li .cmAv .im{width:28px;height:28px} .cmCn li li .cmIn{width:calc(100% - 52px);margin:0 6px} .cmHl >li{padding-left:17.5px} .cmHl >li >.cmAv{position:absolute;left:0;top:12px} .cmHl >li >.cmIn{padding:12px 15px 12px 28px;border:1px solid var(--contentL);border-radius:12px;box-shadow:0 10px 8px -10px rgba(0,0,0,.1)} /* Comments Show/Hide */ #comment:target{margin:0;padding-top:60px} .cmSh:checked ~ .cmShw, .cmShw ~ .cm:not(.cmBr), #comment:target .cmShw, #comment:target .cmSh:checked ~ .cm:not(.cmBr){display:none} .cmSh:checked ~ .cm:not(.cmBr), #comment:target .cm:not(.cmBr), #comment:target .cmSh:checked ~ .cmShw{display:block} .cmBtn{display:block;padding:20px;text-align:center;max-width:100%} .cmBtn.ln:hover{color:var(--linkB)} /* Comments Pop-up */ #comment:target .cmSh:checked ~ .cm.cmBr{bottom:-100%;opacity:0;visibility:hidden} #comment:target .cmSh:checked ~ .cm.cmBr .fCls{opacity:0;visibility:hidden}

/* Widget Style */ .widget .imgThm{display:block;position:absolute;top:50%;left:50%;max-width:none;max-height:108%; font-size:12px;text-align:center; transform:translate(-50%, -50%)} .widget .title{margin:0 0 25px; font-size:var(--widgetT);font-weight:var(--widgetTw);position:relative;/*margin-top:20px*/} .widget .title::after{content:'';display:inline-block;vertical-align:middle; width:var(--widgetTa); margin:0 10px;border-bottom:1px solid var(--widgetTac); opacity:.5} .widget input[type=text]:focus, .widget input[type=email]:focus, .widget textarea:focus, .widget input[data-text=fl], .widget textarea[data-text=fl]{border-color:var(--linkB);background:#ececec} .widget input[type=button], .widget input[type=submit]{display:inline-flex;align-items:center; padding:12px 30px; outline:0;border:0;border-radius:4px; color:#fffdfc; background:var(--linkB); font-size:14px; white-space:nowrap;overflow:hidden;max-width:100%} .widget input[type=button]:hover, .widget input[type=submit]:hover{opacity:.7} /* Widget BlogSearch */ .BlogSearch{position:fixed;top:0;left:0;right:0;z-index:12} .BlogSearch form{position:relative;min-width:320px} .BlogSearch input{position:relative;display:block;background:var(--srchB);border:0;outline:0;margin-top:-100%;padding:10px 55px;width:100%;height:72px;transition:var(--trans-1);z-index:2;border-radius:0 0 12px 12px} .BlogSearch input:focus{margin-top:0;box-shadow:0 10px 40px rgba(0,0,0,.2)} .BlogSearch input:focus ~ button.sb{opacity:.9} .BlogSearch .sb{position:absolute;left:0;top:0;display:flex;align-items:center;padding:0 20px;z-index:3;opacity:.7;height:100%;background:transparent;border:0;outline:0} .BlogSearch .sb svg{width:18px;height:18px;stroke:var(--srchI)} .BlogSearch button.sb{left:auto;right:0;opacity:0;font-size:13px} .BlogSearch button.sb::before{content:'\2715'} @media screen and (min-width:897px){header .BlogSearch{position:static;z-index:1} header .BlogSearch input{margin-top:0;padding:12px 42px;height:auto;font-size:13px;border-radius:20px;background:var(--transB); width:calc(100% + 26px);left:-13px;right:-13px;transition:var(--trans-2)} header .BlogSearch input:hover{background:var(--transB)} header .BlogSearch input:focus{box-shadow:none;margin-top:0; background:var(--transB)} header .BlogSearch .sb{padding:0} header .BlogSearch .fCls{display:none}} /* Widget Profile */ .prfI:checked ~ .mainWrp .wPrf{top:0;opacity:1;visibility:visible} .prfI:checked ~ .mainWrp .wPrf ~ .fCls{z-index:3;opacity:1;visibility:visible} .wPrf{display:flex;position:absolute;top:-5px;right:0;background:var(--contentB);border-radius:16px 5px 16px 16px;width:260px;max-height:400px;box-shadow:0 10px 25px -3px rgba(0,0,0,.1);transition:var(--trans-1);z-index:4;opacity:0;visibility:hidden;overflow:hidden} .wPrf .prfS{background:inherit} .wPrf.tm .im{width:39px;height:39px;flex-shrink:0} .wPrf.sl .im{width:60px;height:60px;border-radius:26px;margin:0 auto} .wPrf.sl .prfC{text-align:center} .prfH .c{display:none} .prfL{display:flex;align-items:center;position:relative;width:calc(100% + 16px);left:-8px;right:-8px;border-radius:8px;padding:8px 0;transition:var(--trans-1)} .prfL::after{content:attr(data-text);margin:0 2px} .prfL >*{margin:0 8px;flex-shrink:0} a.prfL:hover{background:var(--transB)} .sInf{margin-bottom:0} .sInf .sDt .l{display:inline-flex;align-items:center} .sInf .sTxt{margin:5px auto 0;max-width:320px;font-size:93%;opacity:.9;line-height:1.5em} .sInf .sTxt a{text-decoration:underline} .sInf .lc{display:flex;justify-content:center;margin:10px 0 0;opacity:.8;font-size:90%} .sInf .lc svg{width:16px;height:16px} .sInf .lc::after{content:attr(data-text);margin:0 4px} /* Widget FeaturedPost */ @media screen and (min-width:501px){.FeaturedPost .itemFt{position:relative;overflow:hidden;padding:10px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .drK .FeaturedPost .itemFt{background:var(--darkBa)} .FeaturedPost .itemFt::after{content:'';position: absolute;right:0;top:0;width:40px;height:15px;}} .itemFt .itm >*{flex:0 0 310px;width:310px} .itemFt .itm >*:last-child{flex:1 0 calc(100% - 310px - 40px);width:calc(100% - 310px - 40px)} .drK .FeaturedPost .itemFt::after{background:var(--darkU);} /* Widget ToC */ .tocL{position:fixed;top:0;bottom:5%;right:-280px;width:280px;transition:var(--trans-1);z-index:5} .tocLi{width:100%;height:100%;position:relative;background:var(--contentB);box-shadow:0 5px 30px 0 rgba(0,0,0,.05);z-index:2;border-radius:20px 0 0 20px} .tocLs{position:relative;top:20px;background:inherit} .tocIn{padding:60px 0 0;overflow-y:scroll;overflow-x:hidden;width:100%;height:calc(100vh - var(--headerH))} .tocC{position:absolute;left:-45px;top:105px;transition:var(--trans-1)} .tocC span{display:flex;align-items:center;justify-content:center;width:45px;height:40px;border-radius:20px 0 0 20px;background:var(--contentB);transition:inherit;z-index:1;box-shadow:0 5px 20px 0 rgba(0,0,0,.1)} .tocL svg.rad{width:20px;height:20px;position:absolute;right:-2px;top:-19px;fill:var(--contentB);transform:rotate(92deg);transition:inherit} .tocL svg.rad.in{top:auto;bottom:-19px;transform:rotate(-2deg)} .tocC span svg{opacity:.8;animation:wiggle 3s infinite} .tocT{display:flex;width:100%} .tocL ol{margin:0;padding-inline-start:35px;line-height:1.6em} .tocL li ol{margin:5px 0 10px;list-style:lower-roman} .tocL a{color:inherit;opacity:.8} .tocL a:hover{text-decoration:underline} .tocI:checked ~ .tocL{right:0;z-index:10} .tocI:checked ~ .tocL .tocC{opacity:0;visibility:hidden} .tocI:checked ~ .tocL .fCls{background:rgba(0,0,0,.25);opacity:1;visibility:visible}  /* Widget PopularPosts */ .PopularPosts{padding:17px 20px 30px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .itemPp{counter-reset:p-cnt} .itemPp .iCtnt{display:flex} .itemPp >*:not(:last-child){margin-bottom:25px} .itemPp .iCtnt::before{flex-shrink:0;content:'0' counter(p-cnt);counter-increment:p-cnt;width:25px;opacity:.6;font-size:85%;line-height:1.8em} .iInr{flex:1 0;width:calc(100% - 25px)} .iTtl{font-size:.95rem;font-weight:700;line-height:1.5em} .iTtmp{display:none} .iTtmp::after{content:'\2014';margin:0 5px; color:var(--widgetTac);opacity:.7} .iInf{margin:0 25px 8px; overflow:hidden;white-space:nowrap;text-overflow:ellipsis} .iInf .pLbls >*{color:#fefefe;display:inline;margin-right:5px;border-radius: 20px;background:#06D7A0;height:24px;padding:0 10px}.iInf .pLbls >*:hover{text-decoration:none;color:#0b57cf;background:rgba(0,0,0,.05);font-weight:normal}.iInf .pLbls a:nth-child(1){background:var(--linkB)}.iInf .pLbls a:nth-child(2){background:var(--darkU)}.iInf .pLbls a:nth-child(3){background:var(--linkC)}
/* Widget Label */ /* List Label */ .Label{padding:20px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px} .wL ul{display:flex;flex-wrap:wrap; list-style:none;margin:0;padding:0; position:relative;width:calc(100% + 30px);left:-15px;right:-15px; font-size:13px} .wL li{width:calc(50% - 10px); margin:0 5px} .wL li >*{display:flex;align-items:baseline;justify-content:space-between; color:var(--bodyC);width:100%; padding:8px 10px;border-radius:35px;line-height:20px} .wL li >* svg{width:18px;height:18px;opacity:.8} .wL li >*:hover svg, .wL li >div svg{/*fill:var(--linkC) !important;*/stroke:var(--linkC)} .wL li >*:hover .lbC, .wL li >div .lbC{color:var(--linkC)} .wL .lbR{display:inline-flex;align-items:center} .wL .lbR .lbC{margin:0 5px} .wL .lbAl{max-height:0; overflow:hidden; transition:var(--trans-4)} .wL .lbM{display:inline-block; margin-top:10px;line-height:20px; color:var(--linkC)} .wL .lbM::before{content:attr(data-show)} .wL .lbM::after, .wL .lbC::after{content:attr(data-text)} .wL .lbM::after{margin:0 8px} .wL .lbT{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.7} .wL .lbC, .wL .lbM::after{flex-shrink:0;font-size:12px;opacity:.7} .lbIn:checked ~ .lbAl{max-height:1000vh} .lbIn:checked ~ .lbM::before{content:attr(data-hide)} .lbIn:checked ~ .lbM::after{visibility:hidden} .wL.bg ul{width:calc(100% + 10px);left:-5px;right:-5px} .wL.bg li{margin-bottom:10px} .wL.bg li >*{background:#f6f6f6} /* Cloud Label */ .wL.cl{display:flex;flex-wrap:wrap} .wL.cl >*, .wL.cl .lbAl >*{display:block;max-width:100%} .wL.cl .lbAl{display:flex;flex-wrap:wrap} .wL.cl .lbC::before{content:'';margin:0 4px;flex:0 0} .wL.cl .lbN{display:flex;justify-content:space-between; margin:0 0 8px;padding:9px 13px; border:1px solid var(--contentL);border-radius:20px; color:inherit;line-height:20px} .wL.cl .lbN:hover .lbC, .wL.cl div.lbN .lbC{color:var(--linkB); opacity:1} .wL.cl .lbN:not(div):hover, .wL.cl div.lbN{border-color:var(--linkB)} .wL.cl .lbSz{display:flex} .wL.cl .lbSz::after{content:'';margin:0 4px;flex:0 0}/* Widget ContactForm */ .ContactForm{max-width:500px; font-family:var(--fontB);font-size:14px} .cArea:not(:last-child){margin-bottom:25px} .cArea label{display:block;position:relative} .cArea label .n{display:block;position:absolute;left:0;right:0;top:0; color:rgba(8,16,43,.4);line-height:1.6em;padding:15px 16px 0;border-radius:4px 4px 0 0;transition:var(--trans-1)} .cArea label .n.req::after{content:'*';font-size:85%} .cArea textarea{height:100px} .cArea textarea:focus, .cArea textarea[data-text=fl]{height:200px} .cArea input:focus ~ .n, .cArea textarea:focus ~ .n, .cArea input[data-text=fl] ~ .n, .cArea textarea[data-text=fl] ~ .n{padding-top:5px;color:rgba(8,16,43,.7);font-size:90%;background:#ececec} .cArea .h{display:block;font-size:90%;padding:5px 16px 0;opacity:.7;line-height:normal} .nArea .contact-form-error-message-with-border{color:#d32f2f} .nArea .contact-form-success-message-with-border{color:#2e7b32} /* Widget Sliders */ .sldO{position:relative;display:flex;overflow-y:hidden;overflow-x:scroll; scroll-behavior:smooth;scroll-snap-type:x mandatory;list-style:none;margin:0;padding:0; -ms-overflow-style: none} .sldO.no-items{display:none} .sldO.no-items + .section{margin-top:0} .sldO .widget:not(:first-child){margin-top:0} .sldO .widget{position:relative;flex:0 0 100%;width:100%;background:transparent; outline:0;border:0} .sldC{position:relative} .sldS{position:absolute;top:0;left:0;width:100%;height:100%;scroll-snap-align:center;z-index:-1} .sldIm{background-repeat:no-repeat;background-size:cover;background-position:center;background-color:var(--transB);display:block;padding-top:40%;border-radius:3px;color:#fffdfc;font-size:13px} .sldT{position:absolute;bottom:0;left:0;right:0;display:block;padding:20px; background:linear-gradient(0deg, rgba(30,30,30,.1) 0%, rgba(30,30,30,.05) 60%, rgba(30,30,30,0) 100%); border-radius:0 0 3px 3px} .sldS{animation-name:tonext, snap;animation-timing-function:ease;animation-duration:4s;animation-iteration-count:infinite} .sldO .widget:last-child .sldS{animation-name:tostart, snap} .Rtl .sldS{animation-name:tonext-rev, snap} .Rtl .sldO .widget:last-child .sldS{animation-name:tostart-rev, snap} .sldO:hover .widget .sldS, .Rtl .sldO:hover .widget .sldS, .sldO:focus-within .widget .sldS, .Rtl .sldO:focus-within .widget .sldS{animation-name:none} @media (prefers-reduced-motion:reduce){.sldS, .Rtl .sldS{animation-name:none}} @media screen and (max-width:640px){.sldO{width:calc(100% + 40px);left:-20px;right:-20px;padding:0 12.5px 10px} .sldO .widget{flex:0 0 90%;width:90%;margin:0 7.5px; box-shadow:0 10px 8px -8px rgb(0 0 0 / 12%)} .sldT{padding:10px 15px} .sldIm{font-size:12px}}

/* Sticky Ad */ .ancrA{position:fixed;bottom:0;left:0;right:0;min-height:70px;max-height:200px;padding:5px;box-shadow:0 -6px 18px 0 rgba(9,32,76,.1); transition:var(--trans-1);display:flex;align-items:center;justify-content:center;background:#fffdfc;z-index:50;border-top:1px solid var(--contentL)} .ancrC{width:40px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:12px 0 0;border:1px solid var(--contentL);border-bottom:0;border-right:0;position:absolute;right:0;top:-30px;background:inherit} .ancrC::after{content:'\2715';line-height:18px;font-size:14px} .ancrCn{flex-grow:1;overflow:hidden;display:block;position:relative} .ancrI:checked ~ .ancrA{padding:0;min-height:0} .ancrI:checked ~ .ancrA .ancrCn{display:none} /* Error Page */ .erroP{display:flex;align-items:center;justify-content:center;height:100vh;text-align:center;padding:0;background-image:url('https://j.gifs.com/5y8xPR.gif');} .erroC{width:calc(100% - 40px);max-width:450px;margin:auto;font-family:var(--fontBa)} .erroC h3{font-size:1.414rem;font-family:inherit} .erroC h3 span{display:block;font-size:140px;line-height:.8;color:#ebebf0} .erroC p{margin:30px 5%;line-height:1.6em;opacity:.7} .erroC .button{margin:0;padding-left:2em;padding-right:2em;font-size:14px}

/* Basic Layout */ @media screen and (min-width:897px){.LS-2 header, .LS-2 .tocLi::before, .LS-3 header{border:0} .LS-2, .LS-2 .headCn, .LS-2 .mnBrs, .LS-3 .mnBrs, .LS-3 .headL{background:#fafafc} .LS-2 .blogCont::before{border:0;top:0;right:0;bottom:0;height:100%;z-index:-1;background:var(--contentB);border-radius:15px 0 0 0} .LS-3 .headCn{background:transparent} .LS-3 .headR{background:var(--headerB)} .LS-3 .blogCont::before{z-index:10} .LS-3 .blogMn{z-index:11} .LS-3 .tocL{top:var(--headerHi);z-index:10} .LS-3 .tocI:checked ~ .tocL{z-index:10} .LS-3:not(.hdMn) .navI:checked ~ .mainWrp .headN, .LS-3.hdMn .navI:not(:checked) ~ .mainWrp .headN{display:none} .LS-3:not(.hdMn) .navI:checked ~ .mainWrp .headL, .LS-3 .navI:not(:checked) ~ .mainWrp .headL{width:75px}}

/* Responsive */
@media screen and (min-width:897px){/* mainIn */ .mainIn, .blogM{display:flex} .blogMn{width:var(--navW);flex-shrink:0;position:relative;transition:var(--trans-1);z-index:1} .blogCont{padding-top:30px} .blogCont::before{content:'';position:absolute;top:var(--headerHi);left:0;height:calc(100% + var(--headerH));border-right:var(--navL) solid var(--contentL)} .blogCont{width:calc(100% - var(--navW))} .blogCont .secIn{padding-left:25px;padding-right:25px} .mainbar{flex:1 0 calc(100% - var(--sideW) - 25px);width:calc(100% - var(--sideW) - 25px)} .sidebar{display:flex;flex:0 0 calc(var(--sideW) + 25px);width:calc(var(--sideW) + 25px); margin:0} .sidebar::before{content:'';flex:0 0 25px} .sidebar .sideIn{width:calc(100% - 25px)} /* mainNav */ .mnBr{position:sticky;position:-webkit-sticky;top:var(--headerH)} .mnBrs{display:flex;height:calc(100vh - var(--headerH));font-size:13px;position:relative} .mnBrs >*:not(.mnMob){width:100%} .mnMen{padding:20px;overflow-y:hidden;overflow-x:hidden} .mnMen:hover{overflow-y:scroll} .mnMob{position:fixed;width:var(--navW)} .mnH, .mobMn{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .blogMn, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob, .hdMn .navI:not(:checked) ~ .mainWrp .blogMn, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob{width:75px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn a:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn a:hover{opacity:1;color:inherit} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .a, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .a{max-width:40px; border-radius:15px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .drp.mr, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn svg.d, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .PageList, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mSoc, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .drp.mr, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn svg.d, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .PageList, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mSoc{display:none} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMob .mNav, .hdMn .navI:not(:checked) ~ .mainWrp .mnMob .mNav{display:flex} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn >li.br::after, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn >li.br::after{max-width:20px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMen:hover, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen, .hdMn .navI:not(:checked) ~ .mainWrp .mnMen:hover{overflow-y:visible;overflow-x:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{position:absolute;left:35px;top:3px;margin:0 5px;padding:8px 10px;border-radius:5px 16px 16px 16px;max-width:160px;background:var(--contentB);color:var(--bodyC);opacity:0;visibility:hidden;box-shadow:0 5px 20px 0 rgba(0,0,0,.1);z-index:1} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{padding:0 5px;margin:0;overflow:hidden;display:block} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):last-child ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):last-child ul{top:auto;bottom:3px;border-radius:16px 16px 16px 5px} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):hover ul, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.drp) .a:hover .n, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):hover ul{opacity:1;visibility:visible} .bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn ul li >*, .hdMn .navI:not(:checked) ~ .mainWrp .mnMn ul li >*{border-radius:0} /* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} .onIndx.onMlt .blogPts >*{flex:0 0 calc(25% - 20px);width:calc(25% - 20px)} /* Widget ToC */ .tocL{position:absolute;z-index:2} .tocLi::before{content:'';border-left:1px solid var(--contentL);position:absolute;top:0;bottom:0;left:0;z-index:1} .tocLs{position:-webkit-sticky;position:sticky;top:var(--headerH)} .tocC{top:40px} .tocI:checked ~ .tocL{z-index:2} .tocI:checked ~ .tocL .fCls{background:transparent}}
@media screen and (min-width:768px){::-webkit-scrollbar{-webkit-appearance:none;width:4px;height:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:10px}::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.35)}::-webkit-scrollbar-thumb:active{background:rgba(0,0,0,.35)}}
@media screen and (max-width:1100px){/* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} .onIndx.onMlt .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} /* Widget */ .itemFt .itm >*, .itemFt .itm >*:last-child{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)} .itemFt .itm >*:last-child{flex-grow:1} .itemFt .pSnpt{display:none}}
@media screen and (max-width:896px){/* Header */ .ntfC{padding-left:20px;padding-right:20px} .headI .headS{margin:0} /* mainNav */ .blogMn{display:flex;justify-content:flex-start;position:fixed;left:0;top:0;bottom:0;margin-left:-100%;z-index:20;transition:var(--trans-1);width:100%;height:100%} .mnBr{width:80%;top:2%;left:10%;bottom:2%;max-width:480px;height:96%;border-radius:10px 10px 10px 10px;transition:var(--trans2);z-index:3;overflow:hidden;position:relative;box-shadow:0 5px 30px 0 rgba(0,0,0,.05)} .mnBrs{padding:60px 0 0;overflow-y:scroll;overflow-x:hidden;width:100%;height:100%} .mnH{padding:0 15px} .mnH label{padding:15px 10px} .mnH .c::after{margin:0 13px} .mnMen{padding-top:0} .navI:checked ~ .mainWrp .blogMn{margin-left:0} .navI:checked ~ .mainWrp .blogMn .fCls{opacity:1;visibility:visible;background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} /* Article */ .onIndx.onHm .blogPts >*{flex:0 0 calc(33.33% - 20px);width:calc(33.33% - 20px)} /* Widget */ .itemFt .pSnpt{display:-webkit-box} .mobMn:not(.no-items) + footer{padding-bottom:calc(20px + 20px)}}
@media screen and (max-width:768px){/* Article */ .onIndx.onHm .blogPts >*, .onIndx.onMlt .blogPts >*{flex:0 0 calc(50% - 20px);width:calc(50% - 20px)}}
@media screen and (max-width:640px){/* Header */ .headCn{height:var(--headerHm)} /* Pop-up */ .fixL{align-items:flex-end} .fixL .fixLi, .fixL .cmBri{border-radius:12px 12px 0 0; max-width:680px} .fixL .cmBri:not(.mty){border-radius:0;height:100%;max-height:100%}}
@media screen and (max-width:500px){/* Font and Blog */ .iFxd, .crdtIn{font-size:12px} .brdCmb{font-size:13px} .pDesc{font-size:14px} .pEnt{font-size:var(--postFm)} .pTtl.itm{font-size:var(--postTm)} .pInf.ps .pTtmp::after{content:attr(data-time)} .pInf.ps .pDr{font-size:12px} /* Article */ .onIndx:not(.oneGrd) .blogPts{width:calc(100% + 15px);left:-7.5px;right:-7.5px} .onIndx:not(.oneGrd) .blogPts >*{flex:0 0 calc(50% - 15px);width:calc(50% - 15px);margin-left:7.5px;margin-right:7.5px} .onIndx:not(.oneGrd) .blogPts div.ntry{flex:0 0 calc(100% - 15px)} .onIndx:not(.oneGrd) .ntry .pSml{font-size:12px} .onIndx:not(.oneGrd) .ntry .pTtl{font-size:.9rem} .onIndx:not(.oneGrd) .ntry:not(.pTag) .pSnpt, .onIndx:not(.oneGrd) .ntry .pInf:not(.nSpr) .pJmp, .onIndx:not(.oneGrd) .ntry .iFxd .spnr{display:none} .onIndx:not(.oneGrd) .ntry .iFxd{padding:8px 3px} .onIndx:not(.oneGrd) .ntry .iFxd .cmnt{padding:3px} .onIndx:not(.oneGrd) .ntry .iFxd >* svg{padding:1px} .onIndx.oneGrd .blogPts >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)} /* Share */ .pShc{width:calc(100% + 10px);left:-5px;right:-5px} .pShc::before{width:calc(100% - 10px);margin:0 5px 12px} .pShc .wa::after, .pShc .tw::after{display:none} /* Widget */ .prfI:checked ~ .mainWrp .wPrf{top:auto;bottom:0} .prfI:checked ~ .mainWrp .Profile .fCls{background:rgba(0,0,0,.2); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .prfH .c{display:flex} .wPrf{position:fixed;top:auto;left:0;right:0;bottom:-100%;width:100%;max-height:calc(100% - var(--headerH));border-radius:12px 12px 0 0} .itemFt .itm{padding-bottom:80px} .itemFt .itm >*{flex:0 0 calc(100% - 20px);width:calc(100% - 20px)} .itemFt .itm .iCtnt{flex:0 0 calc(100% - 42px);width:calc(100% - 42px);margin:0 auto;position:absolute;left:0;right:0;bottom:0;padding:13px;background:rgba(255,253,252,.92);border-radius:10px;box-shadow:0 10px 20px -5px rgba(0,0,0,.1); -webkit-backdrop-filter:saturate(180%) blur(10px); backdrop-filter:saturate(180%) blur(10px)} .itemFt .pTtl{font-size:1rem} .itemFt .pSnpt{font-size:93%}
}

/* Keyframes Animation */ @keyframes shimmer{100%{transform:translateX(100%)}} @keyframes fadein{50%{opacity:1}80%{opacity:1;padding-top:5px;height:22px}100%{opacity:0;padding-top:0;height:0}} @keyframes nudge{0%{transform:translateX(0)}30%{transform:translateX(-5px)}50%{transform:translateX(5px)}70%{transform:translateX(-2px)}100%{transform:translateX(0)}} @keyframes tonext{ 75%{left:0} 95%{left:100%} 98%{left:100%} 99%{left:0}} @keyframes tostart{ 75%{left:0} 95%{left:-300%} 98%{left:-300%} 99%{left:0}} @keyframes tonext-rev{ 75%{right:0} 95%{right:100%} 98%{right:100%} 99%{right:0}} @keyframes tostart-rev{ 75%{right:0} 95%{right:-300%} 98%{right:-300%} 99%{right:0}} @keyframes snap{ 96%{scroll-snap-align:center} 97%{scroll-snap-align:none} 99%{scroll-snap-align:none} 100%{scroll-snap-align:center}} @-webkit-keyframes fadein{50%{opacity:1}80%{opacity:1;padding-top:5px;height:22px}100%{opacity:0;padding-top:0;height:0}} @-webkit-keyframes nudge{0%{transform:translateX(0)}30%{transform:translateX(-5px)}50%{transform:translateX(5px)}70%{transform:translateX(-2px)}100%{transform:translateX(0)}} @-webkit-keyframes tonext{ 75%{left:0} 95%{left:100%} 98%{left:100%} 99%{left:0}} @-webkit-keyframes tostart{ 75%{left:0} 95%{left:-300%} 98%{left:-300%} 99%{left:0}} @-webkit-keyframes tonext-rev{ 75%{right:0} 95%{right:100%} 98%{right:100%} 99%{right:0}} @-webkit-keyframes tostart-rev{ 75%{right:0} 95%{right:-300%} 98%{right:-300%} 99%{right:0}} @-webkit-keyframes snap{ 96%{scroll-snap-align:center} 97%{scroll-snap-align:none} 99%{scroll-snap-align:none} 100%{scroll-snap-align:center}}

/* Noscript Option */ .lazy:not([lazied]){display:none} .noJs{display:flex;justify-content:flex-end;align-items:center;position:fixed;top:20px;left:20px;right:20px;z-index:99;max-width:640px;border-radius:12px;margin:auto;padding:10px 5px;background:#ffdfdf;font-size:13px;box-shadow:0 10px 20px -10px rgba(0,0,0,.1);color:#48525c} .noJs::before{content:attr(data-text);padding:0 10px;flex-grow:1} .noJs label{flex-shrink:0;padding:10px} .noJs label::after{content:'\2715';line-height:18px;font-size:14px} .nJs:checked ~ .noJs{display:none}

/* Hide Scroll */ .scrlH::-webkit-scrollbar{width:0;height:0} .scrlH::-webkit-scrollbar-track{background:transparent} .scrlH::-webkit-scrollbar-thumb{background:transparent;border:none}

/* --- Remove to reduce CSS size or if you aren't using RTL --- */

.adB{position:relative;display:flex;align-items:center;justify-content:center;min-height:100px;padding:15px;border:1px solid rgba(0,0,0,.05);border-radius:15px;color:#969896;font-size:10px;font-family:var(--fontB)} .adB:before{content:'Ads go here' !important}  .drK .adB{border-color:rgba(255,255,255,.1)} .drK .adB:after{background-color:rgba(255,255,255,.1)}

/* RTL Mode */ .Rtl #dateNow {text-align: left}.Rtl #dateNow{margin-left:0;margin-right:5px}.Rtl .pLbL {text-align: right;} .Rtl .pLbL > a{margin-right:0;margin-left:5px}.Rtl .ntfT{padding:0 0 0 15px} .Rtl .headL{padding:0 20px 0 0} .Rtl .headL .headN{padding:0 5px 0 0} .Rtl .BlogSearch .sb{left:auto;right:0} .Rtl .BlogSearch button.sb{left:0;right:auto} .Rtl .wPrf{right:auto;left:0;border-radius:5px 16px 16px 16px} .Rtl .toTopF{right:auto;left:18px} .Rtl .cmAc a::before{content:'\2935'} .Rtl .cmHl >li{padding:0 17.5px 0 0} .Rtl .cmHl >li >.cmAv{left:auto;right:0} .Rtl .cmHl >li >.cmIn{padding:12px 28px 12px 15px} .Rtl .mnMn li:not(.mr) ul{padding-left:0;padding-right:30px} .Rtl .tocL{right:auto;left:-280px} .Rtl .tocLi{border-radius:0 12px 12px 0} .Rtl .tocLi::before{left:auto;right:0} .Rtl .tocC{left:auto;right:-45px} .Rtl .tocC span{border-radius:0 20px 20px 0} .Rtl .tocL svg.rad{right:auto;left:-2px;transform:rotate(176deg)} .Rtl .tocL svg.rad.in{transform:rotate(-86deg)} .Rtl .tocI:checked ~ .tocL{right:auto;left:0} @media screen and (min-width:897px){.Rtl .blogCont::before{left:auto;right:0} .Rtl:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .Rtl:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .Rtl.hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .Rtl.hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{left:auto;right:35px;border-radius:16px 5px 16px 16px} .Rtl:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr):last-child ul, .Rtl.hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr):last-child ul{border-radius:16px 16px 5px 16px}} @media screen and (max-width:896px){.Rtl .headR{padding:0 0 0 20px} .Rtl .headL{padding:0 15px 0 0} .Rtl .blogMn{left:auto;right:0;margin-right:-100%} .Rtl .mnBr{right:2%;border-radius:20px 20px 20px 20px} .Rtl .navI:checked ~ .mainWrp .blogMn{margin-left:auto;margin-right:0}} @media screen and (max-width:500px){.Rtl .wPrf{right:0;border-radius:12px 12px 0 0}}

/* Basic Layout */ @media screen and (min-width:897px){.LS-2 header, .LS-2 .tocLi::before, .LS-3 header{border:0} .LS-2, .LS-2 .headCn, .LS-2 .mnBrs, .LS-3 .mnBrs, .LS-3 .headL{background:#fafafc} .LS-2 .blogCont::before{border:0;top:0;right:0;bottom:0;height:100%;z-index:-1;background:var(--contentB);border-radius:15px 0 0 0} .LS-3 .headCn{background:transparent} .LS-3 .headR{background:var(--headerB)} .LS-3 .blogCont::before{z-index:10} .LS-3 .blogMn{z-index:11} .LS-3 .tocL{top:var(--headerHi);z-index:10} .LS-3 .tocI:checked ~ .tocL{z-index:10} .LS-3:not(.hdMn) .navI:checked ~ .mainWrp .headN, .LS-3.hdMn .navI:not(:checked) ~ .mainWrp .headN{display:none} .LS-3:not(.hdMn) .navI:checked ~ .mainWrp .headL, .LS-3 .navI:not(:checked) ~ .mainWrp .headL{width:75px}}

/* --- End --- */

/*]]>*/</style>
  
  <style>/*<![CDATA[*/ /* Dark Mode */.drK.onIndx .blogPts >*, .drK .rPst, .drK .PopularPosts, .drK .pInf.ps, .drK .Label, .drK footer{background:var(--darkBa)} .drK .tDL .d2{display:block} .drK .tDL::after{content:attr(data-light)} .drK .tDL svg .f{stroke:none;fill:var(--darkT)}  .drK .pThmb:not(.nul)::before{background-image:linear-gradient(90deg, rgba(0,0,0,0) 0, rgba(0,0,0,.07) 20%, rgba(0,0,0,.1) 60%, rgba(0,0,0,0))} .drK input::placeholder, .drK .cpL input, .drK .cArea label .n{color:rgba(255,255,255,.25)} .drK .nArea .contact-form-error-message-with-border{color:#f94f4f} .drK .cmC i[rel=image]::before, .drK .widget input[type=text], .drK .widget input[type=email], .drK .widget textarea{background:var(--darkBs);border-color:rgba(255,255,255,.15)} .drK .erroC h3 span{color:rgba(255,255,255,.1)} .drK svg, .drK svg.c-1{fill:var(--darkT)} .drK svg.line{fill:none;stroke:var(--darkT)} .drK svg.c-2{fill:var(--darkTalt); opacity:.4} .drK, .drK .headCn, .drK .mnBrs{background:var(--darkB);color:var(--darkT)} .drK .ntfC, .drK .mobMn{background:var(--darkBa);color:var(--darkTa)} .drK header, .drK .mnMn >li.br::after, .drK .blogCont::before, .drK .tbHd, .drK .cmHl >li >.cmIn, .drK .pTag .pMart a, .drK .pRelate, .drK blockquote, .drK .cmC i[rel=quote], .drK blockquote.s-1, .drK details.sp, .drK .ps table:not(.tr-caption-container), .drK .ps table th, .drK .ps table:not(.tr-caption-container) tr:not(:last-child) td, .drK .pre.tb .preH, .drK details.ac, .drK .ancrA, .drK .ancrC{border-color:rgba(255,255,255,.15)} .drK .pre{background:var(--darkBs);color:var(--darkTa)} .drK footer{background:transparent;border-color:rgba(255,255,255,.15)} .drK .tIc::after, .drK .mnMn li:not(.mr) .a:hover, .drK .mnMn ul li >*:hover, .drK .wL.bg li >*, .drK .mobMn li >*:hover, .drK .shL a, .drK .cpLb{background:rgba(0,0,0,.15)} .drK .wPrf{background:var(--darkBa);box-shadow:0 10px 40px rgba(0,0,0,.2)} .drK h1, .drK h2, .drK h3, .drK h4, .drK h5, .drK h6, .drK footer, .drK .button{color:var(--darkT)} .drK .admPs, .drK .dlBox, .drK .fixLs, .drK .cArea input:focus ~ .n, .drK .cArea textarea:focus ~ .n, .drK .cArea input[data-text=fl] ~ .n, .drK .cArea textarea[data-text=fl] ~ .n{background:var(--darkBa)} .drK .tocLi{background:var(--darkB)} .drK .tocC span, .drK .pShc >*:not(.c), .drK .ancrA, .drK .BlogSearch input{background:var(--darkBa)} .drK .tocL svg.rad{fill:var(--darkBa)} .drK .mobMn li >*:hover svg.line{fill:var(--darkT) !important} .drK.mobS .mobMn li >*:hover, .drK .button.ln{background:transparent} .drK .pTag .pPric::before, .drK .pTag .pInfo small{color:var(--darkTa)} .drK::selection, .drK a, .drK .free::after, .drK .new::after, .drK .mnMn li:not(.mr) .a:hover, .drK .mnMn ul li a:hover, .drK .aTtl a:hover, .drK .pSnpt.nTag, .drK .pTag .pPric, .drK details.ac[open] summary, .drK .cpL label, .drK .wL li >*:hover .lbC, .drK .wL li >div .lbC, .drK .wL .lbM, .drK .cmBtn.ln:hover, .drK .wL.cl .lbN:hover .lbC, .drK .wL.cl div.lbN .lbC{color:var(--darkU)} .drK .mnMn .a:hover svg:not(.d){fill:var(--darkU)} .drK .mnMn .a:hover svg.line:not(.d), .drK .pJmp svg{fill:none;stroke:var(--darkU)} .drK .wL li >*:hover svg, .drK .wL li >div svg{fill:var(--darkU) !important;stroke:var(--darkU)} .drK.MN-3 .mobMn li >*:hover::after, .drK .toTopF, .drK .blogPg >*, .drK .button, .drK .zmImg::after, .drK .widget input[type=button], .drK .widget input[type=submit]{background:var(--darkU)} .drK.MN-3 .mobMn li >*:hover svg.line{stroke:var(--darkU);fill:var(--darkU) !important} .drK.MN-3 .mobMn li >*:hover svg .f{fill:var(--darkU)} .drK .pS input[id*="1"]:checked ~ .tbHd label[for*="1"], .drK .pS input[id*="2"]:checked ~ .tbHd label[for*="2"], .drK .pS input[id*="3"]:checked ~ .tbHd label[for*="3"], .drK .pS input[id*="4"]:checked ~ .tbHd label[for*="4"], .drK .widget input[type=text]:focus, .drK .widget input[type=email]:focus, .drK .widget textarea:focus, .drK .widget input[data-text=fl], .drK .widget textarea[data-text=fl], .drK .wL.cl .lbN:not(div):hover, .drK .wL.cl div.lbN{border-color:var(--darkU)} .drK .button.ln:hover{border-color:var(--darkU);box-shadow:0 0 0 1px var(--darkU) inset} .drK header a, .drK .mnBr a, .drK .pLbls >*, .drK .aTtl a, .drK .blogPg >*, .drK .brdCmb a, .drK .wL li >*, .drK .mobMn li >*, .drK .cmAc a{color:inherit} .drK .blogPg .nPst, .drK .blogPg .current{background:var(--contentL);color:var(--bodyCa)} @media screen and (min-width:897px){.drK header .BlogSearch input{background:var(--darkBs)} .drK header .BlogSearch input:focus, .drK header .BlogSearch input:hover{background:var(--darkBs)} .drK.bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn .n, .drK.bD:not(.hdMn) .navI:checked ~ .mainWrp .mnMn li:not(.mr) ul, .drK.hdMn .navI:not(:checked) ~ .mainWrp .mnMn .n, .drK.hdMn .navI:not(:checked) ~ .mainWrp .mnMn li:not(.mr) ul{background:var(--darkBa);box-shadow:0 10px 40px rgba(0,0,0,.2);color:var(--darkTa)} .drK.LS-2 .blogCont::before{background:var(--darkBs)} .drK.LS-3 .headCn{background:transparent} .drK.LS-3 .headL, .drK.LS-3 .mnBrs{background:var(--darkBs)} .drK.LS-3 .headR{background:var(--darkB)} .drK .tocLi::before{border-color:rgba(255,255,255,.15)}} @media screen and (max-width:500px){.drK .itemFt .itm .iCtnt{background:var(--darkBa)}} .drK footer{background:var(--darkBa)} .drK .headCn{background:var(--darkBa)}
/*]]>*/</style>
  
  <b:if cond='data:view.isSingleItem'>
    <style>/*<![CDATA[*/ /* Related Posts */ .rPst{padding:20px 20px 30px;background:var(--contentB);box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:10px; margin:40px 0 0} .rPst ul{display:flex;flex-wrap:wrap; position:relative;width:calc(100% + 20px);left:-10px;right:-10px; list-style:none;margin:0;padding:0; counter-reset:p-cnt} .rPst ul li{width:calc(50% - 20px);margin:0 10px 30px;position:relative} .rPst ul.s-2 li, .rPst ul.s-3 li, .rPst ul.s-4 li{width:calc(33.3% - 20px)} .rPst .iF{display:flex;flex-direction:row-reverse;align-items:flex-start;position:relative;width:calc(100% + 15px);left:-7.5px;right:-7.5px} .rPst .iF >*{margin:0 7.5px} .rPst .iF .pThmb{flex:0 0 72px} .rPst .iF .pThmb .thmb{padding-top:100%} .rPst .iF .pCtnt{display:flex;flex-grow:1;width:calc(100% - 102px)} .rPst .iF .pCtnt::before{flex-shrink:0;content:'0' counter(p-cnt);counter-increment:p-cnt;width:25px;opacity:.6;font-size:85%;line-height:1.8em} .rPst .iF .pInf{position:relative;margin-top:8px} .rPst .iF .pInr{flex:1 0;width:calc(100% - 25px)} .rPst .iF .pSnpt{font-size:93%;margin-top:8px} .pTag + .pFoot .rPst .pSnpt{display:none} .rPst .thmb::before{content:'No image';display:block;position:absolute;top:50%;left:50%;max-width:none;max-height:100%;-webkit-transform:translate(-50%, -50%);transform:translate(-50%, -50%); font-size:12px; opacity:.7;white-space:nowrap} .rPst .thmb div{background-position:center;background-size:cover;background-repeat:no-repeat; position:absolute;top:0;left:0;bottom:0;right:0} .rPst .pSnpt{} .rPst .pInf{position:absolute;bottom:0;left:0;right:0} .rPst .pInf::before{content:attr(data-date);opacity:.8} .rPst .s-4 li{padding-bottom:30px} @media screen and (max-width:640px){.rPst ul:not(.s-2) li, .rPst ul:not(.s-3) li, .rPst ul:not(.s-4) li{width:calc(100% - 20px)} .rPst .iF{max-width:500px;margin-left:auto;margin-right:auto} .rPst ul.s-2 li, .rPst ul.s-3 li, .rPst ul.s-4 li{width:calc(50% - 20px)} .rPst .iTtl{font-size:14px}} @media screen and (max-width:500px){.rPst ul{width:calc(100% + 15px);left:-7.5px;right:-7.5px} .rPst ul li{width:calc(50% - 15px);margin:0 7.5px 30px} .rPst ul:not(.s-2) li, .rPst ul:not(.s-3) li, .rPst ul:not(.s-4) li{width:calc(100% - 15px)} .rPst ul.s-2 li{width:calc(50% - 15px)} .rPst ul.s-3 li{width:100%;margin:0 0 20px} .rPst ul.s-3 .i{display:flex;align-items:center} .rPst ul.s-3 .i >*{flex:0 0 calc(40% + 15px);margin:0 7.5px} .rPst ul.s-3 .iTtl{flex-grow:1} .rPst ul.s-3 .iTtl a::after{content:attr(data-text);display:block;margin-top:8px;font-weight:400;font-size:12px;opacity:.7} .rPst ul.s-4{flex-wrap:nowrap;width:calc(100% + 40px);left:-20px;right:-20px;padding:0 12.5px; overflow-y:hidden;overflow-x:scroll;scroll-behavior:smooth;scroll-snap-type:x mandatory; -ms-overflow-style:none;-webkit-overflow-scrolling:touch} .rPst ul.s-4 li{flex-shrink:0;width:80%;margin-bottom:0;scroll-snap-align:center} .rPst ul.s-4 .iTtl{font-size:14px}}

/*]]>*/</style>
  </b:if>

  <b:defaultmarkups>
    <!--[ Blogger defaultmarkups ]-->
    <b:defaultmarkup type='Common'>
      
      <!--[ In-feed ad ]-->
      <b:includable id='post-adIn'>
        <div class='ntry pAdin'>
          <!--[ InFeed Ad ]-->
          
          <!--<ins class='adsbygoogle'/>
          <script>...</script>-->
          
        </div>
      </b:includable>
      
      <!--[ Top article ad ]-->
      <b:includable id='post-adTop'>
        <div class='pAd'>
          <!--[ Top article Ad ]-->
          
          <!--<ins class='adsbygoogle'/>
          <script>...</script>-->
          
        </div>
      </b:includable>
      
      <!--[ Bottom article ad ]-->
      <b:includable id='post-adBot'>
        <div class='pAd'>
          <!--[ Bottom article Ad ]-->
          
          <!--<ins class='adsbygoogle'/>
          <script>...</script>-->
          
        </div>
      </b:includable>
      
      <!--[ Matched content Ad ]-->
      <b:includable id='post-relatedAd'>
        <div class='relatedPosts'>
          <!--[ Matched content Ad ]-->
          
          <!--<ins class='adsbygoogle'/>
          <script>...</script>-->
          
        </div>
      </b:includable>
      
      <!--[ Index title ]-->
      <b:includable id='titlePost'>
        <div class='blogTtl'>
          <b:class cond='data:view.isHomepage' name='hm'/>
          <b:if cond='data:view.isHomepage'>
            
            <!--[ Change <data:messages.latestPosts/> to replace 'Latest Posts' with your special text ]-->
            <h3 class='title'><data:messages.latestPosts/></h3>

            <b:else/>
            <div class='t'>
              <b:class cond='data:view.search or data:view.isArchive and data:view.url != data:blog.homepageUrl.canonical path &quot;search&quot;' name='srch'/>
              <b:if cond='data:view.search.label'>
                <span class='hm' expr:data-text='data:messages.home'/><data:blog.pageName/>
                
                <b:elseif cond='data:view.search.query'/>
                <span expr:data-text='data:messages.search + &quot;:&quot;'/><data:view.search.query/>
                
                <b:elseif cond='data:view.isArchive'/>
                <span expr:data-text='data:messages.blogArchive + &quot;:&quot;'/><data:blog.pageName/>
                
                <b:else/>

                <!--[ Change all <data:messages.posts/> to replace 'Posts' with your special text ]-->
                <span class='hm' expr:data-text='data:messages.home'/><data:messages.posts/>
             
              </b:if>
            </div>
          </b:if>
        </div>
      </b:includable>
      
      <!--[ Theme Customisation ]-->
      <b:includable id='theme-custom'>
        <input class='cusI visibal' id='forCusThm' type='checkbox'/>
        <div class='cusW'>
          <div class='cusH'>
            <span class='cusHi' data-text='Theme Color'/>
            <label class='cusCl' for='forCusThm'/>
          </div>
          <div class='cusP'>
            <!--[ Replace color hex code with custom color hex code ]-->
            <span class='tPkr thB0' onclick='webTheme(&quot;theme0&quot;);modeL()' style='--pkrC:#eceff1'/><span class='tPkr thB1' onclick='webTheme(&quot;theme1&quot;);modeL()' style='--pkrC:#F44336'/><span class='tPkr thB2' onclick='webTheme(&quot;theme2&quot;);modeL()' style='--pkrC:#00BFA5'/><span class='tPkr thB3' onclick='webTheme(&quot;theme3&quot;);modeL()' style='--pkrC:#2196F3'/><span class='tPkr thB4' onclick='webTheme(&quot;theme4&quot;);modeL()' style='--pkrC:#FBC02D'/><span class='tPkr thB5' onclick='webTheme(&quot;theme5&quot;);modeL()' style='--pkrC:#E91E63'/><span class='tPkr thB6' onclick='webTheme(&quot;theme6&quot;);modeL()' style='--pkrC:#FF5722'/><span class='tPkr thB7' onclick='webTheme(&quot;theme7&quot;);modeL()' style='--pkrC:#607D8B'/><span class='tPkr thB8' onclick='webTheme(&quot;theme8&quot;);modeL()' style='--pkrC:#5D4037'/><span class='tPkr thB9' onclick='webTheme(&quot;theme9&quot;);modeL()' style='--pkrC:#744D97'/><span class='tPkr thB10' onclick='webTheme(&quot;theme10&quot;);modeL()' style='--pkrC:#3949AB'/>
          </div>
        </div>
        <label class='fCls' for='forCusThm'/>
      </b:includable>
      
      <!--[ Related post ]-->
      <b:includable id='post-related'>
        <div class='rPst' id='rPst'>
          <script>
              var labelArray = [<b:if cond='data:post.labels'><b:loop values='data:post.labels' var='label'>&quot;<data:label.name/>&quot;<b:if cond='data:label.isLast != &quot;true&quot;'>,</b:if></b:loop></b:if>];
              var relatedPostConfig = {
                homePage: &quot;<data:blog.homepageUrl.canonical/>&quot;,
            
                // Replace <data:messages.youMayLikeThesePosts/> to change Related Posts title
                widgetTitle: &quot;<h2 class='title'><b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])'><data:messages.youMayLikeThesePosts/><b:else/>Related products!</b:if></h2>&quot;,
            
                numPosts: 6,
                summaryLength: 180,
                titleLength:&quot;auto&quot;,
                thumbnailSize: 300,
                noImage: &quot;data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=&quot;,
                containerId: &quot;rPst&quot;,
                newTabLink: false,
                moreText: &quot;Read more&quot;,
            
                // Change the related post style, there are 4 styles available
                widgetStyle: 2,
            
                callBack:function(){}
              }
          </script>
          <script>/*<![CDATA[*/ /*! Related Posts by Taufik Nurrohman dte.web.id */ var randomRelatedIndex,showRelatedPost;(function(n,m,k){var d={widgetTitle:"<h3 class='title'>Related Posts</h3>",widgetStyle:1,homePage:"http://www.shivatechnicworld.eu.org",numPosts:7,summaryLength:320,titleLength:"auto",thumbnailSize:200,noImage:"data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=",containerId:"related-posts",newTabLink:false,moreText:"Read more",callBack:function(){}}; for(var f in relatedPostConfig){d[f]=(relatedPostConfig[f]=="undefined")?d[f]:relatedPostConfig[f]}var j=function(a){var b=m.createElement("script");b.async="async";b.rel="preload";b.src=a;k.appendChild(b)},o=function(b,a){return Math.floor(Math.random()*(a-b+1))+b},l=function(a){var p=a.length,c,b;if(p===0){return false}while(--p){c=Math.floor(Math.random()*(p+1));b=a[p];a[p]=a[c];a[c]=b}return a},e=(typeof labelArray=="object"&&labelArray.length>0)?"/-/"+l(labelArray)[0]:"",h=function(b){var c=b.feed.openSearch$totalResults.$t-d.numPosts,a=o(1,(c>0?c:1));j(d.homePage.replace(/\/$/,"")+"/feeds/posts/summary"+e+"?alt=json-in-script&orderby=updated&start-index="+a+"&max-results="+d.numPosts+"&callback=showRelatedPost")},g=function(z){var s=document.getElementById(d.containerId),x=l(z.feed.entry),A=d.widgetStyle,c=d.widgetTitle+'<ul class="s-'+A+' scrlH">',b=d.newTabLink?' target="_blank"':"",y=d.moreText,v,t,w,r,u;if(!s){return}for(var q=0;q<d.numPosts;q++){if(q==x.length){break}t=x[q].title.$t;w=(d.titleLength!=="auto"&&d.titleLength<t.length)?t.substring(0,d.titleLength)+"&hellip;":t; r=("media$thumbnail"in x[q]&&d.thumbnailSize!==false)?x[q].media$thumbnail.url.replace(/.*?:\/\//g , "//").replace(/\/s[0-9]+(\-c)?/, "/s"+d.thumbnailSize).replace(/\=s[0-9]+(\-c)?/, "=s"+d.thumbnailSize):d.noImage; month=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];date=x[q].published.$t.substring(0,10); Y=date.substring(0, 4); m=date.substring(5, 7); D=date.substring(9, 10); M=month[parseInt(m-1)]; u=("summary"in x[q]&&d.summaryLength>0)?x[q].summary.$t.replace(/<br ?\/?>/g," ").replace(/<.*?>/g,"").replace(/[<>]/g,"").substring(0,d.summaryLength)+"&hellip;":"";for(var p=0,a=x[q].link.length;p<a;p++){v=(x[q].link[p].rel=="alternate")?x[q].link[p].href:"#"} if(A==2){c+='<li><div class="i"><div class="pThmb"><a class="thmb" aria-label="'+w+'" href="'+v+'" title="'+t+'"><div class="lazy" data-style="background-image: url('+r+')"></div></a></div><div class="iTtl aTtl"><a href="'+v+'" '+b+'>'+w+'</a></div></div></li>'} else{if(A==3){c+='<li><div class="i"><div class="pThmb"><a class="thmb" aria-label="'+w+'" href="'+v+'" title="'+t+'"><div class="lazy" data-style="background-image: url('+r+')"></div></a></div><div class="iTtl aTtl"><a href="'+v+'" '+b+' data-date="'+M+' '+D+', '+Y+'" data-text="'+y+'">'+w+'</a></div></div></li>'} else{if(A==4){c+='<li><div class="i"><div class="pThmb"><a class="thmb" aria-label="'+w+'" href="'+v+'" title="'+t+'"><div class="lazy" data-style="background-image: url('+r+')"></div></a></div><div class="iTtl aTtl"><a href="'+v+'" '+b+'>'+w+'</a></div><div class="pSnpt">'+u+'</div><div class="pInf pSml" data-date="'+M+' '+D+', '+Y+'"></div></div></li>'} else{c+='<li><div class="iF"><div class="pThmb"><a class="thmb" aria-label="'+w+'" href="'+v+'" title="'+t+'"><div class="lazy" data-style="background-image: url('+r+')"></div></a></div><div class="pCtnt"><div class="pInr"><div class="iTtl aTtl"><a href="'+v+'" '+b+'>'+w+'</a></div><div class="pSnpt">'+u+'</div><div class="pInf pSml" data-date="'+M+' '+D+', '+Y+'"></div></div></div></div></li>'} }}}s.innerHTML=c+="</ul>";d.callBack()};randomRelatedIndex=h;showRelatedPost=g;j(d.homePage.replace(/\/$/,"")+"/feeds/posts/summary"+e+"?alt=json-in-script&orderby=updated&max-results=0&callback=randomRelatedIndex")})(window,document,document.getElementsByTagName("head")[0]); /*]]>*/</script>
        </div>
      </b:includable>
      
      <!--[ In-Post Quick Edit ]-->
      <b:includable id='quick-edit'>
        <div class='blog-admin qEdit' id='qEdit'><input class='qeMn hidden' id='offqeMn' type='checkbox'/><label class='qeBtn' for='offqeMn'><b:include name='settings-icon'/><b:include name='close-icon'/></label><div class='qeBtns'><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/blog/settings/&quot; + data:blog.blogId' rel='nofollow noopener noreferrer' target='_blank' title='Settings'><b:include name='settings-icon'/></a><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/blog/comments/&quot; + data:blog.blogId' rel='nofollow noopener noreferrer' target='_blank' title='Comments'><b:include name='comments-icon'/></a><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/feeds/&quot; + data:blog.blogId + &quot;/archive&quot;' rel='nofollow noopener noreferrer' title='Backup content'><b:include name='download-alt-icon'/></a><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/blog/stats/week/&quot; + data:blog.blogId' rel='nofollow noopener noreferrer' target='_blank' title='7-days blog stats'><b:include name='stats-icon'/></a><b:if cond='data:view.isPost'><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/blog/posts/&quot; + data:blog.blogId' rel='nofollow noopener noreferrer' target='_blank' title='Dashboard'><b:include name='list-icon'/></a><b:else/><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/blog/pages/&quot; + data:blog.blogId' rel='nofollow noopener noreferrer' target='_blank' title='Dashboard'><b:include name='list-icon'/></a></b:if><b:if cond='data:view.isPost'><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/blog/post/edit/&quot; + data:blog.blogId + &quot;/&quot; + data:post.id' rel='nofollow noopener noreferrer' target='_blank' title='Edit post'><b:include name='edit-icon'/></a><b:else/><a class='qeBtn a' expr:href='&quot;https://www.blogger.com/blog/page/edit/&quot; + data:blog.blogId + &quot;/&quot; + data:post.id' rel='nofollow noopener noreferrer' target='_blank' title='Edit page'><b:include name='edit-icon'/></a></b:if></div><label class='fCls' for='offqeMn'/></div>
      </b:includable>
      
      <!--[ Quick Edit on Thumbnails ]-->
      <b:includable id='thmb-quickedit'>
        <div class='blog-admin'>
          <div class='iFxd l'>
            <a aria-label='Edit this post' class='edit' data-text='Edit' expr:href='&quot;https://www.blogger.com/blog/post/edit/&quot; + data:blog.blogId + &quot;/&quot; + data:post.id' role='button' target='_blank'><b:include name='edit-alt-icon'/></a>
          </div>
        </div>
      </b:includable>
      
      <!--[ Cookies Consent ]-->
      <b:includable id='cookies-consent'>
        <div class='ckWrap hide' id='ckBox'>
          <div class='ckCont'>
            <h2>Cookies Consent</h2>
            <p>This website uses cookies to ensure you get the best experience on our website.</p>
          </div>
          <button class='button highH' id='ckAcptBtn'>Accept Cookies!</button>
          <label class='button ln highH' for='offchangeLog99'>Learn More</label>  
        </div>
        <input class='logInput hidden' id='offchangeLog99' type='checkbox'/>
        <div class='changeLog'>
          <label class='logClose' for='offchangeLog99'>
            <b:include name='close-icon'/>
          </label>
          <div class='logContent'>
            <data:content/>
          </div>
        </div>   
      </b:includable>
      
      <b:includable id='main'>
                 <!--[ Anti Ad-Blocker by Fineshop ]-->
<div class='popSc hidden' id='antiAdBlock'>
  <div class='popBo'>
    <svg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><circle cx='12' cy='12' r='10'/><line x1='12' x2='12' y1='8' y2='12'/><line x1='12' x2='12.01' y1='16' y2='16'/></svg>
    <h2>Ad-Blocker Detected!</h2>
    <p>Sorry, we detected that you have activated Ad-Blocker.<br/>Please consider supporting us by disabling your Ad-Blocker, it helps us in developing this Website.<br/>Thank you!</p>
  </div>
</div>
    
    <script>/*<![CDATA[*/ /* Anti Ad-Blocker Script by Fineshop (Lazyload) */ var lazyAnti=!1;window.addEventListener("scroll",function(){(0!=document.documentElement.scrollTop&&!1===lazyAnti||0!=document.body.scrollTop&&!1===lazyAnti)&&(!function(){var antiAdBlock=document.querySelector("#antiAdBlock");var e=document.createElement("script");e.type="text/javascript",e.async=!0,e.src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";e.onerror=function(){if(antiAdBlock!=null){antiAdBlock.classList.remove("hidden");window.lazyAnti=!0}};var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(e,a)}(),lazyAnti=!0)},!0); /*]]>*/</script>
    
              </b:includable>
      
      <!--[ Post authors ]-->
      <b:includable id='post-authorProfile'>
        <div class='admPs'>
          <div class='admIm'>
            <b:include name='post-authorImage'/>
          </div>
          <div class='admI'>
            <bdi class='admN' expr:data-text='data:post.author.name' expr:data-write='data:messages.postedBy'/>
            <div class='admA'>
              <b:eval expr='data:post.author.aboutMe snippet {length: 200, links: true, linebreaks: true}'/>
              <!--<data:post.author.aboutMe/>-->
            </div>
          </div>
        </div>
      </b:includable>
      
      <b:includable id='post-authorImage'>
        <b:if cond='data:post.author.authorPhoto.image'>
          <b:if cond='!data:view.isPost'>
            <div class='im' expr:data-style='&quot;background-image: url(&quot; + resizeImage(data:post.author.authorPhoto.image,20,&quot;1:1&quot;) + &quot;)&quot;'>
              <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
              <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + resizeImage(data:post.author.authorPhoto.image,20,&quot;1:1&quot;) + &quot;)&quot;' name='style'/>
            </div>
            <noscript><div class='im' expr:style='&quot;background-image: url(&quot; + resizeImage(data:post.author.authorPhoto.image,20,&quot;1:1&quot;) + &quot;)&quot;'/></noscript>
            <b:else/>
            <div class='im lazy' expr:data-style='&quot;background-image: url(&quot; + resizeImage(data:post.author.authorPhoto.image,40,&quot;1:1&quot;) + &quot;)&quot;'>
              <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
              <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + resizeImage(data:post.author.authorPhoto.image,20,&quot;1:1&quot;) + &quot;)&quot;' name='style'/>
            </div>
            <noscript><div class='im' expr:style='&quot;background-image: url(&quot; + resizeImage(data:post.author.authorPhoto.image,40,&quot;1:1&quot;) + &quot;)&quot;'/></noscript>
          </b:if>
          <b:elseif cond='!data:view.isMultipleItems'/>
          <div class='im'><b:include name='profile-icon'/></div>
        </b:if>
      </b:includable>
      
      <b:includable id='post-authorName'>
        <bdi class='nm' expr:data-text='data:post.author.name' expr:data-write='data:widgets.Blog.first.allBylineItems.author.label'/>
        
        <!--[ Post Author with Link ]-->
        <!--<b:tag class='nm' expr:data-text='data:post.author.name' expr:data-write='data:widgets.Blog.first.allBylineItems.author.label' expr:name='data:post.author.profileUrl ? &quot;a&quot; : &quot;span&quot;'>
          <b:attr cond='data:post.author.profileUrl' expr:value='data:post.author.name' name='aria-label'/>
          <b:attr cond='data:post.author.profileUrl' expr:value='data:post.author.profileUrl' name='href'/>
          <b:attr cond='data:post.author.profileUrl' value='author noreferrer' name='rel'/>
          <b:attr cond='data:post.author.profileUrl' value='_blank' name='target'/>
        </b:tag>-->
      </b:includable>
      
      <!--[ Post article ]-->
      <b:includable id='postHeaders'>
        <div class='pHdr pSml'>
          <b:include name='postLabelorSponsor'/>
        </div>
      </b:includable>
      
      <b:includable id='postCommentsLinks'>
        <b:if cond='data:post.allowComments and data:post.numberOfComments &gt; 0'>
          <a class='cmnt' expr:aria-label='data:messages.comments' expr:data-text='data:post.numberOfComments' expr:href='data:post.url.canonical fragment &quot;comment&quot;' role='button'>
            <b:include name='chat-icon'/>
          </a>
        </b:if>
      </b:includable>
      
      <b:includable id='postCommentsUrl'>
        <b:if cond='data:post.allowComments and data:post.numberOfComments &gt; 0'>
          <a class='cmnt' expr:aria-label='data:messages.comments' expr:data-text='data:post.numberOfComments' expr:href='data:post.url.canonical fragment &quot;comment&quot;' role='button'>
            <b:class cond='data:view.isSingleItem' name='tIc'/>
            <b:include name='chat-icon'/>
          </a>
        </b:if>
      </b:includable>
      
      <b:includable id='postCommentsLabel'>
        <b:if cond='data:post.allowComments and data:post.numberOfComments &gt; 0'>
          <label class='cmnt' expr:data-text='data:post.numberOfComments' for='forComments'>
            <b:class cond='data:view.isSingleItem' name='tIc'/>
            <b:include name='chat-icon'/>
          </label>
        </b:if>
      </b:includable>
      
      <b:includable id='postSponsored'>
        <div class='spnr'>
          <b:include name='link-icon'/>
        </div>
      </b:includable>
      
      <b:includable id='postProduct'>
        <div class='spnr'>
          <b:include name='tag-icon'/>
        </div>
      </b:includable>
      
      <b:includable id='postLabelSponsored'>
        <div class='pLbls nSpr'>
          <b:loop index='s' values='data:post.labels' var='label'>
            <b:if cond='data:s == 0'>
              <b:tag expr:data-text='data:label.name' name='span'/>
            </b:if>
          </b:loop>
        </div>
      </b:includable>
      
      <b:includable id='postLabel'>
        <b:if cond='data:widgets.Blog.first.allBylineItems.labels'>
          <div class='pLbls'>
            <b:attr cond='data:post.labels' expr:value='data:widgets.Blog.first.allBylineItems.labels.label' name='data-text'/>
            <b:loop index='i' values='data:post.labels' var='label'>
              <b:if cond='data:i &lt;= 1'>
                <b:tag expr:data-text='data:label.name' expr:name='data:blog.url != data:label.url ? &quot;a&quot; : &quot;span&quot;'>
                  <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.url.canonical' name='href'/>
                  <b:attr cond='data:blog.url != data:label.url' name='rel' value='tag'/>
                  <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.name' name='aria-label'/>
                </b:tag>
              </b:if>
            </b:loop>
          </div>
        </b:if>
      </b:includable>
      
      <b:includable id='postLabelorSponsor'>
        <b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
          <!--[ Post labels ]-->
          <b:include cond='data:post.labels' name='postLabel'/>
          <b:else/>
          <b:include name='postLabelSponsored'/>
        </b:if>
      </b:includable>
      
      <b:includable id='postJumpLinks'>
        <a class='pJmp' expr:aria-label='data:blog.jumpLinkMessage' expr:data-text='data:messages.keepReading' expr:href='data:post.url.canonical'/>
      </b:includable>
      
      <b:includable id='postTimestampPublish'>
        <time class='aTtmp pTtmp pbl' expr:data-text='format(data:post.date, &quot;MMM d, YYYY&quot;)' expr:datetime='data:post.date.iso8601' expr:title='&quot;Published: &quot; + data:post.date format &quot;MMMM d, YYYY&quot;'/>
      </b:includable>
      
      <b:includable id='postTimestamps'>
        <b:if cond='data:post.lastUpdated != data:post.date'>
          <time class='aTtmp pTtmp upd' data-date='Updated:' expr:data-text='format(data:post.lastUpdated, &quot;MMMM d, YYYY&quot;)' expr:data-time='format(data:post.lastUpdated, &quot;MMM d, YYYY&quot;)' expr:datetime='data:post.lastUpdated.iso8601' expr:title='&quot;Last updated: &quot; + data:post.lastUpdated format &quot;MMMM d, YYYY&quot;'/>
          <b:else/>
          <time class='aTtmp pTtmp pbl' expr:data-text='format(data:post.date, &quot;MMMM d, YYYY&quot;)' expr:data-time='format(data:post.lastUpdated, &quot;MMM d, YYYY&quot;)' expr:datetime='data:post.date.iso8601' expr:title='&quot;Published: &quot; + data:post.date format &quot;MMMM d, YYYY&quot;'/>
        </b:if>
      </b:includable>
      
      <b:includable id='postEntrySnippet'>
        <b:eval expr='snippet(data:post.snippets.long, {length: 150, links: false, linebreaks: false})'/>
        <!--<b:eval expr='snippet(data:post.body, {length: 90, links: false, linebreaks: false})'/>-->
      </b:includable>
      
      <b:includable id='postEntryThumbnail'>
        <b:if cond='data:post.featuredImage.isYoutube'>
          <img class='imgThm lazy' expr:alt='data:post.title ? data:post.title : data:messages.image' expr:data-src='data:post.featuredImage.youtubeMaxResDefaultUrl.isResizable ? resizeImage(data:post.featuredImage.youtubeMaxResDefaultUrl, 600, &quot;18:9&quot;) : data:post.featuredImage.youtubeMaxResDefaultUrl' src='data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs='/>
          <noscript><img class='imgThm' expr:alt='data:post.title ? data:post.title : data:messages.image' expr:src='data:post.featuredImage.youtubeMaxResDefaultUrl.isResizable ? resizeImage(data:post.featuredImage.youtubeMaxResDefaultUrl, 600, &quot;18:9&quot;) : data:post.featuredImage.youtubeMaxResDefaultUrl'/></noscript>
          <b:else/>          
          <img class='imgThm lazy' expr:alt='data:post.title ? data:post.title : data:messages.image' expr:data-src='data:post.featuredImage.isResizable ? resizeImage(data:post.featuredImage, 600, &quot;18:9&quot;) : data:post.featuredImage' src='data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs='/>
          <noscript><img class='imgThm' expr:alt='data:post.title ? data:post.title : data:messages.image' expr:src='data:post.featuredImage.isResizable ? resizeImage(data:post.featuredImage, 600, &quot;18:9&quot;) : data:post.featuredImage'/></noscript>
        </b:if>
      </b:includable>
      
      <!--[ Comment button ]-->
      <b:includable id='post-commentButton'>
        <!--[ Show/hide Comment ]-->
        <div class='cmShw'>
          <label class='cmBtn button' for='forComments'>
            <!--[ Delete tag bellow to change button style ]-->
            <b:class name='ln'/>
          
            <b:if cond='data:post.numberOfComments &gt; 0'>
              <span><data:messages.joinTheConversation/> (<data:post.numberOfComments/>)</span>
              <b:else/>
              <data:messages.postAComment/>
            </b:if>
          </label>
        </div>
      </b:includable>
      
      <!--[ Comment disqus ]-->
      <b:includable id='post-commentDisqus'>
        <div class='cmDisqus' id='disqus_thread'>
          <div class='cmBtn button' id='disqusshow' onclick='load_Comments()'>
            <!--[ Delete tag bellow to change button style ]-->
            <b:class name='ln'/>
            
            <span><data:messages.joinTheConversation/></span>
          </div>
        </div>
        <script>/*<![CDATA[*/ var disqus_shortname = "shiva-technic-world"; !function(){var e=document.createElement("script");e.defer=!0,e.src="//"+disqus_shortname+".disqus.com/blogger_item.js",(document.getElementsByTagName("head")[0]||document.getElementsByTagName("body")[0]).appendChild(e)}(); function load_Comments(){var e=document.getElementById("disqusshow");e.style.display="none";var t="shiva-technic-world";!function(){var e=document.createElement("script");e.defer=!0,e.src="https://"+t+".disqus.com/embed.js",(document.getElementsByTagName("head")[0]||document.getElementsByTagName("body")[0]).appendChild(e)}()}; var uri = window.location.toString(); if (uri.indexOf("?m=1","?m=1") > 0) {var clean_uri = uri.substring(0, uri.indexOf("?m=1"));window.history.replaceState({}, document.title, clean_uri); }; /*]]>*/</script>
      </b:includable>
      
      <!--[ Comment disqus on-scroll ]-->
      <b:includable id='post-commentDisqusScroll'>
        <div class='cmDisqus' id='disqus_thread'>
          <div id='disqus_empty'/>
        </div>
        
        <!--[ Disqus script by bungfrangki.com, change 'shiva-technic-world' with your disqus_shortname ]-->
        <script>var disqus_blogger_current_url = &quot;<data:blog.canonicalUrl/>&quot;; if (!disqus_blogger_current_url.length) {disqus_blogger_current_url = &quot;<data:blog.url/>&quot;;} var disqus_blogger_homepage_url = &quot;<data:blog.canonicalHomepageUrl/>&quot;; var disqus_blogger_canonical_homepage_url = &quot;<data:blog.canonicalHomepageUrl/>&quot;;</script>
        <script>/*<![CDATA[*/ function load_disqus( disqus_shortname ) {var y = document.getElementById('disqus_empty'), t = document.getElementById('disqus_thread'), e = document.createElement('script'), d = document.createElement('script'), h = (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]); if( t && y ) {e.async = true; e.src = '//' + disqus_shortname + '.disqus.com/embed.js'; h.appendChild(e); d.async = !0; d.src = '//' + disqus_shortname + '.disqus.com/blogger_item.js'; h.appendChild(d); y.remove(); } }; window.addEventListener('scroll', function(e) {var currentScroll = document.scrollingElement.scrollTop; var t = document.getElementById('disqus_thread'); if( t && (currentScroll > t.getBoundingClientRect().top - 150) ) {load_disqus('shiva-technic-world'); console.log('Disqus loaded.'); }}, false); var uri = window.location.toString(); if (uri.indexOf("?m=1","?m=1") > 0) {var clean_uri = uri.substring(0, uri.indexOf("?m=1"));window.history.replaceState({}, document.title, clean_uri); }; /*]]>*/</script>
      </b:includable>
      
      <!--[ Comment FB ]-->
      <b:includable id='post-commentFB'>        
        <div id='fb-root'/>
        <script src='http://connect.facebook.net/en_US/all.js#xfbml=1' type='deferjs'/>
        <div id='commentFB'><fb:comments expr:href='data:post.url' num_posts='10' width='650'/></div>
        <script>/*<![CDATA[*/ var uri = window.location.toString(); if (uri.indexOf("?m=1","?m=1") > 0) {var clean_uri = uri.substring(0, uri.indexOf("?m=1"));window.history.replaceState({}, document.title, clean_uri); }; /*]]>*/</script>
      </b:includable>
      
      <!--[ Loadmore pagination ]-->
      <b:includable id='post-paginationMore'>
        <script> /*! Simple AJAX infinite scroll by Taufik Nurrohman dte.web.id */ !function(t,e){t.InfiniteScroll=function(n){function r(t,n){return n=n||e,n.querySelectorAll(t)}function o(t){return void 0!==t}function a(t){return&quot;function&quot;==typeof t}function i(t,e){t=t||{};for(var n in e)t[n]=&quot;object&quot;==typeof e[n]?i(t[n],e[n]):e[n];return t}function s(t,e,n){return o(t)?o(e)?void(o(n)?g[t][n]=e:g[t].push(e)):g[t]:g}function d(t,e){o(e)?delete g[t][e]:g[t]=[]}function l(t,e){if(o(g[t]))for(var n in g[t])g[t][n](e)}function c(){return L.innerHTML=p.text.loading,v=!0,M?(y.classList.add(p.state.loading),l(&quot;loading&quot;,[p]),void u(M,function(t,n){y.className=x+&quot; &quot;+p.state.load,h=e.createElement(&quot;div&quot;),h.innerHTML=t;var o=r(&quot;title&quot;,h),a=r(p.target.post,h),i=r(p.target.anchors+&quot; &quot;+p.target.anchor,h),s=r(p.target.post,H);if(o=o&amp;&amp;o[0]?o[0].innerHTML:&quot;&quot;,a.length&amp;&amp;s.length){var d=s[s.length-1];e.title=o,d.insertAdjacentHTML(&quot;afterend&quot;,&quot; &quot;),h=e.createElement(&quot;div&quot;);for(var c=0,u=a.length;u&gt;c;++c)h.appendChild(a[c]);d.insertAdjacentHTML(&quot;afterend&quot;,h.innerHTML),f(),M=i.length?i[0].href:!1,v=!1,q++,l(&quot;load&quot;,[p,t,n])}},function(t,e){y.classList.add(p.state.error),v=!1,f(1),l(&quot;error&quot;,[p,t,e])})):(y.classList.add(p.state.loaded),L.innerHTML=p.text.loaded,l(&quot;loaded&quot;,[p]))}function f(t){if(L.innerHTML=&quot;&quot;,T){h.innerHTML=p.text[t?&quot;error&quot;:&quot;load&quot;];var e=h.firstChild;e.onclick=function(){return 2===p.type&amp;&amp;(T=!1),c(),!1},L.appendChild(e)}}var u=&quot;infinite-scroll-state-&quot;,p={target:{posts:&quot;.posts&quot;,post:&quot;.post&quot;,anchors:&quot;.anchors&quot;,anchor:&quot;.anchor&quot;},text:{load:&quot;%s&quot;,loading:&quot;%s&quot;,loaded:&quot;%s&quot;,error:&quot;%s&quot;},state:{load:u+&quot;load&quot;,loading:u+&quot;loading&quot;,loaded:u+&quot;loaded&quot;,error:u+&quot;error&quot;}},g={load:[],loading:[],loaded:[],error:[]};p=i(p,n||{}),p.on=s,p.off=d;var h=null,u=function(e,n,r){if(t.XMLHttpRequest){var o=new XMLHttpRequest;o.onreadystatechange=function(){if(4===o.readyState){if(200!==o.status)return void(r&amp;&amp;a(r)&amp;&amp;r(o.responseText,o));n&amp;&amp;a(n)&amp;&amp;n(o.responseText,o)}},o.open(&quot;GET&quot;,e),o.send()}},T=1!==p.type,v=!1,H=r(p.target.posts)[0],L=r(p.target.anchors)[0],M=r(p.target.anchor,L),m=e.body,y=e.documentElement,x=y.className||&quot;&quot;,E=H.offsetTop+H.offsetHeight,j=t.innerHeight,A=0,b=null,q=1;if(M.length){M=M[0].href,H.insertAdjacentHTML(&quot;afterbegin&quot;,&quot; &quot;),h=e.createElement(&quot;div&quot;),f();var w=function(){E=H.offsetTop+H.offsetHeight,j=t.innerHeight,A=m.scrollTop||y.scrollTop,v||E&gt;A+j||c()};w(),0!==p.type&amp;&amp;t.addEventListener(&quot;scroll&quot;,function(){T||(b&amp;&amp;t.clearTimeout(b),b=t.setTimeout(w,200))},!1)}return p}}(window,document);
if(typeof InfiniteScroll !== &quot;undefined&quot;) { var infinite_scroll = new InfiniteScroll ({ type: 0,
target: { posts: &quot;.blogPts&quot;, post: &quot;.ntry&quot;, anchors: &quot;.blogPg&quot;, anchor: &quot;.olLnk&quot;},
text: {
load: &quot;<a class='jsLd' expr:aria-label='data:messages.loadMorePosts' expr:data-text='data:messages.loadMorePosts' href='javascript:;'/>&quot;,
loading: &quot;<div class='jsLd wait nPst' expr:data-text='data:messages.loading'><svg viewBox='0 0 50 50' x='0px' y='0px'><path d='M25.251,6.461c-10.318,0-18.683,8.365-18.683,18.683h4.068c0-8.071,6.543-14.615,14.615-14.615V6.461z'><animateTransform attributeName='transform' attributeType='xml' dur='0.6s' from='0 25 25' repeatCount='indefinite' to='360 25 25' type='rotate'/></path></svg></div>&quot;,
loaded: &quot;<div class='jsLd nPst' expr:data-text='data:messages.noResultsFound'/>&quot;,
error: &quot;<a class='jsLd error' expr:aria-label='data:messages.loadMorePosts' expr:data-text='data:messages.moreEllipsis' href='javascript:;'/>&quot;} }); }</script>
      </b:includable>
        
      <!--[ Single page condition ]-->
      <b:includable id='post-singlePage'>
        <style>/*<![CDATA[*/ .blogM .mainbar{flex-basis:100%} .blogM .sidebar{display:none; flex:0 0 530px;margin:50px auto 0} .blogM .sidebar::before{display:none} .sideIn{width:100%} /*]]>*/</style>
      </b:includable>
        
       <!--[ SVG Icon ]-->      
      <b:includable id='back-icon'>
        <!--[ Back icon ]-->
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(12.000000, 12.000000) rotate(-270.000000) translate(-12.000000, -12.000000) translate(5.000000, 8.500000)'><path d='M14,0 C14,0 9.856,7 7,7 C4.145,7 0,0 0,0'/></g></svg>
      </b:includable>
      
      <b:includable id='forward-icon'>
        <!--[ Forward icon ]-->
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(12.000000, 12.000000) rotate(-90.000000) translate(-12.000000, -12.000000) translate(5.000000, 8.500000)'><path d='M14,0 C14,0 9.856,7 7,7 C4.145,7 0,0 0,0'/></g></svg>
      </b:includable>
      
      <b:includable id='arrow-right-icon'>
        <!--[ Arrow right icon ]-->
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(12.000000, 12.000000) rotate(-90.000000) translate(-12.000000, -12.000000) translate(5.500000, 4.000000)'><line x1='6.7743' x2='6.7743' y1='15.7501' y2='0.7501'/><path d='M12.7988,9.6998 C12.7988,9.6998 9.5378,15.7498 6.7758,15.7498 C4.0118,15.7498 0.7498,9.6998 0.7498,9.6998'/></g></svg>
      </b:includable>
      
        <b:includable id='close-icon'>
          <!--[ Close icon ]-->
          <svg class='line' viewBox='0 0 24 24'><line x1='18' x2='6' y1='6' y2='18'/><line x1='6' x2='18' y1='6' y2='18'/></svg>
        </b:includable>
      
      <b:includable id='arrow-left-icon'>
        <!--[ Arrow left icon ]-->
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(12.000000, 12.000000) rotate(-270.000000) translate(-12.000000, -12.000000) translate(5.500000, 4.000000)'><line x1='6.7743' x2='6.7743' y1='15.7501' y2='0.7501'/><path d='M12.7988,9.6998 C12.7988,9.6998 9.5378,15.7498 6.7758,15.7498 C4.0118,15.7498 0.7498,9.6998 0.7498,9.6998'/></g></svg>
      </b:includable>
      
      <b:includable id='arow-down-icon'>
        <!--[ Arrow down icon ]-->
        <svg class='line d' viewBox='0 0 24 24'><g transform='translate(5.000000, 8.500000)'><path d='M14,0 C14,0 9.856,7 7,7 C4.145,7 0,0 0,0'/></g></svg>
      </b:includable>
      
      <b:includable id='arow-up-icon'>
        <!--[ Arrow up icon ]-->
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(12.000000, 12.000000) rotate(-180.000000) translate(-12.000000, -12.000000) translate(5.000000, 8.500000)'><path d='M14,0 C14,0 9.856,7 7,7 C4.145,7 0,0 0,0'/></g></svg>
      </b:includable>
      
      <b:includable id='eye-icon'>
        <!--[ Eye icon ]-->
       <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.000000, 4.000000)'><path d='M13.1643,8.0521 C13.1643,9.7981 11.7483,11.2141 10.0023,11.2141 C8.2563,11.2141 6.8403,9.7981 6.8403,8.0521 C6.8403,6.3051 8.2563,4.8901 10.0023,4.8901 C11.7483,4.8901 13.1643,6.3051 13.1643,8.0521 Z'/><path d='M0.7503,8.0521 C0.7503,11.3321 4.8923,15.3541 10.0023,15.3541 C15.1113,15.3541 19.2543,11.3351 19.2543,8.0521 C19.2543,4.7691 15.1113,0.7501 10.0023,0.7501 C4.8923,0.7501 0.7503,4.7721 0.7503,8.0521 Z'/></g></svg>
      </b:includable>
      
      <b:includable id='send-icon'>
        <!--[ Send icon ]-->
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g transform='translate(2.800000, 2.800000)'><path d='M8.69324995,9.63816777 C8.69324995,9.63816777 -3.28340005,7.16056777 0.878549946,4.75801777 C4.39069995,2.73071777 16.4946499,-0.75483223 18.1856499,0.14576777 C19.0862499,1.83676777 15.6006999,13.9407178 13.5733999,17.4528678 C11.1708499,21.6148178 8.69324995,9.63816777 8.69324995,9.63816777 Z'/><line class='svg-c' x1='8.69325' x2='18.18565' y1='9.638168' y2='0.145768'/></g></svg>

      </b:includable>
      
      <!--[ Profile icon ]-->
      <b:includable id='profile-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g transform='translate(5.000000, 2.400000)'><path d='M6.84454545,19.261909 C3.15272727,19.261909 -8.52651283e-14,18.6874153 -8.52651283e-14,16.3866334 C-8.52651283e-14,14.0858516 3.13272727,11.961909 6.84454545,11.961909 C10.5363636,11.961909 13.6890909,14.0652671 13.6890909,16.366049 C13.6890909,18.6658952 10.5563636,19.261909 6.84454545,19.261909 Z'/><path d='M6.83729838,8.77363636 C9.26002565,8.77363636 11.223662,6.81 11.223662,4.38727273 C11.223662,1.96454545 9.26002565,-1.0658141e-14 6.83729838,-1.0658141e-14 C4.41457111,-1.0658141e-14 2.45,1.96454545 2.45,4.38727273 C2.44184383,6.80181818 4.39184383,8.76545455 6.80638929,8.77363636 C6.81729838,8.77363636 6.82729838,8.77363636 6.83729838,8.77363636 Z'/></g></svg>
      </b:includable>
      
      <!--[ Profiles icon ]-->
      <b:includable id='profiles-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g transform='translate(2.749500, 2.549500)'><path d='M6.809,18.9067 C3.137,18.9067 9.41469125e-14,18.3517 9.41469125e-14,16.1277 C9.41469125e-14,13.9037 3.117,11.8997 6.809,11.8997 C10.481,11.8997 13.617,13.8847 13.617,16.1077 C13.617,18.3307 10.501,18.9067 6.809,18.9067 Z'/><path d='M6.809,8.728 C9.219,8.728 11.173,6.774 11.173,4.364 C11.173,1.954 9.219,-2.48689958e-14 6.809,-2.48689958e-14 C4.399,-2.48689958e-14 2.44496883,1.954 2.44496883,4.364 C2.436,6.766 4.377,8.72 6.778,8.728 L6.809,8.728 Z'/><path class='svg-c' d='M14.0517,7.5293 C15.4547,7.1543 16.4887007,5.8753 16.4887007,4.3533 C16.4897,2.7653 15.3627,1.4393 13.8647,1.1323'/><path class='svg-c' d='M14.7113,11.104 C16.6993,11.104 18.3973,12.452 18.3973,13.655 C18.3973,14.364 17.8123,15.092 16.9223,15.301'/></g></svg>
      </b:includable>
      
      <!--[ Profile Circle icon ]-->
      <b:includable id='profile-circle-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M12.12 12.78C12.05 12.77 11.96 12.77 11.88 12.78C10.12 12.72 8.71997 11.28 8.71997 9.50998C8.71997 7.69998 10.18 6.22998 12 6.22998C13.81 6.22998 15.28 7.69998 15.28 9.50998C15.27 11.28 13.88 12.72 12.12 12.78Z'/><path d='M18.74 19.3801C16.96 21.0101 14.6 22.0001 12 22.0001C9.40001 22.0001 7.04001 21.0101 5.26001 19.3801C5.36001 18.4401 5.96001 17.5201 7.03001 16.8001C9.77001 14.9801 14.25 14.9801 16.97 16.8001C18.04 17.5201 18.64 18.4401 18.74 19.3801Z'/><path class='svg-c' d='M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z'/></svg>
      </b:includable>

      
      <!--[ Search icon ]-->
      <b:includable id='search-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.000000, 2.000000)'><circle cx='9.76659044' cy='9.76659044' r='8.9885584'/><line class='svg-c' x1='16.0183067' x2='19.5423342' y1='16.4851259' y2='20.0000001'/></g></svg>
      </b:includable>
      
      <!--[ Translate icon ]-->
      <b:includable id='translate-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M.5,2V18A1.5,1.5,0,0,0,2,19.5H17L10.5.5H2A1.5,1.5,0,0,0,.5,2Z'/><path d='M12,4.5H22A1.5,1.5,0,0,1,23.5,6V22A1.5,1.5,0,0,1,22,23.5H13.5l-1.5-4'/><line x1='17' x2='13.5' y1='19.5' y2='23.5'/><line class='svg-c' x1='14.5' x2='21.5' y1='10.5' y2='10.5'/><line class='svg-c' x1='17.5' x2='17.5' y1='9.5' y2='10.5'/><path class='svg-c' d='M20,10.5c0,1.1-1.77,4.42-4,6'/><path class='svg-c' d='M16,13c.54,1.33,4,4.5,4,4.5'/><path class='svg-c' d='M10.1,7.46a4,4,0,1,0,1.4,3h-4'/></svg>
        </b:includable>
      
      <b:includable id='notification-icon'>
        <!--[ Notification icon ]-->
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g transform='translate(4.614552, 2.514190)'><path d='M7.38163814,2.84217094e-14 C2.94735243,2.84217094e-14 1.02068576,4.0152381 1.02068576,6.66952381 C1.02068576,8.65333333 1.30830481,8.06952381 0.210209572,10.4895238 C-1.13074281,13.9380952 4.26163814,15.347619 7.38163814,15.347619 C10.5006858,15.347619 15.8930667,13.9380952 14.5530667,10.4895238 C13.4549715,8.06952381 13.7425905,8.65333333 13.7425905,6.66952381 C13.7425905,4.0152381 11.8149715,2.84217094e-14 7.38163814,2.84217094e-14 Z'/><path d='M9.691448,17.998 C8.39716229,19.4437143 6.37811467,19.4608571 5.071448,17.998'/></g></svg>
      </b:includable>
      
      <b:includable id='setting-icon'>
        <!--[ Setting icon ]-->
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g transform='translate(3.500000, 2.500000)'><path class='svg-c' d='M8.5,7 C9.88088012,7 11,8.11911988 11,9.5 C11,10.8808801 9.88088012,12 8.5,12 C7.11911988,12 6,10.8808801 6,9.5 C6,8.11911988 7.11911988,7 8.5,7 Z'/><path d='M16.6680023,4.75024695 L16.6680023,4.75024695 C15.9844554,3.55799324 14.4712377,3.15003899 13.2885153,3.83852352 C12.2597626,4.43613205 10.9740669,3.68838056 10.9740669,2.49217572 C10.9740669,1.11619444 9.86587758,0 8.4997646,0 L8.4997646,0 C7.13365161,0 6.02546233,1.11619444 6.02546233,2.49217572 C6.02546233,3.68838056 4.73976662,4.43613205 3.71199461,3.83852352 C2.52829154,3.15003899 1.01507378,3.55799324 0.331526939,4.75024695 C-0.351039204,5.94250065 0.053989269,7.46664934 1.23769234,8.15414609 C2.26546435,8.7527424 2.26546435,10.2472576 1.23769234,10.8458539 C0.053989269,11.5343384 -0.351039204,13.0584871 0.331526939,14.2497531 C1.01507378,15.4420068 2.52829154,15.849961 3.71101391,15.1624643 L3.71199461,15.1624643 C4.73976662,14.5638679 6.02546233,15.3116194 6.02546233,16.5078243 L6.02546233,16.5078243 C6.02546233,17.8838056 7.13365161,19 8.4997646,19 L8.4997646,19 C9.86587758,19 10.9740669,17.8838056 10.9740669,16.5078243 L10.9740669,16.5078243 C10.9740669,15.3116194 12.2597626,14.5638679 13.2885153,15.1624643 C14.4712377,15.849961 15.9844554,15.4420068 16.6680023,14.2497531 C17.3515491,13.0584871 16.9455399,11.5343384 15.7628176,10.8458539 L15.7618369,10.8458539 C14.7340648,10.2472576 14.7340648,8.7527424 15.7628176,8.15414609 C16.9455399,7.46664934 17.3515491,5.94250065 16.6680023,4.75024695 Z'/></g></svg>
      </b:includable>
      
       <b:includable id='sitemap-icon'>
        <!--[ Sitemap icon ]-->
        <svg height='1080pt' preserveAspectRatio='xMidYMid meet' version='1.1' viewBox='0 0 1080 1080' width='1080pt'>
<g fill='evenood' stroke='#ffffff' transform='translate(0,1080) scale(0.100000,-0.100000)'>
<path d='M4090 8595 l0 -1325 443 -1 c243 0 493 0 555 1 l112 1 0 -655 0 -656 -1742 -1 c-959 -1 -1747 0 -1753 2 -5 2 -30 3 -54 4 -37 0 -47 -5 -65 -28 l-21 -28 -3 -1095 -2 -1094 -508 -2 -507 -3 -3 -1317 -2 -1318 1325 0 1325 0 0 1321 0 1320 -447 -1 c-247 -1 -501 -1 -565 -1 l-118 1 10 26 c6 16 10 354 10 895 l0 869 1560 0 1560 0 0 -895 0 -895 -555 6 -555 7 0 -1326 0 -1327 1320 0 1320 0 0 1327 0 1326 -457 -8 c-252 -4 -483 -9 -513 -9 l-55 -1 -3 898 -2 897 1490 0 1490 0 0 -889 0 -888 -119 -6 c-66 -3 -302 -3 -525 0 l-406 6 0 -1326 0 -1327 1325 0 1325 0 0 1327 0 1326 -592 -6 -593 -6 -1 1072 c0 590 -3 1092 -5 1117 l-4 45 -1690 5 -1690 5 -3 653 -2 652 82 0 c46 1 278 0 516 0 l432 -1 0 1326 0 1325 -1320 0 -1320 0 0 -1325z m2188 38 l-3 -878 -894 -3 c-849 -2 -893 -1 -885 15 5 10 10 406 12 881 l2 862 885 0 885 0 -2 -877z m3642 -6243 l0 -880 -965 0 -965 0 0 880 0 880 965 0 965 0 0 -880z m-3608 -26 c2 -476 1 -868 -1 -870 -2 -2 -414 -4 -915 -4 l-911 0 3 857 c1 472 4 864 7 871 3 9 195 12 910 12 l905 0 2 -866z m-3532 -4 l0 -860 -917 2 -918 3 -3 845 c-1 465 0 851 3 858 3 9 197 12 920 12 l915 0 0 -860z'/>
</g>
</svg>
      </b:includable>
      
      <!--[ Triangle Danger icon ]-->
      <b:includable id='triangle-danger-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.500000, 3.000000)'><path d='M9.5,18 C3.00557739,18 0.456662548,17.5386801 0.0435259337,15.2033146 C-0.36961068,12.8679491 2.27382642,8.47741935 3.08841712,7.02846996 C5.81256986,2.18407813 7.66371927,0 9.5,0 C11.3362807,0 13.1874301,2.18407813 15.9115829,7.02846996 C16.7261736,8.47741935 19.3696107,12.8679491 18.9564741,15.2033146 C18.5443995,17.5386801 15.9944226,18 9.5,18 Z'/><line x1='9.5' x2='9.5' y1='5.5' y2='9.395'/><line class='svg-c' x1='9.4957' x2='9.5047' y1='12.895' y2='12.895'/></g></svg>
      </b:includable>

      
      <!--[ Share icon ]-->
      <b:includable id='share-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M16.44 8.8999C20.04 9.2099 21.51 11.0599 21.51 15.1099V15.2399C21.51 19.7099 19.72 21.4999 15.25 21.4999H8.73998C4.26998 21.4999 2.47998 19.7099 2.47998 15.2399V15.1099C2.47998 11.0899 3.92998 9.2399 7.46998 8.9099'/><path d='M12 15.0001V3.62012'/><path class='svg-c' d='M15.35 5.85L12 2.5L8.65002 5.85'/></svg>
      </b:includable>
      
      <!--[ Share icon ]-->
      <b:includable id='share-alt-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M92.30583,264.72053a3.42745,3.42745,0,0,1-.37,1.57,3.51,3.51,0,1,1,0-3.13995A3.42751,3.42751,0,0,1,92.30583,264.72053Z' transform='translate(-83.28571 -252.73452)'/><circle cx='18.48892' cy='5.49436' r='3.51099'/><circle cx='18.48892' cy='18.50564' r='3.51099'/><line class='cls-3' x1='12.53012' x2='8.65012' y1='8.476' y2='10.416'/><line class='cls-3 svg-c' x1='12.53012' x2='8.65012' y1='15.496' y2='13.556'/></svg>
      </b:includable>
      
      <!--[ Instagram icon ]-->
      <b:includable id='instagram-icon'>
        <svg viewBox='0 0 32 32'><path d='M22,3H10a7,7,0,0,0-7,7V22a7,7,0,0,0,7,7H22a7,7,0,0,0,7-7V10A7,7,0,0,0,22,3Zm5,19a5,5,0,0,1-5,5H10a5,5,0,0,1-5-5V10a5,5,0,0,1,5-5H22a5,5,0,0,1,5,5Z'/><path class='svg-c' d='M16,9.5A6.5,6.5,0,1,0,22.5,16,6.51,6.51,0,0,0,16,9.5Zm0,11A4.5,4.5,0,1,1,20.5,16,4.51,4.51,0,0,1,16,20.5Z'/><circle class='svg-c' cx='23' cy='9' r='1'/></svg>
      </b:includable>
      
      <!--[ Facebook icon ]-->
      <b:includable id='facebook-icon'>
        <svg viewBox='0 0 32 32'><path d='M24,3H8A5,5,0,0,0,3,8V24a5,5,0,0,0,5,5H24a5,5,0,0,0,5-5V8A5,5,0,0,0,24,3Zm3,21a3,3,0,0,1-3,3H17V18h4a1,1,0,0,0,0-2H17V14a2,2,0,0,1,2-2h2a1,1,0,0,0,0-2H19a4,4,0,0,0-4,4v2H12a1,1,0,0,0,0,2h3v9H8a3,3,0,0,1-3-3V8A3,3,0,0,1,8,5H24a3,3,0,0,1,3,3Z'/></svg>
      </b:includable>
      
      <!--[ Facebook rounded icon ]-->
      <b:includable id='facebook-r-icon'>
        <svg viewBox='0 0 64 64'><path d='M20.1,36h3.4c0.3,0,0.6,0.3,0.6,0.6V58c0,1.1,0.9,2,2,2h7.8c1.1,0,2-0.9,2-2V36.6c0-0.3,0.3-0.6,0.6-0.6h5.6 c1,0,1.9-0.7,2-1.7l1.3-7.8c0.2-1.2-0.8-2.4-2-2.4h-6.6c-0.5,0-0.9-0.4-0.9-0.9v-5c0-1.3,0.7-2,2-2h5.9c1.1,0,2-0.9,2-2V6.2 c0-1.1-0.9-2-2-2h-7.1c-13,0-12.7,10.5-12.7,12v7.3c0,0.3-0.3,0.6-0.6,0.6h-3.4c-1.1,0-2,0.9-2,2v7.8C18.1,35.1,19,36,20.1,36z'/></svg>
      </b:includable>
      
      <!--[ Twitter icon ]-->
      <b:includable id='twitter-icon'>
        <svg viewBox='0 0 32 32'><path d='M13.35,28A13.66,13.66,0,0,1,2.18,22.16a1,1,0,0,1,.69-1.56l2.84-.39A12,12,0,0,1,5.44,4.35a1,1,0,0,1,1.7.31,9.87,9.87,0,0,0,5.33,5.68,7.39,7.39,0,0,1,7.24-6.15,7.29,7.29,0,0,1,5.88,3H29a1,1,0,0,1,.9.56,1,1,0,0,1-.11,1.06L27,12.27c0,.14,0,.28-.05.41a12.46,12.46,0,0,1,.09,1.43A13.82,13.82,0,0,1,13.35,28ZM4.9,22.34A11.63,11.63,0,0,0,13.35,26,11.82,11.82,0,0,0,25.07,14.11,11.42,11.42,0,0,0,25,12.77a1.11,1.11,0,0,1,0-.26c0-.22.05-.43.06-.65a1,1,0,0,1,.22-.58l1.67-2.11H25.06a1,1,0,0,1-.85-.47,5.3,5.3,0,0,0-4.5-2.51,5.41,5.41,0,0,0-5.36,5.45,1.07,1.07,0,0,1-.4.83,1,1,0,0,1-.87.2A11.83,11.83,0,0,1,6,7,10,10,0,0,0,8.57,20.12a1,1,0,0,1,.37,1.05,1,1,0,0,1-.83.74Z'/></svg>
      </b:includable>
      
      <!--[ Twitter rounded icon ]-->
      <b:includable id='twitter-r-icon'>
        <svg viewBox='0 0 64 64'><path d='M11.4,26.6C11.5,26.6,11.5,26.6,11.4,26.6c-0.9,0-1.8-0.2-2.6-0.4c-1.3-0.4-2.5,0.8-2.1,2 c1.1,4.3,4.5,7.7,8.8,8.6c-1,0.3-2,0.4-3,0.4c-1,0-1.7,1.1-1.2,2c1.9,3.5,5.6,5.9,9.7,6h1c1.1,0,2,0.9,2,2c0,1.1-0.9,2-2,2 c-1.3,0-2.9-0.1-4.5-0.5c-1-0.2-2-0.2-2.9,0.1c-1.7,0.6-3.5,1.1-5.4,1.3C8.5,50.2,8,50.7,8,51.4v0c0,0.5,0.3,1,0.8,1.2 c3.9,1.7,8.3,2.7,12.9,2.7c21.1,0,32.7-17.9,32.7-33.5v0c0-0.9,0.4-1.8,1.1-2.4c1.2-1,2.3-2.1,3.3-3.4c0.4-0.5-0.1-1.2-0.7-1 c-1.2,0.4-2.4,0.7-3.7,0.9c-0.2,0-0.3-0.2-0.1-0.4c1.5-1.1,2.8-2.6,3.6-4.3c0.3-0.6-0.3-1.2-0.9-0.9c-1.1,0.6-2.3,1-3.5,1.4 c-1.2,0.4-2.6,0.1-3.6-0.7c-1.9-1.5-4.4-2.4-7-2.4c-5.3,0-9.8,3.7-11.1,8.8c-0.2,0.9,0.5,1.7,1.4,1.7c1.6-0.1,3.2-0.3,4.4-0.5 c1-0.2,2,0.3,2.4,1.2c0.5,1.2-0.2,2.4-1.3,2.7c-4.6,1.3-9.7,0.4-9.7,0.4l0,0C21.2,21.8,14.3,18,9.3,12.5C8.6,11.7,7.3,12,7,12.9 c-0.4,1.2-0.6,2.5-0.6,3.9C6.4,20.9,8.4,24.5,11.4,26.6z'/></svg>
      </b:includable>
      
      <!--[ Telegram icon ]-->
      <b:includable id='telegram-icon'>
        <svg viewBox='0 0 32 32'><path d='M24,28a1,1,0,0,1-.62-.22l-6.54-5.23a1.83,1.83,0,0,1-.13.16l-4,4a1,1,0,0,1-1.65-.36L8.2,18.72,2.55,15.89a1,1,0,0,1,.09-1.82l26-10a1,1,0,0,1,1,.17,1,1,0,0,1,.33,1l-5,22a1,1,0,0,1-.65.72A1,1,0,0,1,24,28Zm-8.43-9,7.81,6.25L27.61,6.61,5.47,15.12l4,2a1,1,0,0,1,.49.54l2.45,6.54,2.89-2.88-1.9-1.53A1,1,0,0,1,13,19a1,1,0,0,1,.35-.78l7-6a1,1,0,1,1,1.3,1.52Z'/></svg>
      </b:includable>
      
      <!--[ Telegram rounded icon ]-->
      <b:includable id='telegram-r-icon'>
        <svg viewBox='0 0 64 64'><path d='M56.4,8.2l-51.2,20c-1.7,0.6-1.6,3,0.1,3.5l9.7,2.9c2.1,0.6,3.8,2.2,4.4,4.3l3.8,12.1c0.5,1.6,2.5,2.1,3.7,0.9 l5.2-5.3c0.9-0.9,2.2-1,3.2-0.3l11.5,8.4c1.6,1.2,3.9,0.3,4.3-1.7l8.7-41.8C60.4,9.1,58.4,7.4,56.4,8.2z M50,17.4L29.4,35.6 c-1.1,1-1.9,2.4-2,3.9c-0.2,1.5-2.3,1.7-2.8,0.3l-0.9-3c-0.7-2.2,0.2-4.5,2.1-5.7l23.5-14.6C49.9,16.1,50.5,16.9,50,17.4z'/></svg>
      </b:includable>
      
      <!--[ Tiktok icon ]-->
      <b:includable id='tiktok-icon'>
        <svg viewBox='0 0 32 32'><path d='M24,3H8A5,5,0,0,0,3,8V24a5,5,0,0,0,5,5H24a5,5,0,0,0,5-5V8A5,5,0,0,0,24,3Zm3,21a3,3,0,0,1-3,3H8a3,3,0,0,1-3-3V8A3,3,0,0,1,8,5H24a3,3,0,0,1,3,3Z'/><path class='svg-c' d='M22,12a3,3,0,0,1-3-3,1,1,0,0,0-2,0V19a3,3,0,1,1-3-3,1,1,0,0,0,0-2,5,5,0,1,0,5,5V13a4.92,4.92,0,0,0,3,1,1,1,0,0,0,0-2Z'/></svg>
      </b:includable>
      
      <!--[ Tumblr icon ]-->
      <b:includable id='tumblr-icon'>
        <svg viewBox='0 0 32 32'><path d='M16,2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Zm0,26A12,12,0,1,1,28,16,12,12,0,0,1,16,28Z'/><path class='svg-c' d='M20,19a1,1,0,0,0-1,1,1,1,0,0,1-1,1H17a1,1,0,0,1-1-1V15h3a1,1,0,0,0,0-2H16V10a1,1,0,0,0-2,0v3H12a1,1,0,0,0,0,2h2v5a3,3,0,0,0,3,3h1a3,3,0,0,0,3-3A1,1,0,0,0,20,19Z'/></svg>
      </b:includable>
      
      <!--[ line icon ]-->
      <b:includable id='line-icon'>
        <svg viewBox='0 0 32 32'><path d='M16,2C8.28,2,2,7.38,2,14c0,5.48,4.34,10.24,10.44,11.6L12,28.87a1,1,0,0,0,.37.91A1,1,0,0,0,13,30a1,1,0,0,0,.35-.06C14,29.68,30,23.58,30,14,30,7.38,23.72,2,16,2ZM14.22,27.4l.33-2.47a1,1,0,0,0-.83-1.12C8.09,22.91,4,18.78,4,14,4,8.49,9.38,4,16,4S28,8.49,28,14C28,20.61,18.14,25.66,14.22,27.4Z'/><path class='svg-c' d='M10,15.25H8.75V12a.75.75,0,0,0-1.5,0v4a.76.76,0,0,0,.75.75h2a.75.75,0,0,0,0-1.5Z'/><path class='svg-c' d='M24,12.75a.75.75,0,0,0,0-1.5H22a.76.76,0,0,0-.75.75v4a.76.76,0,0,0,.75.75h2a.75.75,0,0,0,0-1.5H22.75v-.5H24a.75.75,0,0,0,0-1.5H22.75v-.5Z'/><path class='svg-c' d='M13,11.25a.76.76,0,0,0-.75.75v4a.75.75,0,0,0,1.5,0V12A.76.76,0,0,0,13,11.25Z'/><path class='svg-c' d='M19,11.25a.76.76,0,0,0-.75.75v1.75l-1.65-2.2a.75.75,0,0,0-1.35.45v4a.75.75,0,0,0,1.5,0V14.25l1.65,2.2a.75.75,0,0,0,.6.3.67.67,0,0,0,.24,0,.75.75,0,0,0,.51-.71V12A.76.76,0,0,0,19,11.25Z'/></svg>
      </b:includable>
      
      <!--[ Line rounded icon ]-->
      <b:includable id='line-r-icon'>
        <svg viewBox='0 0 24 24'><path d='M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314'/></svg>
      </b:includable>
      
      <!--[ Youtube icon ]-->
      <b:includable id='youtube-icon'>
        <svg viewBox='0 0 32 32'><path d='M29.73,9.9A5,5,0,0,0,25.1,5.36a115.19,115.19,0,0,0-18.2,0A5,5,0,0,0,2.27,9.9a69,69,0,0,0,0,12.2A5,5,0,0,0,6.9,26.64c3,.24,6.06.36,9.1.36s6.08-.12,9.1-.36a5,5,0,0,0,4.63-4.54A69,69,0,0,0,29.73,9.9Zm-2,12A3,3,0,0,1,25,24.65a113.8,113.8,0,0,1-17.9,0,3,3,0,0,1-2.78-2.72,65.26,65.26,0,0,1,0-11.86A3,3,0,0,1,7.05,7.35C10,7.12,13,7,16,7s6,.12,9,.35a3,3,0,0,1,2.78,2.72A65.26,65.26,0,0,1,27.73,21.93Z'/><path class='svg-c' d='M21.45,15.11l-8-4A1,1,0,0,0,12,12v8a1,1,0,0,0,.47.85A1,1,0,0,0,13,21a1,1,0,0,0,.45-.11l8-4a1,1,0,0,0,0-1.78ZM14,18.38V13.62L18.76,16Z'/></svg>        
      </b:includable>
      
      <!--[ LinkedIn icon ]-->
      <b:includable id='linkedIn-icon'>
        <svg viewBox='0 0 32 32'><path d='M24,3H8A5,5,0,0,0,3,8V24a5,5,0,0,0,5,5H24a5,5,0,0,0,5-5V8A5,5,0,0,0,24,3Zm3,21a3,3,0,0,1-3,3H8a3,3,0,0,1-3-3V8A3,3,0,0,1,8,5H24a3,3,0,0,1,3,3Z'/><path class='svg-c' d='M11,14a1,1,0,0,0-1,1v6a1,1,0,0,0,2,0V15A1,1,0,0,0,11,14Z'/><path class='svg-c' d='M19,13a4,4,0,0,0-4,4v4a1,1,0,0,0,2,0V17a2,2,0,0,1,4,0v4a1,1,0,0,0,2,0V17A4,4,0,0,0,19,13Z'/><circle class='svg-c' cx='11' cy='11' r='1'/></svg>        
      </b:includable>
      
      <!--[ LinkedIn rounded icon ]-->
      <b:includable id='linkedIn-r-icon'>
        <svg viewBox='0 0 64 64'><path d='M8,54.7C8,55.4,8.6,56,9.3,56h9.3c0.7,0,1.3-0.6,1.3-1.3V23.9c0-0.7-0.6-1.3-1.3-1.3H9.3 c-0.7,0-1.3,0.6-1.3,1.3V54.7z'/><path class='svg-c' d='M46.6,22.3c-4.5,0-7.7,1.8-9.4,3.7c-0.4,0.4-1.1,0.1-1.1-0.5l0-1.6c0-0.7-0.6-1.3-1.3-1.3h-9.4 c-0.7,0-1.3,0.6-1.3,1.3c0.1,5.7,0,25.4,0,30.7c0,0.7,0.6,1.3,1.3,1.3h9.5c0.7,0,1.3-0.6,1.3-1.3V37.9c0-1,0-2,0.3-2.7 c0.8-2,2.6-4.1,5.7-4.1c4.1,0,6,3.1,6,7.6v15.9c0,0.7,0.6,1.3,1.3,1.3h9.3c0.7,0,1.3-0.6,1.3-1.3V37.4C60,27.1,54.1,22.3,46.6,22.3 z'/><path class='svg-c' d='M13.9,18.9L13.9,18.9c3.8,0,6.1-2.4,6.1-5.4C19.9,10.3,17.7,8,14,8c-3.7,0-6,2.3-6,5.4 C8,16.5,10.3,18.9,13.9,18.9z'/></svg>
      </b:includable>
      
      <!--[ Whatsapp icon ]-->
      <b:includable id='whatsapp-icon'>
        <svg viewBox='0 0 32 32'><path d='M16,2A13,13,0,0,0,8,25.23V29a1,1,0,0,0,.51.87A1,1,0,0,0,9,30a1,1,0,0,0,.51-.14l3.65-2.19A12.64,12.64,0,0,0,16,28,13,13,0,0,0,16,2Zm0,24a11.13,11.13,0,0,1-2.76-.36,1,1,0,0,0-.76.11L10,27.23v-2.5a1,1,0,0,0-.42-.81A11,11,0,1,1,16,26Z'/><path class='svg-c' d='M19.86,15.18a1.9,1.9,0,0,0-2.64,0l-.09.09-1.4-1.4.09-.09a1.86,1.86,0,0,0,0-2.64L14.23,9.55a1.9,1.9,0,0,0-2.64,0l-.8.79a3.56,3.56,0,0,0-.5,3.76,10.64,10.64,0,0,0,2.62,4A8.7,8.7,0,0,0,18.56,21a2.92,2.92,0,0,0,2.1-.79l.79-.8a1.86,1.86,0,0,0,0-2.64Zm-.62,3.61c-.57.58-2.78,0-4.92-2.11a8.88,8.88,0,0,1-2.13-3.21c-.26-.79-.25-1.44,0-1.71l.7-.7,1.4,1.4-.7.7a1,1,0,0,0,0,1.41l2.82,2.82a1,1,0,0,0,1.41,0l.7-.7,1.4,1.4Z'/></svg>
      </b:includable>
      
      <!--[ Whatsapp rounded icon ]-->
      <b:includable id='whatsapp-r-icon'>
        <svg viewBox='0 0 64 64'><path d='M6.9,48.4c-0.4,1.5-0.8,3.3-1.3,5.2c-0.7,2.9,1.9,5.6,4.8,4.8l5.1-1.3c1.7-0.4,3.5-0.2,5.1,0.5 c4.7,2.1,10,3,15.6,2.1c12.3-1.9,22-11.9,23.5-24.2C62,17.3,46.7,2,28.5,4.2C16.2,5.7,6.2,15.5,4.3,27.8c-0.8,5.6,0,10.9,2.1,15.6 C7.1,44.9,7.3,46.7,6.9,48.4z M21.3,19.8c0.6-0.5,1.4-0.9,1.8-0.9s2.3-0.2,2.9,1.2c0.6,1.4,2,4.7,2.1,5.1c0.2,0.3,0.3,0.7,0.1,1.2 c-0.2,0.5-0.3,0.7-0.7,1.1c-0.3,0.4-0.7,0.9-1,1.2c-0.3,0.3-0.7,0.7-0.3,1.4c0.4,0.7,1.8,2.9,3.8,4.7c2.6,2.3,4.9,3,5.5,3.4 c0.7,0.3,1.1,0.3,1.5-0.2c0.4-0.5,1.7-2,2.2-2.7c0.5-0.7,0.9-0.6,1.6-0.3c0.6,0.2,4,1.9,4.7,2.2c0.7,0.3,1.1,0.5,1.3,0.8 c0.2,0.3,0.2,1.7-0.4,3.2c-0.6,1.6-2.1,3.1-3.2,3.5c-1.3,0.5-2.8,0.7-9.3-1.9c-7-2.8-11.8-9.8-12.1-10.3c-0.3-0.5-2.8-3.7-2.8-7.1 C18.9,22.1,20.7,20.4,21.3,19.8z'/></svg>
      </b:includable>
      
      <!--[ Pinterest icon ]-->
      <b:includable id='pinterest-icon'>
        <svg viewBox='0 0 32 32'><path d='M16,2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Zm0,26a12,12,0,0,1-3.81-.63l1.2-4.81A7.93,7.93,0,0,0,16,23a8.36,8.36,0,0,0,1.4-.12,8,8,0,1,0-9.27-6.49,1,1,0,0,0,2-.35,6,6,0,1,1,3.79,4.56L15,16.24A1,1,0,1,0,13,15.76l-2.7,10.81A12,12,0,1,1,16,28Z'/></svg>
      </b:includable>
      
      <!--[ Pinteres rounded icon ]-->
      <b:includable id='pinterest-r-icon'>
        <svg viewBox='0 0 64 64'><path d='M14.4,53.8c2.4,2,6.1,0.6,6.8-2.4l0-0.1c0.4-1.8,2.4-10.2,3.2-13.7c0.2-0.9,0.2-1.8-0.1-2.7 C24.2,34,24,32.8,24,31.5c0-4.1,2.4-7.2,5.4-7.2c2.5,0,3.8,1.9,3.8,4.2c0,2.6-1.6,6.4-2.5,9.9c-0.7,3,1.5,5.4,4.4,5.4 c5.3,0,8.9-6.8,8.9-14.9c0-6.1-4.1-10.7-11.6-10.7c-8.5,0-13.8,6.3-13.8,13.4c0,2.4,0.7,4.2,1.8,5.5c0.5,0.6,0.6,0.9,0.4,1.6 c-0.1,0.5-0.4,1.8-0.6,2.2c-0.2,0.7-0.8,1-1.4,0.7c-3.9-1.6-5.7-5.9-5.7-10.7c0-8,6.7-17.5,20-17.5c10.7,0,17.7,7.7,17.7,16 c0,11-6.1,19.2-15.1,19.2c-1.9,0-3.8-0.7-5.2-1.6c-0.9-0.6-2.1-0.1-2.4,0.9c-0.5,1.9-1.1,4.3-1.3,4.9c-0.1,0.5-0.3,0.9-0.4,1.4 c-1,2.7,0.9,5.5,3.7,5.7c2.1,0.1,4.2,0,6.3-0.3c12.4-2,22.1-12.2,23.4-24.7C61.5,18.1,48.4,4,32,4C16.5,4,4,16.5,4,32 C4,40.8,8.1,48.6,14.4,53.8z'/></svg>
      </b:includable>
      
      <!--[ Mail rounded icon ]-->
      <b:includable id='mail-r-icon'>
        <svg viewBox='0 0 500 500'><path d='M468.051,222.657c0-12.724-5.27-24.257-13.717-32.527 L282.253,45.304c-17.811-17.807-46.702-17.807-64.505,0L45.666,190.129c-8.448,8.271-13.717,19.803-13.717,32.527v209.054 c0,20.079,16.264,36.341,36.34,36.341h363.421c20.078,0,36.34-16.262,36.34-36.341V222.657z M124.621,186.402h250.758 c11.081,0,19.987,8.905,19.987,19.991v34.523c-0.088,4.359-1.818,8.631-5.181,11.997l-55.966,56.419l83.224,83.127 c6.904,6.904,6.904,18.081,0,24.985s-18.085,6.904-24.985,0l-85.676-85.672H193.034l-85.492,85.672 c-6.907,6.904-18.081,6.904-24.985,0c-6.906-6.904-6.906-18.081,0-24.985l83.131-83.127l-55.875-56.419 c-3.638-3.638-5.363-8.358-5.181-13.177v-33.343C104.632,195.307,113.537,186.402,124.621,186.402z'/></svg>
      </b:includable>
      
      <!--[ Circle icon ]-->
      <b:includable id='circle-icon'>
        <svg viewBox='0 0 32 32'><path d='M16,2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Zm0,26A12,12,0,1,1,28,16,12,12,0,0,1,16,28Z'/><path d='M16,9.5A6.5,6.5,0,1,0,22.5,16,6.51,6.51,0,0,0,16,9.5Zm0,11A4.5,4.5,0,1,1,20.5,16,4.51,4.51,0,0,1,16,20.5Z'/></svg>
      </b:includable>
      
      <!--[ Home icon ]-->
      <b:includable id='home-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g><line class='svg-c' x1='14.71978' x2='9.28022' y1='15.00368' y2='15.00368'/><path d='M100.28571,274.70685h-10a5,5,0,0,1-5-5v-5.00916a5,5,0,0,1,1.601-3.667l5.6798-5.2648a4,4,0,0,1,5.43845,0l5.67981,5.2648a5,5,0,0,1,1.601,3.667v5.00916A5,5,0,0,1,100.28571,274.70685Z' transform='translate(-83.28571 -252.70317)'/></g></svg>
      </b:includable>
      
      <!--[ Home alt icon ]-->
      <b:includable id='home-alt-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g><line class='svg-c' x1='14.71978' x2='9.28022' y1='15.00368' y2='15.00368'/><path d='M100.28571,274.70685h-10a5,5,0,0,1-5-5v-5.00916a5,5,0,0,1,1.601-3.667l5.6798-5.2648a4,4,0,0,1,5.43845,0l5.67981,5.2648a5,5,0,0,1,1.601,3.667v5.00916A5,5,0,0,1,100.28571,274.70685Z' transform='translate(-83.28571 -252.70317)'/></g></svg>
      </b:includable>
      
      <!--[ Folder icon ]-->
      <b:includable id='folder-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g><path d='M21.4446 15.7579C21.4446 19.336 19.336 21.4446 15.7579 21.4446H7.97172C4.38443 21.4446 2.27588 19.336 2.27588 15.7579V7.9626C2.27588 4.38444 3.5903 2.27588 7.16846 2.27588H9.16749C9.88576 2.27588 10.5621 2.61406 10.9931 3.18868L11.9059 4.40269C12.3378 4.97618 13.0135 5.31406 13.7315 5.31549H16.5611C20.1484 5.31549 21.472 7.14108 21.472 10.7923L21.4446 15.7579Z'/><path class='svg-c' d='M7.05893 14.4891H16.6524'/></g></svg>
      </b:includable>
      
      <!--[ Message icon ]-->
      <b:includable id='message-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><path class='svg-c' d='M17.2677 9.06113L13.0023 12.4954C12.1951 13.1283 11.0635 13.1283 10.2563 12.4954L5.95424 9.06113'/><path d='M6.88787 3.5H16.3158C17.6752 3.51525 18.969 4.08993 19.896 5.0902C20.823 6.09048 21.3022 7.42903 21.222 8.79412V15.322C21.3022 16.6871 20.823 18.0256 19.896 19.0259C18.969 20.0262 17.6752 20.6009 16.3158 20.6161H6.88787C3.96796 20.6161 2 18.2407 2 15.322V8.79412C2 5.87545 3.96796 3.5 6.88787 3.5Z'/></svg>
      </b:includable>
      
      <!--[ Paper icon ]-->
      <b:includable id='paper-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(3.649800, 2.749900)'><line class='svg-c' x1='10.6555' x2='5.2555' y1='12.6999' y2='12.6999'/><line x1='8.6106' x2='5.2546' y1='8.6886' y2='8.6886'/><path d='M16.51,5.55 L10.84,0.15 C10.11,0.05 9.29,0 8.39,0 C2.1,0 -1.95399252e-14,2.32 -1.95399252e-14,9.25 C-1.95399252e-14,16.19 2.1,18.5 8.39,18.5 C14.69,18.5 16.79,16.19 16.79,9.25 C16.79,7.83 16.7,6.6 16.51,5.55 Z'/><path d='M10.2844,0.0827 L10.2844,2.7437 C10.2844,4.6017 11.7904,6.1067 13.6484,6.1067 L16.5994,6.1067'/></g></svg>
      </b:includable>
      
      <!--[ Document icon ]-->
      <b:includable id='document-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><path d='M15.7162 16.2234H8.4962'/><path d='M15.7162 12.0369H8.4962'/><path class='svg-c' d='M11.2513 7.86008H8.4963'/><path d='M15.9086 2.74979C15.9086 2.74979 8.2316 2.75379 8.2196 2.75379C5.4596 2.77079 3.7506 4.58679 3.7506 7.35679V16.5528C3.7506 19.3368 5.4726 21.1598 8.2566 21.1598C8.2566 21.1598 15.9326 21.1568 15.9456 21.1568C18.7056 21.1398 20.4156 19.3228 20.4156 16.5528V7.35679C20.4156 4.57279 18.6926 2.74979 15.9086 2.74979Z'/></svg>
      </b:includable>
      
      <!--[ Buy icon ]-->
      <b:includable id='buy-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(3.650200, 2.850200)'><path d='M2.044,3.58024493 C7.3705141,2.243 13.9926469,2.32498848 15.5231061,4.06777179 C17.0535652,5.8105551 17.0220031,11.638 15.2330031,13.237 C13.4450031,14.836 5.68,14.988 3.22,13.237 C0.621,11.386 2.129,5.692 2.044,2.243 C2.095,0.313 -1.13686838e-13,0 -1.13686838e-13,0'/><line class='svg-c' x1='10.5059' x2='13.2789' y1='7.8696' y2='7.8696'/><path d='M3.6138,17.2773 C3.9138,17.2773 4.1578,17.5213 4.1578,17.8213 C4.1578,18.1223 3.9138,18.3663 3.6138,18.3663 C3.3128,18.3663 3.0688,18.1223 3.0688,17.8213 C3.0688,17.5213 3.3128,17.2773 3.6138,17.2773 Z'/><path d='M13.9453,17.2773 C14.2463,17.2773 14.4903,17.5213 14.4903,17.8213 C14.4903,18.1223 14.2463,18.3663 13.9453,18.3663 C13.6453,18.3663 13.4013,18.1223 13.4013,17.8213 C13.4013,17.5213 13.6453,17.2773 13.9453,17.2773 Z'/></g></svg>
      </b:includable>
      
      <!--[ Download icon ]-->
      <b:includable id='download-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.000000, 2.000000)'><line class='svg-c' x1='9.8791' x2='9.8791' y1='12.791' y2='0.75'/><polyline points='12.7951 9.8642 9.8791 12.7922 6.9631 9.8642'/><path d='M14.3703,5.2587 C17.9493,5.5887 19.2503,6.9287 19.2503,12.2587 C19.2503,19.3587 16.9393,19.3587 10.0003,19.3587 C3.0593,19.3587 0.7503,19.3587 0.7503,12.2587 C0.7503,6.9287 2.0503,5.5887 5.6303,5.2587'/></g></svg>
      </b:includable>
      
      <!--[ Download alt icon ]-->
      <b:includable id='download-alt-icon'>
        <svg class='line' viewBox='0 0 24 24'><polyline points='8 17 12 21 16 17'/><line class='svg-c' x1='12' x2='12' y1='12' y2='21'/><path d='M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29'/></svg>
      </b:includable>
      
      <!--[ Lock icon ]-->
      <b:includable id='lock-icon'>
       <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><path d='M16.4234 9.4478V7.3008C16.4234 4.7878 14.3854 2.7498 11.8724 2.7498C9.35937 2.7388 7.31337 4.7668 7.30237 7.2808V7.3008V9.4478'/><path d='M15.6832 21.2496H8.04218C5.94818 21.2496 4.25018 19.5526 4.25018 17.4576V13.1686C4.25018 11.0736 5.94818 9.37659 8.04218 9.37659H15.6832C17.7772 9.37659 19.4752 11.0736 19.4752 13.1686V17.4576C19.4752 19.5526 17.7772 21.2496 15.6832 21.2496Z'/><path class='svg-c' d='M11.8629 14.2027V16.4237'/></svg>
      </b:includable>
      
      <!--[ Shield done icon ]-->
      <b:includable id='shield-done-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><path d='M18.865 5.1238C19.302 5.2768 19.594 5.6888 19.594 6.1518V12.9248C19.594 14.8178 18.906 16.6248 17.691 18.0248C17.08 18.7298 16.307 19.2788 15.486 19.7228L11.928 21.6448L8.364 19.7218C7.542 19.2778 6.768 18.7298 6.156 18.0238C4.94 16.6238 4.25 14.8158 4.25 12.9208V6.1518C4.25 5.6888 4.542 5.2768 4.979 5.1238L11.561 2.8108C11.795 2.7288 12.05 2.7288 12.283 2.8108L18.865 5.1238Z'/><path class='svg-c' d='M9.32251 11.9177L11.2145 13.8107L15.1125 9.91269'/></svg>
      </b:includable>
      
      <!--[ Plus icon ]-->
      <b:includable id='plus-icon'>
        <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g transform='translate(2.300000, 2.300000)'><line class='svg-c' x1='9.73684179' x2='9.73684179' y1='6.162632' y2='13.3110531'/><line class='svg-c' x1='13.3146315' x2='6.158842' y1='9.73684179' y2='9.73684179'/><path d='M-3.55271368e-14,9.73684211 C-3.55271368e-14,2.43473684 2.43473684,2.13162821e-14 9.73684211,2.13162821e-14 C17.0389474,2.13162821e-14 19.4736842,2.43473684 19.4736842,9.73684211 C19.4736842,17.0389474 17.0389474,19.4736842 9.73684211,19.4736842 C2.43473684,19.4736842 -3.55271368e-14,17.0389474 -3.55271368e-14,9.73684211 Z'/></g></svg>
      </b:includable>
      
      <!--[ Moon icon ]-->
      <b:includable id='moon-sun-icon'>
        <svg class='line' viewBox='0 0 24 24'>
          <g class='d1'><path d='M183.72453,170.371a10.4306,10.4306,0,0,1-.8987,3.793,11.19849,11.19849,0,0,1-5.73738,5.72881,10.43255,10.43255,0,0,1-3.77582.89138,1.99388,1.99388,0,0,0-1.52447,3.18176,10.82936,10.82936,0,1,0,15.118-15.11819A1.99364,1.99364,0,0,0,183.72453,170.371Z' transform='translate(-169.3959 -166.45548)'/></g>
          <g class='d2'><path class='f' d='M12 18.5C15.5899 18.5 18.5 15.5899 18.5 12C18.5 8.41015 15.5899 5.5 12 5.5C8.41015 5.5 5.5 8.41015 5.5 12C5.5 15.5899 8.41015 18.5 12 18.5Z'/><path class='svg-c' d='M19.14 19.14L19.01 19.01M19.01 4.99L19.14 4.86L19.01 4.99ZM4.86 19.14L4.99 19.01L4.86 19.14ZM12 2.08V2V2.08ZM12 22V21.92V22ZM2.08 12H2H2.08ZM22 12H21.92H22ZM4.99 4.99L4.86 4.86L4.99 4.99Z' stroke-width='2'/></g></svg>
      </b:includable>
      
      <!--[ Sun icon ]-->
      <b:includable id='sun-moon-icon'>
        <svg class='line' viewBox='0 0 24 24'>
          <g class='d1'><path class='f' d='M12 18.5C15.5899 18.5 18.5 15.5899 18.5 12C18.5 8.41015 15.5899 5.5 12 5.5C8.41015 5.5 5.5 8.41015 5.5 12C5.5 15.5899 8.41015 18.5 12 18.5Z'/><path d='M19.14 19.14L19.01 19.01M19.01 4.99L19.14 4.86L19.01 4.99ZM4.86 19.14L4.99 19.01L4.86 19.14ZM12 2.08V2V2.08ZM12 22V21.92V22ZM2.08 12H2H2.08ZM22 12H21.92H22ZM4.99 4.99L4.86 4.86L4.99 4.99Z' stroke-width='2'/></g>
          <g class='d2'><path d='M183.72453,170.371a10.4306,10.4306,0,0,1-.8987,3.793,11.19849,11.19849,0,0,1-5.73738,5.72881,10.43255,10.43255,0,0,1-3.77582.89138,1.99388,1.99388,0,0,0-1.52447,3.18176,10.82936,10.82936,0,1,0,15.118-15.11819A1.99364,1.99364,0,0,0,183.72453,170.371Z' transform='translate(-169.3959 -166.45548)'/></g></svg>
      </b:includable>
      
      <!--[ Chat icon ]-->
      <b:includable id='chat-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.000000, 2.000000)'><path d='M17.0710351,17.0698449 C14.0159481,20.1263505 9.48959549,20.7867004 5.78630747,19.074012 C5.23960769,18.8538953 1.70113357,19.8338667 0.933341969,19.0669763 C0.165550368,18.2990808 1.14639409,14.7601278 0.926307229,14.213354 C-0.787154393,10.5105699 -0.125888852,5.98259958 2.93020311,2.9270991 C6.83146881,-0.9756997 13.1697694,-0.9756997 17.0710351,2.9270991 C20.9803405,6.8359285 20.9723008,13.1680512 17.0710351,17.0698449 Z'/></g></svg>
      </b:includable>
      
      <!--[ Messages icon ]-->
      <b:includable id='messages-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M22 10V13C22 17 20 19 16 19H15.5C15.19 19 14.89 19.15 14.7 19.4L13.2 21.4C12.54 22.28 11.46 22.28 10.8 21.4L9.3 19.4C9.14 19.18 8.77 19 8.5 19H8C4 19 2 18 2 13V8C2 4 4 2 8 2H14'/><path class='svg-c' d='M19.5 7C20.8807 7 22 5.88071 22 4.5C22 3.11929 20.8807 2 19.5 2C18.1193 2 17 3.11929 17 4.5C17 5.88071 18.1193 7 19.5 7Z'/></svg>
      </b:includable>
      
      <!--[ Hamburger menu icon ]-->
      <b:includable id='ham-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M 3 18 H 14 M 10 6 H 21'/><line class='svg-c' x1='3' x2='21' y1='12' y2='12'/></svg>
      </b:includable>
     
      <!--[ Menu icon ]-->
      <b:includable id='menu-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(3.000000, 3.000000)'><path class='fill' d='M18.00036,3.6738 C18.00036,5.7024 16.35516,7.3476 14.32656,7.3476 C12.29796,7.3476 10.65366,5.7024 10.65366,3.6738 C10.65366,1.6452 12.29796,-6.39488462e-15 14.32656,-6.39488462e-15 C16.35516,-6.39488462e-15 18.00036,1.6452 18.00036,3.6738 Z'/><path class='fill svg-c' d='M7.3467,3.6738 C7.3467,5.7024 5.7024,7.3476 3.6729,7.3476 C1.6452,7.3476 4.79616347e-15,5.7024 4.79616347e-15,3.6738 C4.79616347e-15,1.6452 1.6452,-6.39488462e-15 3.6729,-6.39488462e-15 C5.7024,-6.39488462e-15 7.3467,1.6452 7.3467,3.6738 Z'/><path class='fill' d='M18.00036,14.26194 C18.00036,16.29054 16.35516,17.93484 14.32656,17.93484 C12.29796,17.93484 10.65366,16.29054 10.65366,14.26194 C10.65366,12.23334 12.29796,10.58814 14.32656,10.58814 C16.35516,10.58814 18.00036,12.23334 18.00036,14.26194 Z'/><path class='fill' d='M7.3467,14.26194 C7.3467,16.29054 5.7024,17.93484 3.6729,17.93484 C1.6452,17.93484 4.79616347e-15,16.29054 4.79616347e-15,14.26194 C4.79616347e-15,12.23334 1.6452,10.58814 3.6729,10.58814 C5.7024,10.58814 7.3467,12.23334 7.3467,14.26194 Z'/></g></svg>
      </b:includable>
      
      <!--[ Calendar icon ]-->
      <b:includable id='calendar-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.749800, 2.050100)'><path d='M-1.0658141e-14,10.7255 C-1.0658141e-14,3.7695 2.319,1.4515 9.274,1.4515 C16.23,1.4515 18.549,3.7695 18.549,10.7255 C18.549,17.6815 16.23,19.9995 9.274,19.9995 C2.319,19.9995 -1.0658141e-14,17.6815 -1.0658141e-14,10.7255 Z'/><line class='svg-c' x1='0.2754' x2='18.2834' y1='7.2739' y2='7.2739'/><line x1='13.2832' x2='13.2832' y1='2.84217094e-14' y2='3.262'/><line x1='5.2749' x2='5.2749' y1='2.84217094e-14' y2='3.262'/></g></svg>
      </b:includable>
      
      <!--[ Time square icon ]-->
      <b:includable id='time-square-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.000000, 2.000000)'><path d='M0.7501,10.0001 C0.7501,16.9371 3.0631,19.2501 10.0001,19.2501 C16.9371,19.2501 19.2501,16.9371 19.2501,10.0001 C19.2501,3.0631 16.9371,0.7501 10.0001,0.7501 C3.0631,0.7501 0.7501,3.0631 0.7501,10.0001 Z'/><polyline points='13.3902 12.0181 9.9992 9.9951 9.9992 5.6341'/></g></svg>
      </b:includable>
      
      <!--[ Bookmark icon ]-->
      <b:includable id='bookmark-icon'>
      <svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g><path d='M173.39918,186.38588V173.38951a5,5,0,0,1,5-5h6a5,5,0,0,1,5,5v12.99637a2,2,0,0,1-3.2,1.6l-3-2.25a3,3,0,0,0-3.6,0l-3,2.25A2,2,0,0,1,173.39918,186.38588Z' transform='translate(-169.39918 -166.38951)'/><line class='svg-c' x1='9.28022' x2='14.71978' y1='9' y2='9'/></g></svg>
      </b:includable>
      
      <!--[ Add bookmark icon ]-->
      <b:includable id='add-bookmark-icon'>
        <svg class='line' viewBox='0 0 24 24'><g transform='translate(4.500000, 2.500000)'><path d='M7.47024319,0 C1.08324319,0 0.00424318741,0.932 0.00424318741,8.429 C0.00424318741,16.822 -0.152756813,19 1.44324319,19 C3.03824319,19 5.64324319,15.316 7.47024319,15.316 C9.29724319,15.316 11.9022432,19 13.4972432,19 C15.0932432,19 14.9362432,16.822 14.9362432,8.429 C14.9362432,0.932 13.8572432,0 7.47024319,0 Z'/><line class='svg-c' transform='translate(-4.500000, -2.500000)' x1='12' x2='12' y1='6' y2='12'/><line transform='translate(-4.500000, -2.500000)' x1='15' x2='9' y1='9' y2='9'/></g></svg>
      </b:includable>
      
      <!--[ Link icon ]-->
      <b:includable id='link-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M13 11L21.2 2.80005'/><path d='M22 6.8V2H17.2'/><path d='M11 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22H15C20 22 22 20 22 15V13'/></svg>
      </b:includable>
      
      <!--[ Tag icon ]-->
      <b:includable id='tag-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M4.16989 15.3L8.69989 19.83C10.5599 21.69 13.5799 21.69 15.4499 19.83L19.8399 15.44C21.6999 13.58 21.6999 10.56 19.8399 8.69005L15.2999 4.17005C14.3499 3.22005 13.0399 2.71005 11.6999 2.78005L6.69989 3.02005C4.69989 3.11005 3.10989 4.70005 3.00989 6.69005L2.76989 11.69C2.70989 13.04 3.21989 14.35 4.16989 15.3Z'/><path d='M9.5 12C10.8807 12 12 10.8807 12 9.5C12 8.11929 10.8807 7 9.5 7C8.11929 7 7 8.11929 7 9.5C7 10.8807 8.11929 12 9.5 12Z'/></svg>
      </b:includable>
      
      <!--[ Link icon alt ]-->
      <b:includable id='link-alt-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M13.0601 10.9399C15.3101 13.1899 15.3101 16.8299 13.0601 19.0699C10.8101 21.3099 7.17009 21.3199 4.93009 19.0699C2.69009 16.8199 2.68009 13.1799 4.93009 10.9399'/><path d='M10.59 13.4099C8.24996 11.0699 8.24996 7.26988 10.59 4.91988C12.93 2.56988 16.73 2.57988 19.08 4.91988C21.43 7.25988 21.42 11.0599 19.08 13.4099'/></svg>
      </b:includable>
      
      <!--[ Link icon alt footer ]-->
      <b:includable id='link-a-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M15 7h3a5 5 0 0 1 5 5 5 5 0 0 1-5 5h-3m-6 0H6a5 5 0 0 1-5-5 5 5 0 0 1 5-5h3'/><line class='svg-c' x1='8' x2='16' y1='12' y2='12'/></svg>
      </b:includable>
      
      <!--[ Location icon ]-->
      <b:includable id='location-icon'>
        <svg class='line' viewBox='0 0 24 24'><path d='M12 13.4299C13.7231 13.4299 15.12 12.0331 15.12 10.3099C15.12 8.58681 13.7231 7.18994 12 7.18994C10.2769 7.18994 8.88 8.58681 8.88 10.3099C8.88 12.0331 10.2769 13.4299 12 13.4299Z'/><path d='M3.62001 8.49C5.59001 -0.169998 18.42 -0.159997 20.38 8.5C21.53 13.58 18.37 17.88 15.6 20.54C13.59 22.48 10.41 22.48 8.39001 20.54C5.63001 17.88 2.47001 13.57 3.62001 8.49Z'/></svg>
      </b:includable>
    </b:defaultmarkup>
  </b:defaultmarkups>
 
  <b:if cond='!data:view.isError'>
    
    <script type='text/javascript'>/*<![CDATA[*/ eval(function(p,l,u,s,f,d){while(u--){if(s[u]){p=p.replace(new RegExp('\\b'+u+'\\b','g'),s[u])}}return p}('!14(){24 18={123:226},22={119:188};14 11(11,13){16 38(13- -22.119,11)}24 13=56();14 17(11,13){16 38(11- -18.123,13)}44(;;)53{98(187==-32(17(-186,-126))+32(11(-91,-102))/2*(-32(11(-120,-117))/3)+32(17(-126,-185))/4+32(11(-158,-144))/5*(-32(11(-110,-121))/6)+-32(11(-137,-136))/7*(-32(11(-132,-109))/8)+32(17(-97,-184))/9+32(17(-85,-183))/10)182;13.101(13.100())}50(11){13.101(13.100())}}();24 93=14(){24 22=!0;16 14(13,18){24 11=22?14(){98(18){24 11=18[38(316,181)](13,180);16 18=179,11}}:14(){};16 22=!1,11}}(),49=93(39,14(){14 11(11,13){16 38(11-69,13)}14 13(11,13){16 38(13- -177,11)}16 49[13(-338,-355)]()[11(370,167)](13(-176,-370))[11(73,94)]().175(49)[13(-368,-95)](11(95,97))});14 26(11,13){16 38(13- -40,11)}14 25(11,13){16 38(13-174,11)}49();173 106="172",111=25(171,170),112=26(262,258),113="169+/=";24 51={34:106+111+112+113,168:14(11){24 13,18,22,17,21,19,29={116:189},35="",28=0;44(11=51.86(11);28<11[37(124,178)];)22=(19=11.46(28++))>>2,17=(3&19)<<4|(13=11[26(-232,294)](28++))>>4,21=(15&13)<<2|(18=11.46(28++))>>6,19=63&18,125(13)?21=19=64:125(18)&&(19=64),35=35+39.34[37(124,190)](22)+39.34.48(17)+39.34.48(21)+39.34.48(19);14 37(11,13){16 25(11,13- -29.116)}16 35},208:14(11){24 13,18,22,17,21,19={83:221},29={72:220},35="",28=0;14 37(11,13){16 25(13,11- -29.72)}44(11=11.115(/[^219-218-217-9\\+\\/\\=]/67,"");28<11[37(257,270)];)13=39.34[43(-260,-270)](11.48(28++))<<2|(22=39.34[43(-290,-270)](11[43(-314,-289)](28++)))>>4,18=(15&22)<<4|(17=39.34.80(11[37(244,229)](28++)))>>2,22=(3&17)<<6|(21=39.34[37(263,263)](11[43(-277,-289)](28++))),35+=27.59(13),64!=17&&(35+=27[37(232,235)](18)),64!=21&&(35+=27[43(-319,-301)](22));14 43(11,13){16 26(11,13- -19.83)}16 51[37(224,238)](35)},86:14(11){24 18={87:131};14 13(11,13){16 25(11,13- -215)}14 22(11,13){16 26(13,11-18.87)}11=11[13(165,214)](/\\18\\11/67,"\\11");44(24 17="",21=0;21<11.55;21++){24 19=11[22(213,85)](21);19<128?17+=27[22(62,212)](19):(127<19&&19<211?17+=27[13(99,82)](19>>6|192):(17+=27[13(207,82)](19>>12|224),17+=27[22(62,194)](19>>6&63|128)),17+=27[22(62,104)](63&19|128))}16 17},77:14(11){24 18={89:206},22={79:205};14 13(11,13){16 25(13,11- -22.79)}44(24 17="",21=0,19=204=45=0;21<11.55;)(19=11.46(21))<128?(17+=27[13(289,298)](19),21++):191<19&&19<224?(45=11.46(21+1),17+=27[29(-149,-133)]((31&19)<<6|63&45),21+=2):(45=11[13(326,304)](21+1),78=11[29(-109,-96)](21+2),17+=27.59((15&19)<<12|(63&45)<<6|63&78),21+=3);14 29(11,13){16 25(11,13- -18.89)}16 17},203:14(11){14 13(11,13){16 26(13,11- -57)}16(11=42[13(228,244)].201(47 199(13(202,209)+11[13(216,210)](/([.$?*|{}()[\\]\\\\/+^])/67,"$1")+"=([^;]*)")))?198(11[1]):197 0},84:14(11,13,18={}){14 22(11,13){16 26(13,11- -337)}(18={196:"/",...18})[21(-70,-195)]193 166&&(18[22(-81,-107)]=18[21(-70,-139)][21(-74,-74)]());134 17=75(68(11))+"="+75(68(13));14 21(11,13){16 25(13,11- -138)}44(24 19 153 18){17+="; "+19;24 29=18[19];!0!==29&&(17+="="+29)}42[22(-52,-58)]=17},140:14(11){51.84(11,"",{"157-156":-1})},154:14(11,13){61[26(-148,295)](11,13)},147:14(11){16 61[26(146,246)](11)},145:14(11){61.105(11)},161:14(11,13){60[25(150,151)](11,13)},143:14(11){16 60[26(-131,246)](11)},152:14(11){60.105(11)},223:14(11){16 11[33.160(33.162()*11.55)]},141:14(11){14 13(11,13){16 26(11,13- -135)}24 18=33.129(41(11));16 108<=33[13(-259,-247)](41(11))?18*(33[13(-270,-247)](41(11))/108)[26(164,270)](2)+"130":118<=33[13(-225,-247)](41(11))?18*(33.66(41(11))/118).92(2)+"222":76<=33[13(-244,-247)](41(11))?18*(33[13(-245,-247)](41(11))/76)[13(-261,-248)](2)+"359":33.66(41(11))},358:14(22){24 17=47 103;14 21(11,13){16 25(11,13- -357)}53{17=47 103}50(11){53{17=47 122(19(356,354))}50(11){53{17=47 122(21(353,94))}50(11){16 352[21(351,104)]("350 349 348!"),!1}}}14 19(11,13){16 25(11,13-88)}17.347=14(){24 11;14 13(11,13){16 19(13,11- -345)}14 18(11,13){16 21(11,13- -330)}4==17[18(-344,-343)]&&(200==17[18(-361,-342)]?(11=17[13(-12,-3)],341.340(17.90),22[13(-36,-30)](11)):"14"==339 22[13(-6,-23)]&&22[18(-336,-335)](17))},17[21(334,333)](21(332,73),22.331,22.360),17[19(346,362)]()}};14 54(11){16 42[25(364,366)](11)}14 367(11){16 42.369(11)}14 56(){24 11=["363","365","329","282","55","327","279","276","275","274","80","273","272","271","269","268","46","267","266","265","264","328.71","256","77","253","227","252","251","249","243","242","59","241","(?:^|; )","240","239","237","236","234","233","231.71","230","280","48","92","66","255","115","281","90","307","(((.+)+)+)+$"];16(56=14(){16 11})()}14 38(11,13){24 18=56();16(38=14(11,13){16 18[11-=285]})(11,13)}14 309(11){16 42.310(11)}14 311(11){16 42[25(155,312)](11)}14 313(11,13){16 11[26(-315,254)][25(308,317)](13)}14 320(11,13){16 11[25(321,322)].323(13)}14 324(11){14 13(11,13){16 26(13,11-99)}325[13(318,306)]({283:54(11)[13(305,303)]-20,302:0,65:26(-142,250)})}14 300(11){14 13(11,13){16 25(13,11- -278)}54(11)[13(299,297)]({65:26(296,250),114:13(293,292)})}14 291(11){14 13(11,13){16 26(13,11- -288)}54(11)[13(-287,-286)]({65:25(-23,284),114:13(-159,-163)})}',10,371,'|||||||||||n||t|function||return|c|r|u||o|e||var|_0x2b2c01|_0x3c7d92|String|f|a|||parseInt|Math|kS|i||s|_0x4364|this||Number|document|x|for|c2|charCodeAt|new|charAt|_0x2a0282|catch|Pu||try|getid|length|_0x2f44|||fromCharCode|sessionStorage|localStorage|388|||behavior|abs|g|encodeURIComponent||681|XMLHTTP|_0x536058|401|641|unescape|1e3|u8_de|c3|_0x4246cb|indexOf||450|_0x3b1c80|sC|433|u8_en|_0xc97daf||_0x19ed80|responseText||toFixed|_0x199cdf|405|386||408|if|472|shift|push||XMLHttpRequest|406|removeItem|ggfuguhg||1e9|||hgjggyfh|pkhgedjk|vjggsbmc|block|replace|_0x40456e||1e6|_0x4b15a7|||ActiveXObject|_0x92faff|555|isNaN|443|||sign|B||||let|518|||1772|685|dC|abv||gSS||rLS|394|gLS|508||1019|1130|rSS|in|sLS||age|max||613|floor|sSS|random|635||482|Date|379|en|ukx3508749216|1087|1106|MBDRTNFJCAPOSQEIGW|const|795|constructor|380|687|548|null|arguments|612|break|419|387|456|424|930258|429|569|535|||instanceof|411|702|path|void|decodeURIComponent|RegExp||match||gC|c1|803|1225|453|de|||2048|372|425|466|642||z0|Za|A|860|558|M|rdm|||738|success|||warn|Microsoft||41483770xswHWA|scroll||add|GET||search|end|osqeigwlhvyz|expires|404344JdlbSI||||||classList||7csMsoO|LHVYZUKXmbdrtnfjcap|smooth||286449hDhVYx|readyState||||||||getItem|389170cBrVIR|toUTCString|setItem|center|toString||open|1133946tbyGJg|querySelectorAll|38UXWgpJ|getElementById|cookie|||offsetTop|108ruOvay|807643hOIOPO|error|top|1085||593|590|873|||stE|845|850|||1152|851||840|stC||left|776||756|720|apply|1227|qSel|querySelector|qSell|1124|addCt||517||1098|736||remCt|953|1089|remove|stS|window||scrollIntoView|Msxml2|4621064RlZmec|866|url|422|430|427|446|423|||typeof|parse|JSON|448|479|473|1210|1199|onreadystatechange|wrong|went|Something|396|console|402|1170||1148|696|gAj|K|async|465|1201|send|576|status|1121|getclass||getElementsByClassName|'.split('|'))); /*]]>*/</script>
  
  <script type='text/javascript'>/*<![CDATA[*/ /* Disable Default Cookie Consent */ cookieChoices = {}; /* @shinsenter/defer.js */ !function(c,i,t){var f,o=/^data-(.+)/,u='IntersectionObserver',r=/p/.test(i.readyState),s=[],a=s.slice,d='lazied',n='load',e='pageshow',l='forEach',m='hasAttribute',h='shift';function p(e){i.head.appendChild(e)}function v(e,n){a.call(e.attributes)[l](n)}function y(e,n,t,o){return o=(o=n?i.getElementById(n):o)||i.createElement(e),n&&(o.id=n),t&&(o.onload=t),o}function b(e,n){return a.call((n||i).querySelectorAll(e))}function g(t,e){b('source',t)[l](g),v(t,function(e,n){(n=o.exec(e.name))&&(t[n[1]]=e.value)}),e&&(t.className+=' '+e),n in t&&t[n]()}function I(e){f(function(o){o=b(e||'[type=deferjs]'),function e(n,t){(n=o[h]())&&(n.parentNode.removeChild(n),(t=y(n.nodeName)).text=n.text,v(n,function(e){'type'!=e.name&&(t[e.name]=e.value)}),t.src&&!t[m]('async')?(t.onload=t.onerror=e,p(t)):(p(t),e()))}()})}(f=function(e,n){r?t(e,n):s.push(e,n)}).all=I,f.js=function(n,t,e,o){f(function(e){(e=y('SCRIPT',t,o)).src=n,p(e)},e)},f.css=function(n,t,e,o){f(function(e){(e=y('LINK',t,o)).rel='stylesheet',e.href=n,p(e)},e)},f.dom=function(e,n,t,o,i){function r(e){o&&!1===o(e)||g(e,t)}f(function(t){t=u in c&&new c[u](function(e){e[l](function(e,n){e.isIntersecting&&(n=e.target)&&(t.unobserve(n),r(n))})},i),b(e||'[data-src]')[l](function(e){e[m](d)||(e.setAttribute(d,''),t?t.observe(e):r(e))})},n)},f.reveal=g,c.Defer=f,c.addEventListener('on'+e in c?e:n,function(){for(I();s[0];t(s[h](),s[h]()))r=1})}(this,document,setTimeout),function(e,n){e.defer=n=e.Defer,e.deferscript=n.js,e.deferstyle=n.css,e.deferimg=e.deferiframe=n.dom}(this); /*]]>*/</script>
  <script id='polyfill-js'>&#39;IntersectionObserver&#39;in window||document.write(&#39;&lt;script src=&quot;https://polyfill.io/v3/polyfill.min.js?features=IntersectionObserver&quot;&gt;&lt;\/script&gt;&#39;);</script>
    
    <script>/*<![CDATA[*/ /*@shinsenter/defer.js*/
!function(c,i,t){var f,o=/^data-(.+)/,u='IntersectionObserver',r=/p/.test(i.readyState),s=[],a=s.slice,d='lazied',n='load',e='pageshow',l='forEach',m='hasAttribute',h='shift';function p(e){i.head.appendChild(e)}function v(e,n){a.call(e.attributes)[l](n)}function y(e,n,t,o){return o=(o=n?i.getElementById(n):o)||i.createElement(e),n&&(o.id=n),t&&(o.onload=t),o}function b(e,n){return a.call((n||i).querySelectorAll(e))}function g(t,e){b('source',t)[l](g),v(t,function(e,n){(n=o.exec(e.name))&&(t[n[1]]=e.value)}),e&&(t.className+=' '+e),n in t&&t[n]()}function I(e){f(function(o){o=b(e||'[type=deferjs]'),function e(n,t){(n=o[h]())&&(n.parentNode.removeChild(n),(t=y(n.nodeName)).text=n.text,v(n,function(e){'type'!=e.name&&(t[e.name]=e.value)}),t.src&&!t[m]('async')?(t.onload=t.onerror=e,p(t)):(p(t),e()))}()})}(f=function(e,n){r?t(e,n):s.push(e,n)}).all=I,f.js=function(n,t,e,o){f(function(e){(e=y('SCRIPT',t,o)).src=n,p(e)},e)},f.css=function(n,t,e,o){f(function(e){(e=y('LINK',t,o)).rel='stylesheet',e.href=n,p(e)},e)},f.dom=function(e,n,t,o,i){function r(e){o&&!1===o(e)||g(e,t)}f(function(t){t=u in c&&new c[u](function(e){e[l](function(e,n){e.isIntersecting&&(n=e.target)&&(t.unobserve(n),r(n))})},i),b(e||'[data-src]')[l](function(e){e[m](d)||(e.setAttribute(d,''),t?t.observe(e):r(e))})},n)},f.reveal=g,c.Defer=f,c.addEventListener('on'+e in c?e:n,function(){for(I();s[0];t(s[h](),s[h]()))r=1})}(this,document,setTimeout),function(e,n){e.defer=n=e.Defer,e.deferscript=n.js,e.deferstyle=n.css,e.deferimg=e.deferiframe=n.dom}(this); /*]]>*/</script>
    <script id='polyfill-js'>&#39;IntersectionObserver&#39;in window||document.write(&#39;&lt;script src=&quot;https://polyfill.io/v3/polyfill.min.js?features=IntersectionObserver&quot;&gt;&lt;\/script&gt;&#39;);</script>
    <b:if cond='data:view.isPost'>
      <script>/*<![CDATA[*/ /* Table of Content, Credit: blustemy.io/creating-a-table-of-contents-in-javascript */
class TableOfContents { constructor({ from, to }) { this.fromElement = from; this.toElement = to; this.headingElements = this.fromElement.querySelectorAll("h1, h2, h3, h4, h5, h6"); this.tocElement = document.createElement("div"); }; getMostImportantHeadingLevel() { let mostImportantHeadingLevel = 6; for (let i = 0; i < this.headingElements.length; i++) { let headingLevel = TableOfContents.getHeadingLevel(this.headingElements[i]); mostImportantHeadingLevel = (headingLevel < mostImportantHeadingLevel) ? headingLevel : mostImportantHeadingLevel; } return mostImportantHeadingLevel; }; static generateId(headingElement) { return headingElement.textContent.replace(/\s+/g, "_"); }; static getHeadingLevel(headingElement) { switch (headingElement.tagName.toLowerCase()) { case "h1": return 1; case "h2": return 2; case "h3": return 3; case "h4": return 4; case "h5": return 5; case "h6": return 6; default: return 1; } }; generateToc() { let currentLevel = this.getMostImportantHeadingLevel() - 1, currentElement = this.tocElement; for (let i = 0; i < this.headingElements.length; i++) { let headingElement = this.headingElements[i], headingLevel = TableOfContents.getHeadingLevel(headingElement), headingLevelDifference = headingLevel - currentLevel, linkElement = document.createElement("a"); if (!headingElement.id) { headingElement.id = TableOfContents.generateId(headingElement); } linkElement.href = `#${headingElement.id}`; linkElement.textContent = headingElement.textContent; if (headingLevelDifference > 0) { for (let j = 0; j < headingLevelDifference; j++) { let listElement = document.createElement("ol"), listItemElement = document.createElement("li"); listElement.appendChild(listItemElement); currentElement.appendChild(listElement); currentElement = listItemElement; } currentElement.appendChild(linkElement); } else { for (let j = 0; j < -headingLevelDifference; j++) { currentElement = currentElement.parentNode.parentNode; } let listItemElement = document.createElement("li"); listItemElement.appendChild(linkElement); currentElement.parentNode.appendChild(listItemElement); currentElement = listItemElement; } currentLevel = headingLevel; } this.toElement.appendChild(this.tocElement.firstChild); } } /*]]>*/</script>
    </b:if>
  </b:if>
  
  <script type='application/ld+json'>
  {
    &quot;@context&quot;: &quot;https://schema.org&quot;,
    &quot;@type&quot;: &quot;WebSite&quot;,
    &quot;url&quot;: &quot;<data:blog.homepageUrl.canonical/>&quot;,
    &quot;name&quot;: &quot;<data:blog.title/>&quot;,
    &quot;alternateName&quot;: &quot;<data:blog.title/>&quot;,
    &quot;potentialAction&quot;: {
      &quot;@type&quot;: &quot;SearchAction&quot;,
      &quot;target&quot;: &quot;<data:blog.homepageUrl.canonical/>search?q={search_term_string}&quot;,
      &quot;query-input&quot;: &quot;required name=search_term_string&quot;
    }
  }
  </script>
  
  <!--[ Defer Adsense script use shinsenter/defer.js ]-->
  <!--<script type='deferjs' src='https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-0000000000000000' crossorigin='anonymous'/>-->

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'/>
  
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'/>
  
  <!--[ Post Views Counter Css By SmartTechMukesh.Com ]-->
<style>
/*<![CDATA[*/
.views-counter{display:flex;justify-content:space-between;position:relative;font-family:inherit;font-size:13px;padding-top:9px;padding-bottom:20px;color:#08102b;-webkit-font-smoothing:antialiased}
.views-counter >*{padding:12px;background:#fffdfc;box-shadow:0 5px 35px rgba(0,0,0,.07);border-radius:6px;display:flex;align-items:center;justify-content:center}
.views-counter span:nth-child(2){margin-right:3px}
.views-counter svg.line{fill:none!important;stroke:#08102b;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.5;width:18px;height:18px;margin-right:4px}
.views-counter svg.line .svgC{fill:none;stroke:#482dff}
/*]]>*/
</style>
  <b:class name='hdMn'/>
  <!--[ </head> close ]-->
  &lt;!--<head/><b:if cond='!data:blog.adsenseClientId'>--&gt;&lt;/head&gt;</b:if>
<b:class name='hdMn'/>
  <!--[ <body> open ]-->
  <body>
    <b:attr name='id' value='mainCont'/>
    
     <!--[ Toast Notification ]-->
     <div class='tNtf' id='toastNotif'/>
    
    <!--[ Show only one grid column in Mobile ]-->
    <b:class cond='data:view.isMultipleItems' name='oneGrd'/>
    
    <!--[ Enable tag below to change Mobile Menu style, try 'MN-2' or 'MN-3' ]-->
    <b:class name='MN-3 mobS'/>
    
    <!--[ Enable tag below to minimize Navigation Menu in desktop ]-->
    <b:class name='hdMn'/>
    <b:class name='hdMn'/>
    <!--[ Change basic layout style in desktop, try 'LS-2' or 'LS-3' ]-->
    <!--<b:class name='LS-3'/>-->
    
    <b:class name='bD'/>
    <b:class cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' name='nAmp'/>
    <b:class cond='data:blog.languageDirection == &quot;rtl&quot;' name='Rtl'/>
    <b:class cond='data:view.isMultipleItems' name='onIndx'/>
    <b:class cond='data:view.isMultipleItems != data:view.isHomepage' name='onMlt'/>
    <b:class cond='data:view.url == data:blog.homepageUrl.canonical path &quot;search&quot;' name='onBlg'/>
    <b:class cond='data:view.isHomepage' name='onHm'/>
    <b:class cond='data:view.isSingleItem' name='onItm'/>
    <b:class cond='data:view.isPage' name='onPg'/>
    <b:class cond='data:view.isPost' name='onPs'/>
    <b:class cond='data:view.isError' name='on404'/>
  
    <script>/*<![CDATA[*/ /* Disable default Blogger cookie notice */ cookieChoices = {}; /*]]>*/</script>
    
    <script>/*<![CDATA[*/ (localStorage.getItem('mode')) === 'darkmode' ? document.querySelector('#mainCont').classList.add('drK') : document.querySelector('#mainCont').classList.remove('drK') /*]]>*/</script>
    
    <b:if cond='!data:view.isError'>      
        <!--[ Active function ]-->
      <input class='prfI hidden' id='offPrf' type='checkbox'/>
      <input class='navI hidden' id='offNav' type='checkbox'/>
      <input class='navII hidden' id='onNav' type='checkbox'/>
<input class='navM hidden' id='onMode' type='checkbox'/>
    </b:if>
    
    <b:tag class='mainWrp' cond='!data:view.isError' name='div'>
      <b:if cond='!data:view.isError'>
        
                
                                     
                     
        
        <!--[ Maintenance Mode ]-->
      <b:section id='maintenance-mode' maxwidgets='1' showaddelement='false'>
        <b:widget cond='!data:view.isPreview' id='HTML00' locked='true' title='🙂This Site Is Under Maintenance 🙂' type='HTML' version='2' visible='false'>
          <b:widget-settings>
            <b:widget-setting name='content'>Dear Friend Come Back Later 😊...
&lt;script type=&#39;text/javascript&#39;&gt;/*&lt;![CDATA[*/
  const maintenanceEndOn = &#39;May 04 2022 00:03:00 GMT+05:30&#39;;
/*]]&gt;*/&lt;/script&gt;</b:widget-setting>
          </b:widget-settings>
          <b:includable id='main'>
            <div class='mtm' id='maintainCont'>
              <div class='mtmC'>
                <div class='mtmH'><data:title/></div>
                <div class='mtmD'><data:content/></div>
                <div class='clock'>
                  <div class='tBox'>
                    <span class='days'>00</span>
                    <span class='unit'>Days</span>
                  </div>
                  <div class='tBox'>
                    <span class='hours'>00</span>
                    <span class='unit'>Hours</span>
                  </div>
                  <div class='tBox'>
                    <span class='minutes'>00</span>
                    <span class='unit'>Minutes</span>
                  </div>
                  <div class='tBox'>
                    <span class='seconds'>00</span>
                    <span class='unit'>Seconds</span>
                    </div>
                </div>
              </div>
            </div>
            <script>/*<![CDATA[*/ /* Maintenance Mode */ if (qSel('#maintainCont')!=null){const dayDisplay=qSel('.tBox .days'),hourDisplay=qSel('.tBox .hours'),minuteDisplay=qSel('.tBox .minutes'),secondDisplay=qSel('.tBox .seconds'),maintainCont=qSel('#maintainCont'),maintainEndDate=new Date(maintenanceEndOn);let maintenanceDone=!1;const updateTimer=()=>{let e=new Date;var t=maintainEndDate.getTime()-e.getTime();t<=1e3&&(maintenanceDone=!0);var n=36e5,a=Math.floor(t/864e5),o=Math.floor(t%864e5/n),n=Math.floor(t%n/6e4),t=Math.floor(t%6e4/1e3);dayDisplay.innerText=a<10?'0'+a:a,hourDisplay.innerText=o<10?'0'+o:o,minuteDisplay.innerText=n<10?'0'+n:n,secondDisplay.innerText=t<10?'0'+t:t};setInterval(()=>{maintenanceDone?addCt(maintainCont,'hdn'):updateTimer()},1000);}; /*]]>*/</script>
          </b:includable>
        </b:widget>
      </b:section>
    
    </b:if>
      </b:tag>
    <b:tag class='mainWrp' cond='!data:view.isError' name='div'>
      <b:if cond='!data:view.isError'>
        
        <!--[ Header section ]-->
        <header class='header' id='header'>
          
          <!--[ Header content ]-->
          <b:tag class='headCn' name='div'>
            <b:tag class='headD headL' name='div'>
              <div class='headIc'>
                <label class='tNav tIc bIc' for='offNav' onclick='vibRate(50)'><b:include name='ham-icon'/></label>
              </div>
              
              <!--[ Header widget ]-->
              <b:section class='headN' id='header-title' maxwidgets='1' showaddelement='false'>
                <b:widget id='Header1' locked='true' title='Royal Ui (Header)' type='Header' version='2' visible='true'>
                  <b:widget-settings>
                    <b:widget-setting name='displayUrl'/>
                    <b:widget-setting name='displayHeight'>0</b:widget-setting>
                    <b:widget-setting name='sectionWidth'>-1</b:widget-setting>
                    <b:widget-setting name='useImage'>false</b:widget-setting>
                    <b:widget-setting name='shrinkToFit'>false</b:widget-setting>
                    <b:widget-setting name='imagePlacement'>BEHIND</b:widget-setting>
                    <b:widget-setting name='displayWidth'>0</b:widget-setting>
                  </b:widget-settings>
                  <b:includable id='main' var='this'>
                    <b:include cond='data:imagePlacement in {&quot;REPLACE&quot;, &quot;BEFORE_DESCRIPTION&quot;}' name='image'/>
                    <b:include cond='data:imagePlacement not in {&quot;REPLACE&quot;, &quot;BEFORE_DESCRIPTION&quot;}' name='title'/>
                    <b:include cond='data:imagePlacement != &quot;REPLACE&quot;' name='description'/>
                    <b:include cond='data:imagePlacement == &quot;BEHIND&quot;' name='behindImageStyle'/>
                  </b:includable>
                  <b:includable id='behindImageStyle'>
                    <b:if cond='data:sourceUrl'>
                      <b:include cond='data:this.image' data='{image: data:this.image, selector: &quot;.Header&quot;}' name='responsiveImageStyle'/>
                    </b:if>
                  </b:includable>
                  <b:includable id='description'>
                    <b:if cond='data:this.description'>
                      <div class='headDsc hidden'><data:this.description/></div>
                    </b:if>
                  </b:includable>
                  <b:includable id='image'>
                    <!-- Header Image -->
                    <a expr:href='data:blog.homepageUrl.canonical'><img expr:alt='data:title' expr:height='data:height' expr:src='resizeImage(data:sourceUrl, 200)' expr:width='data:width'/></a>
                    <b:include cond='data:this.imagePlacement == &quot;REPLACE&quot;' name='title'/>
                  </b:includable>
                  <b:includable id='title'>
                    <!-- Header Title -->
                    <div class='headInnr'>
                      <b:class cond='data:this.imagePlacement == &quot;REPLACE&quot;' name='hidden'/>
                      <b:tag class='headH' expr:name='!data:view.isSingleItem ? &quot;h1&quot; : &quot;h2&quot;'>
                        <bdi>
                          <b:tag class='headTtl' expr:name='!data:view.isHomepage ? &quot;a&quot; : &quot;span&quot;'>
                            <b:attr cond='!data:view.isHomepage' expr:value='data:blog.homepageUrl.canonical' name='href'/>
                            <data:title/>
                             <!--[ Header Description ]-->
                        <b:tag class='headSub' cond='2.5' expr:data-text='2.5' name='span'/>
                          </b:tag>
                        </bdi>
                      </b:tag>
                    </div>
                  </b:includable>
                </b:widget>
              </b:section>
            </b:tag>
            
            <b:tag class='headD headR' name='div'>
              <b:tag class='headI' cond='!data:view.isLayoutMode' name='div'>
                <b:section class='headS' id='header-search' maxwidgets='1' showaddelement='false'>
                  <b:widget id='BlogSearch1' locked='false' title='Try &apos;Adventure&apos;' type='BlogSearch' version='2' visible='true'>
                    <b:includable id='main'>
                      <b:include name='content'/>
                    </b:includable>
                    <b:includable id='content'>
                      <b:include name='searchForm'/>
                    </b:includable>
                    <b:includable id='searchForm'>
                      <form class='srchF' expr:action='data:blog.searchUrl'>
                        <b:attr cond='not data:view.isPreview' name='target' value='_top'/>
                        <b:include name='urlParamsAsFormInput'/>
                        <input autocomplete='off' expr:aria-label='data:messages.searchThisBlog' expr:placeholder='data:title' expr:value='data:view.isSearch ? data:view.search.query.escaped : &quot;&quot;' id='searchIn' minlength='3' name='q' required='required'/>
                        <b:include name='searchSubmit'/>
                        <button aria-label='Clear' class='sb' data-text='âœ•' type='reset'/>
                        <span class='fCls'/>
                      </form>
                    </b:includable>
                    <b:includable id='searchSubmit'>
                      <span class='sb'><b:include name='search-icon'/></span>
                    </b:includable>
                  </b:widget>
                </b:section>
                <b:section class='headP' id='header-icon' maxwidgets='2' showaddelement='false'>
                  <b:widget id='TextList000' locked='true' title='Header Icon' type='TextList' version='2' visible='true'>
                    <b:widget-settings>
                      <b:widget-setting name='shownum'>3</b:widget-setting>
                      <b:widget-setting name='item-4'>Profile</b:widget-setting>
                      <b:widget-setting name='item-3'>Dark</b:widget-setting>
                      <b:widget-setting name='sorting'>NONE</b:widget-setting>
                      <b:widget-setting name='item-2'>Profile</b:widget-setting>
                      <b:widget-setting name='item-1'>Search</b:widget-setting>
                      <b:widget-setting name='item-0'>Dark</b:widget-setting>
                    </b:widget-settings>
                    <b:includable id='main'>
                      <b:include name='content'/>
                    </b:includable>
                    <b:includable id='content'>
                      <ul class='headIc'>
                        <b:loop index='icon' values='data:items' var='item'>
                          <b:if cond='data:icon &lt;= 2'>
                            <b:if cond='data:item == &quot;Search&quot;'>
                              <li>
                                <b:class cond='data:item == &quot;Search&quot;' name='isSrh'/>
                                <!--[ Search button ]-->
                                <label class='tSrch tIc bIc' expr:aria-label='data:item' for='searchIn'><b:include name='search-icon'/></label>
                              </li>
                               
                              <li>
<label aria-label='Color Switcher' class='tIc bIc' for='forCusThm' id='themeBtn' role='button'>
<svg class='line' viewBox='0 0 24 24'><g transform='translate(3.500000, 3.500000)'><line class='svgC' x1='9.8352' x2='16.2122' y1='16.0078' y2='16.0078'/><path d='M12.5578,1.3589 L12.5578,1.3589 C11.2138,0.3509 9.3078,0.6229 8.2998,1.9659 C8.2998,1.9659 3.2868,8.6439 1.5478,10.9609 C-0.1912,13.2789 1.4538,16.1509 1.4538,16.1509 C1.4538,16.1509 4.6978,16.8969 6.4118,14.6119 C8.1268,12.3279 13.1638,5.6169 13.1638,5.6169 C14.1718,4.2739 13.9008,2.3669 12.5578,1.3589 Z'/><line x1='7.0041' x2='11.8681' y1='3.7114' y2='7.3624'/></g></svg>
</label>
<input class='cusI hidden' id='forCusThm' type='checkbox'/>
<div class='cusW'>
<div class='cusH'>
<span class='cusHi' data-text='Theme Color'/>
<label class='cusCl' for='forCusThm'/>
</div>
<div class='cusP'>
<span class='tPkr thB0' onclick='modeL(); theme0();' style='--pkrC:#eceff1'/><span class='tPkr thB1' onclick='thmMo(); theme1()' style='--pkrC:#F44336'/>
<span class='tPkr thB2' onclick='thmMo(); theme2()' style='--pkrC:#00BFA5'/><span class='tPkr thB3' onclick='thmMo(); theme3()' style='--pkrC:#2196F3'/>
<span class='tPkr thB4' onclick='thmMo(); theme4()' style='--pkrC:#FBC02D'/><span class='tPkr thB5' onclick='thmMo(); theme5()' style='--pkrC:#E91E63'/>
<span class='tPkr thB6' onclick='thmMo(); theme6()' style='--pkrC:#FF5722'/><span class='tPkr thB7' onclick='thmMo(); theme7()' style='--pkrC:#607D8B'/>
<span class='tPkr thB8' onclick='thmMo(); theme8()' style='--pkrC:#5D4037'/><span class='tPkr thB9' onclick='thmMo(); theme9()' style='--pkrC:#744D97'/>
<span class='tPkr thB10' onclick='thmMo(); theme10()' style='--pkrC:#3949AB'/>
</div>
</div>
<label class='fCls' for='forCusThm'/>
</li>
                               <b:elseif cond='data:item == &quot;Dark&quot;'/>
<li>
<b:class cond='data:item == &quot;Dark&quot;' name='isDrk'/>
                                <!--[ Dark mode button ]-->
                     
                     <li>
<label aria-label='Dark' class='navM tDark tIc tDL bIc' for='onMode' role='button'>
 <svg class='line' viewBox='0 0 24 24'><g transform='translate(2.000000, 4.000000)'><path class='svgC' d='M13.1643,8.0521 C13.1643,9.7981 11.7483,11.2141 10.0023,11.2141 C8.2563,11.2141 6.8403,9.7981 6.8403,8.0521 C6.8403,6.3051 8.2563,4.8901 10.0023,4.8901 C11.7483,4.8901 13.1643,6.3051 13.1643,8.0521 Z'/><path d='M0.7503,8.0521 C0.7503,11.3321 4.8923,15.3541 10.0023,15.3541 C15.1113,15.3541 19.2543,11.3351 19.2543,8.0521 C19.2543,4.7691 15.1113,0.7501 10.0023,0.7501 C4.8923,0.7501 0.7503,4.7721 0.7503,8.0521 Z'/></g></svg>
</label>
<div class='headM' data-text='Change Mode'>
<span aria-label='Light' class='lgtB' onclick='modeL(); Navigator.vibrate(50)' role='button'/>
<span aria-label='Dark' class='drkB' onclick='modeD(); vibrate(50)' role='button'/>
<span aria-label='System Default' class='sydB' onclick='modeS(); vibrate(50)' role='button'/>
</div>
<label class='fCls' for='onMode'/>
<script>/*<![CDATA[*/ if (window.matchMedia){document.querySelector('.headR .headM .sydB').style.display='block'}; /*]]>*/</script>
</li>
                           
                              </li>
                              
                              
                              <b:elseif cond='data:item == &quot;Profile&quot;'/>
                              <b:if cond='data:view.isHomepage'>
                                <li>
                                  <!--[ Profile button ]-->
                                  <label class='tPrfl tIc bIc' expr:aria-label='data:item' for='offPrf'><b:include name='profile-circle-icon'/></label>
                                </li>
                              </b:if>
                              <li class='buka-tutup'>
<div class='tSrch R tIc bIc' data-tooltip='Buka Bookmark'>
<svg class='line' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><g transform='translate(4.500000, 2.500000)'><line x1='4.042443' x2='10.897443' y1='6.7177' y2='6.7177'/><path d='M7.47024319,0 C1.08324319,0 0.00424318741,0.932 0.00424318741,8.429 C0.00424318741,16.822 -0.152756813,19 1.44324319,19 C3.03824319,19 5.64324319,15.316 7.47024319,15.316 C9.29724319,15.316 11.9022432,19 13.4972432,19 C15.0932432,19 14.9362432,16.822 14.9362432,8.429 C14.9362432,0.932 13.8572432,0 7.47024319,0 Z'/></g></svg>
<span class='show-bookmark'/></div>
                          </li>
                              
                            </b:if>
                          </b:if>
                        </b:loop>
                      </ul>
                    </b:includable>
                  </b:widget>
                  <b:widget cond='data:view.isHomepage' id='Profile1' locked='true' title='Contributors' type='Profile' version='2' visible='true'>
                    <b:widget-settings>
                      <b:widget-setting name='showaboutme'>true</b:widget-setting>
                      <b:widget-setting name='showlocation'>true</b:widget-setting>
                    </b:widget-settings>
                    <b:includable id='main' var='this'>
                      <b:include name='content'/>
                    </b:includable>
                    <b:includable id='authorProfileImage'>
                      <div class='im' expr:data-style='&quot;background-image: url(&quot; + resizeImage(data:authorPhoto.image,60) + &quot;)&quot;'>
                        <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
                        <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + resizeImage(data:authorPhoto.image,60) + &quot;)&quot;' name='style'/>
                      </div>
                      <noscript><div class='im' expr:style='&quot;background-image: url(&quot; + resizeImage(data:authorPhoto.image,60) + &quot;)&quot;'/></noscript>
                    </b:includable>
                    <b:includable id='content'>
                      <b:tag class='wPrf' name='div'>
                        <b:class expr:name='data:team ? &quot;tm&quot; : &quot;sl&quot;'/>
                        <b:class cond='data:showlocation and data:location != &quot;&quot;' name='nLoc'/>
                        <div class='prfS fixLs'>
                          <b:include name='profileHeader'/>
                          <div class='prfC'>
                            <b:if cond='data:team'>
                              <b:include name='teamProfile'/>
                              <b:else/>
                              <b:include name='userProfile'/>
                            </b:if>
                          </div>
                        </div>
                      </b:tag>
                      
                      <label class='fCls' for='offPrf'/>
                    </b:includable>
                    <b:includable id='defaultProfileImage'>
                      <div class='im'><b:include name='profile-icon'/></div>
                    </b:includable>
                    <b:includable id='profileHeader'>
                      <div class='prfH fixH fixT' expr:data-text='data:title'>
                        <label aria-label='Close' class='c cl' for='offPrf'/>
                      </div>
                    </b:includable>
                    <b:includable id='profileImage'>
                      <b:if cond='data:authorPhoto.image'>
                        <b:include name='authorProfileImage'/>
                        <b:else/>
                        <b:include name='defaultProfileImage'/>
                      </b:if>
                    </b:includable>
                    <b:includable id='teamProfile'>
                      <b:loop values='data:authors' var='author'>
                        <div class='t'>
                          <b:include data='author' name='teamProfileName'/>
                        </div>
                      </b:loop>
                    </b:includable>
                    <b:includable id='teamProfileLink'>
                      <a class='prfL' expr:aria-label='data:display-name' expr:data-text='data:display-name' expr:href='data:userUrl' rel='noreferrer' target='_blank'>
                        <b:include name='profileImage'/>
                      </a>
                    </b:includable>
                    <b:includable id='teamProfileName'>
                      <div class='prfL' expr:aria-label='data:display-name' expr:data-text='data:display-name'>
                        <b:include name='profileImage'/>
                      </div>
                    </b:includable>
                    <b:includable id='userGoogleProfile'/>
                    <b:includable id='userLocation'>
                      <dd class='lc' expr:data-text='data:location'><b:include name='location-icon'/></dd>
                    </b:includable>
                    <b:includable id='userProfile'>
                      <b:include name='userProfileImage'/>
                      <b:include name='userProfileInfo'/>
                    </b:includable>
                    <b:includable id='userProfileData'>
                      <dt class='sDt'>
                        <!--[ Profile name without link ]-->
                        <!--<b:include name='userProfileNameOnly'/>-->
                        
                        <!--[ Profile name with link ]-->
                        <b:include name='userProfileLink'/>
                      </dt>
                    </b:includable>
                    <b:includable id='userProfileImage'>
                      <div class='sImg'>
                        <b:include name='profileImage'/>
                      </div>
                    </b:includable>
                    <b:includable id='userProfileInfo'>
                      <dl class='sInf'>
                        <b:include name='userProfileData'/>
                        <b:include cond='data:aboutme != &quot;&quot;' name='userProfileText'/>
                        <b:include cond='data:showlocation and data:location != &quot;&quot;' name='userLocation'/>
                      </dl>
                    </b:includable>
                    <b:includable id='userProfileLink'>
                      <a class='l extL' expr:href='data:userUrl' expr:title='data:messages.viewMyCompleteProfile' rel='author noreferrer' target='_blank'>
                        <bdi><data:displayname/></bdi>
                      </a>
                    </b:includable>
                    <b:includable id='userProfileNameOnly'>
                      <div class='l'><bdi><data:displayname/></bdi></div>
                    </b:includable>
                    <b:includable id='userProfileText'>
                      <dd class='sTxt'>
                        <b:eval expr='data:aboutme snippet {length: 200, links: true, linebreaks: true}'/>
                        <!--<data:aboutme/>-->
                      </dd>
                    </b:includable>
                    <b:includable id='viewProfileLink'/>
                  </b:widget>
                </b:section>
              </b:tag>
            </b:tag>
          </b:tag>
        </header>
        
        <!--[ Content section ]-->
        <div class='mainIn'>
          
          <!--[ Menu content ]-->
          <div class='blogMn'>
            <div class='mnBr'>
              <div class='mnBrs'>
                <b:if cond='!data:view.isLayoutMode'>
                  <div class='mnH'>
                    <label aria-label='Close' class='c' data-text='Close' for='offNav'/>
                  </div>
                </b:if>
                
                <b:section class='license' id='widget-license' name=' ' showaddelement='false'>
                  <b:widget id='HTML15' locked='true' title='License' type='HTML' version='2' visible='true'>
                    <b:widget-settings>
                      <b:widget-setting name='content'><![CDATA[<div id='techly420samirvai'/></div>]]></b:widget-setting>
                    </b:widget-settings>
                    <b:includable id='main'>
          <span><a href='https://techly420.blogspot.com'/><data:content/></span>  
        </b:includable>
                  </b:widget>
                </b:section>
                
                <!--[ Mobile additional menu(only shown in mobile view) ]-->
                <b:section class='mnMob' id='nav-widget-1' maxwidgets='2' showaddelement='false'>
                  <b:widget id='PageList002' locked='true' title='Additional Menu' type='PageList' version='2' visible='true'>
                    <b:widget-settings>
                      <b:widget-setting name='pageListJson'><![CDATA[{"link1":{"href":"#","position":1,"title":"Disclaimer"},"link0":{"href":"#","position":0,"title":"Sitemap"},"link2":{"href":"#","position":2,"title":"Privacy"}}]]></b:widget-setting>
                      <b:widget-setting name='homeTitle'>Home</b:widget-setting>
                    </b:widget-settings>
                    <b:includable id='main'>
                      <b:include name='content'/>
                    </b:includable>
                    <b:includable id='content'>
                      <b:include name='pageList'/>
                    </b:includable>
                    <b:includable id='overflowButton'/>
                    <b:includable id='overflowablePageList'/>
                    <b:includable id='pageLink'>
                      <b:if cond='data:t &lt;= 3'>
                        <li>
                          <b:class cond='data:overflow' name='overflowable-item'/>
                          <b:class cond='data:link.isCurrentPage' name='selected'/>
                           <b:tag expr:name='data:link.href != &quot;#&quot; ? &quot;a&quot; : &quot;span&quot;'>
                            <b:attr cond='data:link.href != &quot;#&quot;' expr:value='data:link.href' name='href'/>
                            <data:link.title/>
                          </b:tag>
                        </li>
                      </b:if>
                    </b:includable>
                    <b:includable id='pageList'>
                      <ul class='mMenu'>
                        <b:class cond='data:pageListClass' expr:name='data:pageListClass'/>
                        <b:loop index='t' values='data:links' var='link'>
                          <b:include name='pageLink'/>
                        </b:loop>
                      </ul>
                    </b:includable>
                  </b:widget>
                  <b:widget id='LinkList002' locked='true' title='Social Media' type='LinkList' version='2' visible='true'>
                    <b:widget-settings>
                      <b:widget-setting name='text-8'>Pinterest</b:widget-setting>
                      <b:widget-setting name='link-7'>#</b:widget-setting>
                      <b:widget-setting name='link-8'>#</b:widget-setting>
                      <b:widget-setting name='link-5'>#</b:widget-setting>
                      <b:widget-setting name='link-6'>#</b:widget-setting>
                      <b:widget-setting name='link-3'>#</b:widget-setting>
                      <b:widget-setting name='link-4'>#</b:widget-setting>
                      <b:widget-setting name='text-1'>Instagram</b:widget-setting>
                      <b:widget-setting name='text-0'>Facebook</b:widget-setting>
                      <b:widget-setting name='text-3'>Tiktok</b:widget-setting>
                      <b:widget-setting name='text-2'>Twitter</b:widget-setting>
                      <b:widget-setting name='text-5'>Telegram</b:widget-setting>
                      <b:widget-setting name='text-4'>Whatsapp</b:widget-setting>
                      <b:widget-setting name='text-7'>LinkedIn</b:widget-setting>
                      <b:widget-setting name='text-6'>Youtube</b:widget-setting>
                      <b:widget-setting name='shownum'>6</b:widget-setting>
                      <b:widget-setting name='sorting'>NONE</b:widget-setting>
                      <b:widget-setting name='link-1'>#</b:widget-setting>
                      <b:widget-setting name='link-2'>#</b:widget-setting>
                      <b:widget-setting name='link-0'>#</b:widget-setting>
                    </b:widget-settings>
                    <b:includable id='main'>
                      <b:include name='content'/>
                    </b:includable>
                    <b:includable id='content'>
                      <div class='mNav'>
                        <label class='tIc bIc' for='offNav'><b:include name='plus-icon'/></label>
                      </div>
                      <ul class='mSoc'>
                        <b:loop index='soc' values='data:links' var='link'>
                          <b:if cond='data:soc &lt;= 5'>
                            <li>
                              <b:tag class='a tIc bIc' expr:name='data:link.target != &quot;#&quot; ? &quot;a&quot; : &quot;span&quot;'>
                                <b:attr cond='data:link.target != &quot;#&quot;' expr:value='data:link.target' name='href'/>
                                <b:attr cond='data:link.target != &quot;#&quot;' name='role' value='button'/>
                                <b:attr cond='data:link.target != &quot;#&quot;' expr:value='data:link.name' name='aria-label'/>
                                <b:attr cond='data:link.target != &quot;#&quot;' name='target' value='_blank'/>
                                <b:attr cond='data:link.target != &quot;#&quot;' name='rel' value='noopener'/>
                                <b:if cond='data:link.name == &quot;Facebook&quot;'>
                                  <b:include name='facebook-icon'/>
                          
                                  <b:elseif cond='data:link.name == &quot;Instagram&quot;'/>
                                  <b:include name='instagram-icon'/>
                              
                                  <b:elseif cond='data:link.name == &quot;Twitter&quot;'/>
                                  <b:include name='twitter-icon'/>
                              
                                  <b:elseif cond='data:link.name == &quot;Youtube&quot;'/>
                                  <b:include name='youtube-icon'/>
                              
                                  <b:elseif cond='data:link.name == &quot;LinkedIn&quot;'/>
                                  <b:include name='linkedIn-icon'/>
                              
                                  <b:elseif cond='data:link.name == &quot;Pinterest&quot;'/>
                                  <b:include name='pinterest-icon'/>
                            
                                  <b:elseif cond='data:link.name == &quot;Whatsapp&quot;'/>
                                  <b:include name='whatsapp-icon'/>
                              
                                  <b:elseif cond='data:link.name == &quot;Telegram&quot;'/>
                                  <b:include name='telegram-icon'/>
                              
                                  <b:elseif cond='data:link.name == &quot;Tiktok&quot;'/>
                                  <b:include name='tiktok-icon'/>
                              
                                  <b:else/>
                                  <b:include name='circle-icon'/>
                                </b:if>
                              </b:tag>
                            </li>
                          </b:if>
                        </b:loop>
                      </ul>
                    </b:includable>
                  </b:widget>
                </b:section>
                
                <b:section class='mnMen' id='nav-widget-2' maxwidgets='2' showaddelement='false'>
                  <b:widget id='HTML000' locked='true' title='Navigation Menu' type='HTML' version='2' visible='true'>
                    <b:widget-settings>
                      <b:widget-setting name='content'><![CDATA[<!--[ you can only edit this widget from HTML theme ]-->]]></b:widget-setting>
                    </b:widget-settings>
                    <b:includable id='main'>
                      <ul class='mnMn' itemscope='itemscope' itemtype='https://schema.org/SiteNavigationElement'>
                  
                        <b:if cond='!data:view.isHomepage'>
                          <!--[ Home link ]-->
                          <li class='hm'>
                            <a class='a' expr:href='data:blog.homepageUrl.canonical' itemprop='url'>
                              <b:include name='home-icon'/>
                        
                              <!--[ Title navigation ]-->
                              <span class='n' itemprop='name'><data:messages.home/></span>
                            </a>
                          </li>
                        </b:if>
                    
                        <!--[ Dropdown style 1 ]-->
                        <li class='drp'>
                          <input class='drpI hidden' id='drpDwn-1' name='drpDwn' type='checkbox'/>
                          <label class='a' for='drpDwn-1'>
                            <!--[ Icon ]-->
                            <b:include name='folder-icon'/>
                          
                            <!--[ Title navigation ]-->
                            <span class='n'>Sub menu</span>
                        
                            <b:include name='arow-down-icon'/>
                          </label>
                          <ul>
                            <!--[ Change attribute href='#' to add url ]-->
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 01</a></li>
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 02</a></li>
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 03</a></li>
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 04</a></li>
                          </ul>
                        </li>
                    
                        <!--[ Dropdown style 1 ]-->
                        <li class='drp br'>
                          <input class='drpI hidden' id='drpDwn-2' name='drpDwn' type='checkbox'/>
                          <label class='a' for='drpDwn-2'>
                            <!--[ Icon ]-->
                            <b:include name='folder-icon'/>
                          
                            <!--[ Title navigation ]-->
                            <span class='n'>Sub menu</span>
                        
                            <b:include name='arow-down-icon'/>
                          </label>
                          <ul>
                            <!--[ Change attribute href='#' to add url ]-->
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 05</a></li>
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 06</a></li>
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 07</a></li>
                            <li itemprop='name'><a href='#' itemprop='url'>Sub menu 08</a></li>
                          </ul>
                        </li>
                          
                        <!--[ Standar menu ]-->
                        <li>
                          <!--[ Change attribute href='#' to add url ]-->
                          <a class='a' href='#' itemprop='url'>
                            <!--[ Icon ]-->
                            <b:include name='profiles-icon'/>
                          
                            <!--[ Title navigation ]-->
                            <span class='n' itemprop='name'>About</span>
                          </a>
                        </li>
                          
                        <!--[ Standar menu ]-->
                        <li class='br'>
                          <!--[ Change attribute href='#' to add url ]-->
                          <a class='a' href='#' itemprop='url'>
                            <!--[ Icon ]-->
                            <b:include name='message-icon'/>
                          
                            <!--[ Title navigation ]-->
                            <span class='n' itemprop='name'>Contact</span>
                          </a>
                        </li>
                      
                        <!--[ Dropdown style 2 ]-->
                        <li class='drp mr br'>
                          <input checked='checked' class='drpI hidden' id='drpMr-2' name='drpDwn' type='checkbox'/>
                          <label class='a' for='drpMr-2'>
                            
                            <!--[ Title navigation ]-->
                            <span class='n'>More...</span>
                          
                            <b:include name='arow-down-icon'/>
                          </label>
                          <ul>
                            <!--[ Change attribute href='#' to add url ]-->
                            <li itemprop='name'><a class='soon' href='#' itemprop='url'>Landing Page</a></li>
                          </ul>
                        </li>
                        
                        <!--[ Standar menu ]-->
                        <li>
                          <a class='a' href='https://techly420.blogspot.com' itemprop='url'>
                            <!--[ Icon ]-->
                            <b:include name='download-alt-icon'/>
                            
                            <!--[ Title navigation ]-->
                            <span class='n' itemprop='name'>Download this theme</span>
                          </a>
                        </li>
                          
                      </ul>
                    </b:includable>
                  </b:widget>
                  <b:widget id='PageList000' locked='true' title='Navigation Menu (Simple)' type='PageList' version='2' visible='false'>
                    <b:widget-settings>
                      <b:widget-setting name='pageListJson'><![CDATA[{"link1":{"href":"#","position":1,"title":"About"},"link0":{"href":"/","position":0,"title":"Home"},"link3":{"href":"#","position":3,"title":"Custom menu"},"link2":{"href":"#","position":2,"title":"Contact"}}]]></b:widget-setting>
                      <b:widget-setting name='homeTitle'>Home</b:widget-setting>
                    </b:widget-settings>
                    <b:includable id='main'>
                      <b:include name='content'/>
                    </b:includable>
                    <b:includable id='content'>
                      <b:include name='pageList'/>
                    </b:includable>
                    <b:includable id='overflowButton'/>
                    <b:includable id='overflowablePageList'/>
                    <b:includable id='pageLink'>
                      <b:if cond='data:i &lt;= 4'>
                        <li>
                          <b:class cond='data:link.isCurrentPage' name='selected'/>
                          <b:class cond='data:link.href == data:blog.homepageUrl.canonical' name='hm'/>
                        
                          <b:tag class='a' expr:name='!data:link.isCurrentPage and data:link.href != &quot;#&quot; ? &quot;a&quot; : &quot;span&quot;'>
                            <b:attr cond='!data:link.isCurrentPage and data:link.href != &quot;#&quot;' expr:value='data:link.href' name='href'/>
                            <b:attr cond='!data:link.isCurrentPage and data:link.href != &quot;#&quot;' name='itemprop' value='url'/>
                              
                            <!--[ Icon ]-->
                            <b:if cond='data:link.title == &quot;Home&quot;'>
                              <b:include name='home-icon'/>
                                
                              <b:elseif cond='data:link.title == &quot;About&quot;'/>
                              <b:include name='profiles-icon'/>
                              
                              <b:elseif cond='data:link.title == &quot;Contact&quot;'/>
                              <b:include name='message-icon'/>
                                
                              <b:elseif cond='data:link.title == &quot;Download this theme&quot; or data:link.title == &quot;Download&quot;'/>
                              <b:include name='download-icon'/>
                              
                              <b:elseif cond='data:link.title == &quot;Sitemap&quot;'/>
                              <b:include name='document-icon'/>
                          
                              <b:elseif cond='data:link.title == &quot;Disclaimers&quot;'/>
                              <b:include name='shield-done-icon'/>
                          
                            
                              <b:elseif cond='data:link.title == &quot;Privacy&quot;'/>
                              <b:include name='lock-icon'/>
                                
                              <b:else/>
                              <b:include name='folder-icon'/>
                            </b:if>
                              
                            <!--[ Title navigation ]-->
                            <span class='n'>
                              <b:attr cond='!data:link.isCurrentPage and data:link.href != &quot;#&quot;' name='itemprop' value='name'/>
                              <data:link.title/>
                            </span>
                          </b:tag>
                        </li>
                      </b:if>
                        
                      <b:if cond='data:i == 5'>
                        <li class='drp'>
                          <input class='dropIn hidden' id='drpDwn-00' name='drpDwn' type='checkbox'/>
                          <label class='a' for='drpDwn-00'>
                            <!--[ Icon ]-->
                            <b:include name='folder-icon'/>
                              
                            <!--[ Title navigation ]-->
                            <span class='n'><data:messages.moreEllipsis/></span>
                        
                            <b:include name='arow-down-icon'/>
                          </label>
                          <ul>
                            <b:loop index='all' values='data:links' var='link'>
                              <b:if cond='data:all &gt;= 5'>
                                <li>
                                  <b:attr cond='!data:link.isCurrentPage and data:link.href != &quot;#&quot;' name='itemprop' value='name'/>
                                  
                                  <b:tag expr:name='!data:link.isCurrentPage and data:link.href != &quot;#&quot; ? &quot;a&quot; : &quot;span&quot;'>
                                    <b:attr cond='!data:link.isCurrentPage and data:link.href != &quot;#&quot;' expr:value='data:link.href' name='href'/>
                                    <b:attr cond='!data:link.isCurrentPage and data:link.href != &quot;#&quot;' name='itemprop' value='url'/>
                                    <data:link.title/>
                                  </b:tag>
                                </li>
                              </b:if>
                            </b:loop>
                          </ul>
                        </li>
                      </b:if>
                    </b:includable>
                    <b:includable id='pageList'>
                      <ul class='mnMn' itemscope='itemscope' itemtype='https://schema.org/SiteNavigationElement'>
                        <b:loop index='i' values='data:links' var='link'>
                          <b:include name='pageLink'/>
                        </b:loop>
                      </ul>
                    </b:includable>
                  </b:widget>
                </b:section>
              </div>
            </div>
            <label class='fCls' for='offNav'/>
          </div>
          
          <!--[ Blog content ]-->
          <div class='blogCont'>
            <div class='secIn'>
              
               <b:section cond='!data:view.isPreview' id='notif-widget' maxwidgets='1' showaddelement='false'>
                 <b:widget id='LinkList001' locked='true' title='Scroll Menu' type='LinkList' version='2' visible='true'>
                   <b:widget-settings>
                     <b:widget-setting name='link-5'>/search/label/Food</b:widget-setting>
                     <b:widget-setting name='link-6'>/search/label/Adventure</b:widget-setting>
                     <b:widget-setting name='link-3'>/search/label/Photography</b:widget-setting>
                     <b:widget-setting name='link-4'>/search/label/Nature</b:widget-setting>
                     <b:widget-setting name='text-1'>Script</b:widget-setting>
                     <b:widget-setting name='text-0'>Blogger</b:widget-setting>
                     <b:widget-setting name='text-3'>Photography</b:widget-setting>
                     <b:widget-setting name='text-2'>Life Style</b:widget-setting>
                     <b:widget-setting name='text-5'>Food</b:widget-setting>
                     <b:widget-setting name='text-4'>Nature</b:widget-setting>
                     <b:widget-setting name='text-6'>Adventure</b:widget-setting>
                     <b:widget-setting name='shownum'>7</b:widget-setting>
                     <b:widget-setting name='sorting'>NONE</b:widget-setting>
                     <b:widget-setting name='link-1'>/search/label/Script</b:widget-setting>
                     <b:widget-setting name='link-2'>/search/label/Life%20Style</b:widget-setting>
                     <b:widget-setting name='link-0'>/search/label/Blogger</b:widget-setting>
                   </b:widget-settings>
                   <b:includable id='main'>
                    <b:include name='content'/>
                  </b:includable>
                   <b:includable id='content'>
                    <!--[ Scroll Menu ]-->
                    <nav class='navS scrlH'>
                      <div class='secIn'>
                        <ul>
                          <b:loop index='s' values='data:links' var='link'>
                            <b:if cond='data:s &lt;= 12'>
                              <li>
                                <b:tag class='l' expr:data-text='data:link.name' expr:name='data:link.target != &quot;#&quot; and data:link.target != data:blog.url.canonical ? &quot;a&quot; : &quot;span&quot;'>
                                  <b:attr cond='data:link.target != &quot;#&quot; and data:link.target != data:blog.url.canonical' expr:value='data:link.target' name='href'/>
                                  <b:attr cond='data:link.target != &quot;#&quot; and data:link.target != data:blog.url.canonical' expr:value='data:link.name' name='aria-label'/>
                                  <b:class cond='data:link.target == data:blog.url.canonical' name='a'/>
                                </b:tag>
                                </li>
                            </b:if>
                          </b:loop>
                        </ul>
                      </div>
                    </nav>
                  </b:includable>
                 </b:widget>
                 <b:widget id='HTML0' locked='true' title='Notification' type='HTML' version='2' visible='true'>
                   <b:widget-settings>
                     <b:widget-setting name='content'>&lt;!--[ Your content here, Lorem ipsum dolor sit amet, consectetur adipiscing elit. ]--&gt;

&lt;!--[ Alternatif content with button link ]--&gt;
&lt;div class=&#39;ntfA&#39;&gt; 
  &lt;span&gt;

Buy Now T420DESIGN Blogger Template &lt;a href=&#39;https://telegram.me/Techly420_Admin&#39; target=&#39;_blank&#39;&gt;Contact Us&lt;/a&gt;
&lt;/span&gt; 
  &lt;a href=&#39;https://telegram.me/Techly420_Admin&#39; target=&#39;_blank&#39;&gt;Buy Now!&lt;/a&gt;
&lt;/div&gt;</b:widget-setting>
                   </b:widget-settings>
                   <b:includable id='main'>
                    <!--[ Notification Widget ]-->
                    <input class='ntfI hidden' id='forNft' type='checkbox'/>
                    <div class='ntfC'>
                      <div class='ntfT'><data:content/></div>
                      <label aria-label='Close Menu' class='c' for='forNft'/>
                    </div>
                  </b:includable>
                 </b:widget>
               </b:section>
                
              <b:if cond='!data:view.isPreview'>
                      
                
            
                <!--[ Ad content ]-->
                <b:tag class='blogAd' name='div'>
                  <b:section id='horizontal-ad' maxwidgets='3' showaddelement='true'>
                    <b:widget id='HTML91' locked='true' title='Under Header Ad' type='HTML' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'/>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <b:if cond='data:content != &quot;&quot;'>
                          <data:content/>
                          
                          <b:else/>
                          <!--[ Blank ad ]-->
                          <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                        </b:if>
                      </b:includable>
                    </b:widget>
                  </b:section>
                </b:tag>
              </b:if>
              
              <b:tag class='blogM' name='div'>
                <!--[ Main content ]-->
                <main class='blogItm mainbar'>
                    
                  <b:if cond='data:view.isHomepage'>
                    <b:section aria-label='Gallery' class='sldO scrlH' id='slider-widget' maxwidgets='4' showaddelement='false'>
                      <b:widget id='Image1' locked='true' title='Slider Image 01' type='Image' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='displayUrl'>https://1.bp.blogspot.com/-yMSpgmjn390/YF1Q5CvGIcI/AAAAAAAAQlg/59LxYemhlyEbbhqlpdfypu5OXRav4t-JgCNcBGAsYHQ/s1600/slider-1-min.png</b:widget-setting>
                          <b:widget-setting name='displayHeight'>648</b:widget-setting>
                          <b:widget-setting name='sectionWidth'>379</b:widget-setting>
                          <b:widget-setting name='shrinkToFit'>false</b:widget-setting>
                          <b:widget-setting name='displayWidth'>1600</b:widget-setting>
                          <b:widget-setting name='link'/>
                          <b:widget-setting name='caption'/>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <b:include name='content'/>
                        </b:includable>
                        <b:includable id='content'>
                          <div class='sldC' expr:id='data:widget.instanceId + &quot;_img&quot;'>
                            <b:tag class='sldIm' expr:data-style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;'>
                              <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
                              <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' name='style'/>
                              <b:attr cond='data:link' expr:value='data:link' name='href'/>
                              <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                              <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>
                            </b:tag>
                            <noscript>
                              <b:tag class='sldIm' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;' expr:style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;'>
                                <b:attr cond='data:link' expr:value='data:link' name='href'/>
                                <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                                <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>
                              </b:tag>
                            </noscript>
                          </div>
                          <div class='sldS'/>
                        </b:includable>
                      </b:widget>
                      <b:widget id='Image2' locked='true' title='Slider Image 02' type='Image' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='displayUrl'>https://1.bp.blogspot.com/-dGxoQ9YQYsM/YF1Q71CYmII/AAAAAAAAQlo/0scDqH__JA87HT6QpRcFZt9Y7CucundjQCNcBGAsYHQ/s1600/slider-2-min.png</b:widget-setting>
                          <b:widget-setting name='displayHeight'>648</b:widget-setting>
                          <b:widget-setting name='sectionWidth'>379</b:widget-setting>
                          <b:widget-setting name='shrinkToFit'>false</b:widget-setting>
                          <b:widget-setting name='displayWidth'>1600</b:widget-setting>
                          <b:widget-setting name='link'/>
                          <b:widget-setting name='caption'/>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <b:include name='content'/>
                        </b:includable>
                        <b:includable id='content'>
                          <div class='sldC' expr:id='data:widget.instanceId + &quot;_img&quot;'>
                            <b:tag class='sldIm' expr:data-style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;'>
                              <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
                              <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' name='style'/>
                              <b:attr cond='data:link' expr:value='data:link' name='href'/>
                              <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                              <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>                                
                            </b:tag>
                            <noscript>
                              <b:tag class='sldIm' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;' expr:style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;'>
                                <b:attr cond='data:link' expr:value='data:link' name='href'/>
                                <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                                <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>
                              </b:tag>
                            </noscript>
                          </div>
                          <div class='sldS'/>
                        </b:includable>
                      </b:widget>
                      <b:widget id='Image3' locked='true' title='Slider Image 03' type='Image' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='displayUrl'>https://1.bp.blogspot.com/-vK7BQxXeYnk/YF1Q9MVgZ8I/AAAAAAAAQls/OanP_Tl4sd4616Y1RaD2JPA_UOWtMkDAQCNcBGAsYHQ/s1600/slider-3-min.png</b:widget-setting>
                          <b:widget-setting name='displayHeight'>648</b:widget-setting>
                          <b:widget-setting name='sectionWidth'>379</b:widget-setting>
                          <b:widget-setting name='shrinkToFit'>false</b:widget-setting>
                          <b:widget-setting name='displayWidth'>1600</b:widget-setting>
                          <b:widget-setting name='link'/>
                          <b:widget-setting name='caption'/>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <b:include name='content'/>
                        </b:includable>
                        <b:includable id='content'>
                          <div class='sldC' expr:id='data:widget.instanceId + &quot;_img&quot;'>
                            <b:tag class='sldIm' expr:data-style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;'>
                              <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
                              <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' name='style'/>
                              <b:attr cond='data:link' expr:value='data:link' name='href'/>
                              <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                              <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>                                
                            </b:tag>
                            <noscript>
                              <b:tag class='sldIm' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;' expr:style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;'>
                                <b:attr cond='data:link' expr:value='data:link' name='href'/>
                                <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                                <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>
                              </b:tag>
                            </noscript>
                          </div>
                          <div class='sldS'/>
                        </b:includable>
                      </b:widget>
                      <b:widget id='Image4' locked='true' title='Slider Image 04' type='Image' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='displayUrl'>https://1.bp.blogspot.com/-Q_BGkGuukLE/YF1Q67reH4I/AAAAAAAAQlk/jXe6LIyIjkkNpJu7ShtztoUWV4JylmCkgCNcBGAsYHQ/s1600/slider-4-min.png</b:widget-setting>
                          <b:widget-setting name='displayHeight'>648</b:widget-setting>
                          <b:widget-setting name='sectionWidth'>379</b:widget-setting>
                          <b:widget-setting name='shrinkToFit'>false</b:widget-setting>
                          <b:widget-setting name='displayWidth'>1600</b:widget-setting>
                          <b:widget-setting name='link'/>
                          <b:widget-setting name='caption'/>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <b:include name='content'/>
                        </b:includable>
                        <b:includable id='content'>
                          <div class='sldC' expr:id='data:widget.instanceId + &quot;_img&quot;'>
                            <b:tag class='sldIm' expr:data-style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;'>
                              <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
                              <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;' name='style'/>
                              <b:attr cond='data:link' expr:value='data:link' name='href'/>
                              <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                              <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>                                
                            </b:tag>
                            <noscript>
                              <b:tag class='sldIm' expr:name='data:link ? &quot;a&quot; : &quot;div&quot;' expr:style='&quot;background-image: url(&quot; + data:sourceUrl + &quot;)&quot;'>
                                <b:attr cond='data:link' expr:value='data:link' name='href'/>
                                <b:attr cond='data:link' expr:value='data:title' name='aria-label'/>
                                <b:if cond='data:caption'><span class='sldT'><data:caption/></span></b:if>
                              </b:tag>
                            </noscript>
                          </div>
                          <div class='sldS'/>
                        </b:includable>
                      </b:widget>
                    </b:section>
                  </b:if>
                    
                  <b:section cond='data:view.isHomepage' id='top-widget' showaddelement='true'>
                    <b:widget id='HTML2' locked='false' title='Category' type='HTML' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'>&lt;div class=&#39;widget HTML&#39; data-version=&#39;2&#39; id=&#39;HTML05&#39;&gt;
&lt;style&gt;/*&lt;![CDATA[*/
/* Category layout */.stw-feature{padding:5px;text-align:center;position:relative}.stw-feature h2{font-size:1.6em;line-height:1.6em;margin-bottom:0;padding-bottom:0}.stw-feature ul{clear:both;margin:15px 0 20px;width:100%;display:flex;padding:0;flex-wrap:wrap;justify-content:space-between;margin-bottom: 40px;}.stw-feature.icon-p-2 li{position:relative;width:30%;list-style:none;line-height:1.3em;text-align:center;border-radius:10px;margin:6px 0;background:var(--contentB);box-shadow:0 5px 35px rgb(0 0 0/7%);padding:6px 0 12px;display:flex;align-items:center;justify-content:center}.stw-feature li a{display:block;text-decoration:none;color:var(--fontC)}.stw-feature li svg{margin:3px 0;width:35px;height:35px;display:inline-block}.stw-feature li span{display:block;padding:0 3px}.drK .stw-feature li{background:var(--darkBa)} /*]]&gt;*/&lt;/style&gt;
&lt;div class=&#39;stw-feature coll-3 icon-p-2&#39;&gt;&lt;b&gt;
&lt;h2&gt;
&lt;span&gt;Choose Category And See Category Post! &lt;/span&gt;
&lt;/h2&gt;&lt;/b&gt;
&lt;ul&gt;
&lt;li&gt;
&lt;a href=&#39;/search/label/Blogger&#39; title=&#39;Blogger&#39;&gt;
&lt;svg xmlns=&#39;http://www.w3.org/2000/svg&#39; viewbox=&#39;0 0 32 32&#39;&gt;&lt;path d=&#39;M28,12H26V9.5A7.5,7.5,0,0,0,18.5,2h-9A7.5,7.5,0,0,0,2,9.5V19a1,1,0,0,0,2,0V9.5A5.51,5.51,0,0,1,9.5,4h9A5.51,5.51,0,0,1,24,9.5V12a2,2,0,0,0,2,2h2v8.5A5.51,5.51,0,0,1,22.5,28H9.5A5.51,5.51,0,0,1,4,22.5V22a1,1,0,0,0-2,0v.5A7.5,7.5,0,0,0,9.5,30h13A7.5,7.5,0,0,0,30,22.5V14A2,2,0,0,0,28,12Z&#39;/&gt;&lt;path class=&#39;svg-c&#39; d=&#39;M11.5,14h5a2.5,2.5,0,0,0,0-5h-5a2.5,2.5,0,0,0,0,5Zm0-3h5a.5.5,0,0,1,0,1h-5a.5.5,0,0,1,0-1Z&#39;/&gt;&lt;path class=&#39;svg-c&#39; d=&#39;M11.5,23h9a2.5,2.5,0,0,0,0-5h-9a2.5,2.5,0,0,0,0,5Zm0-3h9a.5.5,0,0,1,0,1h-9a.5.5,0,0,1,0-1Z&#39;/&gt;&lt;/path&gt;&lt;/path&gt;&lt;/path&gt;&lt;/svg&gt;

&lt;span&gt;Blogger&lt;/span&gt;&lt;/a&gt;
&lt;/li&gt;
&lt;li&gt;
&lt;a href=&#39;/search/label/Tools&#39; title=&#39;Tools&#39;&gt;
&lt;svg class=&#39;line svg-1&#39; viewbox=&#39;0 0 24 24&#39;&gt;&lt;g transform=&#39;translate(3.500000, 2.500000)&#39;&gt;&lt;path class=&#39;svgC&#39; d=&#39;M8.5,7 C9.88088012,7 11,8.11911988 11,9.5 C11,10.8808801 9.88088012,12 8.5,12 C7.11911988,12 6,10.8808801 6,9.5 C6,8.11911988 7.11911988,7 8.5,7 Z&#39;/&gt;&lt;path d=&#39;M16.6680023,4.75024695 L16.6680023,4.75024695 C15.9844554,3.55799324 14.4712377,3.15003899 13.2885153,3.83852352 C12.2597626,4.43613205 10.9740669,3.68838056 10.9740669,2.49217572 C10.9740669,1.11619444 9.86587758,0 8.4997646,0 L8.4997646,0 C7.13365161,0 6.02546233,1.11619444 6.02546233,2.49217572 C6.02546233,3.68838056 4.73976662,4.43613205 3.71199461,3.83852352 C2.52829154,3.15003899 1.01507378,3.55799324 0.331526939,4.75024695 C-0.351039204,5.94250065 0.053989269,7.46664934 1.23769234,8.15414609 C2.26546435,8.7527424 2.26546435,10.2472576 1.23769234,10.8458539 C0.053989269,11.5343384 -0.351039204,13.0584871 0.331526939,14.2497531 C1.01507378,15.4420068 2.52829154,15.849961 3.71101391,15.1624643 L3.71199461,15.1624643 C4.73976662,14.5638679 6.02546233,15.3116194 6.02546233,16.5078243 L6.02546233,16.5078243 C6.02546233,17.8838056 7.13365161,19 8.4997646,19 L8.4997646,19 C9.86587758,19 10.9740669,17.8838056 10.9740669,16.5078243 L10.9740669,16.5078243 C10.9740669,15.3116194 12.2597626,14.5638679 13.2885153,15.1624643 C14.4712377,15.849961 15.9844554,15.4420068 16.6680023,14.2497531 C17.3515491,13.0584871 16.9455399,11.5343384 15.7628176,10.8458539 L15.7618369,10.8458539 C14.7340648,10.2472576 14.7340648,8.7527424 15.7628176,8.15414609 C16.9455399,7.46664934 17.3515491,5.94250065 16.6680023,4.75024695 Z&#39;/&gt;&lt;/path&gt;&lt;/path&gt;&lt;/g&gt;&lt;/svg&gt;
&lt;span&gt;Tools&lt;/span&gt;&lt;/a&gt;
&lt;/li&gt;
&lt;li&gt;
&lt;a href=&#39;/search/label/Example&#39; title=&#39;Example&#39;&gt;
&lt;svg viewbox=&#39;0 0 16 16&#39;&gt;&lt;path d=&#39;M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z&#39; fill-rule=&#39;evenodd&#39;/&gt;&lt;path class=&#39;svgC&#39; d=&#39;M4.285 9.567a.5.5 0 0 1 .683.183A3.498 3.498 0 0 0 8 11.5a3.498 3.498 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.498 4.498 0 0 1 8 12.5a4.498 4.498 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683z&#39;/&gt;&lt;path class=&#39;svgC&#39; d=&#39;M7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5zm4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5z&#39;/&gt;&lt;/path&gt;&lt;/path&gt;&lt;/path&gt;&lt;/svg&gt;
&lt;span&gt;Example&lt;/span&gt;&lt;/a&gt;
&lt;/li&gt;
&lt;/ul&gt;
&lt;/div&gt;
&lt;/div&gt;</b:widget-setting>
                      </b:widget-settings>
                      <b:includable id='main'>
  <b:include name='widget-title'/>
  <div class='widget-content'>
    <data:content/>
  </div>
</b:includable>
                    </b:widget>
                    <b:widget cond='!data:view.isPreview' id='HTML92' locked='true' title='Ad placement' type='HTML' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'/>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <div class='widget-content'>
                          <b:if cond='data:content != &quot;&quot;'>
                            <data:content/>
                          
                            <b:else/>
                            <!--[ Blank ad ]-->
                            <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                          </b:if>
                        </div>
                      </b:includable>
                    </b:widget>
                    <b:widget id='FeaturedPost1' locked='true' title='Pinned Post' type='FeaturedPost' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='showSnippet'>true</b:widget-setting>
                        <b:widget-setting name='showPostTitle'>true</b:widget-setting>
                        <b:widget-setting name='postId'>4246342226471678914</b:widget-setting>
                        <b:widget-setting name='showFirstImage'>true</b:widget-setting>
                        <b:widget-setting name='useMostRecentPost'>false</b:widget-setting>
                      </b:widget-settings>
                      <b:includable id='main' var='this'>
                        <b:if cond='data:title != &quot;&quot;'>
                          <h2 class='title'><data:title/></h2>
                        </b:if>
                        <b:include name='snippetedPosts'/>
                      </b:includable>
                      <b:includable id='blogThisShare'/>
                      <b:includable id='bylineByName' var='byline'/>
                      <b:includable id='bylineRegion' var='regionItems'/>
                      <b:includable id='commentsLink'/>
                      <b:includable id='commentsLinkIframe'/>
                      <b:includable id='emailPostIcon'/>
                      <b:includable id='facebookShare'/>
                      <b:includable id='footerBylines'/>
                      <b:includable id='googlePlusShare'/>
                      <b:includable id='headerByline'/>
                      <b:includable id='linkShare'/>
                      <b:includable id='otherSharingButton'/>
                      <b:includable id='platformShare'/>
                      <b:includable id='postAuthor'/>
                      <b:includable id='postCommentsLink'/>
                      <b:includable id='postInfo'>
                        <div class='pInf pSml'>
                          <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])' name='nSpr'/>
                          <b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                            <!--[ Post timestamp ]-->
                            <b:include cond='data:widgets.Blog.first.allBylineItems.timestamp' name='postTimestampPublish'/>
                          </b:if>
                    
                          <!--[ Post jumplinks ]-->
                          <b:include cond='data:widgets.Blog.first.allBylineItems.timestamp' name='postJumpLinks'/>
                        </div>
                      </b:includable>
                      <b:includable id='postJumpLink' var='post'/>
                      <b:includable id='postLabels'/>
                      <b:includable id='postLocation'/>
                      <b:includable id='postReactions'/>
                      <b:includable id='postShareButtons'/>
                      <b:includable id='postTimestamp'/>
                      <b:includable id='sharingButton'/>
                      <b:includable id='sharingButtonContent'/>
                      <b:includable id='sharingButtons'/>
                      <b:includable id='sharingButtonsMenu'/>
                      <b:includable id='sharingPlatformIcon'/>
                      <b:includable id='snippetedPostByline'/>
                      <b:includable id='snippetedPostContent'>
                        <!--[ Post Thumbnail ]-->
                        <b:include name='snippetedPostThumbnail'/>
                    
                        <div class='iCtnt'>
                          <!--[ Post header ]-->
                          <b:include name='postHeaders'/>
                          
                          <b:include cond='data:this.postDisplay.showTitle' name='snippetedPostTitle'/>
                          <b:include cond='data:this.postDisplay.showSnippet' name='snippetedPostEntry'/>
                      
                          <!--[ Post info ]-->
                          <b:include cond='!data:view.isPage and data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])' name='postInfo'/>
                        </div>
                      </b:includable>
                      <b:includable id='snippetedPostEntry'>
                        <div class='pSnpt'>
                          <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])' name='nTag'/>
                          <b:include name='postEntrySnippet'/>
                        </div>
                      </b:includable>
                      <b:includable id='snippetedPostThumbnail'>
                        <div class='iThmb pThmb'>
                          <b:class cond='data:post.featuredImage.isYoutube' name='iyt'/>
                          <b:class cond='!data:this.postDisplay.showFeaturedImage or !data:post.featuredImage' name='nul'/>
                          <b:tag class='thmb' expr:name='data:this.postDisplay.showFeaturedImage and data:post.featuredImage ? &quot;a&quot; : &quot;div&quot;'>
                            <b:attr cond='data:this.postDisplay.showFeaturedImage and data:post.featuredImage' expr:value='data:post.url' name='href'/>
                            <b:if cond='data:this.postDisplay.showFeaturedImage and data:post.featuredImage'>
                              <b:include name='postEntryThumbnail'/>
                              <b:else/>
                              <span class='imgThm' data-text='No image'/>
                            </b:if>
                          </b:tag>
                          
                          <!--[ Comments count ]-->
                          <b:tag class='iFxd' cond='data:post.allowComments and data:post.numberOfComments &gt; 0 or data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])' name='div'>
                            <b:if cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                              <b:include name='postSponsored'/>
                              <b:elseif cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])'/>
                              <b:include name='postProduct'/>
                            </b:if>
                            <b:if cond='data:widgets.Blog.first.allBylineItems.comments and data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])'>
                              <b:include name='postCommentsLinks'/>
                            </b:if>
                          </b:tag>
                        </div>
                      </b:includable>
                      <b:includable id='snippetedPostTitle'>
                        <h3 class='pTtl aTtl'><a expr:href='data:post.url.canonical'><data:post.title.escaped/></a></h3>
                      </b:includable>
                      <b:includable id='snippetedPosts'>
                        <div class='itemFt' role='feed'>
                          <!-- Don't render the post that we're currently already looking at. -->
                          <b:loop values='data:posts filter (p =&gt; p.id != data:view.postId)' var='post'>
                            <article class='itm'>
                              <b:class cond='data:this.postDisplay.showFeaturedImage and !data:post.featuredImage' name='noThmb'/>
                              <b:class cond='!data:this.postDisplay.showFeaturedImage' name='noImage'/>
                              <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])' name='pTag'/>
                              <b:include name='snippetedPostContent'/>
                            </article>
                          </b:loop>
                        </div>
                      </b:includable>
                    </b:widget>
                    <b:widget cond='data:view.isSingleItem and data:posts any (p =&gt; p.id != data:view.postId)' id='PopularPosts1' locked='false' title='' type='PopularPosts' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='numItemsToShow'>3</b:widget-setting>
                        <b:widget-setting name='showThumbnails'>true</b:widget-setting>
                        <b:widget-setting name='showSnippets'>true</b:widget-setting>
                        <b:widget-setting name='timeRange'>LAST_YEAR</b:widget-setting>
                      </b:widget-settings>
                      <b:includable id='main' var='this'>
          <b:comment>Default the title to &#39;Popular posts from this blog&#39;.</b:comment>
          <b:with value='data:messages.popularPostsFromThisBlog' var='defaultTitle'>
            <b:include name='super.main'/>
          </b:with>
        </b:includable>
                      <b:includable id='blogThisShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=270,width=475\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
                      <b:includable id='bylineByName' var='byline'>
  <b:switch var='data:byline.name'>
  <b:case value='share'/>
    <b:include cond='data:post.shareUrl' name='postShareButtons'/>
  <b:case value='comments'/>
    <b:include cond='data:post.allowComments' name='postCommentsLink'/>
  <b:case value='location'/>
    <b:include cond='data:post.location' name='postLocation'/>
  <b:case value='timestamp'/>
    <b:include cond='not data:view.isPage' name='postTimestamp'/>
  <b:case value='author'/>
    <b:include name='postAuthor'/>
  <b:case value='labels'/>
    <b:include cond='data:post.labels' name='postLabels'/>
  <b:case value='icons'/>
    <b:include cond='data:post.emailPostUrl' name='emailPostIcon'/>
  </b:switch>
</b:includable>
                      <b:includable id='bylineRegion' var='regionItems'>
  <b:loop values='data:regionItems' var='byline'>
    <b:include data='byline' name='bylineByName'/>
  </b:loop>
</b:includable>
                      <b:includable id='commentsLink'>
          <a class='comment-link' expr:href='data:post.commentsUrl' expr:onclick='data:post.commentsUrlOnclick'>
            <b:include data='{ iconClass: &quot;touch-icon&quot; }' name='commentIcon'/>
            <span class='num_comments'>
              <b:if cond='data:post.numberOfComments &gt; 0'>
                <b:message name='messages.numberOfComments'>
                  <b:param expr:value='data:post.numberOfComments' name='numComments'/>
                </b:message>
              <b:else/>
                <data:messages.postAComment/>
              </b:if>
            </span>
          </a>
        </b:includable>
                      <b:includable id='commentsLinkIframe'>
  <!-- G+ comments, no longer available. The includable is retained for backwards-compatibility. -->
</b:includable>
                      <b:includable id='emailPostIcon'>
  <span class='byline post-icons'>
    <!-- email post links -->
    <span class='item-action'>
      <a expr:href='data:post.emailPostUrl' expr:title='data:messages.emailPost'>
        <b:include data='{ iconClass: &quot;touch-icon sharing-icon&quot; }' name='emailIcon'/>
      </a>
    </span>
  </span>
</b:includable>
                      <b:includable id='facebookShare'>
  <b:with value='&quot;window.open(this.href, \&quot;_blank\&quot;, \&quot;height=430,width=640\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
                      <b:includable id='footerBylines'>
  <b:if cond='data:widgets.Blog.first.footerBylines'>
    <b:loop index='i' values='data:widgets.Blog.first.footerBylines' var='region'>
      <b:if cond='not data:region.items.empty'>
        <div expr:class='&quot;post-footer-line post-footer-line-&quot; + (data:i + 1)'>
          <b:with value='&quot;footer-&quot; + (data:i + 1)' var='regionName'>
            <b:include data='region.items' name='bylineRegion'/>
          </b:with>
        </div>
      </b:if>
    </b:loop>
  </b:if>
</b:includable>
                      <b:includable id='googlePlusShare'>
</b:includable>
                      <b:includable id='headerByline'>
  <b:if cond='data:widgets.Blog.first.headerByline'>
    <div class='post-header'>
      <div class='post-header-line-1'>
        <b:with value='&quot;header-1&quot;' var='regionName'>
          <b:include data='data:widgets.Blog.first.headerByline.items' name='bylineRegion'/>
        </b:with>
      </div>
    </div>
  </b:if>
</b:includable>
                      <b:includable id='linkShare'>
  <b:with value='&quot;window.prompt(\&quot;Copy to clipboard: Ctrl+C, Enter\&quot;, \&quot;&quot; + data:originalUrl + &quot;\&quot;); return false;&quot;' var='onclick'>
    <b:include name='platformShare'/>
  </b:with>
</b:includable>
                      <b:includable id='otherSharingButton'>
  <span class='sharing-platform-button sharing-element-other' expr:aria-label='data:messages.shareToOtherApps.escaped' expr:data-url='data:originalUrl' expr:title='data:messages.shareToOtherApps.escaped' role='menuitem' tabindex='-1'>
    <b:with value='{key: &quot;sharingOther&quot;}' var='platform'>
      <b:include name='sharingPlatformIcon'/>
    </b:with>
    <span class='platform-sharing-text'><data:messages.shareOtherApps.escaped/></span>
  </span>
</b:includable>
                      <b:includable id='platformShare'>
  <a expr:class='&quot;goog-inline-block sharing-&quot; + data:platform.key' expr:data-url='data:originalUrl' expr:href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:onclick='data:onclick ? data:onclick : &quot;&quot;' expr:title='data:platform.shareMessage' target='_blank'>
    <span class='share-button-link-text'>
      <data:platform.shareMessage/>
    </span>
  </a>
</b:includable>
                      <b:includable id='postAuthor'>
  <span class='byline post-author vcard'>
    <span class='post-author-label'>
      <data:byline.label/>
    </span>
    <span class='fn'>
      <b:if cond='data:post.author.profileUrl'>
        <meta expr:content='data:post.author.profileUrl'/>
        <a class='g-profile' expr:href='data:post.author.profileUrl' rel='author' title='author profile'>
          <span><data:post.author.name/></span>
        </a>
      <b:else/>
        <span><data:post.author.name/></span>
      </b:if>
    </span>
  </span>
</b:includable>
                      <b:includable id='postCommentsLink'>
  <span class='byline post-comment-link container'>
    <b:include cond='data:post.commentSource != 1' name='commentsLink'/>
  </span>
</b:includable>
                      <b:includable id='postFooter' var='post'>
          <div class='post-bottom'>
            <div class='post-footer float-container'>
              <b:include name='footerBylines'/>
              <b:include cond='data:widget.type == &quot;Blog&quot;' data='post' name='postFooterAuthorProfile'/>
            </div>
            <b:if cond='data:view.isSingleItem'>
                <b:include data='{ shareButtonClass: &quot;post-share-buttons-bottom invisible&quot;, overridden: true }' name='maybeAddShareButtons'/>
            <b:else/>
              <b:include data='post' name='postFooterJumpLink'/>
            </b:if>
          </div>
        </b:includable>
                      <b:includable id='postFooterJumpLink'>
          <b:comment>Ripple, and show &#39;keep reading&#39; as the default.</b:comment>
          <div class='jump-link flat-button ripple'>
            <a expr:href='data:post.hasJumpLink ? data:post.url fragment &quot;more&quot; : data:post.url' expr:title='data:post.title'>
              <data:blog.jumpLinkMessage/>
            </a>
          </div>
        </b:includable>
                      <b:includable id='postJumpLink'>
          <b:comment>Overridden, and migrated to postFooter. Called as postFooterJumpLink.</b:comment>
        </b:includable>
                      <b:includable id='postLabels'>
          <b:comment>We don&#39;t display labels on the home page.</b:comment>
          <b:if cond='data:view.isSingleItem and data:widget.type == &quot;Blog&quot;'>
            <b:include name='super.postLabels'/>
          </b:if>
        </b:includable>
                      <b:includable id='postLocation'>
  <span class='byline post-location'>
    <data:byline.label/>
    <a expr:href='data:post.location.mapsUrl' target='_blank'><data:post.location.name/></a>
  </span>
</b:includable>
                      <b:includable id='postReactions'>
  <!-- Reaction feature no longer available. The includable is retained for backwards-compatibility. -->
</b:includable>
                      <b:includable id='postShareButtons' var='post'>
          <b:comment>We call super.postShareButtons from the migrated positions.</b:comment>
        </b:includable>
                      <b:includable id='postTimestamp'>
  <span class='byline post-timestamp'>
    <data:byline.label/>
    <b:if cond='data:post.url'>
      <meta expr:content='data:post.url.canonical'/>
      <a class='timestamp-link' expr:href='data:post.url' rel='bookmark' title='permanent link'>
        <time class='published' expr:datetime='data:post.date.iso8601' expr:title='data:post.date.iso8601'>
          <data:post.date/>
        </time>
      </a>
    </b:if>
  </span>
</b:includable>
                      <b:includable id='sharingButton'>
  <span expr:aria-label='data:platform.shareMessage' expr:class='&quot;sharing-platform-button sharing-element-&quot; + data:platform.key' expr:data-href='data:shareUrl + &quot;&amp;target=&quot; + data:platform.target' expr:data-url='data:originalUrl' expr:title='data:platform.shareMessage' role='menuitem' tabindex='-1'>
    <b:include name='sharingPlatformIcon'/>
    <span class='platform-sharing-text'><data:platform.name/></span>
  </span>
</b:includable>
                      <b:includable id='sharingButtonContent'>
  <div class='flat-icon-button ripple'>
    <b:include name='shareIcon'/>
  </div>
</b:includable>
                      <b:includable id='sharingButtons'>
  <div class='sharing' expr:aria-owns='&quot;sharing-popup-&quot; + data:sharingId' expr:data-title='data:shareTitle'>
    <button class='sharing-button touch-icon-button' expr:aria-controls='&quot;sharing-popup-&quot; + data:sharingId' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-button-&quot; + data:sharingId' role='button'>
      <b:include name='sharingButtonContent'/>
    </button>
    <b:include name='sharingButtonsMenu'/>
  </div>
</b:includable>
                      <b:includable id='sharingButtonsMenu'>
  <div class='share-buttons-container'>
    <ul aria-hidden='true' class='share-buttons hidden' expr:aria-label='data:messages.share.escaped' expr:id='&quot;sharing-popup-&quot; + data:sharingId' role='menu'>
      <b:loop values='(data:platforms ?: data:blog.sharing.platforms) filter (p =&gt; p.key not in {&quot;blogThis&quot;})' var='platform'>
        <li>
          <b:include name='sharingButton'/>
        </li>
      </b:loop>
      <li aria-hidden='true' class='hidden'>
        <b:include name='otherSharingButton'/>
      </li>
    </ul>
  </div>
</b:includable>
                      <b:includable id='sharingPlatformIcon'>
  <b:include data='{ iconClass: (&quot;touch-icon sharing-&quot; + data:platform.key) }' expr:name='data:platform.key + &quot;Icon&quot;'/>
</b:includable>
                      <b:includable id='snippetedPostByline'>
          <b:include name='headerByline'/>
        </b:includable>
                      <b:includable id='snippetedPostContent'>
          <b:comment>Add a &#39;keep reading&#39; link to the item-content.</b:comment>
          <b:include name='snippetedPostTitle'/>
          <b:include name='snippetedPostByline'/>
          <div class='item-content float-container'>
            <b:include cond='data:this.postDisplay.showFeaturedImage and data:post.featuredImage' name='snippetedPostThumbnail'/>
            <b:if cond='data:this.postDisplay.showSnippet'>
              <b:with value='&quot;popular-posts&quot;' var='snippetPrefix'>
                <b:include cond='data:post' data='post' name='postSnippet'/>
              </b:with>
            </b:if>
            <b:include data='post' name='postFooterJumpLink'/>
          </div>
        </b:includable>
                      <b:includable id='snippetedPostThumbnail'>
  <div class='item-thumbnail'>
    <a expr:href='data:post.url'>
      <b:include data='{                         image: data:post.featuredImage,                         imageSizes: [72, 144],                         imageRatio: &quot;1:1&quot;,                         sourceSizes: &quot;72px&quot;                        }' name='responsiveImage'/>
    </a>
  </div>
</b:includable>
                      <b:includable id='snippetedPostTitle'>
  <b:if cond='data:post.title != &quot;&quot;'>
    <h3 class='post-title'><a expr:href='data:post.url'><data:post.title/></a></h3>
  </b:if>
</b:includable>
                      <b:includable id='snippetedPosts'>
  <div role='feed'>
    <!-- Don't render the post that we're currently already looking at. -->
    <b:loop values='data:posts filter (p =&gt; p.id != data:view.postId)' var='post'>
      <article class='post' role='article'>
        <b:include name='snippetedPostContent'/>
      </article>
    </b:loop>
  </div>
</b:includable>
                    </b:widget>
                  </b:section>
                
                  <b:section id='main-widget' showaddelement='true'>
                    <b:widget cond='!data:view.isPreview and !data:blog.isMobileRequest and (data:view.isHomepage or data:view.isPost)' id='HTML93' locked='true' title='Ad placement' type='HTML' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'/>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <div class='widget-content'>
                          <b:if cond='data:content != &quot;&quot;'>
                            <data:content/>
                          
                            <b:else/>
                            <!--[ Blank ad ]-->
                            <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                          </b:if>
                        </div>
                      </b:includable>
                    </b:widget>
                    <b:widget id='Blog1' locked='true' title='Blog Posts' type='Blog' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='showDateHeader'>false</b:widget-setting>
                        <b:widget-setting name='commentLabel'>Comment</b:widget-setting>
                        <b:widget-setting name='style.textcolor'>#08102b</b:widget-setting>
                        <b:widget-setting name='showShareButtons'>true</b:widget-setting>
                        <b:widget-setting name='authorLabel'>Oleh</b:widget-setting>
                        <b:widget-setting name='showCommentLink'>true</b:widget-setting>
                        <b:widget-setting name='style.urlcolor'>#767676</b:widget-setting>
                        <b:widget-setting name='showAuthor'>true</b:widget-setting>
                        <b:widget-setting name='style.linkcolor'>#005cf4</b:widget-setting>
                        <b:widget-setting name='style.unittype'>TextAndImage</b:widget-setting>
                        <b:widget-setting name='style.bgcolor'>#ffffff</b:widget-setting>
                        <b:widget-setting name='timestampLabel'>On</b:widget-setting>
                        <b:widget-setting name='reactionsLabel'/>
                        <b:widget-setting name='showAuthorProfile'>true</b:widget-setting>
                        <b:widget-setting name='style.layout'>1x1</b:widget-setting>
                        <b:widget-setting name='showLabels'>true</b:widget-setting>
                        <b:widget-setting name='showLocation'>false</b:widget-setting>
                        <b:widget-setting name='postLabelsLabel'>In</b:widget-setting>
                        <b:widget-setting name='showTimestamp'>true</b:widget-setting>
                        <b:widget-setting name='postsPerAd'>1</b:widget-setting>
                        <b:widget-setting name='showBacklinks'>false</b:widget-setting>
                        <b:widget-setting name='style.bordercolor'>#ffffff</b:widget-setting>
                        <b:widget-setting name='showInlineAds'>false</b:widget-setting>
                        <b:widget-setting name='showReactions'>false</b:widget-setting>
                      </b:widget-settings>
                      <b:includable id='main' var='this'>
                          
                        <b:include cond='data:view.isMultipleItems' name='titlePost'/>
                  
                        <div class='blogPts'>
                          <b:class cond='data:posts.empty' name='mty'/>
                  
                          <!--[ Fullpage condition ]-->
                          <b:class cond='data:view.isSingleItem and data:posts any (p =&gt; p.labels any (l =&gt; l.name in [ &quot;Fullpage&quot; , &quot;Label_2&quot; ]))' name='fullP'/>
                          <b:include cond='data:view.isSingleItem and data:posts any (p =&gt; p.labels any (l =&gt; l.name in [ &quot;Fullpage&quot; , &quot;Label_2&quot; ]))' name='post-singlePage'/>
                      
                          <!--[ If no content found ]-->
                          <b:include name='noContentPlaceholder'/>
                      
                          <b:with value='data:widgets.FeaturedPost filter (w =&gt; w.sectionId == &quot;top-widget&quot;) map (w =&gt; w.postId)' var='featuredPostIds'>
                            <b:with value='data:view.isHomepage ? data:posts filter (post =&gt; post.id not in data:featuredPostIds) : data:posts' var='posts'>
                            
                              <b:loop index='i' values='data:posts' var='post'>
                                <!--[ Remove comment tag below to enable in-feed ad ]-->
                                <!--<b:if cond='data:i == 3'>
                                  <b:include name='post-adIn'/>                                
                                </b:if>
                                <b:if cond='data:i == 6'>
                                  <b:include name='post-adIn'/>                                
                                </b:if>-->
                                <b:include data='post' name='postCommentsAndAd'/>
                              </b:loop>
                          
                            </b:with>
                          </b:with>
                        </div>
                  
                        <b:include cond='data:view.isMultipleItems and !data:posts.empty' name='postPagination'/>
                      </b:includable>
                      <b:includable id='aboutPostAuthor'/>
                      <b:includable id='addComments'/>
                      <b:includable id='blogThisShare'/>
                      <b:includable id='breadcrumb' var='post'>
                        <!--[ Post breadcrumbs ]-->
                        <div class='brdCmb' itemscope='itemscope' itemtype='https://schema.org/BreadcrumbList'>
                          <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])' name='sponsored'/>
                          <div class='hm' itemprop='itemListElement' itemscope='itemscope' itemtype='https://schema.org/ListItem'>
                            <a expr:href='data:blog.homepageUrl.canonical' itemprop='item'><span itemprop='name'><data:messages.home/></span></a>
                            <meta content='1' itemprop='position'/>
                          </div>
                          <b:if cond='data:post.labels'>
                            <b:loop index='num' values='data:post.labels' var='label'>
                              <b:if cond='data:num == 0'>
                                <div class='lb' itemprop='itemListElement' itemscope='itemscope' itemtype='https://schema.org/ListItem'>
                                  <a expr:href='data:label.url.canonical' itemprop='item'><span itemprop='name'><data:label.name/></span></a>
                                  <meta expr:content='data:num+2' itemprop='position'/>
                                </div>
                              </b:if>
                              <b:if cond='data:num == 1 and data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                                <div class='lb' itemprop='itemListElement' itemscope='itemscope' itemtype='https://schema.org/ListItem'>
                                  <a expr:href='data:label.url.canonical' itemprop='item'><span itemprop='name'><data:label.name/></span></a>
                                  <meta expr:content='data:num+2' itemprop='position'/>
                                </div>
                              </b:if>
                            </b:loop>
                            <b:elseif cond='data:view.isPost'/>
                            <div class='lb nob'><data:messages.posts/></div>
                          </b:if>
                            
                          <!--[ Change cond='data:view.isPage' to cond='data:view.isSingleItem' if you want to show post title on breadcrumb ]-->
                          <b:tag class='tl' cond='data:view.isPage' expr:data-text='data:post.title' name='div'/>
                        </div>
                      </b:includable>
                      <b:includable id='bylineByName' var='byline'/>
                      <b:includable id='bylineRegion' var='regionItms'/>
                      <b:includable id='commentAuthorAvatar'/>
                      <b:includable id='commentDeleteIcon' var='comment'/>
                      <b:includable id='commentForm' var='post'/>
                      <b:includable id='commentFormIframeSrc' var='post'/>
                      <b:includable id='commentItem' var='comment'/>
                      <b:includable id='commentList' var='comments'/>
                      <b:includable id='commentPicker' var='post'/>
                      <b:includable id='commentblock' var='cb'>
                        <div class='cmAv'>
                          <b:if cond='data:cb.level.authorAvatarSrc'>
                            <div class='im' expr:data-style='&quot;background-image: url(&quot; + resizeImage(data:cb.level.authorAvatarSrc, 35, &quot;1:1&quot;) + &quot;)&quot;'>
                              <b:class cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='lazy'/>
                              <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' expr:value='&quot;background-image: url(&quot; + resizeImage(data:cb.level.authorAvatarSrc, 35, &quot;1:1&quot;) + &quot;)&quot;' name='style'/>
                            </div>
                          </b:if>
                        </div>
                  
                        &lt;div class=&#39;cmIn&#39;&gt;
                        <div class='cmBd'>
                          <b:class cond='data:cb.level.isDeleted' name='del'/>
                          <b:attr cond='!data:cb.level.isDeleted' name='itemscope' value='itemscope'/>
                          <b:attr cond='!data:cb.level.isDeleted' name='itemtype' value='https://schema.org/Comment'/>
                          <div class='cmHr'>
                            <b:class cond='data:post.author.name == data:cb.level.author' name='a'/>
                            <span class='n'>
                              <b:attr cond='!data:cb.level.isDeleted' name='itemprop' value='author'/>
                              <b:attr cond='!data:cb.level.isDeleted' name='itemscope' value='itemscope'/>
                              <b:attr cond='!data:cb.level.isDeleted' name='itemtype' value='https://schema.org/Person'/>
                              <b:if cond='data:cb.level.author != &quot;Anonymous&quot;'>
                                <bdi><b:attr cond='!data:cb.level.isDeleted' name='itemprop' value='name'/><data:cb.level.author/></bdi>
                                <b:else/>
                                <bdi><b:attr cond='!data:cb.level.isDeleted' name='itemprop' value='name'/>Anonymous</bdi>
                              </b:if>
                            </span>
                    
                            <b:if cond='!data:cb.level.isDeleted'>
                              <!--[ Remove dtTm in className to disable Second Ago script ]-->
                              <b:if cond='data:blog.languageDirection != &quot;rtl&quot;'>
                                <span class='d dtTm' expr:data-datetime='data:cb.level.timestamp'/>
                              </b:if>
                              <span class='d date' expr:data-datetime='data:cb.level.timestamp' itemprop='datePublished'><data:cb.level.timestamp/></span>
                            </b:if>
                          </div>

                          <div class='cmCo'>
                            <b:class cond='!data:post.allowNewComments' name='dis'/>
                            <b:attr cond='!data:cb.level.isDeleted' name='itemprop' value='text'/>
                            <b:if cond='data:cb.level.author != data:post.author.name'>
                              <b:eval expr='data:cb.level.body snippet { links: false }'/>
                              <b:else/>
                              <data:cb.level.body/>
                            </b:if>
                          </div>
                    
                        </div>
                      </b:includable>
                      <b:includable id='comments' var='post'/>
                      <b:includable id='commentsLink'/>
                      <b:includable id='commentsLinkIframe'/>
                      <b:includable id='commentsTitle'>
                        <h3 class='title'>
                          <b:if cond='data:post.numberOfComments &gt; 0'>
                            <b:message name='messages.numberOfComments'>
                              <b:param expr:value='data:post.numberOfComments' name='numComments'/>
                            </b:message>
                            <b:else/>
                            <data:messages.postAComment/>
                          </b:if>
                        </h3>
                      </b:includable>
                      <b:includable id='defaultAdUnit'>
                        <ins class='adsbygoogle' data-ad-format='auto' expr:data-ad-client='data:adClientId ?: data:blog.adsenseClientId' expr:data-ad-host='data:blog.adsenseHostId' expr:data-analytics-uacct='data:blog.analyticsAccountNumber' expr:style='data:style ?: &quot;display: block;&quot;'/>
                        <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
                      </b:includable>
                      <b:includable id='emailPostIcon'/>
                      <b:includable id='facebookShare'/>
                      <b:includable id='feedLinks'/>
                      <b:includable id='feedLinksBody' var='links'/>
                      <b:includable id='footerBylines'/>
                      <b:includable id='googlePlusShare'/>
                      <b:includable id='headerByline'/>
                      <b:includable id='homePageLink'/>
                      <b:includable id='iframeComments' var='post'/>
                      <b:includable id='inlineAd' var='post'>
                        <b:if cond='!data:view.isPreview'>
                          <b:if cond='data:this.adCode or data:this.adClientId or data:blog.adsenseClientId'>
                            <!-- Ad -->
                            <div class='inline-ad'>
                              <b:if cond='data:this.adCode != &quot;&quot;'>
                                <data:this.adCode/>
                                <b:else/>
                                <b:include cond='data:this.adClientId or data:blog.adsenseClientId' name='defaultAdUnit'/>
                              </b:if>
                            </div>
                          </b:if>
                          <b:else/>
                          <div class='inline-ad'>
                            <div class='inline-ad-placeholder'>
                              <span><b:message name='messages.adsGoHere'/></span>
                            </div>
                          </div>
                        </b:if>
                      </b:includable>
                      <b:includable id='linkShare'/>
                      <b:includable id='manageComments'/>
                      <b:includable id='nextPageLink'/>
                      <b:includable id='noContentPlaceholder'>
                        <b:if cond='data:posts.empty'>
                         
                    <!--[ No posts messages ]-->
                          <div class='noPosts'><data:messages.noResultsFound/>...</div>
                        </b:if>
                      </b:includable>
                      <b:includable id='otherSharingButton'/>
                      <b:includable id='platformShare'/>
                      <b:includable id='post' var='post'/>
                      <b:includable id='postAuthor'/>
                      <b:includable id='postBody' var='post'/>
                      <b:includable id='postBodySnippet' var='post'/>
                      <b:includable id='postCommentsAndAd' var='post'>
                        
                        <!--[ Post article ]-->
                        <article class='ntry'>
                          <b:class cond='data:view.isSingleItem' name='ps'/>
                          <b:class cond='data:view.isSingleItem' name='post'/>
                          <b:class cond='data:view.isMultipleItems and !data:post.featuredImage' name='noThmb'/>
                          <b:class cond='!data:widgets.Blog.first.allBylineItems.timestamp' name='noInf'/>
                          <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])' name='noAd'/>
                          <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])' name='pTag'/>
                    
                          <!--[ Post brdCmb ]-->
                          <b:include cond='data:view.isSingleItem' data='post' name='breadcrumb'/>
                        
                          <b:if cond='data:view.isMultipleItems'>
                              
                              
                          
                         
                            <!--[ Post thumbnail and labels ]-->
                            <div class='pThmb'>
                              <b:class cond='data:post.featuredImage.isYoutube' name='iyt'/>
                              <b:class cond='!data:post.featuredImage' name='nul'/>
                              <b:tag class='thmb' expr:name='data:post.featuredImage ? &quot;a&quot; : &quot;div&quot;'>
                                <b:attr cond='data:post.featuredImage' expr:value='data:post.url' name='href'/>
                                <b:if cond='data:post.featuredImage'>
                                  <b:include name='postEntryThumbnail'/>
                                  <b:else/>
                                  <span class='imgThm' data-text='No image'/>
                                </b:if>
                              </b:tag>
                                
                              <!--[ Comments count ]-->
                              <b:tag class='iFxd' cond='data:post.allowComments and data:post.numberOfComments &gt; 0 or data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])' name='div'>
                                <b:if cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                                  <b:include name='postSponsored'/>
                                  <b:elseif cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])'/>
                                  <b:include name='postProduct'/>
                                </b:if>
                                <b:if cond='data:widgets.Blog.first.allBylineItems.comments and data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])'>
                                  <b:include name='postCommentsLinks'/>
                                </b:if>
                              </b:tag>
                            </div>
                          </b:if>
                    
                          <b:tag class='pCntn' cond='data:view.isMultipleItems' name='div'>
                              
                            <!--[ Post header ]-->
                            <b:include cond='data:view.isMultipleItems' name='postHeaders'/>
                          
                            <!--[ Post title ]-->
                            <b:tag class='pTtl aTtl sml' expr:name='data:post.link or (data:post.url and data:view.url != data:post.url) ? &quot;h2&quot; : &quot;h1&quot;'>
                              <b:class cond='data:view.isSingleItem' name='itm'/>
                              <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])' name='nSpr'/>
                              <b:tag expr:name='data:post.link or (data:post.url and data:view.url != data:post.url) ? &quot;a&quot; : &quot;span&quot;'>
                                <b:attr cond='data:post.link or (data:post.url and data:view.url != data:post.url)' expr:value='data:post.url.canonical' name='href'/>
                                <b:attr cond='data:post.link or (data:post.url and data:view.url != data:post.url)' expr:value='data:post.title' name='data-text'/>
                                <b:attr cond='data:post.link or (data:post.url and data:view.url != data:post.url)' name='rel' value='bookmark'/>
                                <data:post.title/>
                              </b:tag>
                            </b:tag>
                              
                            <b:if cond='data:blog.metaDescription and data:view.isPost'>
                              <!-- Post Description -->
                              <div class='pDesc'><data:blog.metaDescription/></div>
                            </b:if>
                          
                            <b:if cond='data:view.isMultipleItems'>
                              <!--[ Post snippets ]-->
                              <div class='pSnpt'>
                                <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])' name='nTag'/>
                                <b:include name='postEntrySnippet'/>
                              </div>
                            </b:if>
                        
                            <!--[ Post info ]-->
                            <b:include cond='!data:view.isPage' name='postInfo'/>
                        
                            <b:tag class='pInr' cond='data:view.isSingleItem' name='div'>
                              <b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                                <!--[ Post top ad ]-->
                                <b:include cond='data:view.isPost and !data:view.isPreview' data='post' name='post-adTop'/>
                              </b:if>
                          
                              <b:if cond='data:view.isSingleItem'>
                                <!--[ Post body ]-->
                                <div class='pEnt' expr:id='&quot;postID-&quot; + data:post.id'>
                                   
    <div class='greeting'><svg version='1.1' viewBox='0 0 106.059 106.059' x='0' xmlns='http://www.w3.org/2000/svg' y='0'><path d='M90.546 15.518c-20.688-20.69-54.346-20.69-75.03-.005-20.688 20.685-20.686 54.345.002 75.034 20.682 20.684 54.34 20.684 75.026-.004 20.686-20.685 20.684-54.343.002-75.025zm-5.789 69.24c-17.493 17.494-45.961 17.496-63.455.002-17.498-17.497-17.495-45.966 0-63.46 17.494-17.493 45.96-17.495 63.457.002 17.494 17.494 17.492 45.963-.002 63.456zM33.299 44.364h-3.552a.822.822 0 0 1-.82-.817c0-.184.062-.363.175-.507l7.695-9.755c.158-.196.392-.308.645-.308s.486.111.641.304l7.697 9.757c.189.237.229.58.1.859a.822.822 0 0 1-.741.467h-3.554a.59.59 0 0 1-.463-.225l-3.68-4.664-3.681 4.664a.59.59 0 0 1-.462.225zm44.599-1.326a.84.84 0 0 1 .1.859.822.822 0 0 1-.741.467h-3.554a.588.588 0 0 1-.463-.225l-3.681-4.664-3.681 4.664a.59.59 0 0 1-.462.225h-3.552a.822.822 0 0 1-.82-.817c0-.184.062-.363.175-.507l7.695-9.755a.823.823 0 0 1 .645-.308c.254 0 .486.111.642.304l7.697 9.757zm-1.882 21.03c-3.843 8.887-12.843 14.629-22.927 14.629-10.301 0-19.354-5.771-23.064-14.703a3 3 0 1 1 5.54-2.3c2.776 6.686 9.655 11.004 17.523 11.004 7.69 0 14.528-4.321 17.42-11.011a2.999 2.999 0 0 1 3.944-1.563 2.999 2.999 0 0 1 1.564 3.944z'/></svg><span id='greeting'/></div>
      
                                  <div class='pS post-body postBody' id='postBody'><data:post.body/></div>
                                </div>
                              </b:if>
                              
                              <b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                                <!--[ Post bottom ad ]-->
                                <b:include cond='data:view.isPost and !data:view.isPreview' data='post' name='post-adBot'/>
                              </b:if>
                      
                              <b:include data='post' name='postMetadataJSON'/>
                              
                              <b:if cond='data:view.isPost and data:widgets.Blog.first.allBylineItems.timestamp and data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])'>
                                <script>/*<![CDATA[*/ function get_text(el) {ret = ''; var length = el.childNodes.length; for(var i = 0; i < length; i++) {var node = el.childNodes[i]; if(node.nodeType != 8) {ret += node.nodeType != 1 ? node.nodeValue : get_text(node);} } return ret;} var words = get_text(document.getElementById('postBody')); var count = words.split(' ').length; var avg = 200; var counted = count / avg; var maincount = Math.round(counted); document.getElementById('rdTime').innerHTML = maincount + ' min read'; /*]]>*/</script>
                              </b:if>
                        
                              <b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])'>
                               <!--[ Tags ]-->           
                                <b:if cond='data:blog.pageType == &quot;item&quot;'> 
                                  
                                    <span class='pLbL'>        
                                      <b:if cond='data:post.labels'> 
      
                                       <b:loop values='data:post.labels' var='label'>     
                                      <a expr:href='data:label.url + &quot;?max-results=9&quot;' expr:title='data:label.name' rel='tag nofollow'><data:label.name/></a>                                                </b:loop>
                                  </b:if>
                                 </span> 
                                </b:if>
                                <!--[ Post writter ]-->
                                <b:include cond='data:post.author.aboutMe and data:view.isPost and !data:view.isPreview' name='post-authorProfile'/>
                              </b:if>
                          
                              <!--[ Share button ]-->
                              <b:include cond='data:post.shareUrl and data:view.isPost and !data:view.isPreview' name='postInfoShare'/>
                     
                              
                              
                            </b:tag>
                          
                          </b:tag>
                        </article>
                  
                        <!--[ Post footer ]-->
                        <b:tag class='pFoot' cond='data:view.isPost' name='div'>
                          <!--[ Share button pop-up/sticky ]-->
                          <b:include cond='data:post.shareUrl and data:view.isPost and !data:view.isPreview' name='postInfoShareMore'/>
                            
                          <!--[ Related post ]-->
                          <b:include cond='data:view.isPost and !data:view.isPreview' data='post' name='post-related'/>
                    
                          <!--[ Matched content ad ]-->
                          <!--<b:include cond='data:view.isPost and !data:view.isPreview' data='post' name='post-relatedAd'/>-->
                    
                          <b:tag class='pCmnts' cond='data:post.allowComments and data:view.isPost and !data:view.isPreview' id='comment' name='div'>
                            <!--[ Blogger Comments ]-->
                            <b:include cond='data:post.allowComments and data:view.isPost and !data:view.isPreview' data='post' name='threadedComments-modifV3'/>
                          </b:tag>
                        </b:tag>
                        
                        <!--[ Show ad. ]-->
                        <b:include cond='data:post.includeAd' data='post' name='inlineAd'/>
                      </b:includable>
                      <b:includable id='postCommentsLink'/>
                      <b:includable id='postFooter' var='post'/>
                      <b:includable id='postFooterAuthorProfile' var='post'/>
                      <b:includable id='postHeader'/>
                      <b:includable id='postInfo'>
                        <b:tag class='pInf pSml' name='div'>
                          <b:class cond='data:view.isSingleItem' name='ps'/>
                          <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])' name='nSpr'/>
                          <b:class cond='!data:widgets.Blog.first.allBylineItems.timestamp' name='nTm'/>
                          <b:class cond='!data:widgets.Blog.first.allBylineItems.author and !data:widgets.Blog.first.allBylineItems.timestamp and (!data:post.shareUrl and !data:widgets.Blog.first.allBylineItems.share) and (!data:post.allowComments and !data:widgets.Blog.first.allBylineItems.comments or data:post.numberOfComments == 0)' name='nul'/>
                        
                          <b:if cond='data:view.isMultipleItems'>
                            <b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])'>
                                         
                              <!--[ Post timestamp ]-->
                              <b:include cond='data:widgets.Blog.first.allBylineItems.timestamp' name='postTimestampPublish'/>
                            </b:if>
                      
                            
                   
                            <!--[ Post jumplinks ]-->
                            <b:include cond='data:widgets.Blog.first.allBylineItems.timestamp and data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])' name='postJumpLinks'/>                    
                        
                            <b:else/>
                      
                            <!--[ Info in item page ]-->
                            <b:if cond='data:widgets.Blog.first.allBylineItems.author and data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])'>
                              <b:if cond='data:post.author.authorPhoto.image'>
                                <div class='pIm ps'><b:include name='post-authorImage'/></div>
                              </b:if>
                            </b:if>
                              
                            <b:tag class='pNm' cond='data:widgets.Blog.first.allBylineItems.author or data:widgets.Blog.first.allBylineItems.timestamp' name='div'>
                              <b:class cond='!data:widgets.Blog.first.allBylineItems.timestamp and data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])' name='l'/>
                              <b:class cond='!data:post.author.authorPhoto.image' name='n'/>
                              <b:include cond='data:widgets.Blog.first.allBylineItems.author and data:post.labels none (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])' name='post-authorName'/>
                                
                              <b:if cond='data:widgets.Blog.first.allBylineItems.timestamp'>
                                <div class='pDr'>
                                  <bdi class='pDt pIn'><b:include name='postTimestamps'/></bdi>
                                
                                  <b:if cond='data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])'>
                                
                                    <!--[ Reading time ]-->
                                    <div class='pRd pIn'><bdi id='rdTime'/></div>
                                  </b:if>
                                  <!--[ Post Views Counter By SmartTechMukesh.Com ]-->
<div class='views-counter'>
<span><svg class='line' viewBox='0 0 24 24'><g transform='translate(2.000000, 4.000000)'><path class='svgC' d='M13.1643,8.0521 C13.1643,9.7981 11.7483,11.2141 10.0023,11.2141 C8.2563,11.2141 6.8403,9.7981 6.8403,8.0521 C6.8403,6.3051 8.2563,4.8901 10.0023,4.8901 C11.7483,4.8901 13.1643,6.3051 13.1643,8.0521 Z'/><path d='M0.7503,8.0521 C0.7503,11.3321 4.8923,15.3541 10.0023,15.3541 C15.1113,15.3541 19.2543,11.3351 19.2543,8.0521 C19.2543,4.7691 15.1113,0.7501 10.0023,0.7501 C4.8923,0.7501 0.7503,4.7721 0.7503,8.0521 Z'/></g></svg><span expr:data-id='data:post.id' id='viewscount'/>Views</span>
</div>    
                                </div>
                              </b:if>
                            </b:tag>
                              
                            <b:if cond='(data:post.allowComments and data:widgets.Blog.first.allBylineItems.comments and data:post.numberOfComments &gt; 0) or (data:post.shareUrl and data:widgets.Blog.first.allBylineItems.share)'>
                              <div class='pCm'>
                                <b:class cond='(data:post.allowComments and data:widgets.Blog.first.allBylineItems.comments and data:post.numberOfComments &gt; 0) and (data:post.shareUrl and data:widgets.Blog.first.allBylineItems.share)' name='l'/>
                                <div class='pIc'>
                                  <b:include cond='data:post.allowComments and data:widgets.Blog.first.allBylineItems.comments' name='postCommentsLabel'/>
                                  
                                   <div class='hartomy-bookmark-btn' data-quantity='1' expr:data-borkimage='resizeImage(data:post.featuredImage, 400, &quot;16:9&quot;)' expr:data-id='data:post.id' expr:data-link='data:post.url' expr:data-title='data:post.title'><svg class='line' viewBox='0 0 24 24'><g transform='translate(4.500000, 2.500000)'><path d='M7.47024319,0 C1.08324319,0 0.00424318741,0.932 0.00424318741,8.429 C0.00424318741,16.822 -0.152756813,19 1.44324319,19 C3.03824319,19 5.64324319,15.316 7.47024319,15.316 C9.29724319,15.316 11.9022432,19 13.4972432,19 C15.0932432,19 14.9362432,16.822 14.9362432,8.429 C14.9362432,0.932 13.8572432,0 7.47024319,0 Z'/><line transform='translate(-4.500000, -2.500000)' x1='12' x2='12' y1='6' y2='12'/><line transform='translate(-4.500000, -2.500000)' x1='15' x2='9' y1='9' y2='9'/></g></svg>
                                  
                                  <!--[ Google Translate button ]-->
                                <label class='tIc bIc' expr:aria-label='data:item' role='button'><b:include name='translate-icon'/><span id='google_translate_element'/></label>
                                  
                                  
                                <!--  <b:if cond='data:post.shareUrl and data:widgets.Blog.first.allBylineItems.share'>
                                    <label class='sh tIc' for='forShare'><b:include name='share-icon'/></label> -->
                                    
                                
                                   
                                </div>
                               </div>
                            </div>
                                </b:if>
                            
                            
                           <div class='hartomy-bookmark-btn' data-quantity='1' expr:data-borkimage='resizeImage(data:post.featuredImage, 400, &quot;16:9&quot;)' expr:data-id='data:post.id' expr:data-link='data:post.url' expr:data-title='data:post.title'><svg class='line' viewBox='0 0 24 24'><g transform='translate(4.500000, 2.500000)'><path d='M7.47024319,0 C1.08324319,0 0.00424318741,0.932 0.00424318741,8.429 C0.00424318741,16.822 -0.152756813,19 1.44324319,19 C3.03824319,19 5.64324319,15.316 7.47024319,15.316 C9.29724319,15.316 11.9022432,19 13.4972432,19 C15.0932432,19 14.9362432,16.822 14.9362432,8.429 C14.9362432,0.932 13.8572432,0 7.47024319,0 Z'/><line transform='translate(-4.500000, -2.500000)' x1='12' x2='12' y1='6' y2='12'/><line transform='translate(-4.500000, -2.500000)' x1='15' x2='9' y1='9' y2='9'/></g></svg>
</div>
                          </b:if>
                        </b:tag>
                      </b:includable>
                      <b:includable id='postInfoShare'>
                        <div class='pSh'>
                          <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])' name='nSpr'/>
                          <div class='pShc' expr:data-text='data:messages.share + &quot;:&quot;'>
                            <!-- Share to Facebook -->
                            <a aria-label='Facebook' class='c fb' data-text='Share' expr:href='&quot;https://www.facebook.com/sharer.php?u=&quot; + data:blog.url.canonical' rel='noopener' role='button' target='_blank'><b:include name='facebook-r-icon'/></a>
                            
                            <!-- Share to Whatsapp -->
                            <a aria-label='Whatsapp' class='c wa' data-text='Share' expr:href='&quot;https://api.whatsapp.com/send?text=&quot; + data:blog.url.canonical' rel='noopener' role='button' target='_blank'><b:include name='whatsapp-r-icon'/></a>
                                
                            <!-- Share to Twitter -->
                            <a aria-label='Twitter' class='c tw' data-text='Tweet' expr:href='&quot;https://twitter.com/share?url=&quot; + data:blog.url.canonical' rel='noopener' role='button' target='_blank'><b:include name='twitter-r-icon'/></a>
                            
                            <label expr:aria-label='data:messages.shareToOtherApps' for='forShare'><b:include name='plus-icon'/></label>
                          </div>
                        </div>
                      </b:includable>
                      <b:includable id='postInfoShareMore'>
                        <input class='shIn fixi hidden' id='forShare' type='checkbox'/>
                        <div class='shBr fixL'>
                          <div class='shBri fixLi'>
                            <div class='shBrs fixLs'>
                              <div class='shH fixH fixT' expr:data-text='data:messages.shareToOtherApps'>
                                <label aria-label='Close' class='c cl' for='forShare'/>
                              </div>
                              <div class='shC'>
                                <!--[ Share to other apps ]-->
                                <div class='shL'>
                                  <div data-text='Facebook'>
                                    <!-- Share to Facebook -->
                                    <a aria-label='Facebook' expr:href='&quot;https://www.facebook.com/sharer.php?u=&quot; + data:blog.url.canonical' rel='noopener' target='_blank'>
                                      <b:include name='facebook-icon'/>
                                    </a>
                                  </div>
                                    
                                  <div data-text='WhatsApp'>
                                    <!-- Share to Whatsapp -->
                                    <a aria-label='Whatsapp' expr:href='&quot;https://api.whatsapp.com/send?text=&quot; + data:blog.url.canonical' rel='noopener' target='_blank'>
                                      <b:include name='whatsapp-icon'/>
                                    </a>
                                  </div>
                                    
                                  <div data-text='Twitter'>
                                    <!-- Share to Twitter -->
                                    <a aria-label='Twitter' expr:href='&quot;https://twitter.com/share?url=&quot; + data:blog.url.canonical' rel='noopener' target='_blank'>
                                      <b:include name='twitter-icon'/>
                                    </a>
                                  </div>
                                    
                                  <div data-text='Telegram'>
                                    <!-- Share to Telegram -->
                                    <a aria-label='Telegram' expr:href='&quot;https://t.me/share/url?url=&quot; + data:blog.url.canonical' rel='noopener' target='_blank'>
                                      <b:include name='telegram-icon'/>
                                    </a>
                                  </div>
                                    
                                  <div data-text='Pinterest'>
                                    <!-- Pin to Pinterst -->
                                    <a aria-label='Pinterest' data-pin-config='beside' expr:href='&quot;https://pinterest.com/pin/create/button/?url=&quot; + data:blog.url.canonical + &quot;&amp;media=&quot; + resizeImage(data:blog.postImageUrl, 1600)' rel='noopener' target='_blank'>
                                      <b:include name='pinterest-icon'/>
                                    </a>
                                  </div>
                                    
                                  <div data-text='LinkedIn'>
                                    <!-- Share Linkedin -->
                                    <a aria-label='Linkedin' expr:href='&quot;https://www.linkedin.com/sharing/share-offsite/?url=&quot; + data:blog.url.canonical' rel='noopener' target='_blank'>
                                      <b:include name='linkedIn-icon'/>
                                    </a>
                                  </div>
                                    
                                  <div data-text='Line'>
                                    <!-- Share to Line -->
                                    <a aria-label='Line' expr:href='&quot;https://timeline.line.me/social-plugin/share?url=&quot; + data:blog.url.canonical' rel='noopener' target='_blank'>
                                      <b:include name='line-icon'/>
                                    </a>
                                  </div>
                                    
                                  <div data-text='Email'>
                                    <!-- Send to email -->
                                    <a aria-label='Email' expr:href='&quot;mailto:?body=&quot; + data:blog.url.canonical' target='_blank'>
                                      <b:include name='message-icon'/>
                                    </a>
                                  </div>
                                </div>
                                  
                                <!--[ Copy link ]-->
                                <div class='cpL' data-text='or copy link' expr:data-message='data:messages.copyToClipboard'>
                                  <div class='cpLb'>
                                    <b:include name='link-alt-icon'/>
                                    <input expr:value='data:blog.url.canonical' id='getlink' onClick='this.select()' readonly='readonly'/>
                                    <label for='getlink' onclick='copyFunction()'><data:messages.copy/></label>
                                  </div>
                                  
                                  <p class='note hidden' id='cpNotif'/>
                                  
                                  <script>function copyFunction(){document.getElementById(&quot;getlink&quot;).select(),document.execCommand(&quot;copy&quot;),document.getElementById(&quot;cpNotif&quot;).innerText=&quot;<data:messages.linkCopiedToClipboard/>&quot;;document.getElementById(&quot;cpNotif&quot;).classList.remove(&#39;hidden&#39;);setTimeout(function () {document.getElementById(&quot;cpNotif&quot;).classList.add(&#39;hidden&#39;);},2500);};</script>
                              </div>
                              </div>
                            </div>
                          </div>
                            
                          <label class='fCls' for='forShare'/>
                        </div>
                      </b:includable>
                      <b:includable id='postJumpLink' var='post'/>
                      <b:includable id='postLabels'/>
                      <b:includable id='postLocation'/>
                      <b:includable id='postMeta' var='post'>
                        <b:include data='post' name='postMetadataJSON'/>
                      </b:includable>
                      <b:includable id='postMetadataJSON'>
                        <script type='application/ld+json'>
                          {
                            &quot;@context&quot;: &quot;http://schema.org&quot;,
                            &quot;@type&quot;: &quot;BlogPosting&quot;,
                            &quot;mainEntityOfPage&quot;: {
                              &quot;@type&quot;: &quot;WebPage&quot;,
                              &quot;@id&quot;: &quot;<data:post.url.canonical.jsonEscaped/>&quot;
                            },
                            &quot;headline&quot;: &quot;<data:post.title.jsonEscaped/>&quot;,
                            &quot;description&quot;: &quot;<b:eval expr='(data:post.body snippet { length: 255, links: false, linebreaks: false, ellipsis: true }).jsonEscaped'/>&quot;,
                            <b:if cond='data:view.isSingleItem'>&quot;articleBody&quot;: &quot;<b:eval expr='(data:post.body).escaped'/>&quot;,</b:if>
                            &quot;datePublished&quot;: &quot;<data:post.date.iso8601.jsonEscaped/>&quot;,
                            &quot;dateModified&quot;: &quot;<data:post.lastUpdated.iso8601.jsonEscaped/>&quot;,
                            <b:include data='post' name='postMetadataJSONImage'/><b:include data='post' name='postMetadataJSONPublisher'/>
                            &quot;author&quot;: {
                              &quot;@type&quot;: &quot;Person&quot;,
                              &quot;name&quot;: &quot;<data:post.author.name.jsonEscaped/>&quot;,
                              &quot;url&quot;: &quot;<b:if cond='data:post.author.profileUrl'><data:post.author.profileUrl.jsonEscaped/><b:else/><data:blog.homepageUrl.jsonEscaped/></b:if>&quot;,
                              &quot;image&quot;: &quot;<data:post.author.authorPhoto.image.jsonEscaped/>&quot;
                            }
                          }
                        </script>
                      </b:includable>
                      <b:includable id='postMetadataJSONImage'>
                            &quot;image&quot;: {
                              &quot;@type&quot;: &quot;ImageObject&quot;,
                              &quot;url&quot;: &quot;<b:eval expr='(data:post.featuredImage ? resizeImage(data:post.featuredImage, 1200, &quot;1200:630&quot;) : &quot;https://1.bp.blogspot.com/-E250bQMM8tk/XomH5DdorOI/AAAAAAAAPY8/SCYwi79WjckWC8wHKK7OblI82BpT9JquACNcBGAsYHQ/s1600/jagotheme-img.png&quot;).jsonEscaped'/>&quot;,
                              &quot;height&quot;: <b:eval expr='data:post.featuredImage ? 630 : 348'/>,
                              &quot;width&quot;: 1200
                            },
                      </b:includable>
                      <b:includable id='postMetadataJSONPublisher'>
                            &quot;publisher&quot;: {
                              &quot;@type&quot;: &quot;Organization&quot;,
                              &quot;name&quot;: &quot;<data:blog.title.escaped/>&quot;,
                              &quot;logo&quot;: {
                                &quot;@type&quot;: &quot;ImageObject&quot;,
                                &quot;url&quot;: &quot;https://1.bp.blogspot.com/-50s1RMWV7jI/X8OaYjJcMiI/AAAAAAAAQK4/sWcpbaP0Sq0hsW473Vnb8AyBvYvdSQEPwCNcBGAsYHQ/s0/jd-logo.png&quot;,
                                &quot;width&quot;: 297,
                                &quot;height&quot;: 45
                              }
                            },
                      </b:includable>
                      <b:includable id='postPagination'>
                        <!--[ Blog navigation ]-->
                        <div class='blogPg' id='blogPager'>
                          <b:tag class='nPst' cond='data:view.url == data:blog.homepageUrl and !data:olderPageUrl' expr:data-text='data:messages.noResultsFound' name='div'/>
                      
                          <b:include cond='!data:posts.empty' name='postPagination.new'/>
                          <b:include cond='!data:posts.empty' name='postPagination.home'/>
                          <b:include cond='!data:posts.empty' name='postPagination.old'/>
                        </div>
                      </b:includable>
                      <b:includable id='postPagination.home'>
                        <b:tag class='hmLnk' expr:name='data:view.url != data:blog.homepageUrl ? &quot;a&quot; : &quot;div&quot;'>
                          <b:class cond='data:view.url == data:blog.homepageUrl' name='nPst'/>
                          <b:attr cond='data:view.url != data:blog.homepageUrl' expr:value='data:blog.homepageUrl.canonical' name='href'/>
                          <b:attr cond='data:view.url != data:blog.homepageUrl' expr:value='data:messages.home' name='aria-label'/>
                          <b:attr cond='data:posts.empty' expr:value='data:messages.home' name='data-text'/>
                          <b:include cond='!data:posts.empty' name='home-alt-icon'/>
                        </b:tag>                      
                      </b:includable>
                      <b:includable id='postPagination.new'>
                        <b:if cond='data:newerPageUrl and data:view.url != data:blog.homepageUrl.canonical path &quot;search&quot;'>
                          <a class='nwLnk' expr:aria-label='data:messages.newest' expr:data-text='data:messages.newest' expr:href='data:newerPageUrl.canonical'>
                            <b:if cond='data:blog.languageDirection != &quot;rtl&quot;'>
                              <b:include name='arrow-left-icon'/>
                              <b:else/>
                              <b:include name='arrow-right-icon'/>
                            </b:if>
                          </a>
                          <b:else/>
                          <div class='nwLnk nPst' expr:data-text='data:messages.newest'>
                            <b:if cond='data:blog.languageDirection != &quot;rtl&quot;'>
                              <b:include name='arrow-left-icon'/>
                              <b:else/>
                              <b:include name='arrow-right-icon'/>
                            </b:if>
                          </div>
                        </b:if>
                      </b:includable>
                      <b:includable id='postPagination.old'>
                        <b:tag class='olLnk' expr:data-text='data:messages.oldest' expr:name='data:olderPageUrl ? &quot;a&quot; : &quot;div&quot;'>
                          <b:class cond='!data:olderPageUrl' name='nPst'/>
                          <b:attr cond='data:olderPageUrl' expr:value='data:olderPageUrl.canonical' name='href'/>
                          <b:attr cond='data:olderPageUrl' expr:value='data:messages.oldest' name='aria-label'/>
                          <b:if cond='data:blog.languageDirection != &quot;rtl&quot;'>
                            <b:include name='arrow-right-icon'/>
                            <b:else/>
                            <b:include name='arrow-left-icon'/>
                          </b:if>
                        </b:tag>
                      </b:includable>
                      <b:includable id='postReactions'/>
                      <b:includable id='postShareButtons'/>
                      <b:includable id='postTimestamp'/>
                      <b:includable id='postTitle' var='post'/>
                      <b:includable id='previousPageLink'/>
                      <b:includable id='sharingButton'/>
                      <b:includable id='sharingButtonContent'/>
                      <b:includable id='sharingButtons'/>
                      <b:includable id='sharingButtonsMenu'/>
                      <b:includable id='sharingPlatformIcon'/>
                      <b:includable id='threadedCommentForm' var='post'/>
                      <b:includable id='threadedCommentJs' var='post'/>
                      <b:includable id='threadedComments' var='post'/>
                      <b:includable id='threadedComments-form' var='post'>
                        <div id='commentForm'>
                          <!--[ Comment message ]-->
                          <b:if cond='data:this.messages.blogComment != &quot;&quot;'>
                            <div class='cmMs note'>
                              <data:this.messages.blogComment/>
                            </div>
                          </b:if>
                            
                          <!--[ Comment iframe (remove comment tag below to improve height of comment form) ]-->
                          <!--<a aria-label='Comment Form' expr:href='data:post.commentFormIframeSrc + &quot;&amp;skin=contempo&quot; + data:variantParam' id='comment-editor-src'/>-->
                          <iframe class='blogger-iframe-colorize blogger-comment-from-post lazy' expr:data-src='data:post.commentFormIframeSrc appendParams {skin: &quot;contempo&quot;}' height='296' id='comment-editor' name='comment-editor' title='Blogger comment' width='100'/>
                         
                          <!--<script src='https://www.blogger.com/static/v1/jsbin/1875144490-comment_from_post_iframe.js'/>
                          <script>BLOG_CMT_createIframe(&#39;<data:post.appRpcRelayPath/>&#39;);</script>-->
                        </div>
                      </b:includable>
                      <b:includable id='threadedComments-modifV3' var='post'>
                        <b:tag class='cmSh fixi hidden' id='forComments' name='input' type='checkbox'/>
                        <b:tag class='cmAl hidden' cond='data:post.numberOfComments &gt; 0' id='forAllCm' name='input' type='checkbox'/>
                          
                        <!--[ Delete tag below to disable show/hide comment ]-->
                        <b:include cond='data:post.allowComments' name='post-commentButton'/>
                    
                        <section class='cm' expr:data-embed='data:post.embedCommentForm' expr:data-num-comments='data:post.numberOfComments' id='comments'>
                            
                          <!--[ Delete tag below to disable Pop-up comments ]-->
                          <b:class name='cmBr fixL'/>
                            
                          <b:tag class='cmBri' name='div'>
                            <b:class cond='data:post.numberOfComments == 0' name='mty'/>
                            <b:tag class='cmBrs fixLs' name='div'>
                    
                              <!--[ Comments title ]-->
                              <div class='cmH fixH'>
                                <b:include name='commentsTitle'/>
                        
                                <div class='cmI cl'>
                                  <!-- Sort comments -->
                                  <b:if cond='data:post.numberOfComments &gt; 0'>
                                    <label class='s' expr:aria-label='data:messages.manageComments' expr:data-new='data:messages.newest' expr:data-text='data:messages.oldest' for='forAllCm'/>
                                  </b:if>
                                  
                                  <label aria-label='Close' class='c' for='forComments'/>
                                </div>
                              </div>
                      
                              <div class='cmC'>
                                <b:if cond='data:post.numberOfComments &gt; 0'>
                                  <div class='cmCn'>
                          
                                    <ol class='cmHl' id='cmHolder'>
                                      <b:loop values='data:post.comments where (c =&gt; not c.inReplyTo)' var='commentLevel1'>
                                        <li class='c' expr:id='&quot;c&quot; + data:commentLevel1.id'>
                                          <b:class cond='data:cb.level.author == data:post.author.name' name='adm'/>
                                          <b:include data='{level: data:commentLevel1,d: true}' name='commentblock'/>
                              
                                          <b:with value='data:post.comments where (c =&gt; c.inReplyTo == data:commentLevel1.id)' var='commentL2'>
                                            <b:if cond='data:commentL2.size != &quot;0&quot;'>
                                              <input class='cmRi hidden' expr:id='&quot;to-&quot; + data:commentLevel1.id' type='checkbox'/>
                                                
                                              <div class='cmRp'>
                                                <div class='cmTh' expr:id='&quot;c&quot; + data:commentLevel1.id + &quot;-rt&quot;'>
                                                  <label class='thTg' data-text='Hide replies' expr:aria-label='&quot;View &quot; +data:commentL2.length+ &quot; replies&quot;' expr:for='&quot;to-&quot; + data:commentLevel1.id'/>
                                    
                                                  <ol class='thCh'>
                                                    <b:loop values='data:commentL2' var='commentLevel2'>
                                                      <li class='c' expr:id='&quot;c&quot; + data:commentLevel2.id'>
                                                        <b:class cond='data:cb.level.author == data:post.author.name' name='adm'/>
                                                        <b:include data='{level: data:commentLevel2,d: true}' name='commentblock'/>
                                                        &lt;/div&gt;
                                                      </li>
                                                    </b:loop>
                                                  </ol>
                                    
                                                </div>
                                                <b:if cond='data:post.allowNewComments'>
                                                  <div class='cmAc cmR'>
                                                    <a aria-label='Reply' class='rpTo' data-text='Reply' expr:data-reply-to='data:commentLevel1.id' href='javascript:;' target='_self'/>
                                                  </div>
                                                </b:if>
                                              </div>
                                            </b:if>
                                          </b:with>
                              
                                          <b:if cond='data:post.allowNewComments'>
                                            <div class='cmAc'>
                                              <a aria-label='Reply' class='rpTo' data-text='Reply' expr:data-reply-to='data:commentLevel1.id' href='javascript:;' target='_self'/>
                                            </div>
                                          </b:if>
                                          &lt;/div&gt;
                                        </li>
                                      </b:loop>
                                    </ol>
                                
                                    <!--[ Timeago script ]-->
                                    <b:if cond='data:blog.languageDirection != &quot;rtl&quot;'>
                                      <script>/*<![CDATA[*/ (function timeAgo(selector) { var templates = {prefix: "", suffix: "", seconds: "second ago", minute: "1 min", minutes: "%d min", hour: "1 hour", hours: "%d hour", day: "1 day", days: "%d days", month: "1 month", months: "%d month", year: "1 year", years: "%d years"}; var template = function(t, n) { return templates[t] && templates[t].replace(/%d/i, Math.abs(Math.round(n))); }; var timer = function(time) { if (!time) return; time = time.replace(/\.\d+/, ""); time = time.replace(/-/, "/").replace(/-/, "/"); time = time.replace(/T/, " ").replace(/Z/, " UTC"); time = time.replace(/([\+\-]\d\d)\:?(\d\d)/, " $1$2"); time = new Date(time * 1000 || time); var now = new Date(); var seconds = ((now.getTime() - time) * .001) >> 0; var minutes = seconds / 60; var hours = minutes / 60; var days = hours / 24; var years = days / 365; return templates.prefix + ( seconds < 45 && template('seconds', seconds) || seconds < 90 && template('minute', 1) || minutes < 45 && template('minutes', minutes) || minutes < 90 && template('hour', 1) || hours < 24 && template('hours', hours) || hours < 42 && template('day', 1) || days < 30 && template('days', days) || days < 45 && template('month', 1) || days < 365 && template('months', days / 30) || years < 1.5 && template('year', 1) || template('years', years) ) + templates.suffix; }; var elements = document.getElementsByClassName('dtTm'); for (var i in elements) { var $this = elements[i]; if (typeof $this === 'object') { $this.innerHTML = timer($this.getAttribute('title') || $this.getAttribute('data-datetime')); } } setTimeout(timeAgo, 60000); })(); /*]]>*/</script>
                                    </b:if>
                                  </div>
                      
                                  <b:if cond='data:post.allowNewComments'>
                                    <div class='cmAd hidden' id='addCm'>
                                      <div aria-label='Berkomentar' class='cmBtn button' role='button'>
                                        <!--[ Delete tag bellow to change button style ]-->
                                        <b:class name='ln'/>
                                          
                                        <b:message name='messages.postAComment'/>
                                      </div>
                                    </div>
                                  </b:if>
                              
                                  <script>var comment = true;</script>
                                  <b:else/>
                                  <script>var comment = false;</script>
                                </b:if>
                    
                                <div class='cmFrm'>
                                  <b:if cond='data:post.embedCommentForm'>
                                    <b:if cond='data:post.allowNewComments'>
                                      <b:include data='post' name='threadedComments-form'/>
                                      <b:else/>
                                      <!--[ If comment was disable ]-->
                                      <div class='cmDis'><data:post.noNewCommentsText/></div>
                                    </b:if>
                                    <b:else/>
                                    <b:if cond='data:post.allowComments'>
                                      <!--[ Comment message ]-->
                                      <b:if cond='data:this.messages.blogComment != &quot;&quot;'>
                                        <div class='cmMs note'>
                                          <data:this.messages.blogComment/>
                                        </div>
                                      </b:if>
                                        
                                      <a class='cmBtn button' expr:href='data:post.commentsUrl' expr:onclick='data:post.commentsUrlOnclick' rel='noreferrer' role='button' target='_blank'>
                                        <!--[ Delete tag bellow to change button style ]-->
                                        <b:class name='ln'/>
                                          
                                        <b:message name='messages.postAComment'/>
                                      </a>
                                    </b:if>
                                  </b:if>
                                </div>
                              </div>
                         
                            </b:tag>
                          </b:tag>
                        
                          <label class='fCls' for='forComments'/>
                        </section>
                  
                        <b:if cond='data:post.allowNewComments'>
                          <script>/*<![CDATA[*/ document.addEventListener('DOMContentLoaded', function() { var a=document, b = a.getElementById('comment-editor'), d = b.getAttribute('data-src'); if (b.setAttribute('src', d), 1 == comment) { var f = a.getElementsByClassName('rpTo'), c = a.getElementById('commentForm'), h = f.length, k = function(b, d, e, f) { b.addEventListener('click', function() { var c = b.getAttribute('data-reply-to'); a.getElementById('c' + c).appendChild(d); a.getElementById('commentForm').className = 'cmRbox'; a.getElementById('addCm').className = 'cmAd'; e.src = f + '&parentID=' + c }) }; for (i = 0; i < h; i++) k(f[i], c, b, d); var l = a.getElementsByClassName('cmFrm')[0]; a.getElementById('addCm').addEventListener('click', function() { l.appendChild(c); a.getElementById('commentForm').className = 'cmRbox'; a.getElementById('addCm').className = 'cmAd hidden'; b.src = d }) } }); /*]]>*/</script>
                        </b:if>
                        <script>/*<![CDATA[*/ /* Comment tag, license: dte.web.id/teknis/paket-javascript-fitur-manipulasi */ function repText(id) {var a = document.getElementById(id); if (!a) return; var b = a.innerHTML; b = b.replace(/<i rel="image">(.*?)<\/i>/ig, "<img class='lazy' data-src='$1' src='data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=' alt='Image Comment' \/>"); a.innerHTML = b;} repText('cmHolder'); /*]]>*/</script>
                      </b:includable>
                    </b:widget>
                    <b:widget cond='data:view.isPost and !data:view.isPreview' id='HTML01' locked='true' title='Middle post ad 01' type='HTML' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'/>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <div class='widget-content'>
                          <b:if cond='data:content != &quot;&quot;'>
                            <data:content/>
                          
                            <b:else/>
                            <!--[ Blank ad ]-->
                            <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                          </b:if>
                    
                          <!--[ Script to move widget to the middle of article ]-->
                          <script>/*<![CDATA[*/ function insertAfter(tbh,tgt) {var prt = tgt.parentNode; if (prt.lastChild == tgt) {prt.appendChild(tbh);} else {prt.insertBefore(tbh,tgt.nextSibling);}} var tgt = document.getElementById('postBody'); var midAd01 = document.getElementById('HTML01'); var showAd01 = tgt.getElementsByTagName('p'); if (showAd01.length > 0) {insertAfter(midAd01,showAd01[10]);}; /*]]>*/</script>
                        </div>
                      </b:includable>
                    </b:widget>
                    <b:widget cond='data:view.isPost and !data:view.isPreview' id='HTML02' locked='true' title='Middle post ad 02' type='HTML' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'/>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <div class='widget-content'>
                          <b:if cond='data:content != &quot;&quot;'>
                            <data:content/>
                          
                            <b:else/>
                            <!--[ Blank ad ]-->
                            <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                          </b:if>
                        
                          <!--[ Script to move widget to the middle of article ]-->
                          <script>/*<![CDATA[*/ function insertAfter(tbh,tgt) {var prt = tgt.parentNode; if (prt.lastChild == tgt) {prt.appendChild(tbh);} else {prt.insertBefore(tbh,tgt.nextSibling);}} var tgt = document.getElementById('postBody'); var midAd02 = document.getElementById('HTML02'); var showAd02 = tgt.getElementsByTagName('p'); if (showAd02.length > 0) {insertAfter(midAd02,showAd02[20]);}; /*]]>*/</script>
                        </div>
                      </b:includable>
                    </b:widget>
                    <b:widget cond='data:view.isHomepage' id='TextList035' locked='true' title='Categorised Post' type='TextList' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='shownum'>6</b:widget-setting>
                        <b:widget-setting name='sorting'>NONE</b:widget-setting>
                        <b:widget-setting name='item-2'>blogger template</b:widget-setting>
                        <b:widget-setting name='item-1'>Blogger</b:widget-setting>
                        <b:widget-setting name='item-0'>Docs</b:widget-setting>
                      </b:widget-settings>
                      <b:includable id='main'>
    <b:include name='content'/>
  </b:includable>
                      <b:includable id='content'>
    <!--[ Categorised Posts by Fineshop Design (fineshopdesign.com) ]-->
    <b:loop index='ctgry' values='data:items' var='item'>
      <div class='ctgW'>
        <h2 class='title'><data:item/></h2>
        <div class='ctgC' data-title='' expr:data-home='data:blog.homepageUrl.canonical' expr:data-label='data:item' expr:id='&quot;categoryId&quot; + data:ctgry'>
          <div class='note'>Loading Posts...</div>
        </div>
      </div>
    </b:loop>
    <script>/*<![CDATA[*/ Defer.js('https://cdn.jsdelivr.net/gh/fineshopdesign/blogger@main/assets/categoryPosts/js/categoryPosts.min.js','cPts-js',10,function(){for(var cId=document.querySelectorAll('[id^=categoryId]'),i=0;i<cId.length;++i){categoryPost({home:cId[i].getAttribute('data-home'),title:cId[i].getAttribute('data-title'),label:cId[i].getAttribute('data-label'),id:cId[i].id,time:'published',ldCl:'loaded',pstNm:6,thmbSize:600,snptLnth:120,pgn:true})};}); /*]]>*/</script>
  </b:includable>
                    </b:widget>
                  </b:section>
                
                  <b:section cond='!data:view.isPreview and !data:view.isSingleItem' id='add-widget' showaddelement='true'>
                    <b:widget cond='!data:view.isPreview' id='HTML94' locked='true' title='Ad placement' type='HTML' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'/>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <div class='widget-content'>
                          <b:if cond='data:content != &quot;&quot;'>
                            <data:content/>
                          
                            <b:else/>
                           
       
                            
                            <!--[ Blank ad ]-->
                            <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                          </b:if>
                        </div>
                      </b:includable>
                    </b:widget>
                  </b:section>
                </main>
                
                <b:if cond='data:view.isHomepage or data:view.isPost'>
                  <!--[ Sidebar content ]-->
                  <b:tag class='blogItm sidebar' name='aside'>
                    <b:tag class='sideIn' name='div'>
                      <b:section id='side-widget' showaddelement='true'>
                        <b:widget id='PopularPosts00' locked='false' title='Popular Posts' type='PopularPosts' version='2' visible='true'>
                          <b:widget-settings>
                            <b:widget-setting name='numItemsToShow'>5</b:widget-setting>
                            <b:widget-setting name='showThumbnails'>true</b:widget-setting>
                            <b:widget-setting name='showSnippets'>true</b:widget-setting>
                            <b:widget-setting name='timeRange'>LAST_WEEK</b:widget-setting>
                          </b:widget-settings>
                          <b:includable id='main' var='this'>
                            <b:if cond='data:title != &quot;&quot;'>
                              <h2 class='title'><data:title/></h2>
                            </b:if>
                            <b:include name='snippetedPosts'/>
                          </b:includable>
                          <b:includable id='blogThisShare'/>
                          <b:includable id='bylineByName' var='byline'/>
                          <b:includable id='bylineRegion' var='regionItms'/>
                          <b:includable id='commentsLink'/>
                          <b:includable id='commentsLinkIframe'/>
                          <b:includable id='emailPostIcon'/>
                          <b:includable id='facebookShare'/>
                          <b:includable id='footerBylines'/>
                          <b:includable id='googlePlusShare'/>
                          <b:includable id='headerByline'/>
                          <b:includable id='linkShare'/>
                          <b:includable id='otherSharingButton'/>
                          <b:includable id='platformShare'/>
                          <b:includable id='postAuthor'/>
                          <b:includable id='postCommentsLink'/>
                          <b:includable id='postInfo'>
                            <div class='iInf pSml'>
                              <b:if cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                                <b:include name='postLabelSponsored'/>
                                <b:else/>
                                
                                <!--[ Post timestamp ]-->
                                <b:include cond='data:widgets.Blog.first.allBylineItems.timestamp and data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])' name='postTimestamp'/>
                                <b:include cond='data:post.labels' name='postLabel'/>
                              </b:if>
                            </div>
                          </b:includable>
                          <b:includable id='postJumpLink' var='post'/>
                          <b:includable id='postLabels'/>
                          <b:includable id='postLocation'/>
                          <b:includable id='postReactions'/>
                          <b:includable id='postShareButtons'/>
                          <b:includable id='postTimestamp'>
                            <time class='aTtmp iTtmp pbl' expr:data-text='format(data:post.date, &quot;MMM d&quot;)' expr:datetime='data:post.date.iso8601' expr:title='&quot;Published: &quot; + data:post.date format &quot;MMMM d, YYYY&quot;'/>
                          </b:includable>
                          <b:includable id='sharingButton'/>
                          <b:includable id='sharingButtonContent'/>
                          <b:includable id='sharingButtons'/>
                          <b:includable id='sharingButtonsMenu'/>
                          <b:includable id='sharingPlatformIcon'/>
                          <b:includable id='snippetedPostByline'/>
                          <b:includable id='snippetedPostContent'>
                            <!--[ Post thumbnail ]-->
                            <b:include cond='data:i == 0 and (data:this.postDisplay.showFeaturedImage and data:post.featuredImage)' name='snippetedPostThumbnail'/>
                      
                            <b:include name='postInfo'/>
                              
                            <div class='iCtnt'>
                              <div class='iInr'>
                                <b:include cond='data:this.postDisplay.showTitle' name='snippetedPostTitle'/>
                                <b:include cond='data:this.postDisplay.showSnippet and data:i == 0' name='snippetedPostEntry'/>
                              </div>
                            </div>
                          </b:includable>
                          <b:includable id='snippetedPostEntry'>
                            <div class='pSnpt'>
                              <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])' name='nTag'/>
                              <b:include name='postEntrySnippet'/>
                            </div>
                          </b:includable>
                          <b:includable id='snippetedPostThumbnail'>
                            <div class='iThmb pThmb'>
                              <b:class cond='data:post.featuredImage.isYoutube' name='iyt'/>
                              <b:class cond='!data:this.postDisplay.showFeaturedImage or !data:post.featuredImage' name='nul'/>
                              <b:tag class='thmb' expr:name='data:this.postDisplay.showFeaturedImage and data:post.featuredImage ? &quot;a&quot; : &quot;div&quot;'>
                                <b:attr cond='data:this.postDisplay.showFeaturedImage and data:post.featuredImage' expr:value='data:post.url' name='href'/>
                                <b:if cond='data:this.postDisplay.showFeaturedImage and data:post.featuredImage'>
                                  <b:include name='postEntryThumbnail'/>
                                  <b:else/>
                                  <span class='imgThm' data-text='No image'/>
                                </b:if>
                              </b:tag>
                              
                              <!--[ Comments count ]-->
                              <b:tag class='iFxd' cond='data:post.allowComments and data:post.numberOfComments &gt; 0 or data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; , &quot;Product&quot; ])' name='div'>
                                <b:if cond='data:post.labels any (label =&gt; label.name in [ &quot;Sponsored&quot; ])'>
                                  <b:include name='postSponsored'/>
                                  <b:elseif cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])'/>
                                  <b:include name='postProduct'/>
                                </b:if>
                                <b:if cond='data:widgets.Blog.first.allBylineItems.comments and data:post.labels none (label =&gt; label.name in [ &quot;Product&quot; ])'>
                                  <b:include name='postCommentsLinks'/>
                                </b:if>
                              </b:tag>
                            </div>
                          </b:includable>
                          <b:includable id='snippetedPostTitle'>
                            <h3 class='iTtl aTtl'><a expr:href='data:post.url.canonical'><data:post.title.escaped/></a></h3>
                          </b:includable>
                          <b:includable id='snippetedPosts'>
                            <div class='itemPp' role='feed'>
                              <!-- Don't render the post that we're currently already looking at. -->
                              <b:loop index='i' values='data:posts filter (p =&gt; p.id != data:view.postId)' var='post'>
                                <article class='itm'>
                                  <b:class cond='data:i == 0 and data:this.postDisplay.showFeaturedImage and !data:post.featuredImage' name='nThmb'/>
                                  <b:class cond='data:i == 0 and data:this.postDisplay.showFeaturedImage and data:post.featuredImage' name='mostP'/>
                                  <b:class cond='data:post.labels any (label =&gt; label.name in [ &quot;Product&quot; ])' name='pTag'/>
                                  <b:include name='snippetedPostContent'/>
                                </article>
                              </b:loop>
                            </div>
                          </b:includable>
                        </b:widget>
                        <b:widget id='Label00' locked='false' title='Labels' type='Label' version='2' visible='true'>
                          <b:widget-settings>
                            <b:widget-setting name='sorting'>ALPHA</b:widget-setting>
                            <b:widget-setting name='display'>CLOUD</b:widget-setting>
                            <b:widget-setting name='selectedLabelsList'/>
                            <b:widget-setting name='showType'>ALL</b:widget-setting>
                            <b:widget-setting name='showFreqNumbers'>true</b:widget-setting>
                          </b:widget-settings>
                          <b:includable id='main' var='this'>
                            <b:include name='widget-title'/>
                            <b:include name='content'/>
                          </b:includable>
                          <b:includable id='cloud'>
                            <b:loop index='tags' values='data:labels' var='label'>
                         
                              <!--[ Only show 6 label ]-->
                              <b:if cond='data:tags &lt;= 5'>
                                <div class='lbSz'>
                                  <b:class expr:name='&quot;s-&quot; + data:label.cssSize'/>
                                  <b:tag class='lbN' expr:name='data:blog.url != data:label.url ? &quot;a&quot; : &quot;div&quot;'>
                                    <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.url' name='href'/>
                                    <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.name' name='aria-label'/>
                                    <span class='lbT'><data:label.name/></span>
                                    <b:tag class='lbC' cond='data:this.showFreqNumbers' expr:data-text='&quot;(&quot; + data:label.count + &quot;)&quot;' name='span'/>
                                  </b:tag>
                                </div>
                              </b:if>
                        
                              <!--[ Hide another label from 7th list ]-->
                              <b:if cond='data:tags == 6'>
                                <div class='lbSh'>
                                  <input class='lbIn hidden' id='lbAl-1' type='checkbox'/>
                                  <div class='lbAl'>
                                    <b:loop index='alltags' values='data:labels' var='label'>
                               
                                      <!--[ Show label from 7th list ]-->
                                      <b:if cond='data:alltags &gt;= 6'>
                                        <div class='lbSz'>
                                          <b:class expr:name='&quot;s-&quot; + data:label.cssSize'/>
                                          <b:tag class='lbN' expr:name='data:blog.url != data:label.url ? &quot;a&quot; : &quot;div&quot;'>
                                            <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.url' name='href'/>
                                            <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.name' name='aria-label'/>
                                            <span class='lbT'><data:label.name/></span>
                                            <b:tag class='lbC' cond='data:this.showFreqNumbers' expr:data-text='&quot;(&quot; + data:label.count + &quot;)&quot;' name='span'/>
                                          </b:tag>
                                        </div>
                                      </b:if>
                                
                                    </b:loop>
                                  </div>
                            
                                  <label aria-label='Show labels' class='lbM' expr:data-hide='data:messages.showLess' expr:data-show='data:messages.showMore' expr:data-text='&quot;(+&quot; + (data:labels.length - 6) + &quot;)&quot;' for='lbAl-1'/>
                                </div>
                              </b:if>
                            </b:loop>
                          </b:includable>
                          <b:includable id='content'>
                            <div class='wL pSml'>
                              <!--[ delete the comment tag below if you want to change style Label List ]-->
                              <b:class name='bg'/>
                                
                              <b:class expr:name='data:this.display == &quot;list&quot; ? &quot;ls&quot; : &quot;cl&quot;'/>
                              <b:include cond='data:this.display == &quot;list&quot;' name='list'/>
                              <b:include cond='data:this.display == &quot;cloud&quot;' name='cloud'/>
                            </div>
                          </b:includable>
                          <b:includable id='list'>
                            <ul>
                              <b:loop index='tags' values='data:labels' var='label'>
                              
                                <!--[ Only show 6 label ]-->
                                <b:if cond='data:tags &lt;= 5'>
                                  <li>
                                    <b:tag class='lbN' expr:name='data:blog.url != data:label.url ? &quot;a&quot; : &quot;div&quot;'>
                                      <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.url' name='href'/>
                                      <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.name' name='aria-label'/>
                                      <span class='lbT'><data:label.name/></span>
                                      <span class='lbR'>
                                        <b:tag class='lbC' cond='data:this.showFreqNumbers' expr:data-text='data:label.count' name='span'/>
                                        <b:include name='bookmark-icon'/>
                                      </span>
                                    </b:tag>
                                  </li>
                                </b:if>
                          
                              </b:loop>
                            </ul>
                              
                            <b:loop index='tags' values='data:labels' var='label'>
                              <!--[ Hide another label from 7th list ]-->
                              <b:if cond='data:tags == 6'>
                                <div class='lbSh'>
                                  <input class='lbIn hidden' id='lbAl-2' type='checkbox'/>
                                  <ul class='lbAl'>
                                    <b:loop index='alltags' values='data:labels' var='label'>
                                      
                                      <!--[ Show label from 7th list ]-->
                                      <b:if cond='data:alltags &gt;= 6'>
                                        <li>
                                          <b:tag class='lbN' expr:name='data:blog.url != data:label.url ? &quot;a&quot; : &quot;div&quot;'>
                                            <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.url' name='href'/>
                                            <b:attr cond='data:blog.url != data:label.url' expr:value='data:label.name' name='aria-label'/>
                                            <span class='lbT'><data:label.name/></span>
                                            <span class='lbR'>
                                              <b:tag class='lbC' cond='data:this.showFreqNumbers' expr:data-text='data:label.count' name='span'/>
                                              <b:include name='bookmark-icon'/>
                                            </span>
                                          </b:tag>
                                        </li>
                                      </b:if>
                                  
                                    </b:loop>
                                  </ul>
                              
                                  <label aria-label='Show labels' class='lbM' expr:data-hide='data:messages.showLess' expr:data-show='data:messages.showMore' expr:data-text='&quot;(+&quot; + (data:labels.length - 6) + &quot;)&quot;' for='lbAl-2' role='button'/>
                                </div>
                              </b:if>
                            </b:loop>
                          </b:includable>
                        </b:widget>
                        <b:widget cond='data:view.isPost' id='HTML11' locked='false' title='Contents' type='HTML' version='2' visible='true'>
                          <b:widget-settings>
                            <b:widget-setting name='content'><![CDATA[<!--[ This is an automatic Table of Content feature that only appears on post pages ]-->]]></b:widget-setting>
                          </b:widget-settings>
                          <b:includable id='main'>
                            <input class='tocI hidden' id='forTocJs' type='checkbox'/>
                            <div class='tocL'>
                              <div class='tocLi'>
                                <div class='tocLs'>
                                  <label aria-label='Close' class='tocH fixH' for='forTocJs'>
                                    <div class='tocC'>
                                      <svg class='rad' viewBox='0 0 160 160'><path d='M0-10,150,0l10,150S137.643,80.734,100.143,43.234,0-10,0-10Z' transform='translate(0 10)'/></svg>
                                      <span><b:include name='document-icon'/></span>
                                      <svg class='rad in' viewBox='0 0 160 160'><path d='M0-10,150,0l10,150S137.643,80.734,100.143,43.234,0-10,0-10Z' transform='translate(0 10)'/></svg>
                                    </div>
                                    <div class='tocT fixT'>
                                      <b:attr expr:value='data:title != &quot;&quot; ? data:title : &quot;Contents&quot;' name='data-text'/>
                                      <span class='c cl' data-texxt='Close'/>
                                    </div>
                                  </label>
                                  
                                  <div class='tocIn' id='tocAuto'/>
                                  <!--[ Script to activate ToC ]-->
                                  <script>/*<![CDATA[*/ document.addEventListener('DOMContentLoaded', () => new TableOfContents({ from: document.querySelector('#postBody'), to: document.querySelector('#tocAuto') }).generateToc() ); /*]]>*/</script>
                                </div>
                              </div>
                              <label class='fCls' for='forTocJs'/>
                            </div>
                          </b:includable>
                        </b:widget>
                      </b:section>
              
                      <!--[ Sidebar sticky ]-->
                      <b:section class='sideSticky' cond='!data:view.isPreview' id='side-sticky' showaddelement='true'>
                        <b:widget cond='!data:view.isPreview and !data:blog.isMobileRequest' id='HTML95' locked='true' title='Sticky ad(desktop only)' type='HTML' version='2' visible='true'>
                          <b:widget-settings>
                            <b:widget-setting name='content'/>
                          </b:widget-settings>
                          <b:includable id='main'>
                            <b:if cond='data:content != &quot;&quot;'>
                              <data:content/>
                          
                              <b:else/>
                              <!--[ Blank ad ]-->
                              <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                            </b:if>
                          </b:includable>
                        </b:widget>
                      </b:section>
                    </b:tag>
                  </b:tag>
                </b:if>
              </b:tag>
              
              <!--[ Mobile Menu ]-->
              <b:section class='mobMn' id='mobile-menu' maxwidgets='1' showaddelement='false'>
                <b:widget id='TextList99' locked='true' title='Mobile Menu' type='TextList' version='2' visible='true'>
                  <b:widget-settings>
                    <b:widget-setting name='shownum'/>
                    <b:widget-setting name='item-6'>Share</b:widget-setting>
                    <b:widget-setting name='item-5'>Comments</b:widget-setting>
                    <b:widget-setting name='item-4'>Share</b:widget-setting>
                    <b:widget-setting name='item-3'>Top</b:widget-setting>
                    <b:widget-setting name='sorting'>NONE</b:widget-setting>
                    <b:widget-setting name='item-2'>Menu</b:widget-setting>
                    <b:widget-setting name='item-1'>Search</b:widget-setting>
                    <b:widget-setting name='item-0'>Home</b:widget-setting>
                  </b:widget-settings>
                  <b:includable id='main'>
                    <b:include name='content'/>
                  </b:includable>
                  <b:includable id='content'>
                    <ul>
                      
                      <b:loop index='m' values='data:items' var='item'>
                        <b:if cond='data:m &lt;= 5'>
                          <b:if cond='data:item == &quot;Home&quot;'>
                            <li class='mH'>
                              <b:class cond='data:view.isHomepage' name='nmH'/>
                              <b:tag expr:data-text='data:item' expr:name='data:view.url == data:blog.homepageUrl ? &quot;span&quot; : &quot;a&quot;'>
                                <b:attr cond='data:view.url != data:blog.homepageUrl' expr:value='data:blog.homepageUrl.canonical' name='href'/>
                                <b:attr cond='data:view.url != data:blog.homepageUrl' name='role' value='button'/>
                                <b:include name='home-alt-icon'/>
                              </b:tag>
                            </li>
                            
                            <b:elseif cond='data:item == &quot;Search&quot;'/>
                            <li class='mS'>
                              <label expr:data-text='data:item' for='searchIn'><b:include name='search-icon'/></label>
                            </li>
                            
                            <b:elseif cond='data:item == &quot;Menu&quot;'/>
                            <li class='mN'>
                              <label expr:data-text='data:item' for='offNav'><b:include name='menu-icon'/></label>
                            </li>
                            
                            <b:elseif cond='data:item == &quot;Dark&quot;'/>
                            <b:if cond='data:view.url != data:view.url params { amp: &quot;1&quot; }'>
                              <li class='mD'>
                                <span class='tDL' data-light='Light' expr:data-text='data:item' onclick='darkMode()' role='button'><b:include name='moon-sun-icon'/></span>
                              </li>
                            </b:if>
                            
                            <b:elseif cond='data:item == &quot;Light&quot;'/>
                            <b:if cond='data:view.url != data:view.url params { amp: &quot;1&quot; }'>
                              <li class='mL'>
                                <span class='tDL' data-light='Dark' expr:data-text='data:item' onclick='darkMode()' role='button'><b:include name='sun-moon-icon'/></span>
                              </li>
                            </b:if>
                            
                            <b:elseif cond='data:item == &quot;Top&quot;'/>
                            <b:if cond='!data:view.isPost'>
                              <li class='mS'>
                                <span expr:aria-label='data:item' expr:data-text='data:item' onclick='window.scrollTo({top: 0});' role='button'><b:include name='arow-up-circle-icon'/></span>
                              </li>
                            </b:if>
                            
                            <b:elseif cond='data:item == &quot;Share&quot;'/>
                            <b:if cond='data:view.isPost'>
                              <li class='mS'>
                                <label expr:data-text='data:item' for='forShare'><b:include name='share-icon'/></label>
                                </li>
                            </b:if>
                            
                            <b:elseif cond='data:item == &quot;Comments&quot;'/>
                            <b:if cond='data:view.isPost'>
                              <li class='mC'>
                                <label expr:data-text='data:item' for='forComments'><b:include name='messages-icon'/></label>
                              </li>
                            </b:if>
                            
                          </b:if>
                        </b:if>
                      </b:loop>
                    </ul>
                  </b:includable>
                </b:widget>
              </b:section>
                           
                            
                          
        
                       <!--[ Footer section ]-->
              <footer>
                <div class='footer'>
                  <div class='fotIn'>
                    <b:section id='footer-widget-1' maxwidgets='2' showaddelement='true'>
                      <b:widget id='HTML77' locked='false' title='Made with coffee by' type='HTML' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='content'>&lt;div&gt;&lt;div class=&#39;lazy abtL&#39; data-style=&#39;background-image:url(https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEidQQr0DgTVD1Wbw6pprt36YqsovXD2eV8gvVzsvAHKMbguox3Kx8JGD5et7cpWKpWxN10r_YoTFuUuIZ6lfttrUrUSq7KbVPos3vCaVWZV3ikG32ZNw8h795T3zQiFSe0eEIaio0w3riL9BWs3ddRwS7gPbs9klY0v3edNxM7Rjv4PZu-pksdvJbTh/s390/imageedit_1_2324919073.png)&#39;&gt;&lt;/div&gt;&lt;div class=&#39;abtT&#39;&gt;&lt;h2 class=&#39;tl&#39;&gt;Royal Ui&lt;/h2&gt;&lt;p class=&#39;abtD&#39;&gt;Good design makes the ordinary extraordinary.&lt;/p&gt;&lt;/div&gt;&lt;/div&gt;
&lt;p class=&#39;hidden pu-views&#39; data-id=&#39;WebsiteStats&#39;&gt;&lt;/p&gt;</b:widget-setting>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <div class='widget-content abtU' expr:data-text='data:title'><data:content/></div>
                        </b:includable>
                      </b:widget>
                      <b:widget id='LinkList1' locked='false' title='Social Media Link' type='LinkList' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='link-3'>#</b:widget-setting>
                          <b:widget-setting name='sorting'>NONE</b:widget-setting>
                          <b:widget-setting name='link-4'>#</b:widget-setting>
                          <b:widget-setting name='text-1'>Instagram</b:widget-setting>
                          <b:widget-setting name='link-1'>#</b:widget-setting>
                          <b:widget-setting name='text-0'>Facebook</b:widget-setting>
                          <b:widget-setting name='link-2'>#</b:widget-setting>
                          <b:widget-setting name='text-3'>Youtube</b:widget-setting>
                          <b:widget-setting name='link-0'>#</b:widget-setting>
                          <b:widget-setting name='text-2'>Twitter</b:widget-setting>
                          <b:widget-setting name='text-4'>LinkedIn</b:widget-setting>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <b:include name='content'/>
                        </b:includable>
                        <b:includable id='content'>                    
                          <ul class='sL'>                      
                            <b:loop values='data:links' var='link'>
                              <li>
                                <b:tag class='l' expr:data-text='data:link.name' expr:name='data:link.target != &quot;#&quot; ? &quot;a&quot; : &quot;span&quot;'>
                                  <b:attr cond='data:link.target != &quot;#&quot;' expr:value='data:link.target' name='href'/>
                                  <b:attr cond='data:link.target != &quot;#&quot;' expr:value='data:link.name' name='aria-label'/>
                                  <b:attr cond='data:link.target != &quot;#&quot;' name='target' value='_blank'/>
                                  <b:attr cond='data:link.target != &quot;#&quot;' name='rel' value='noopener'/>
                                </b:tag>
                              </li>
                            </b:loop>
                          </ul>
                        </b:includable>
                      </b:widget>
                    </b:section>
<b:section id='footer-widget-2' maxwidgets='2' showaddelement='true'>
  <b:widget id='LinkList2' locked='false' title='Company' type='LinkList' version='2' visible='true'>
    <b:widget-settings>
      <b:widget-setting name='sorting'>NONE</b:widget-setting>
      <b:widget-setting name='text-1'>Blog</b:widget-setting>
      <b:widget-setting name='link-1'>#</b:widget-setting>
      <b:widget-setting name='text-0'>About</b:widget-setting>
      <b:widget-setting name='link-0'>#</b:widget-setting>
    </b:widget-settings>
    <b:includable id='main'>
                          <b:include name='widget-title'/>
                          <b:include name='content'/>
                        </b:includable>
    <b:includable id='content'>
                          <div class='widget-content'>
                            <ul>
                              <b:loop values='data:links' var='link'>
                                <li>
                                  <a expr:href='data:link.target'>
                                    <span><data:link.name/></span>
                                  </a>
                                </li>
                              </b:loop>
                            </ul>
                          </div>
                        </b:includable>
  </b:widget>
</b:section>
                    <b:section id='footer-widget-3' maxwidgets='2' showaddelement='true'>
                      <b:widget id='LinkList3' locked='false' title='Product &amp;amp; Service' type='LinkList' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='sorting'>NONE</b:widget-setting>
                          <b:widget-setting name='text-1'>Other Product</b:widget-setting>
                          <b:widget-setting name='link-1'>#</b:widget-setting>
                          <b:widget-setting name='text-0'>Blogger Theme</b:widget-setting>
                          <b:widget-setting name='link-0'>#</b:widget-setting>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <b:include name='widget-title'/>
                          <b:include name='content'/>
                        </b:includable>
                        <b:includable id='content'>
                          <div class='widget-content'>
                            <ul>
                              <b:loop values='data:links' var='link'>
                                <li>
                                  <a expr:href='data:link.target'>
                                    <span><data:link.name/></span>
                                  </a>
                                </li>
                              </b:loop>
                            </ul>
                          </div>
                        </b:includable>
                      </b:widget>
                    </b:section>
                    <b:section id='footer-widget-4' maxwidgets='2' showaddelement='true'>
                      <b:widget id='LinkList4' locked='false' title='Support' type='LinkList' version='2' visible='true'>
                        <b:widget-settings>
                          <b:widget-setting name='sorting'>NONE</b:widget-setting>
                          <b:widget-setting name='text-1'>Documentation</b:widget-setting>
                          <b:widget-setting name='link-1'>#</b:widget-setting>
                          <b:widget-setting name='text-0'>Contact</b:widget-setting>
                          <b:widget-setting name='link-0'>#</b:widget-setting>
                        </b:widget-settings>
                        <b:includable id='main'>
                          <b:include name='widget-title'/>
                          <b:include name='content'/>
                        </b:includable>
                        <b:includable id='content'>
                          <div class='widget-content'>
                            <ul>
                              <b:loop values='data:links' var='link'>
                                <li>
                                  <a expr:href='data:link.target'>
                                    <span><data:link.name/></span>
                                  </a>
                                </li>
                              </b:loop>
                            </ul>
                          </div>
                        </b:includable>
                      </b:widget>
                    </b:section>
                  </div>
            
                  <!--[ Credit ]-->
                  <b:section class='cdtIn' id='credit-widget' maxwidgets='2' showaddelement='false'>
                    <b:widget id='HTML88' locked='true' title='Credit' type='HTML' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='content'/>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <div class='fotCd'>
                          <span class='credit'>
                            <b:if cond='data:content == &quot;&quot;'><span style='font-family:Arial, Helvetica, sans-serif'>&#169;</span> <span id='getYear'><b:if cond='data:view.url != data:view.url params { amp: &quot;1&quot; }'><script>/*<![CDATA[*/ var d = new Date(); var n = d.getFullYear(); document.getElementById('getYear').innerHTML = n; /*]]>*/</script><b:else/>2022</b:if></span> &#8231; <bdi><a expr:href='data:blog.homepageUrl.canonical'><data:blog.title/><b:include name='verified-icon'/></a></bdi> &#8231; All rights reserved.<b:else/><data:content/></b:if>
                          </span>
                          <span class='creator'>Developed by <a href='https://www.fineshopdesign.com'>Fineshop Design</a></span>
                        </div>
                      </b:includable>
                    </b:widget>
                    <b:widget id='TextList88' locked='true' title='Back to top' type='TextList' version='2' visible='true'>
                      <b:widget-settings>
                        <b:widget-setting name='shownum'>1</b:widget-setting>
                        <b:widget-setting name='sorting'>NONE</b:widget-setting>
                        <b:widget-setting name='item-1'>Top</b:widget-setting>
                        <b:widget-setting name='item-0'>Top Sticky</b:widget-setting>
                      </b:widget-settings>
                      <b:includable id='main'>
                        <b:include name='content'/>
                      </b:includable>
                      <b:includable id='content'>
                        <b:loop index='t' values='data:items' var='item'>
                          <b:if cond='data:t &lt;= 0'>
                            <b:if cond='data:item == &quot;Top&quot;'>
                              <!--[ Back top button ]-->
                              <b:tag class='toTop tTop' expr:data-text='data:item' expr:name='data:view.url != data:view.url params { amp: &quot;1&quot; } ? &quot;div&quot; : &quot;a&quot;'>
                                <b:attr cond='data:view.url != data:view.url params { amp: &quot;1&quot; }' name='onclick' value='window.scrollTo({top: 0});'/>
                                <b:attr cond='data:view.url == data:view.url params { amp: &quot;1&quot; }' name='href' value='#mainCont'/>
                                <b:include name='arow-up-icon'/>
</b:tag>
                        
                              <b:elseif cond='data:item == &quot;Top Sticky&quot;'/>
                              <!--[ Back top button fixed/sticky ]-->
                              <b:include name='button-backtoTop'/>
                            </b:if>
                          </b:if>
                        </b:loop>
                      </b:includable>
                    </b:widget>
                  </b:section>
                </div>
              </footer> 
            </div>
          </div> 
        </div>
                                             
                   
                   
                       
                                    
        
        <!--[ Back To Top Button ]-->
        <div class='yzTtop'>
<svg onclick='window.scrollTo({top: 0})' viewBox='0 0 34 34'><circle class='b' cx='17' cy='17' r='15.92'/><circle class='c' cx='17' cy='17' r='15.92'/><path class='line d' d='M15.07,21.06,19.16,17l-4.09-4.06'/></svg>
<div class='credit hidden'>www.yazidtips.com</div>
</div>
                              
                     <!--[ Waves Animation ]-->
<div class='wvC'><div class='wvS'><svg class='waves' preserveAspectRatio='none' shape-rendering='auto' viewBox='0 24 150 28'><defs><path d='M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z' id='wave-bg'/></defs><g class='plx'><use x='48' xlink:href='#wave-bg' y='0'/><use x='48' xlink:href='#wave-bg' y='3'/><use x='48' xlink:href='#wave-bg' y='5'/><use x='48' xlink:href='#wave-bg' y='7'/></g></svg></div><div class='wvH'/></div>             
               
                  
                            
              
              

        
        
        
            <!--[ Royal-Ui Addons ]-->
            <b:section class='Royal-Ui addons' id='Royal-Ui addons' showaddelement='false'>
              <b:widget cond='data:view.isPost' id='HTML22' locked='true' title='Reading Progress Bar' type='HTML' version='2' visible='true'>
                <b:widget-settings>
                  <b:widget-setting name='content'><![CDATA[<!--[ Progress Bar ]-->]]></b:widget-setting>
                </b:widget-settings>
                <b:includable id='main'>
                <!--[ Progress Bar ]-->
                <div class='progB' id='progBar'/>
                <script>/*<![CDATA[*/ window.onscroll = function() {myFunction()};function myFunction(){var winScroll = document.body.scrollTop || document.documentElement.scrollTop;var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;var scrolled = (winScroll / height) * 100;document.getElementById("progBar").style.width = scrolled + "%";} /*]]>*/</script>
              </b:includable>
              </b:widget>
              <b:widget id='HTML23' locked='true' title='Anti Ad-Blocker' type='HTML' version='2' visible='true'>
                <b:widget-settings>
                  <b:widget-setting name='content'><![CDATA[<!--[ Anti Ad-Blocker]-->]]></b:widget-setting>
                </b:widget-settings>
                <b:includable id='main'>
                 <!--[ Anti Ad-Blocker by Fineshop ]-->
<div class='popSc hidden' id='antiAdBlock'>
  <div class='popBo'>
    <svg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><circle cx='12' cy='12' r='10'/><line x1='12' x2='12' y1='8' y2='12'/><line x1='12' x2='12.01' y1='16' y2='16'/></svg>
    <h2>Ad-Blocker Detected!</h2>
    <p>Sorry, we detected that you have activated Ad-Blocker.<br/>Please consider supporting us by disabling your Ad-Blocker, it helps us in developing this Website.<br/>Thank you!</p>
  </div>
</div>
    
    <script>/*<![CDATA[*/ /* Anti Ad-Blocker Script (Lazyload) */ var lazyAnti=!1;window.addEventListener("scroll",function(){(0!=document.documentElement.scrollTop&&!1===lazyAnti||0!=document.body.scrollTop&&!1===lazyAnti)&&(!function(){var antiAdBlock=document.querySelector("#antiAdBlock");var e=document.createElement("script");e.type="text/javascript",e.async=!0,e.src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js";e.onerror=function(){if(antiAdBlock!=null){antiAdBlock.classList.remove("hidden");window.lazyAnti=!0}};var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(e,a)}(),lazyAnti=!0)},!0); /*]]>*/</script>
    
              </b:includable>
              </b:widget>
              <b:widget id='HTML24' locked='true' title='Google Translate (Onscroll load)' type='HTML' version='2' visible='true'>
                <b:widget-settings>
                  <b:widget-setting name='content'>en,bn,hi,gu,bn,ta,te,mr,ne,ml,kn,ar,id</b:widget-setting>
                </b:widget-settings>
                <b:includable id='main'>
                <!--[ Google Translate ]-->
                <script>/*<![CDATA[*/ var lazyts=!1;var gTrans=document.getElementById('gTrans');window.addEventListener("scroll",function(){(0!=document.documentElement.scrollTop&&!1===lazyts||0!=document.body.lazy&&!1===scrollTop)&&(!function(){var e=document.createElement("script");e.type="text/javascript",e.async=!0,e.src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(e,a);if(gTrans!=null){gTrans.classList.remove('gtHide')}}(),lazyts=!0)},!0); /*]]>*/</script>
                <script> function googleTranslateElementInit(){new google.translate.TranslateElement({pageLanguage:&#39;en&#39;,includedLanguages:&#39;<data:content/>&#39;,layout:google.translate.TranslateElement.InlineLayout.SIMPLE},&#39;google_translate_element&#39;)}; </script>
              </b:includable>
              </b:widget>
              <b:widget cond='data:blog.isMobileRequest' id='HTML26' locked='true' title='RGB Effect (Mobile only)' type='HTML' version='2' visible='true'>
                <b:widget-settings>
                  <b:widget-setting name='content'><![CDATA[<!--[ This is RGB effect that appears sticky on footer ]-->]]></b:widget-setting>
                </b:widget-settings>
                <b:includable id='main'>
                <div class='stwRainbow'/>
                <!--[ Remove it to disable blur shadow effect ]-->
                 <div class='stwBlurRainbow'/> 
              </b:includable>
              </b:widget>
              <b:widget id='HTML27' locked='true' title='Internet Toast Notification' type='HTML' version='2' visible='true'>
                <b:widget-settings>
                  <b:widget-setting name='content'><![CDATA[<!--[ This is Internet toast notification that appears when visitors internet gone and restored ]-->]]></b:widget-setting>
                </b:widget-settings>
                <b:includable id='main'>
                      
      <script>/*<![CDATA[*/ /* No Internet Connection Script (Only Toast) */ window.addEventListener("offline",function(){document.querySelector("#toastNotif").innerHTML="<span>No internet connection!</span>"}),window.addEventListener("online",function(){document.querySelector("#toastNotif").innerHTML="<span>Internet connection restored!</span>"}); /*]]>*/</script>
              </b:includable>
              </b:widget>
              <b:widget id='HTML28' locked='true' title='?m=1 hider ( Don&apos;t hide )' type='HTML' version='2' visible='false'>
                <b:widget-settings>
                  <b:widget-setting name='content'><![CDATA[<!--[ Activate this Script to hide ?m=1 on Mobile View (not recommended) ]-->]]></b:widget-setting>
                </b:widget-settings>
                <b:includable id='main'>
                <script>/*<![CDATA[*/ var uri = window.location.toString();if (uri.indexOf("?m=1","?m=1") > 0) {var clean_uri = uri.substring(0, uri.indexOf("?m=1"));window.history.replaceState({}, document.title, clean_uri); }; /*]]>*/</script>
                   </b:includable>
              </b:widget>
            </b:section>
        
        <b:if cond='!data:view.isPreview'>
          <!--[ Delete 'or data:blog.isMobileRequest' if you want to show ad in both(desktop and mobile) ]-->
          <b:section cond='data:view.isLayoutMode or data:blog.isMobileRequest' id='anchor-ad' showaddelement='false'>
            <b:widget id='HTML99' locked='true' title='Anchor ad placement(mobile only)' type='HTML' version='2' visible='true'>
              <b:widget-settings>
                <b:widget-setting name='content'/>
              </b:widget-settings>
              <b:includable id='main'>
                <!--[ Sticky ad ]-->
                <input class='ancrI hidden' id='ancrI' type='checkbox'/>
                <div class='ancrA'>
                  <label aria-label='Close Menu' class='ancrC' for='ancrI'/>
                  <div class='ancrCn'>
                    <b:if cond='data:content != &quot;&quot;'>
                      <data:content/>
                          
                      <b:else/>
                      <!--[ Blank ad ]-->
                      <div class='adB' expr:data-text='data:messages.adsGoHere'/>
                    </b:if>
                  </div>
                </div>
              </b:includable>
            </b:widget>
          </b:section>
        </b:if>
        
      </b:if>
    </b:tag>
    
    <b:tag class='erroP' cond='data:view.isLayoutMode or data:view.isError' name='section'>
      <b:section class='erroC' cond='data:view.isLayoutMode or data:view.isError' id='error-404' showaddelement='false'>
        <b:widget id='HTML404' locked='true' title='Take me back' type='HTML' version='2' visible='true'>
          <b:widget-settings>
            <b:widget-setting name='content'>&lt;h3 style=&#39;color:#fff&#39;&gt;&lt;span&gt;404&lt;/span&gt;Something Wrong!&lt;/h3&gt;

&lt;p style=&#39;color:#fff&#39;&gt;The page you&#39;ve requested can&#39;t be found. &lt;/p&gt;</b:widget-setting>
          </b:widget-settings>
          <b:includable id='main'>
            <data:content/>
            <a class='button' expr:href='data:blog.homepageUrl.canonical'><data:title/></a>
          </b:includable>
        </b:widget>
      </b:section>
    </b:tag>
    
    <!--[ Javascript disable condition ]-->
    <noscript>
      <input class='nJs hidden' id='forNoJS' type='checkbox'/>
      <div class='noJs' expr:data-text='data:blog.title + &quot; works best with JavaScript enabled&quot;'>
        <label for='forNoJS'/>
      </div>
    </noscript>
    
    <b:if cond='!data:view.isError'>
      <!--[ Load More - Delete this section if you want to disable this feature ]-->
      <b:include cond='data:view.isHomepage or data:view.url == data:blog.homepageUrl.canonical path &quot;search&quot;' name='post-paginationMore'/>
      
      <!--[ additional javascript ]-->
      <script>/*<![CDATA[*/ function darkMode(){localStorage.setItem("mode","darkmode"===localStorage.getItem("mode")?"light":"darkmode"),"darkmode"===localStorage.getItem("mode")?document.querySelector("#mainCont").classList.add("drK"):document.querySelector("#mainCont").classList.remove("drK")}; function headScroll() {const distanceY = window.pageYOffset || document.documentElement.scrollTop, shrinkOn = 40, commentEl = document.getElementById('header');if (distanceY > shrinkOn) {commentEl.classList.add("stick");} else {commentEl.classList.remove("stick");} } window.addEventListener('scroll', headScroll); 
/* lazy youtube */ ( function() {var youtube = document.querySelectorAll(".lazyYt"); for (var i = 0; i < youtube.length; i++) {var source = "https://img.youtube.com/vi/"+ youtube[i].dataset.embed +"/sddefault.jpg"; var image = new Image(); image.setAttribute("class", "lazy"); image.setAttribute("data-src",source); image.setAttribute("src","data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="); image.setAttribute("alt","Youtube video"); image.addEventListener( "load", function() {youtube[ i ].appendChild( image );}( i ) ); youtube[i].addEventListener( "click", function() {var iframe = document.createElement( "iframe" ); iframe.setAttribute( "frameborder", "0" ); iframe.setAttribute( "allowfullscreen", "" ); iframe.setAttribute( "src", "https://www.youtube.com/embed/"+ this.dataset.embed +"?rel=0&showinfo=0&autoplay=1" ); this.innerHTML = ""; this.appendChild( iframe ); }); }; })();
/* Lightbox image script, source: kompiajaib.com/2021/09/update-image-lightbox-dengan-css-dan.html */ for (var imageslazy = document.querySelectorAll('.pS .separator img, .pS .tr-caption-container img, .pS .psImg >img, .pS .btImg >img'), i = 0; i < imageslazy.length; i++) imageslazy[i].setAttribute('onclick', 'return false'); function wrap(o, t, e) {for (var i = document.querySelectorAll(t), c = 0; c < i.length; c++) {var a = o + i[c].outerHTML + e; i[c].outerHTML = a} } wrap('<div class="zmImg">', '.pS .separator >a', '</div>'); wrap('<div class="zmImg">', '.pS .tr-caption-container td >a', '</div>'); wrap('<div class="zmImg">', '.pS .separator >img', '</div>'); wrap('<div class="zmImg">', '.pS .tr-caption-container td >img', '</div>'); wrap('<div class="zmImg">', '.pS .psImg >img', '</div>'); wrap('<div class="zmImg">', '.pS .btImg >img', '</div>'); for (var containerimg = document.getElementsByClassName('zmImg'), i = 0; i < containerimg.length; i++) containerimg[i].onclick = function() {this.classList.toggle('s');};
Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}),'undefined'!=typeof infinite_scroll&&infinite_scroll.on('load',function(){Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}) }); /*]]>*/</script>
      
       <!--[ Music player ]-->
      <script>/*<![CDATA[*/
     // player
var music = document.querySelector('.music-element')
var playBtn = document.querySelector('.play')
var seekbar = document.querySelector('.seekbar')
var currentTime = document.querySelector('.current-time')
var duration = document.querySelector('.duration')

function handlePlay() {
    if (music.paused) {
        music.play();
        playBtn.className = 'pause'
        playBtn.innerHTML = '<i class="material-icons">pause</i>'
    } else {
        music.pause();
        playBtn.className = 'play'
        playBtn.innerHTML = '<i class="material-icons">play_arrow</i>'
    }
    music.addEventListener('ended', function () {
        playBtn.className = 'play'
        playBtn.innerHTML = '<i class="material-icons">play_arrow</i>'
        music.currentTime = 0
    });
}

music.onloadeddata = function () {
    seekbar.max = music.duration
    var ds = parseInt(music.duration % 60)
    var dm = parseInt((music.duration / 60) % 60)
    duration.innerHTML = dm + ':' + ds
}
music.ontimeupdate = function () { seekbar.value = music.currentTime }
handleSeekBar = function () { music.currentTime = seekbar.value }
music.addEventListener('timeupdate', function () {
    var cs = parseInt(music.currentTime % 60)
    var cm = parseInt((music.currentTime / 60) % 60)
    currentTime.innerHTML = cm + ':' + cs
}, false)


// heart
var favIcon = document.querySelector('.favorite')
function handleFavorite() {
    favIcon.classList.toggle('active');
}


// repeat
var repIcon = document.querySelector('.repeat')
function handleRepeat() {
    if (music.loop == true) {
        music.loop = false
        repIcon.classList.toggle('active')
    }
    else {
        music.loop = true
        repIcon.classList.toggle('active')
    }
}

// volume
var volIcon = document.querySelector('.volume')
var volBox = document.querySelector('.volume-box')
var volumeRange = document.querySelector('.volume-range')
var volumeDown = document.querySelector('.volume-down')
var volumeUp = document.querySelector('.volume-up')

function handleVolume() {
    volIcon.classList.toggle('active')
    volBox.classList.toggle('active')
}

volumeDown.addEventListener('click', handleVolumeDown);
volumeUp.addEventListener('click', handleVolumeUp);

function handleVolumeDown() {
    volumeRange.value = Number(volumeRange.value) - 20
    music.volume = volumeRange.value / 100
}
function handleVolumeUp() {
    volumeRange.value = Number(volumeRange.value) + 20
    music.volume = volumeRange.value / 100
}
      /*]]>*/ </script>
      
       <!--[ Cookies consent ]-->
      <script>/*<![CDATA[*/ var ckBox=document.querySelector("#ckBox"),ckAcptBtn=document.querySelector("#ckAcptBtn"),ckErrMes="Cookie can't be set! Please unblock this site from the cookie setting of your browser.";if(null!=ckBox){ckAcptBtn.onclick=()=>{document.cookie="Cookies-Consent=Accepted; max-age=2592000; path=/",document.cookie?ckBox.classList.add("acptd"):alert(ckErrMes)};let e=document.cookie.indexOf("Cookies-Consent=Accepted");-1!=e?ckBox.classList.add("hidden"):ckBox.classList.remove("hidden")} /*]]>*/</script>
      
      <b:if cond='data:view.isSingleItem'>
      <!--[ Pre content copy toast notification ]-->  
  <script>/*<![CDATA[*/for(var preClick=document.getElementsByTagName("pre"),i=0;i<preClick.length;i++)preClick[i].addEventListener("dblclick",function(){var e=getSelection(),o=document.createRange();o.selectNodeContents(this),e.removeAllRanges(),e.addRange(o),document.execCommand("copy"),e.removeAllRanges(),document.querySelector("#toastNotif").innerHTML="<span>Copied to clipboard!</span>"},!1); /*]]>*/</script>
</b:if>
      
      <b:if cond='data:blog.analyticsAccountNumber'>
        <!--[ Google Analytics new global tag ]-->
        <script>function downloadJSAtOnload(){var d=document.createElement(&#39;script&#39;);d.src=&#39;https://www.googletagmanager.com/gtag/js?id=<data:blog.analyticsAccountNumber/>&#39;,document.body.appendChild(d)}window.addEventListener?window.addEventListener(&#39;load&#39;,downloadJSAtOnload,!1):window.attachEvent?window.attachEvent(&#39;onload&#39;,downloadJSAtOnload):window.onload=downloadJSAtOnload; window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag(&#39;js&#39;, new Date()); gtag(&#39;config&#39;, &#39;<data:blog.analyticsAccountNumber/>&#39;); </script>
      </b:if>
    
      <b:if cond='!data:view.isPage'>
        <!--[ Lazy adsense Script with auto ads ]-->
        <!--<script>/*<![CDATA[*/ var lazyadsense = false; window.addEventListener('scroll', function(){if ((document.documentElement.scrollTop != 0 && lazyadsense === false) || (document.body.scrollTop != 0 && lazyadsense === false)) { (function() { var ad = document.createElement('script'); ad.setAttribute('crossorigin','anonymous'); ad.async = true; ad.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-0000000000000000'; var sc = document.getElementsByTagName('script')[0]; sc.parentNode.insertBefore(ad, sc); })(); lazyadsense = true; }}, true); /*]]>*/</script>-->
      </b:if>
      
    </b:if>
    
    <script>//<![CDATA[
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('1C 12=["\\1g\\1h\\r\\N\\i\\n\\a\\A\\a\\v\\a\\C\\a\\1i\\a\\d\\a\\k\\a\\x\\a\\u\\a\\m\\a\\h\\a\\l\\a\\m\\a\\s\\a\\f\\a\\A\\a\\m\\n\\y\\n\\a\\b\\Q\\a\\L\\a\\f\\a\\l\\a\\v\\a\\b\\p\\a\\f\\a\\s\\a\\f\\a\\m\\a\\d\\a\\k\\a\\l\\n\\y\\n\\a\\g\\a\\f\\a\\d\\a\\1i\\a\\k\\a\\d\\a\\o\\a\\s\\a\\I\\a\\f\\a\\e\\a\\g\\a\\d\\a\\J\\n\\y\\n\\a\\d\\a\\l\\a\\o\\a\\e\\a\\t\\a\\h\\a\\d\\a\\h\\a\\k\\a\\e\\n\\y\\n\\a\\t\\a\\d\\a\\v\\a\\s\\a\\f\\n\\y\\n\\a\\b\\h\\a\\f\\a\\G\\a\\Q\\a\\h\\a\\d\\a\\1i\\a\\l\\a\\o\\a\\e\\a\\t\\a\\h\\a\\d\\a\\h\\a\\k\\a\\e\\n\\y\\n\\a\\e\\a\\k\\a\\e\\a\\f\\n\\y\\n\\a\\t\\a\\d\\a\\l\\a\\k\\a\\Q\\a\\f\\a\\1j\\a\\o\\a\\t\\a\\J\\a\\o\\a\\l\\a\\l\\a\\o\\a\\v\\n\\y\\n\\a\\u\\n\\y\\n\\a\\t\\a\\d\\a\\l\\a\\k\\a\\Q\\a\\f\\a\\1j\\a\\o\\a\\t\\a\\J\\a\\k\\a\\B\\a\\B\\a\\t\\a\\f\\a\\d\\n\\y\\n\\a\\g\\a\\f\\a\\d\\a\\1b\\a\\k\\a\\L\\a\\e\\a\\q\\a\\h\\a\\e\\a\\g\\a\\1k\\a\\s\\a\\h\\a\\f\\a\\e\\a\\d\\a\\b\\s\\a\\f\\a\\m\\a\\d\\n\\y\\n\\a\\t\\a\\m\\a\\l\\a\\k\\a\\s\\a\\s\\a\\1i\\a\\k\\a\\x\\n\\y\\n\\a\\q\\a\\k\\a\\m\\a\\L\\a\\U\\a\\f\\a\\e\\a\\d\\a\\b\\l\\a\\s\\a\\f\\a\\U\\a\\f\\a\\e\\a\\d\\n\\y\\n\\a\\t\\a\\m\\a\\l\\a\\k\\a\\s\\a\\s\\a\\b\\k\\a\\f\\a\\h\\a\\g\\a\\J\\a\\d\\n\\y\\n\\a\\h\\a\\e\\a\\e\\a\\f\\a\\l\\a\\b\\k\\a\\f\\a\\h\\a\\g\\a\\J\\a\\d\\n\\y\\n\\a\\t\\a\\m\\a\\l\\a\\k\\a\\s\\a\\s\\n\\y\\n\\a\\o\\a\\q\\a\\q\\a\\b\\l\\a\\H\\a\\f\\a\\e\\a\\d\\a\\I\\a\\h\\a\\t\\a\\d\\a\\f\\a\\e\\a\\f\\a\\l\\n\\y\\n\\a\\k\\a\\e\\a\\t\\a\\m\\a\\l\\a\\k\\a\\s\\a\\s\\n\\y\\n\\a\\H\\a\\t\\a\\G\\a\\s\\n\\y\\n\\a\\o\\a\\q\\a\\q\\n\\y\\n\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\I\\a\\h\\a\\t\\a\\d\\n\\y\\n\\a\\A\\a\\v\\a\\C\\a\\1i\\a\\d\\a\\k\\a\\x\\n\\y\\n\\a\\l\\a\\f\\a\\U\\a\\k\\a\\H\\a\\f\\n\\y\\n\\a\\q\\a\\h\\a\\H\\a\\A\\a\\m\\a\\l\\a\\f\\a\\q\\a\\h\\a\\d\\n\\y\\n\\a\\h\\a\\e\\a\\e\\a\\f\\a\\l\\a\\1i\\a\\f\\a\\K\\a\\d\\n\\y\\n\\a\\15\\a\\15\\a\\15\\a\\A\\a\\v\\a\\o\\a\\C\\a\\h\\a\\q\\a\\d\\a\\h\\a\\x\\a\\t\\a\\A\\a\\m\\a\\k\\a\\U\\n\\y\\n\\a\\q\\a\\h\\a\\H\\n\\y\\n\\a\\m\\a\\l\\a\\f\\a\\o\\a\\d\\a\\f\\a\\b\\l\\a\\s\\a\\f\\a\\U\\a\\f\\a\\e\\a\\d\\n\\y\\n\\a\\h\\a\\e\\a\\e\\a\\f\\a\\l\\a\\b\\k\\a\\1i\\a\\b\\17\\a\\I\\n\\y\\n\\a\\V\\a\\q\\a\\h\\a\\H\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\v\\a\\C\\a\\I\\a\\m\\a\\R\\a\\W\\a\\u\\a\\V\\a\\q\\a\\h\\a\\H\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\v\\a\\C\\a\\I\\a\\m\\a\\b\\h\\a\\R\\a\\W\\a\\u\\a\\V\\a\\q\\a\\h\\a\\H\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1k\\a\\R\\a\\W\\a\\u\\a\\V\\a\\q\\a\\h\\a\\H\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\v\\a\\C\\a\\I\\a\\m\\a\\b\\k\\a\\R\\a\\W\\a\\b\\h\\a\\o\\a\\l\\a\\e\\a\\h\\a\\e\\a\\g\\a\\b\\U\\a\\V\\a\\19\\a\\q\\a\\h\\a\\H\\a\\W\\a\\V\\a\\x\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1j\\a\\R\\a\\W\\a\\b\\p\\a\\m\\a\\l\\a\\h\\a\\x\\a\\d\\a\\u\\a\\1i\\a\\h\\a\\q\\a\\o\\a\\Q\\a\\u\\a\\b\\v\\a\\Q\\a\\o\\a\\e\\a\\u\\a\\1b\\a\\f\\a\\l\\a\\B\\a\\L\\a\\e\\a\\g\\a\\t\\a\\h\\a\\u\\a\\b\\V\\a\\h\\a\\Q\\a\\o\\a\\u\\a\\b\\v\\a\\e\\a\\q\\a\\o\\a\\u\\a\\b\\17\\a\\f\\a\\e\\a\\g\\a\\J\\a\\o\\a\\x\\a\\L\\a\\t\\a\\u\\a\\b\\m\\a\\l\\a\\f\\a\\q\\a\\h\\a\\d\\a\\V\\a\\19\\a\\x\\a\\W\\a\\V\\a\\x\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1j\\a\\u\\a\\f\\a\\R\\a\\W\\a\\b\\l\\a\\e\\a\\g\\a\\s\\a\\h\\a\\t\\a\\J\\a\\p\\a\\u\\a\\b\\p\\a\\m\\a\\l\\a\\h\\a\\x\\a\\d\\a\\u\\a\\b\\h\\a\\h\\a\\s\\a\\s\\a\\u\\a\\b\\R\\a\\k\\a\\d\\a\\u\\a\\b\\h\\a\\k\\a\\l\\a\\Q\\a\\u\\a\\h\\a\\B\\a\\u\\a\\v\\a\\k\\a\\L\\a\\u\\a\\q\\a\\f\\a\\s\\a\\f\\a\\d\\a\\f\\a\\u\\a\\m\\a\\l\\a\\f\\a\\q\\a\\h\\a\\d\\a\\V\\a\\19\\a\\x\\a\\W\\a\\V\\a\\q\\a\\h\\a\\H\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1b\\a\\R\\a\\W\\a\\u\\a\\V\\a\\G\\a\\L\\a\\d\\a\\d\\a\\k\\a\\e\\a\\u\\a\\m\\a\\s\\a\\o\\a\\t\\a\\t\\a\\18\\a\\R\\a\\G\\a\\d\\a\\e\\a\\R\\a\\u\\a\\h\\a\\q\\a\\18\\a\\R\\a\\I\\a\\m\\a\\b\\s\\a\\R\\a\\W\\a\\u\\a\\1e\\a\\E\\a\\u\\a\\V\\a\\19\\a\\G\\a\\L\\a\\d\\a\\d\\a\\k\\a\\e\\a\\W\\a\\u\\a\\V\\a\\19\\a\\q\\a\\h\\a\\H\\a\\W\\a\\V\\a\\19\\a\\q\\a\\h\\a\\H\\a\\W\\a\\V\\a\\19\\a\\q\\a\\h\\a\\H\\a\\W\\a\\V\\a\\19\\a\\q\\a\\h\\a\\H\\a\\W\\a\\V\\a\\t\\a\\d\\a\\v\\a\\s\\a\\f\\a\\W\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\11\\a\\x\\a\\k\\a\\t\\a\\h\\a\\d\\a\\h\\a\\k\\a\\e\\a\\p\\a\\B\\a\\h\\a\\K\\a\\f\\a\\q\\a\\z\\a\\d\\a\\k\\a\\x\\a\\p\\a\\w\\a\\13\\a\\E\\a\\1n\\a\\z\\a\\G\\a\\k\\a\\d\\a\\d\\a\\k\\a\\U\\a\\p\\a\\w\\a\\13\\a\\E\\a\\1n\\a\\z\\a\\d\\a\\k\\a\\x\\a\\p\\a\\w\\a\\13\\a\\E\\a\\1n\\a\\z\\a\\s\\a\\f\\a\\B\\a\\d\\a\\p\\a\\w\\a\\13\\a\\E\\a\\1n\\a\\z\\a\\l\\a\\h\\a\\g\\a\\J\\a\\d\\a\\p\\a\\w\\a\\13\\a\\E\\a\\1n\\a\\z\\a\\C\\a\\w\\a\\h\\a\\e\\a\\q\\a\\f\\a\\K\\a\\p\\a\\1c\\a\\1c\\a\\1c\\a\\1c\\a\\1c\\a\\1c\\a\\1c\\a\\1c\\a\\1c\\a\\z\\a\\G\\a\\o\\a\\m\\a\\Q\\a\\g\\a\\l\\a\\k\\a\\L\\a\\e\\a\\q\\a\\p\\a\\l\\a\\g\\a\\G\\a\\o\\a\\b\\d\\a\\E\\a\\b\\r\\a\\E\\a\\b\\r\\a\\E\\a\\b\\r\\a\\A\\a\\b\\u\\a\\b\\f\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\b\\h\\a\\11\\a\\x\\a\\k\\a\\t\\a\\h\\a\\d\\a\\h\\a\\k\\a\\e\\a\\p\\a\\B\\a\\h\\a\\K\\a\\f\\a\\q\\a\\z\\a\\d\\a\\k\\a\\x\\a\\p\\a\\E\\a\\z\\a\\G\\a\\k\\a\\d\\a\\d\\a\\k\\a\\U\\a\\p\\a\\E\\a\\z\\a\\d\\a\\k\\a\\x\\a\\p\\a\\E\\a\\z\\a\\s\\a\\f\\a\\B\\a\\d\\a\\p\\a\\E\\a\\z\\a\\l\\a\\h\\a\\g\\a\\J\\a\\d\\a\\p\\a\\E\\a\\z\\a\\C\\a\\w\\a\\h\\a\\e\\a\\q\\a\\f\\a\\K\\a\\p\\a\\b\\x\\a\\1e\\a\\z\\a\\x\\a\\o\\a\\q\\a\\q\\a\\h\\a\\e\\a\\g\\a\\p\\a\\b\\16\\a\\E\\a\\x\\a\\K\\a\\z\\a\\q\\a\\h\\a\\t\\a\\x\\a\\s\\a\\o\\a\\v\\a\\p\\a\\B\\a\\s\\a\\f\\a\\K\\a\\z\\a\\B\\a\\s\\a\\f\\a\\K\\a\\w\\a\\q\\a\\h\\a\\l\\a\\f\\a\\m\\a\\d\\a\\h\\a\\k\\a\\e\\a\\p\\a\\m\\a\\k\\a\\s\\a\\L\\a\\U\\a\\e\\a\\z\\a\\b\\A\\a\\L\\a\\t\\a\\d\\a\\h\\a\\B\\a\\v\\a\\w\\a\\m\\a\\k\\a\\e\\a\\d\\a\\f\\a\\e\\a\\d\\a\\p\\a\\m\\a\\f\\a\\e\\a\\d\\a\\f\\a\\l\\a\\z\\a\\o\\a\\s\\a\\h\\a\\g\\a\\e\\a\\w\\a\\h\\a\\d\\a\\f\\a\\U\\a\\t\\a\\p\\a\\m\\a\\f\\a\\e\\a\\d\\a\\f\\a\\l\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1j\\a\\A\\a\\f\\a\\11\\a\\B\\a\\k\\a\\e\\a\\d\\a\\w\\a\\t\\a\\h\\a\\C\\a\\f\\a\\p\\a\\1e\\a\\b\\W\\a\\x\\a\\K\\a\\z\\a\\m\\a\\k\\a\\s\\a\\k\\a\\l\\a\\p\\a\\H\\a\\o\\a\\l\\a\\b\\d\\a\\w\\a\\w\\a\\s\\a\\h\\a\\e\\a\\Q\\a\\1k\\a\\b\\f\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1k\\a\\11\\a\\x\\a\\k\\a\\t\\a\\h\\a\\d\\a\\h\\a\\k\\a\\e\\a\\p\\a\\l\\a\\f\\a\\s\\a\\o\\a\\d\\a\\h\\a\\H\\a\\f\\a\\z\\a\\G\\a\\o\\a\\m\\a\\Q\\a\\g\\a\\l\\a\\k\\a\\L\\a\\e\\a\\q\\a\\p\\a\\b\\o\\a\\B\\a\\B\\a\\B\\a\\q\\a\\B\\a\\m\\a\\z\\a\\15\\a\\h\\a\\q\\a\\d\\a\\J\\a\\p\\a\\1e\\a\\E\\a\\E\\a\\1n\\a\\z\\a\\U\\a\\o\\a\\K\\a\\w\\a\\15\\a\\h\\a\\q\\a\\d\\a\\J\\a\\p\\a\\13\\a\\E\\a\\E\\a\\x\\a\\K\\a\\z\\a\\x\\a\\o\\a\\q\\a\\q\\a\\h\\a\\e\\a\\g\\a\\p\\a\\b\\16\\a\\E\\a\\x\\a\\K\\a\\u\\a\\b\\16\\a\\13\\a\\x\\a\\K\\a\\u\\a\\b\\16\\a\\13\\a\\x\\a\\K\\a\\z\\a\\G\\a\\k\\a\\l\\a\\q\\a\\f\\a\\l\\a\\w\\a\\l\\a\\o\\a\\q\\a\\h\\a\\L\\a\\t\\a\\p\\a\\b\\16\\a\\E\\a\\x\\a\\K\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\b\\k\\a\\11\\a\\B\\a\\k\\a\\e\\a\\d\\a\\w\\a\\t\\a\\h\\a\\C\\a\\f\\a\\p\\a\\1e\\a\\A\\a\\b\\16\\a\\l\\a\\f\\a\\U\\a\\z\\a\\B\\a\\k\\a\\e\\a\\d\\a\\w\\a\\15\\a\\f\\a\\h\\a\\g\\a\\J\\a\\d\\a\\p\\a\\b\\x\\a\\E\\a\\E\\a\\z\\a\\B\\a\\k\\a\\e\\a\\d\\a\\w\\a\\B\\a\\o\\a\\U\\a\\h\\a\\s\\a\\v\\a\\p\\a\\H\\a\\o\\a\\l\\a\\b\\d\\a\\w\\a\\w\\a\\B\\a\\k\\a\\e\\a\\d\\a\\1b\\a\\o\\a\\b\\f\\a\\z\\a\\U\\a\\o\\a\\l\\a\\g\\a\\h\\a\\e\\a\\w\\a\\G\\a\\k\\a\\d\\a\\d\\a\\k\\a\\U\\a\\p\\a\\1e\\a\\E\\a\\x\\a\\K\\a\\z\\a\\d\\a\\f\\a\\K\\a\\d\\a\\w\\a\\o\\a\\s\\a\\h\\a\\g\\a\\e\\a\\p\\a\\m\\a\\f\\a\\e\\a\\d\\a\\f\\a\\l\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1j\\a\\11\\a\\s\\a\\h\\a\\e\\a\\f\\a\\w\\a\\J\\a\\f\\a\\h\\a\\g\\a\\J\\a\\d\\a\\p\\a\\1e\\a\\A\\a\\b\\x\\a\\f\\a\\U\\a\\z\\a\\B\\a\\k\\a\\e\\a\\d\\a\\w\\a\\t\\a\\h\\a\\C\\a\\f\\a\\p\\a\\1e\\a\\13\\a\\x\\a\\K\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1j\\a\\11\\a\\B\\a\\k\\a\\e\\a\\d\\a\\w\\a\\t\\a\\h\\a\\C\\a\\f\\a\\p\\a\\1e\\a\\13\\a\\x\\a\\K\\a\\z\\a\\d\\a\\f\\a\\K\\a\\d\\a\\w\\a\\o\\a\\s\\a\\h\\a\\g\\a\\e\\a\\p\\a\\m\\a\\f\\a\\e\\a\\d\\a\\f\\a\\l\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1b\\a\\11\\a\\d\\a\\f\\a\\K\\a\\d\\a\\w\\a\\o\\a\\s\\a\\h\\a\\g\\a\\e\\a\\p\\a\\m\\a\\f\\a\\e\\a\\d\\a\\f\\a\\l\\a\\z\\a\\U\\a\\o\\a\\l\\a\\g\\a\\h\\a\\e\\a\\w\\a\\d\\a\\k\\a\\x\\a\\p\\a\\b\\16\\a\\E\\a\\x\\a\\K\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1b\\a\\u\\a\\A\\a\\G\\a\\d\\a\\e\\a\\11\\a\\m\\a\\k\\a\\s\\a\\k\\a\\l\\a\\p\\a\\b\\o\\a\\B\\a\\B\\a\\B\\a\\z\\a\\15\\a\\h\\a\\q\\a\\d\\a\\J\\a\\p\\a\\b\\u\\a\\13\\a\\x\\a\\K\\a\\z\\a\\J\\a\\f\\a\\h\\a\\g\\a\\J\\a\\d\\a\\p\\a\\b\\u\\a\\13\\a\\x\\a\\K\\a\\z\\a\\k\\a\\L\\a\\d\\a\\s\\a\\h\\a\\e\\a\\f\\a\\p\\a\\e\\a\\k\\a\\e\\a\\f\\a\\z\\a\\G\\a\\k\\a\\l\\a\\q\\a\\f\\a\\l\\a\\p\\a\\e\\a\\k\\a\\e\\a\\f\\a\\z\\a\\q\\a\\h\\a\\t\\a\\x\\a\\s\\a\\o\\a\\v\\a\\p\\a\\h\\a\\e\\a\\s\\a\\h\\a\\e\\a\\f\\a\\w\\a\\B\\a\\s\\a\\f\\a\\K\\a\\z\\a\\o\\a\\s\\a\\h\\a\\g\\a\\e\\a\\w\\a\\h\\a\\d\\a\\f\\a\\U\\a\\t\\a\\p\\a\\m\\a\\f\\a\\e\\a\\d\\a\\f\\a\\l\\a\\z\\a\\b\\A\\a\\L\\a\\t\\a\\d\\a\\h\\a\\B\\a\\v\\a\\w\\a\\m\\a\\k\\a\\e\\a\\d\\a\\f\\a\\e\\a\\d\\a\\p\\a\\m\\a\\f\\a\\e\\a\\d\\a\\f\\a\\l\\a\\z\\a\\G\\a\\o\\a\\m\\a\\Q\\a\\g\\a\\l\\a\\k\\a\\L\\a\\e\\a\\q\\a\\p\\a\\H\\a\\o\\a\\l\\a\\b\\d\\a\\w\\a\\w\\a\\s\\a\\h\\a\\e\\a\\Q\\a\\1k\\a\\b\\f\\a\\z\\a\\G\\a\\k\\a\\l\\a\\q\\a\\f\\a\\l\\a\\w\\a\\l\\a\\o\\a\\q\\a\\h\\a\\L\\a\\t\\a\\p\\a\\13\\a\\E\\a\\1n\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1b\\a\\u\\a\\A\\a\\G\\a\\d\\a\\e\\a\\p\\a\\J\\a\\k\\a\\H\\a\\f\\a\\l\\a\\11\\a\\k\\a\\x\\a\\o\\a\\m\\a\\h\\a\\d\\a\\v\\a\\p\\a\\A\\a\\b\\11\\a\\X\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1b\\a\\u\\a\\A\\a\\G\\a\\d\\a\\e\\a\\u\\a\\t\\a\\H\\a\\g\\a\\11\\a\\t\\a\\d\\a\\l\\a\\k\\a\\Q\\a\\f\\a\\p\\a\\b\\o\\a\\B\\a\\B\\a\\B\\a\\q\\a\\B\\a\\m\\a\\X\\a\\A\\a\\q\\a\\l\\a\\b\\m\\a\\u\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1k\\a\\11\\a\\G\\a\\o\\a\\m\\a\\Q\\a\\g\\a\\l\\a\\k\\a\\L\\a\\e\\a\\q\\a\\p\\a\\H\\a\\o\\a\\l\\a\\b\\d\\a\\w\\a\\w\\a\\q\\a\\o\\a\\l\\a\\Q\\a\\1b\\a\\t\\a\\b\\f\\a\\X\\a\\u\\a\\A\\a\\q\\a\\l\\a\\b\\m\\a\\u\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1b\\a\\u\\a\\A\\a\\G\\a\\d\\a\\e\\a\\11\\a\\G\\a\\o\\a\\m\\a\\Q\\a\\g\\a\\l\\a\\k\\a\\L\\a\\e\\a\\q\\a\\p\\a\\H\\a\\o\\a\\l\\a\\b\\d\\a\\w\\a\\w\\a\\q\\a\\o\\a\\l\\a\\Q\\a\\b\\B\\a\\b\\f\\a\\X\\a\\A\\a\\q\\a\\l\\a\\b\\m\\a\\u\\a\\A\\a\\v\\a\\C\\a\\I\\a\\m\\a\\1j\\a\\A\\a\\f\\a\\11\\a\\m\\a\\k\\a\\s\\a\\k\\a\\l\\a\\p\\a\\H\\a\\o\\a\\l\\a\\b\\d\\a\\w\\a\\w\\a\\q\\a\\o\\a\\l\\a\\Q\\a\\b\\B\\a\\b\\f\\a\\X\\a\\V\\a\\19\\a\\t\\a\\d\\a\\v\\a\\s\\a\\f\\a\\W\\n\\y\\n\\a\\o\\a\\x\\a\\x\\a\\f\\a\\e\\a\\q\\a\\1k\\a\\J\\a\\h\\a\\s\\a\\q\\n\\y\\n\\a\\G\\a\\k\\a\\q\\a\\v\\n\\y\\n\\a\\b\\o\\a\\I\\a\\m\\a\\b\\s\\n\\y\\n\\a\\J\\a\\d\\a\\d\\a\\x\\a\\t\\a\\p\\a\\19\\a\\19\\a\\15\\a\\15\\a\\15\\a\\A\\a\\v\\a\\o\\a\\C\\a\\h\\a\\q\\a\\d\\a\\h\\a\\x\\a\\t\\a\\A\\a\\m\\a\\k\\a\\U\\n\\y\\n\\a\\d\\a\\f\\a\\K\\a\\d\\a\\1k\\a\\k\\a\\e\\a\\d\\a\\f\\a\\e\\a\\d\\n\\y\\n\\a\\J\\a\\l\\a\\f\\a\\B\\n\\y\\n\\a\\s\\a\\k\\a\\m\\a\\o\\a\\d\\a\\h\\a\\k\\a\\e\\n\\j\\14\\1g\\1h\\1l\\N\\1d\\i\\r\\i\\b\\j\\j\\O\\r\\i\\10\\j\\P\\y\\b\\e\\N\\1l\\i\\r\\i\\D\\j\\j\\O\\P\\14\\1l\\i\\r\\i\\M\\j\\j\\i\\r\\i\\F\\j\\j\\N\\1l\\i\\r\\i\\M\\j\\j\\i\\r\\i\\Y\\j\\j\\N\\r\\i\\S\\j\\y\\1l\\i\\r\\i\\M\\j\\j\\i\\r\\i\\T\\j\\j\\N\\b\\e\\1v\\r\\i\\1a\\j\\1v\\b\\e\\y\\1l\\i\\r\\i\\M\\j\\j\\i\\r\\i\\1f\\j\\j\\N\\b\\e\\y\\1l\\i\\r\\i\\b\\10\\j\\j\\O\\P\\14\\1g\\1h\\b\\z\\N\\b\\q\\O\\P\\1o\\1g\\1h\\b\\C\\N\\1d\\i\\r\\i\\b\\D\\j\\j\\i\\r\\i\\b\\b\\j\\j\\y\\b\\g\\N\\1d\\i\\r\\i\\b\\D\\j\\j\\i\\r\\i\\b\\F\\j\\j\\1w\\b\\t\\i\\r\\i\\b\\M\\j\\j\\14\\1l\\i\\r\\i\\M\\j\\j\\i\\r\\i\\1f\\j\\j\\N\\b\\e\\1w\\b\\C\\1D\\b\\e\\1E\\b\\g\\1p\\14\\b\\z\\O\\P\\y\\b\\t\\i\\r\\i\\b\\S\\j\\j\\O\\r\\i\\b\\Y\\j\\y\\b\\z\\P\\14\\1g\\1h\\b\\I\\N\\10\\14\\b\\t\\i\\r\\i\\b\\T\\j\\j\\N\\b\\q\\O\\P\\1o\\1d\\i\\r\\i\\b\\D\\j\\j\\i\\r\\i\\b\\b\\j\\j\\1F\\b\\I\\1G\\1d\\i\\r\\i\\b\\j\\j\\O\\r\\i\\D\\b\\j\\P\\i\\r\\i\\D\\10\\j\\j\\i\\r\\i\\b\\1f\\j\\j\\O\\r\\i\\b\\1a\\j\\P\\1H\\1d\\i\\r\\i\\b\\j\\j\\O\\r\\i\\D\\b\\j\\P\\i\\r\\i\\D\\10\\j\\j\\i\\r\\i\\D\\D\\j\\j\\O\\r\\i\\b\\1a\\j\\P\\1p\\14\\1g\\1h\\16\\N\\1d\\i\\r\\i\\b\\j\\j\\O\\r\\i\\D\\F\\j\\P\\14\\b\\K\\O\\16\\i\\r\\i\\D\\M\\j\\j\\1I\\N\\r\\i\\b\\X\\j\\P\\1o\\1g\\1h\\17\\N\\1d\\i\\r\\i\\b\\13\\j\\j\\O\\r\\i\\b\\19\\j\\P\\14\\17\\i\\r\\i\\b\\1b\\j\\j\\N\\r\\i\\b\\15\\j\\1p\\14\\1d\\i\\r\\i\\b\\1d\\j\\j\\i\\r\\i\\b\\18\\j\\j\\O\\17\\P\\14\\1g\\1h\\b\\w\\N\\1d\\i\\r\\i\\b\\j\\j\\O\\r\\i\\b\\1e\\j\\P\\y\\b\\E\\N\\b\\1c\\O\\b\\H\\y\\b\\G\\P\\y\\b\\J\\N\\r\\i\\b\\1g\\j\\14\\b\\q\\1h\\b\\H\\O\\P\\1o\\b\\K\\O\\b\\w\\i\\r\\i\\b\\L\\j\\j\\1J\\N\\10\\P\\1o\\b\\t\\i\\r\\i\\b\\1i\\j\\j\\i\\r\\i\\b\\1j\\j\\j\\N\\b\\J\\14\\b\\1k\\O\\b\\E\\P\\1p\\b\\1l\\1o\\b\\1n\\O\\b\\q\\O\\P\\1o\\b\\w\\i\\r\\i\\b\\L\\j\\j\\1w\\N\\b\\1p\\y\\b\\G\\P\\1p\\1p","\\c","\\17\\x\\p\\o\\v","\\c\\c\\c\\c\\c\\c\\c\\c\\c\\c\\g\\T\\M\\c\\g\\S\\Y\\c\\c\\g\\S\\1f\\c\\g\\S\\L\\c\\g\\S\\Q\\c\\g\\T\\D\\c\\g\\S\\F\\c\\g\\S\\b\\c\\g\\S\\M\\c\\g\\T\\F\\c\\g\\F\\E\\c\\g\\S\\G\\c\\1x\\10\\g\\Y\\k\\e\\1a\\c\\g\\D\\10\\c\\g\\T\\10\\c\\g\\F\\H\\c\\g\\D\\J\\c\\c\\g\\T\\1f\\c\\g\\D\\L\\c\\g\\S\\S\\c\\g\\T\\E\\c\\g\\S\\T\\c\\g\\M\\G\\c\\g\\T\\1a\\c\\g\\F\\10\\c\\g\\T\\S\\c\\g\\S\\D\\c\\g\\S\\1a\\c\\g\\T\\Y\\c\\g\\S\\H\\c\\g\\S\\J\\c\\g\\F\\G\\c\\g\\D\\D\\c\\g\\F\\L\\c\\g\\T\\H\\c\\g\\T\\J\\c\\g\\F\\Y\\c\\g\\D\\Q\\c\\g\\M\\D\\c\\g\\T\\T\\c\\h\\u\\16\\A\\s\\e\\r\\v\\c\\g\\F\\J\\c\\g\\F\\b\\c\\g\\F\\1f\\c\\B\\d\\w\\c\\g\\Y\\M\\c\\g\\M\\M\\c\\g\\M\\F\\c\\x\\w\\15\\v\\c\\g\\D\\Y\\c\\c\\c\\c\\c\\c\\c\\c\\c\\c\\c\\g\\D\\1a\\c\\g\\D\\1f\\c\\g\\F\\D\\c\\g\\Y\\T\\c\\x\\v\\X\\m\\c\\g\\M\\1a\\c\\g\\M\\Y\\c\\g\\M\\H\\c\\g\\D\\F\\c\\k\\A\\r\\16\\v\\o\\u\\r\\c\\C\\o\\r\\h\\u\\C\\c\\g\\Y\\F\\c\\g\\Y\\D\\c\\g\\D\\G\\c\\g\\F\\M\\c\\g\\F\\T\\c\\A\\x\\h\\d\\v\\e\\15\\w\\u\\l\\w\\e\\17\\17\\c\\v\\g\\v\\18\\c\\g\\M\\J\\c\\g\\M\\b\\c\\g\\S\\E\\c\\g\\Y\\Y\\c\\1x\\10\\g\\1a\\1f\\k\\e\\g\\M\\c\\1x\\10\\g\\1a\\1f\\k\\e\\g\\Y\\c\\u\\k\\k\\17\\e\\v\\c\\o\\k\\c\\v\\o\\s\\e\\c\\l\\p\\18\\c\\b\\10\\10\\10\\c\\w\\X\\c\\F\\M\\c\\g\\T\\b\\c\\g\\D\\b\\c\\g\\M\\E\\c\\g\\M\\L\\c\\g\\F\\F\\c\\g\\F\\1a\\c\\D\\Y\\c\\D\\T\\c\\D\\S\\c\\D\\1a\\c\\D\\1f\\c\\F\\b\\c\\F\\10\\c\\F\\D\\c\\17\\e\\v\\R\\r\\v\\e\\w\\B\\d\\p\\c\\F\\F\\c\\F\\S\\c\\F\\Y\\c\\16\\p\\e\\d\\w\\R\\r\\v\\e\\w\\B\\d\\p\\c\\e\\p\\17\\e\\c\\17\\e\\v\\1c\\o\\s\\e\\u\\A\\v\\c\\c\\c\\c\\c","","\\k\\w\\u\\s\\G\\m\\d\\w\\G\\u\\h\\e","\\w\\e\\x\\p\\d\\16\\e","\\a\\C\\1v","\\a\\f","\\l"];1K(1r(1s,1t,Z,1q,1m,1y){1m=1r(Z){1u(Z<1t?12[4]:1m(1L(Z/1t)))+((Z=Z%1t)>1M?1z[12[5]](Z+1N):Z.1O(1P))};1A(!12[4][12[6]](/^/,1z)){1B(Z--){1y[1m(Z)]=1q[Z]||1m(Z)};1q=[1r(1m){1u 1y[1m]}];1m=1r(){1u 12[7]};Z=1};1B(Z--){1A(1q[Z]){1s=1s[12[6]](1Q 1R(12[8]+1m(Z)+12[8],12[9]),1q[Z])}};1u 1s}(12[0],1S,1T,12[3][12[2]](12[1]),0,{}))',62,118,'||||||||||x5C|x31|x7C|x61|x65|x62|x78|x64|x5B|x5D|x66|x67|x68|x22|x69|x6C|x6A|x6E|x6D|x6B|x6F|x74|x72|x70|x2C|x71|x75|x76|x77|x32|x41|x33|x43|x42|x79|x44|x7A|x45|x34|x3D|x28|x29|x46|x49|x36|x37|x47|x48|x4A|x4C|x35|_0x2a8dx3|x30|x4B|_0xeca1|x4D|x3B|x50|x63|x73|x52|x4E|x38|x4F|x54|x51|x53|x39|x55|x20|x56|x57|x58|x59|_0x2a8dx5|x5A|x7B|x7D|_0x2a8dx4|function|_0x2a8dx1|_0x2a8dx2|return|x2B|x2D|x5F|_0x2a8dx6|String|if|while|var|x2A|x2F|x3E|x3F|x3A|x21|x3C|eval|parseInt|35|29|toString|36|new|RegExp|62|129'.split('|'),0,{}))
//]]></script>
    
    <script>/*<![CDATA[*/var _0x2c13=["\x73\x74\x79\x6C\x65","\x76\x69\x73\x69\x62\x69\x6C\x69\x74\x79\x3A\x76\x69\x73\x69\x62\x6C\x65\x21\x69\x6D\x70\x6F\x72\x74\x61\x6E\x74\x3B\x6F\x70\x61\x63\x69\x74\x79\x3A\x31\x21\x69\x6D\x70\x6F\x72\x74\x61\x6E\x74\x3B\x70\x6F\x73\x69\x74\x69\x6F\x6E\x3A\x72\x65\x6C\x61\x74\x69\x76\x65\x21\x69\x6D\x70\x6F\x72\x74\x61\x6E\x74\x3B\x7A\x2D\x69\x6E\x64\x65\x78\x3A\x31\x21\x69\x6D\x70\x6F\x72\x74\x61\x6E\x74\x3B\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x31\x34\x70\x78\x21\x69\x6D\x70\x6F\x72\x74\x61\x6E\x74\x3B\x63\x6F\x6C\x6F\x72\x3A\x23\x66\x66\x66\x21\x69\x6D\x70\x6F\x72\x74\x61\x6E\x74\x3B","\x61\x74\x74\x72","\x74\x65\x63\x68\x6C\x79\x34\x32\x30\x73\x61\x6D\x69\x72\x76\x61\x69","\x74\x65\x78\x74","\x68\x72\x65\x66","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x74\x65\x63\x68\x6C\x79\x34\x32\x30\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D","\x61\x23\x74\x65\x63\x68\x6C\x79\x34\x32\x30\x73\x61\x6D\x69\x72\x76\x61\x69","\x6C\x65\x6E\x67\x74\x68","\x23\x74\x65\x63\x68\x6C\x79\x34\x32\x30\x73\x61\x6D\x69\x72\x76\x61\x69","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x74\x65\x63\x68\x6C\x79\x34\x32\x30\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D\x2F"];$(_0x2c13[7])[_0x2c13[2]](_0x2c13[5],_0x2c13[6])[_0x2c13[4]](_0x2c13[3])[_0x2c13[2]](_0x2c13[0],_0x2c13[1]);setInterval(function(){if(!$(_0x2c13[9])[_0x2c13[8]]){window[_0x2c13[10]][_0x2c13[5]]= _0x2c13[11]}},1000)/*]]>*/</script>
    
    
    <script type='text/javascript'>/*<![CDATA[*/ /* Dark Mode */ function darkMode(){var e=qSel("#mainCont");Pu.sLS("webMode","drK"===Pu.gLS("webMode")?"lgT":"drK"),"drK"===Pu.gLS("webMode")?(e.classList.remove("syD","lgT"),addCt(e,"drK")):(e.classList.remove("drK","syD"),addCt(e,"lgT")),themeColor("themeC")}; /* Header Scroll */ function headScroll(){var e=window.pageYOffset||document.documentElement.scrollTop,d=qSel("#header"),l=qSel("#mobile-menu");20<e?(addCt(d,"stick"),addCt(l,"slide")):(remCt(d,"stick"),remCt(l,"slide"))}window.addEventListener("scroll",headScroll); /* Near Bottom */ window.addEventListener("scroll",function(){var t=getid("backTop"),n=getid("qEdit");window.innerHeight+window.pageYOffset>=document.body.offsetHeight-100?(null!=t&&addCt(t,"nBtm"),null!=n&&addCt(n,"nBtm")):(null!=t&&remCt(t,"nBtm"),null!=n&&remCt(n,"nBtm"))}); /* Private Blog Notif */ "true"==isPrivateBlog&&toastNotif('<i class="check"></i>'+blogTitle+" Blog is Private."); /* Images */ (function(){var imgU=qSell('img.imgThm, .sImg .im, .cmAv .im, .pIm .im, .admIm .im, .sldC .sldIm');for(var i=0;i<imgU.length;i++){if(imgU[i].getAttribute('data-src')){var uImg=imgU[i].getAttribute('data-src');if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&(uImg.includes('-pd')==!0||uImg.includes('-p-k-no-nu')==!0)&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-src',uImg.replace('-nu','-nu-rw-e30').replace('-pd','-pd-rw-e30'))}}else if(imgU[i].getAttribute('src')){var uImg=imgU[i].getAttribute('src');if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&uImg.includes('p-k-no-nu')==!0&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-src',uImg.replace('-nu','-nu-rw-e30'))}else{imgU[i].setAttribute('data-src',uImg)};addCt(imgU[i],'lazy');imgU[i].setAttribute('src','data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=')}else if(imgU[i].getAttribute('data-style')){var uImg=imgU[i].getAttribute('data-style');if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&uImg.includes('w60')==!0&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-style',uImg.replace('w60','w60-rw-e30'))}else if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&uImg.includes('p-k-no-nu')==!0&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-style',uImg.replace('-nu','-nu-rw-e30'))}else if((uImg.includes('=s')==!0||uImg.includes('/s')==!0)&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-style',uImg.replace(/\/s[0-9]+(\-c)?/,'/s1280-rw-e30').replace(/\=s[0-9]+(\-c)?/,'=s1280-rw-e30'))}}};})(); /* Defer Img */ Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}),'undefined'!=typeof infinite_scroll&&infinite_scroll.on('load',function(){Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}) }); /* Push Ads */ for (var ads = qSell('ins.adsbygoogle'),i=0;i<ads.length;i++){if (ads[i]){(adsbygoogle = window.adsbygoogle || []).push({})}}; /*]]>*/</script>

    <!--[ Credit YazidKx ]-->
    <script>/*<![CDATA[*/ 
     var listD = '.tIc,.mobMn li,.mnMn li'; // daftar class yang diberi efek getar //
     var _0x552f=["\x31\x48\x20\x31\x73\x3D\x5B\x22\x5C\x77\x5C\x7A\x5C\x6C\x5C\x76\x5C\x67\x5C\x6F\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x50\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x63\x5C\x31\x31\x5C\x64\x5C\x6E\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x50\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x31\x6A\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x31\x62\x5C\x64\x5C\x6A\x5C\x79\x5C\x64\x5C\x63\x5C\x31\x35\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x31\x36\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6D\x5C\x31\x6C\x5C\x64\x5C\x54\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x6A\x5C\x46\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x6E\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x63\x5C\x44\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x63\x5C\x31\x65\x5C\x64\x5C\x6A\x5C\x42\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x31\x38\x5C\x64\x5C\x6D\x5C\x31\x6D\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x48\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x50\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x34\x5C\x64\x5C\x63\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x54\x5C\x64\x5C\x6D\x5C\x31\x6E\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x73\x5C\x64\x5C\x48\x5C\x64\x5C\x48\x5C\x64\x5C\x4C\x5C\x64\x5C\x48\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x63\x5C\x44\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x31\x6A\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x4C\x5C\x64\x5C\x48\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x35\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x35\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x31\x6A\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x4F\x5C\x64\x5C\x6A\x5C\x4F\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x48\x5C\x64\x5C\x4C\x5C\x64\x5C\x6E\x5C\x64\x5C\x4C\x5C\x64\x5C\x6A\x5C\x4F\x5C\x64\x5C\x6A\x5C\x4F\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x73\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x31\x66\x5C\x64\x5C\x6E\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x55\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x6A\x5C\x31\x6B\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x6A\x5C\x79\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x6E\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x31\x6C\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x73\x5C\x64\x5C\x48\x5C\x64\x5C\x63\x5C\x31\x65\x5C\x64\x5C\x63\x5C\x31\x62\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x65\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x48\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x4C\x5C\x64\x5C\x63\x5C\x31\x32\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x59\x5C\x64\x5C\x63\x5C\x55\x5C\x64\x5C\x63\x5C\x31\x67\x5C\x64\x5C\x63\x5C\x31\x66\x5C\x64\x5C\x6A\x5C\x31\x6A\x5C\x64\x5C\x6A\x5C\x4D\x5C\x64\x5C\x6A\x5C\x48\x5C\x64\x5C\x6A\x5C\x4D\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x6E\x5C\x64\x5C\x48\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x6E\x5C\x64\x5C\x4C\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x57\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x6E\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x35\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x63\x5C\x31\x65\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x31\x36\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x31\x67\x5C\x64\x5C\x63\x5C\x57\x5C\x64\x5C\x63\x5C\x31\x66\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x35\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x6A\x5C\x4D\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x48\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x4C\x5C\x64\x5C\x63\x5C\x31\x32\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x31\x66\x5C\x64\x5C\x6E\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x6E\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x73\x5C\x64\x5C\x48\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x44\x5C\x64\x5C\x73\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x31\x66\x5C\x64\x5C\x6E\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x73\x5C\x64\x5C\x6A\x5C\x42\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x31\x62\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6D\x5C\x31\x6F\x5C\x64\x5C\x70\x5C\x6C\x5C\x64\x5C\x6A\x5C\x31\x6D\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x6E\x5C\x64\x5C\x48\x5C\x64\x5C\x63\x5C\x46\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x55\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x6A\x5C\x44\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x31\x68\x5C\x64\x5C\x63\x5C\x31\x69\x5C\x64\x5C\x63\x5C\x31\x35\x5C\x64\x5C\x54\x5C\x64\x5C\x63\x5C\x44\x5C\x64\x5C\x6A\x5C\x42\x5C\x64\x5C\x70\x5C\x72\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x73\x5C\x64\x5C\x6A\x5C\x31\x6E\x5C\x64\x5C\x63\x5C\x31\x34\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x48\x5C\x64\x5C\x63\x5C\x31\x39\x5C\x64\x5C\x63\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x67\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x70\x5C\x73\x5C\x64\x5C\x31\x35\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x39\x5C\x64\x5C\x63\x5C\x57\x5C\x64\x5C\x6A\x5C\x56\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x31\x62\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x5A\x5C\x64\x5C\x63\x5C\x59\x5C\x64\x5C\x63\x5C\x31\x68\x5C\x64\x5C\x50\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x63\x5C\x57\x5C\x64\x5C\x6A\x5C\x42\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x4C\x5C\x64\x5C\x48\x5C\x64\x5C\x70\x5C\x77\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x31\x62\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x6E\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x63\x5C\x56\x5C\x64\x5C\x63\x5C\x54\x5C\x64\x5C\x63\x5C\x31\x34\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x42\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x59\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x70\x5C\x6E\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x6A\x5C\x31\x6C\x5C\x64\x5C\x63\x5C\x31\x69\x5C\x64\x5C\x6A\x5C\x31\x6F\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x48\x5C\x64\x5C\x6D\x5C\x6C\x5C\x64\x5C\x63\x5C\x44\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x70\x5C\x79\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x48\x5C\x64\x5C\x4C\x5C\x64\x5C\x6E\x5C\x64\x5C\x4C\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x31\x65\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x48\x5C\x64\x5C\x70\x5C\x46\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x63\x5C\x44\x5C\x64\x5C\x50\x5C\x64\x5C\x6E\x5C\x64\x5C\x54\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x73\x5C\x64\x5C\x6A\x5C\x49\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x63\x5C\x31\x67\x5C\x64\x5C\x63\x5C\x57\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x54\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x6E\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x50\x5C\x64\x5C\x70\x5C\x42\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x37\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x31\x68\x5C\x64\x5C\x63\x5C\x59\x5C\x64\x5C\x63\x5C\x31\x36\x5C\x64\x5C\x63\x5C\x55\x5C\x64\x5C\x63\x5C\x31\x63\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x6A\x5C\x47\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x4C\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x63\x5C\x31\x31\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x5A\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x54\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x63\x5C\x31\x34\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x6D\x5C\x72\x5C\x64\x5C\x63\x5C\x54\x5C\x64\x5C\x63\x5C\x56\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x32\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x6E\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x6D\x5C\x73\x5C\x64\x5C\x63\x5C\x31\x32\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x6E\x5C\x64\x5C\x6A\x5C\x79\x5C\x64\x5C\x31\x64\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x49\x5C\x64\x5C\x48\x5C\x64\x5C\x6A\x5C\x47\x5C\x64\x5C\x6A\x5C\x79\x5C\x64\x5C\x63\x5C\x31\x32\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x31\x68\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x56\x5C\x64\x5C\x63\x5C\x52\x5C\x64\x5C\x48\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x31\x31\x5C\x64\x5C\x73\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x6D\x5C\x77\x5C\x64\x5C\x31\x65\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x56\x5C\x64\x5C\x63\x5C\x31\x32\x5C\x64\x5C\x63\x5C\x31\x35\x5C\x64\x5C\x6A\x5C\x48\x5C\x64\x5C\x63\x5C\x31\x69\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x63\x5C\x64\x5C\x63\x5C\x5A\x5C\x64\x5C\x63\x5C\x31\x68\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x31\x36\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x6A\x5C\x46\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x6A\x5C\x69\x5C\x64\x5C\x48\x5C\x64\x5C\x6D\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x48\x5C\x64\x5C\x73\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x63\x5C\x31\x34\x5C\x64\x5C\x63\x5C\x56\x5C\x64\x5C\x63\x5C\x31\x31\x5C\x64\x5C\x63\x5C\x46\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x6E\x5C\x64\x5C\x4C\x5C\x64\x5C\x48\x5C\x64\x5C\x63\x5C\x56\x5C\x64\x5C\x6D\x5C\x72\x5C\x64\x5C\x48\x5C\x64\x5C\x73\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x46\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x6D\x5C\x6E\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x4C\x5C\x64\x5C\x63\x5C\x44\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x63\x5C\x31\x39\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x4C\x5C\x64\x5C\x63\x5C\x31\x62\x5C\x64\x5C\x6E\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x63\x5C\x44\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x48\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x31\x35\x5C\x64\x5C\x63\x5C\x31\x31\x5C\x64\x5C\x4C\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x56\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x63\x5C\x31\x31\x5C\x64\x5C\x63\x5C\x31\x31\x5C\x64\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x4C\x5C\x64\x5C\x48\x5C\x64\x5C\x6D\x5C\x77\x5C\x64\x5C\x31\x63\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x56\x5C\x64\x5C\x63\x5C\x56\x5C\x64\x5C\x63\x5C\x56\x5C\x64\x5C\x6A\x5C\x31\x6D\x5C\x64\x5C\x6A\x5C\x31\x38\x5C\x64\x5C\x63\x5C\x54\x5C\x64\x5C\x6A\x5C\x31\x38\x5C\x64\x5C\x63\x5C\x54\x5C\x64\x5C\x6A\x5C\x31\x38\x5C\x64\x5C\x63\x5C\x54\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x31\x6B\x5C\x64\x5C\x63\x5C\x55\x5C\x64\x5C\x6D\x5C\x6E\x5C\x64\x5C\x63\x5C\x59\x5C\x64\x5C\x63\x5C\x55\x5C\x64\x5C\x63\x5C\x31\x36\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x6A\x5C\x69\x5C\x64\x5C\x50\x5C\x64\x5C\x6A\x5C\x46\x5C\x64\x5C\x63\x5C\x31\x69\x5C\x64\x5C\x63\x5C\x31\x62\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x44\x5C\x64\x5C\x63\x5C\x31\x63\x5C\x64\x5C\x63\x5C\x55\x5C\x64\x5C\x63\x5C\x59\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x5A\x5C\x64\x5C\x63\x5C\x46\x5C\x64\x5C\x6A\x5C\x48\x5C\x64\x5C\x6D\x5C\x6C\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x31\x6A\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x54\x5C\x64\x5C\x73\x5C\x64\x5C\x63\x5C\x31\x63\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x5A\x5C\x64\x5C\x6A\x5C\x44\x5C\x64\x5C\x63\x5C\x31\x36\x5C\x64\x5C\x63\x5C\x5A\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x6A\x5C\x49\x5C\x64\x5C\x6A\x5C\x49\x5C\x64\x5C\x6A\x5C\x46\x5C\x64\x5C\x63\x5C\x31\x67\x5C\x64\x5C\x6A\x5C\x4D\x5C\x64\x5C\x63\x5C\x52\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x70\x5C\x31\x38\x5C\x64\x5C\x70\x5C\x4F\x5C\x64\x5C\x63\x5C\x31\x65\x5C\x64\x5C\x6A\x5C\x69\x5C\x64\x5C\x63\x5C\x31\x32\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x47\x5C\x64\x5C\x6A\x5C\x31\x6F\x5C\x64\x5C\x6A\x5C\x47\x5C\x64\x5C\x63\x5C\x31\x39\x5C\x64\x5C\x31\x35\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x54\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x6E\x5C\x64\x5C\x31\x65\x5C\x64\x5C\x50\x5C\x64\x5C\x73\x5C\x64\x5C\x31\x63\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6E\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x63\x5C\x53\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x63\x5C\x31\x39\x5C\x64\x5C\x63\x5C\x31\x69\x5C\x64\x5C\x63\x5C\x57\x5C\x64\x5C\x50\x5C\x64\x5C\x63\x5C\x31\x35\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x63\x5C\x44\x5C\x64\x5C\x50\x5C\x64\x5C\x6E\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x31\x37\x5C\x64\x5C\x48\x5C\x64\x5C\x63\x5C\x31\x39\x5C\x64\x5C\x54\x5C\x64\x5C\x4C\x5C\x64\x5C\x31\x6A\x5C\x64\x5C\x73\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x6A\x5C\x44\x5C\x64\x5C\x63\x5C\x42\x5C\x64\x5C\x63\x5C\x31\x63\x5C\x64\x5C\x63\x5C\x5A\x5C\x64\x5C\x63\x5C\x59\x5C\x64\x5C\x63\x5C\x55\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x4C\x5C\x64\x5C\x54\x5C\x64\x5C\x63\x5C\x57\x5C\x64\x5C\x6A\x5C\x48\x5C\x64\x5C\x48\x5C\x6F\x5C\x65\x5C\x6F\x5C\x64\x5C\x73\x5C\x64\x5C\x6A\x5C\x31\x6E\x5C\x64\x5C\x63\x5C\x31\x34\x5C\x64\x5C\x31\x62\x5C\x64\x5C\x31\x64\x5C\x64\x5C\x63\x5C\x44\x5C\x64\x5C\x50\x5C\x64\x5C\x6E\x5C\x64\x5C\x63\x5C\x54\x5C\x6F\x5C\x68\x5C\x4E\x5C\x77\x5C\x7A\x5C\x56\x5C\x76\x5C\x63\x5C\x4C\x5C\x4E\x5C\x61\x5C\x47\x5C\x61\x5C\x6D\x5C\x79\x5C\x65\x5C\x6D\x5C\x46\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x63\x5C\x31\x38\x5C\x76\x5C\x63\x5C\x4C\x5C\x65\x5C\x63\x5C\x31\x64\x5C\x76\x5C\x6D\x5C\x79\x5C\x61\x5C\x62\x5C\x4E\x5C\x70\x5C\x4D\x5C\x61\x5C\x31\x71\x5C\x31\x71\x5C\x67\x5C\x68\x5C\x62\x5C\x4A\x5C\x6A\x5C\x31\x31\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x42\x5C\x76\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x48\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x44\x5C\x31\x45\x5C\x61\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x49\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x47\x5C\x62\x5C\x41\x5C\x7A\x5C\x31\x77\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x52\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x54\x5C\x41\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x4C\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x50\x5C\x41\x5C\x7A\x5C\x31\x77\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x45\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x53\x5C\x31\x45\x5C\x61\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x55\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x56\x5C\x62\x5C\x41\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x69\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x31\x31\x5C\x41\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x31\x32\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x59\x5C\x41\x5C\x7A\x5C\x31\x77\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x57\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x5A\x5C\x31\x45\x5C\x61\x5C\x31\x77\x5C\x63\x5C\x49\x5C\x61\x5C\x63\x5C\x31\x38\x5C\x61\x5C\x70\x5C\x58\x5C\x62\x5C\x62\x5C\x31\x74\x5C\x70\x5C\x31\x33\x5C\x62\x5C\x4E\x5C\x63\x5C\x4F\x5C\x61\x5C\x6D\x5C\x42\x5C\x76\x5C\x76\x5C\x76\x5C\x6D\x5C\x46\x5C\x62\x5C\x4A\x5C\x70\x5C\x31\x30\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x63\x5C\x31\x64\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x31\x64\x5C\x67\x5C\x6C\x5C\x67\x5C\x6B\x5C\x68\x5C\x68\x5C\x61\x5C\x62\x5C\x62\x5C\x4B\x5C\x4B\x5C\x6A\x5C\x31\x32\x5C\x61\x5C\x70\x5C\x31\x35\x5C\x62\x5C\x4A\x5C\x63\x5C\x31\x64\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x31\x64\x5C\x67\x5C\x6C\x5C\x67\x5C\x6B\x5C\x68\x5C\x68\x5C\x61\x5C\x62\x5C\x62\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x61\x5C\x63\x5C\x31\x6A\x5C\x65\x5C\x70\x5C\x31\x36\x5C\x62\x5C\x62\x5C\x4E\x5C\x77\x5C\x7A\x5C\x6D\x5C\x31\x38\x5C\x76\x5C\x61\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6A\x5C\x59\x5C\x76\x5C\x31\x71\x5C\x31\x71\x5C\x67\x5C\x68\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x47\x5C\x61\x5C\x6D\x5C\x4F\x5C\x65\x5C\x6A\x5C\x52\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x55\x5C\x76\x5C\x63\x5C\x4C\x5C\x4E\x5C\x63\x5C\x4F\x5C\x61\x5C\x55\x5C\x61\x5C\x70\x5C\x31\x34\x5C\x62\x5C\x76\x5C\x76\x5C\x76\x5C\x6C\x5C\x67\x5C\x6A\x5C\x68\x5C\x62\x5C\x4A\x5C\x70\x5C\x31\x39\x5C\x67\x5C\x55\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x55\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x55\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x62\x5C\x65\x5C\x70\x5C\x31\x37\x5C\x67\x5C\x55\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x55\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x55\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x55\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x55\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x55\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x62\x5C\x65\x5C\x70\x5C\x31\x61\x5C\x67\x5C\x55\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x55\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x55\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x55\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x55\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x55\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x55\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x55\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x55\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x68\x5C\x65\x5C\x55\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x55\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x55\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x55\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x4D\x5C\x76\x5C\x6A\x5C\x59\x5C\x31\x78\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x46\x5C\x76\x5C\x55\x5C\x4E\x5C\x63\x5C\x4F\x5C\x61\x5C\x46\x5C\x61\x5C\x6D\x5C\x48\x5C\x62\x5C\x31\x71\x5C\x76\x5C\x76\x5C\x46\x5C\x61\x5C\x6D\x5C\x48\x5C\x62\x5C\x62\x5C\x4A\x5C\x70\x5C\x31\x62\x5C\x67\x5C\x46\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x46\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x62\x5C\x65\x5C\x70\x5C\x31\x65\x5C\x67\x5C\x46\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x46\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x46\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x46\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x46\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x62\x5C\x65\x5C\x70\x5C\x31\x66\x5C\x67\x5C\x46\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x46\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x46\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x46\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x46\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x46\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x63\x5C\x4F\x5C\x61\x5C\x6A\x5C\x52\x5C\x62\x5C\x4A\x5C\x63\x5C\x4F\x5C\x61\x5C\x46\x5C\x61\x5C\x6D\x5C\x44\x5C\x62\x5C\x76\x5C\x76\x5C\x76\x5C\x46\x5C\x61\x5C\x6D\x5C\x44\x5C\x62\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x49\x5C\x76\x5C\x6A\x5C\x52\x5C\x67\x5C\x46\x5C\x61\x5C\x6A\x5C\x57\x5C\x62\x5C\x68\x5C\x61\x5C\x6D\x5C\x4F\x5C\x65\x5C\x6A\x5C\x5A\x5C\x62\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x6A\x5C\x52\x5C\x76\x5C\x6A\x5C\x58\x5C\x65\x5C\x6D\x5C\x49\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x70\x5C\x31\x67\x5C\x67\x5C\x46\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x70\x5C\x31\x68\x5C\x67\x5C\x46\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x46\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x46\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x46\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x46\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x46\x5C\x61\x5C\x63\x5C\x31\x6B\x5C\x62\x5C\x62\x5C\x65\x5C\x70\x5C\x31\x69\x5C\x67\x5C\x46\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x46\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x46\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x46\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x46\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x46\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x68\x5C\x65\x5C\x46\x5C\x61\x5C\x63\x5C\x31\x6C\x5C\x62\x5C\x62\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x31\x79\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x4B\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x6A\x5C\x59\x5C\x76\x5C\x31\x71\x5C\x67\x5C\x68\x5C\x65\x5C\x6D\x5C\x4D\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x61\x5C\x62\x5C\x62\x5C\x65\x5C\x6A\x5C\x54\x5C\x76\x5C\x6D\x5C\x31\x38\x5C\x61\x5C\x6D\x5C\x47\x5C\x65\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x63\x5C\x58\x5C\x76\x5C\x63\x5C\x4C\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x6A\x5C\x54\x5C\x67\x5C\x63\x5C\x58\x5C\x61\x5C\x63\x5C\x31\x37\x5C\x62\x5C\x68\x5C\x61\x5C\x62\x5C\x67\x5C\x6C\x5C\x67\x5C\x51\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x58\x5C\x61\x5C\x6D\x5C\x52\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x43\x5C\x68\x5C\x62\x5C\x67\x5C\x63\x5C\x58\x5C\x61\x5C\x63\x5C\x31\x37\x5C\x62\x5C\x68\x5C\x61\x5C\x62\x5C\x67\x5C\x63\x5C\x58\x5C\x61\x5C\x6A\x5C\x31\x33\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x75\x5C\x68\x5C\x68\x5C\x61\x5C\x6A\x5C\x54\x5C\x62\x5C\x67\x5C\x63\x5C\x58\x5C\x61\x5C\x70\x5C\x31\x63\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x58\x5C\x61\x5C\x6D\x5C\x52\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x43\x5C\x68\x5C\x62\x5C\x4B\x5C\x62\x5C\x4E\x5C\x6A\x5C\x54\x5C\x61\x5C\x62\x5C\x4E\x5C\x77\x5C\x7A\x5C\x63\x5C\x31\x33\x5C\x76\x5C\x61\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6A\x5C\x31\x30\x5C\x76\x5C\x31\x71\x5C\x31\x71\x5C\x67\x5C\x68\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x47\x5C\x61\x5C\x6D\x5C\x54\x5C\x65\x5C\x6A\x5C\x4C\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x63\x5C\x31\x6D\x5C\x76\x5C\x63\x5C\x4C\x5C\x4E\x5C\x63\x5C\x4F\x5C\x61\x5C\x63\x5C\x31\x6D\x5C\x61\x5C\x70\x5C\x31\x64\x5C\x62\x5C\x76\x5C\x76\x5C\x76\x5C\x63\x5C\x31\x6D\x5C\x61\x5C\x70\x5C\x31\x6A\x5C\x62\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x4C\x5C\x76\x5C\x70\x5C\x31\x6B\x5C\x67\x5C\x63\x5C\x31\x6D\x5C\x61\x5C\x6A\x5C\x57\x5C\x62\x5C\x68\x5C\x61\x5C\x70\x5C\x31\x6C\x5C\x65\x5C\x6A\x5C\x5A\x5C\x62\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x70\x5C\x31\x6D\x5C\x76\x5C\x6A\x5C\x58\x5C\x65\x5C\x6D\x5C\x4C\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x50\x5C\x76\x5C\x6A\x5C\x31\x30\x5C\x31\x78\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x45\x5C\x76\x5C\x63\x5C\x31\x6D\x5C\x4E\x5C\x63\x5C\x4F\x5C\x61\x5C\x45\x5C\x61\x5C\x6D\x5C\x45\x5C\x62\x5C\x31\x71\x5C\x76\x5C\x76\x5C\x45\x5C\x61\x5C\x6D\x5C\x45\x5C\x62\x5C\x62\x5C\x4A\x5C\x70\x5C\x31\x6E\x5C\x67\x5C\x45\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x63\x5C\x4F\x5C\x61\x5C\x6A\x5C\x4C\x5C\x62\x5C\x4A\x5C\x63\x5C\x4F\x5C\x61\x5C\x45\x5C\x61\x5C\x6D\x5C\x53\x5C\x62\x5C\x31\x71\x5C\x76\x5C\x76\x5C\x45\x5C\x61\x5C\x6D\x5C\x53\x5C\x62\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x63\x5C\x31\x6E\x5C\x4E\x5C\x6A\x5C\x31\x31\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x55\x5C\x76\x5C\x70\x5C\x31\x6F\x5C\x61\x5C\x45\x5C\x61\x5C\x6A\x5C\x31\x35\x5C\x62\x5C\x41\x5C\x45\x5C\x61\x5C\x6D\x5C\x56\x5C\x62\x5C\x41\x5C\x61\x5C\x45\x5C\x61\x5C\x6D\x5C\x69\x5C\x62\x5C\x41\x5C\x45\x5C\x61\x5C\x6D\x5C\x31\x31\x5C\x62\x5C\x41\x5C\x45\x5C\x61\x5C\x6D\x5C\x31\x32\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x6B\x5C\x68\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x63\x5C\x68\x5C\x62\x5C\x4E\x5C\x63\x5C\x31\x6E\x5C\x76\x5C\x6D\x5C\x55\x5C\x61\x5C\x62\x5C\x4B\x5C\x6A\x5C\x31\x32\x5C\x61\x5C\x71\x5C\x6C\x5C\x62\x5C\x4A\x5C\x63\x5C\x31\x6E\x5C\x76\x5C\x71\x5C\x72\x5C\x4B\x5C\x4E\x5C\x77\x5C\x7A\x5C\x6A\x5C\x31\x36\x5C\x76\x5C\x63\x5C\x31\x6E\x5C\x67\x5C\x45\x5C\x61\x5C\x6A\x5C\x31\x34\x5C\x62\x5C\x68\x5C\x76\x5C\x63\x5C\x31\x6E\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x6A\x5C\x68\x5C\x68\x5C\x66\x5C\x66\x5C\x4A\x5C\x4B\x5C\x65\x5C\x6A\x5C\x31\x39\x5C\x76\x5C\x67\x5C\x45\x5C\x61\x5C\x6D\x5C\x59\x5C\x62\x5C\x65\x5C\x45\x5C\x61\x5C\x71\x5C\x73\x5C\x62\x5C\x65\x5C\x45\x5C\x61\x5C\x6D\x5C\x57\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x6D\x5C\x68\x5C\x65\x5C\x45\x5C\x61\x5C\x6D\x5C\x5A\x5C\x62\x5C\x65\x5C\x45\x5C\x61\x5C\x6D\x5C\x58\x5C\x62\x5C\x65\x5C\x45\x5C\x61\x5C\x6D\x5C\x31\x33\x5C\x62\x5C\x68\x5C\x4E\x5C\x6A\x5C\x31\x37\x5C\x61\x5C\x77\x5C\x7A\x5C\x6A\x5C\x50\x5C\x76\x5C\x6A\x5C\x31\x61\x5C\x4E\x5C\x6A\x5C\x50\x5C\x31\x46\x5C\x6A\x5C\x31\x39\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x70\x5C\x68\x5C\x68\x5C\x4E\x5C\x6A\x5C\x50\x5C\x41\x5C\x41\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x63\x5C\x31\x6F\x5C\x76\x5C\x71\x5C\x77\x5C\x67\x5C\x45\x5C\x61\x5C\x6A\x5C\x31\x33\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x75\x5C\x68\x5C\x68\x5C\x67\x5C\x45\x5C\x61\x5C\x6D\x5C\x31\x30\x5C\x62\x5C\x68\x5C\x67\x5C\x45\x5C\x61\x5C\x6A\x5C\x45\x5C\x62\x5C\x68\x5C\x61\x5C\x71\x5C\x6E\x5C\x62\x5C\x65\x5C\x6A\x5C\x31\x62\x5C\x76\x5C\x6A\x5C\x31\x39\x5C\x67\x5C\x6A\x5C\x50\x5C\x68\x5C\x65\x5C\x6A\x5C\x31\x65\x5C\x76\x5C\x6A\x5C\x31\x36\x5C\x67\x5C\x6A\x5C\x31\x62\x5C\x68\x5C\x66\x5C\x66\x5C\x63\x5C\x31\x6F\x5C\x4E\x5C\x63\x5C\x31\x6F\x5C\x67\x5C\x45\x5C\x61\x5C\x71\x5C\x79\x5C\x62\x5C\x68\x5C\x76\x5C\x71\x5C\x46\x5C\x67\x5C\x45\x5C\x61\x5C\x6A\x5C\x45\x5C\x62\x5C\x68\x5C\x61\x5C\x71\x5C\x42\x5C\x62\x5C\x65\x5C\x63\x5C\x31\x6F\x5C\x67\x5C\x45\x5C\x61\x5C\x63\x5C\x31\x37\x5C\x62\x5C\x68\x5C\x76\x5C\x6A\x5C\x31\x65\x5C\x67\x5C\x45\x5C\x61\x5C\x63\x5C\x31\x37\x5C\x62\x5C\x68\x5C\x67\x5C\x45\x5C\x61\x5C\x6A\x5C\x45\x5C\x62\x5C\x68\x5C\x61\x5C\x6A\x5C\x31\x65\x5C\x62\x5C\x65\x5C\x6A\x5C\x31\x36\x5C\x67\x5C\x6A\x5C\x31\x62\x5C\x68\x5C\x76\x5C\x63\x5C\x31\x6F\x5C\x4B\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x31\x35\x5C\x76\x5C\x6A\x5C\x4C\x5C\x67\x5C\x45\x5C\x61\x5C\x6A\x5C\x57\x5C\x62\x5C\x68\x5C\x61\x5C\x6D\x5C\x54\x5C\x65\x5C\x6A\x5C\x5A\x5C\x62\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x6A\x5C\x4C\x5C\x76\x5C\x6A\x5C\x58\x5C\x65\x5C\x6D\x5C\x31\x35\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x31\x79\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x4B\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x6A\x5C\x31\x30\x5C\x76\x5C\x31\x71\x5C\x67\x5C\x68\x5C\x65\x5C\x6D\x5C\x50\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x61\x5C\x62\x5C\x62\x5C\x65\x5C\x63\x5C\x31\x61\x5C\x76\x5C\x63\x5C\x31\x33\x5C\x61\x5C\x6D\x5C\x47\x5C\x65\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x72\x5C\x76\x5C\x63\x5C\x4C\x5C\x65\x5C\x6A\x5C\x6C\x5C\x4E\x5C\x6A\x5C\x31\x31\x5C\x4A\x5C\x63\x5C\x4F\x5C\x61\x5C\x72\x5C\x61\x5C\x71\x5C\x31\x38\x5C\x62\x5C\x31\x71\x5C\x76\x5C\x76\x5C\x72\x5C\x61\x5C\x71\x5C\x4F\x5C\x62\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x31\x36\x5C\x76\x5C\x71\x5C\x4D\x5C\x61\x5C\x72\x5C\x61\x5C\x6A\x5C\x31\x35\x5C\x62\x5C\x41\x5C\x72\x5C\x61\x5C\x6D\x5C\x56\x5C\x62\x5C\x41\x5C\x61\x5C\x72\x5C\x61\x5C\x6D\x5C\x69\x5C\x62\x5C\x41\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x31\x5C\x62\x5C\x41\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x32\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x6B\x5C\x68\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x63\x5C\x68\x5C\x62\x5C\x4E\x5C\x6A\x5C\x6C\x5C\x76\x5C\x6D\x5C\x31\x36\x5C\x61\x5C\x62\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x71\x5C\x48\x5C\x67\x5C\x72\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x71\x5C\x44\x5C\x67\x5C\x72\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x62\x5C\x65\x5C\x71\x5C\x49\x5C\x67\x5C\x72\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x72\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x72\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x71\x5C\x68\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x62\x5C\x65\x5C\x71\x5C\x47\x5C\x67\x5C\x72\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x74\x5C\x68\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x72\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x72\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x4B\x5C\x6A\x5C\x31\x32\x5C\x61\x5C\x71\x5C\x52\x5C\x62\x5C\x4A\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x34\x5C\x62\x5C\x31\x71\x5C\x76\x5C\x76\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x34\x5C\x62\x5C\x31\x78\x5C\x71\x5C\x54\x5C\x76\x5C\x71\x5C\x4C\x5C\x31\x79\x5C\x6A\x5C\x6C\x5C\x76\x5C\x6A\x5C\x72\x5C\x4B\x5C\x4E\x5C\x77\x5C\x7A\x5C\x6A\x5C\x31\x66\x5C\x76\x5C\x6A\x5C\x6C\x5C\x67\x5C\x72\x5C\x61\x5C\x6A\x5C\x31\x34\x5C\x62\x5C\x68\x5C\x76\x5C\x6A\x5C\x6C\x5C\x67\x5C\x72\x5C\x61\x5C\x6A\x5C\x31\x34\x5C\x62\x5C\x68\x5C\x66\x5C\x66\x5C\x4A\x5C\x4B\x5C\x65\x5C\x6A\x5C\x31\x67\x5C\x76\x5C\x67\x5C\x72\x5C\x61\x5C\x6D\x5C\x59\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x43\x5C\x68\x5C\x65\x5C\x72\x5C\x61\x5C\x6D\x5C\x57\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x71\x5C\x50\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x6D\x5C\x5A\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x6D\x5C\x58\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x33\x5C\x62\x5C\x68\x5C\x4E\x5C\x6A\x5C\x31\x37\x5C\x61\x5C\x77\x5C\x7A\x5C\x6A\x5C\x53\x5C\x76\x5C\x6A\x5C\x31\x61\x5C\x4E\x5C\x6A\x5C\x53\x5C\x31\x46\x5C\x6A\x5C\x31\x67\x5C\x67\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x39\x5C\x62\x5C\x68\x5C\x4E\x5C\x6A\x5C\x53\x5C\x41\x5C\x41\x5C\x62\x5C\x4A\x5C\x63\x5C\x4F\x5C\x61\x5C\x72\x5C\x61\x5C\x71\x5C\x45\x5C\x62\x5C\x31\x71\x5C\x76\x5C\x76\x5C\x72\x5C\x61\x5C\x71\x5C\x53\x5C\x62\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6A\x5C\x73\x5C\x76\x5C\x63\x5C\x31\x33\x5C\x67\x5C\x72\x5C\x61\x5C\x6A\x5C\x31\x33\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x75\x5C\x68\x5C\x68\x5C\x67\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x30\x5C\x62\x5C\x68\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x75\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x31\x33\x5C\x62\x5C\x65\x5C\x6A\x5C\x31\x68\x5C\x76\x5C\x6A\x5C\x31\x67\x5C\x67\x5C\x6A\x5C\x53\x5C\x68\x5C\x65\x5C\x6A\x5C\x31\x69\x5C\x76\x5C\x6A\x5C\x31\x66\x5C\x67\x5C\x6A\x5C\x31\x68\x5C\x68\x5C\x66\x5C\x66\x5C\x6A\x5C\x73\x5C\x4E\x5C\x6A\x5C\x73\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x51\x5C\x68\x5C\x68\x5C\x76\x5C\x63\x5C\x31\x33\x5C\x67\x5C\x6C\x5C\x67\x5C\x63\x5C\x75\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x31\x33\x5C\x62\x5C\x65\x5C\x6A\x5C\x73\x5C\x67\x5C\x72\x5C\x61\x5C\x63\x5C\x31\x37\x5C\x62\x5C\x68\x5C\x76\x5C\x6A\x5C\x31\x69\x5C\x67\x5C\x72\x5C\x61\x5C\x63\x5C\x31\x37\x5C\x62\x5C\x68\x5C\x67\x5C\x72\x5C\x61\x5C\x6A\x5C\x45\x5C\x62\x5C\x68\x5C\x61\x5C\x6A\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x6A\x5C\x31\x66\x5C\x67\x5C\x6A\x5C\x31\x68\x5C\x68\x5C\x76\x5C\x6A\x5C\x73\x5C\x4B\x5C\x63\x5C\x50\x5C\x4A\x5C\x71\x5C\x55\x5C\x67\x5C\x72\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x71\x5C\x56\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6B\x5C\x68\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x6D\x5C\x31\x37\x5C\x62\x5C\x62\x5C\x65\x5C\x71\x5C\x69\x5C\x67\x5C\x72\x5C\x61\x5C\x6A\x5C\x31\x63\x5C\x62\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x62\x5C\x65\x5C\x71\x5C\x31\x31\x5C\x67\x5C\x72\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x72\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6D\x5C\x68\x5C\x68\x5C\x67\x5C\x72\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x63\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x6A\x5C\x77\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x63\x5C\x68\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6A\x5C\x68\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x72\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x71\x5C\x31\x32\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x41\x5C\x72\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x72\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x72\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x72\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x71\x5C\x68\x5C\x62\x5C\x4B\x5C\x4B\x5C\x4B\x5C\x62\x5C\x4E\x5C\x63\x5C\x31\x61\x5C\x61\x5C\x62\x5C\x4E\x5C\x6A\x5C\x31\x37\x5C\x61\x5C\x77\x5C\x7A\x5C\x71\x5C\x59\x5C\x65\x5C\x6A\x5C\x31\x64\x5C\x76\x5C\x44\x5C\x67\x5C\x56\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x56\x5C\x61\x5C\x71\x5C\x57\x5C\x62\x5C\x68\x5C\x61\x5C\x71\x5C\x5A\x5C\x62\x5C\x65\x5C\x31\x38\x5C\x76\x5C\x6A\x5C\x31\x61\x5C\x4E\x5C\x31\x38\x5C\x31\x46\x5C\x6A\x5C\x31\x64\x5C\x67\x5C\x56\x5C\x61\x5C\x6D\x5C\x31\x39\x5C\x62\x5C\x68\x5C\x4E\x5C\x31\x38\x5C\x41\x5C\x41\x5C\x62\x5C\x4A\x5C\x6A\x5C\x31\x64\x5C\x67\x5C\x31\x38\x5C\x68\x5C\x67\x5C\x56\x5C\x61\x5C\x71\x5C\x58\x5C\x62\x5C\x41\x5C\x56\x5C\x61\x5C\x71\x5C\x31\x33\x5C\x62\x5C\x68\x5C\x61\x5C\x56\x5C\x61\x5C\x71\x5C\x31\x30\x5C\x62\x5C\x65\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x31\x61\x5C\x76\x5C\x56\x5C\x4E\x5C\x63\x5C\x31\x30\x5C\x67\x5C\x6D\x5C\x31\x61\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x4B\x5C\x62\x5C\x4B\x5C\x4E\x5C\x47\x5C\x7A\x5C\x71\x5C\x31\x35\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x63\x5C\x73\x5C\x76\x5C\x56\x5C\x4E\x5C\x63\x5C\x31\x30\x5C\x67\x5C\x63\x5C\x73\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x63\x5C\x73\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x63\x5C\x73\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x73\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x63\x5C\x73\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x63\x5C\x73\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x73\x5C\x61\x5C\x63\x5C\x31\x6B\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x63\x5C\x73\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x63\x5C\x73\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x73\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x63\x5C\x73\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x71\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x73\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x68\x5C\x65\x5C\x63\x5C\x73\x5C\x61\x5C\x6A\x5C\x77\x5C\x62\x5C\x65\x5C\x63\x5C\x73\x5C\x61\x5C\x63\x5C\x31\x6C\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x63\x5C\x31\x6A\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x31\x62\x5C\x76\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x43\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x75\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x51\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x6B\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x63\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6A\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x6A\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x63\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x70\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x70\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x71\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x43\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x75\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x51\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x6B\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x63\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x6A\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x70\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x71\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x43\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x75\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x51\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x6B\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x63\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x6A\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x51\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x70\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x71\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x43\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x75\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x43\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x75\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x51\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x6A\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x71\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x6B\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x63\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x6A\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x63\x5C\x71\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x70\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x71\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6B\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x43\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x75\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x51\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x36\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x34\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x39\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x37\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x61\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x62\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x65\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x66\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x67\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x68\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x31\x65\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x69\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x51\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x63\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x64\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x6A\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x6B\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x6C\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6D\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x6E\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x31\x6F\x5C\x68\x5C\x68\x5C\x4E\x5C\x63\x5C\x31\x6A\x5C\x76\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x63\x5C\x79\x5C\x7A\x5C\x6D\x5C\x31\x62\x5C\x4B\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x63\x5C\x31\x6A\x5C\x61\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x6C\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x53\x5C\x76\x5C\x56\x5C\x4E\x5C\x63\x5C\x31\x30\x5C\x67\x5C\x53\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x31\x36\x5C\x67\x5C\x53\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x53\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x6A\x5C\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x31\x36\x5C\x67\x5C\x53\x5C\x61\x5C\x6A\x5C\x31\x63\x5C\x62\x5C\x68\x5C\x61\x5C\x53\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x53\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x74\x5C\x68\x5C\x68\x5C\x61\x5C\x53\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x53\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x53\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x53\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x53\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x53\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x53\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x53\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x53\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x71\x5C\x68\x5C\x65\x5C\x53\x5C\x61\x5C\x63\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x6A\x5C\x77\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x51\x5C\x68\x5C\x65\x5C\x53\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x53\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x72\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x52\x5C\x76\x5C\x56\x5C\x4E\x5C\x63\x5C\x31\x30\x5C\x67\x5C\x52\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x31\x36\x5C\x67\x5C\x52\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x52\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x6D\x5C\x68\x5C\x62\x5C\x65\x5C\x31\x36\x5C\x67\x5C\x52\x5C\x61\x5C\x6A\x5C\x31\x63\x5C\x62\x5C\x68\x5C\x61\x5C\x52\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x52\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x52\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x52\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x52\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x52\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x52\x5C\x61\x5C\x63\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x6A\x5C\x77\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x63\x5C\x31\x6C\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x52\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x52\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x52\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x52\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x52\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x52\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x71\x5C\x68\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x73\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x42\x5C\x76\x5C\x56\x5C\x4E\x5C\x63\x5C\x31\x30\x5C\x67\x5C\x42\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x6A\x5C\x72\x5C\x67\x5C\x42\x5C\x61\x5C\x6A\x5C\x55\x5C\x62\x5C\x68\x5C\x31\x76\x5C\x31\x76\x5C\x6A\x5C\x72\x5C\x67\x5C\x42\x5C\x61\x5C\x6A\x5C\x55\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x6D\x5C\x31\x66\x5C\x62\x5C\x41\x5C\x42\x5C\x61\x5C\x6D\x5C\x31\x67\x5C\x62\x5C\x41\x5C\x42\x5C\x61\x5C\x74\x5C\x77\x5C\x62\x5C\x62\x5C\x67\x5C\x42\x5C\x61\x5C\x6D\x5C\x31\x68\x5C\x62\x5C\x68\x5C\x31\x76\x5C\x31\x76\x5C\x61\x5C\x31\x36\x5C\x67\x5C\x42\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x65\x5C\x42\x5C\x61\x5C\x6A\x5C\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x42\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x42\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x42\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x42\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x62\x5C\x62\x5C\x65\x5C\x6A\x5C\x72\x5C\x67\x5C\x42\x5C\x61\x5C\x6A\x5C\x55\x5C\x62\x5C\x68\x5C\x31\x76\x5C\x31\x76\x5C\x6A\x5C\x72\x5C\x67\x5C\x42\x5C\x61\x5C\x6A\x5C\x55\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x6D\x5C\x31\x66\x5C\x62\x5C\x41\x5C\x42\x5C\x61\x5C\x6D\x5C\x31\x67\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x74\x5C\x6E\x5C\x68\x5C\x62\x5C\x67\x5C\x42\x5C\x61\x5C\x6D\x5C\x31\x68\x5C\x62\x5C\x68\x5C\x31\x76\x5C\x31\x76\x5C\x61\x5C\x31\x36\x5C\x67\x5C\x42\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x65\x5C\x42\x5C\x61\x5C\x6D\x5C\x31\x37\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x42\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x42\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x42\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x42\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x42\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x42\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x42\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x42\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x42\x5C\x61\x5C\x6A\x5C\x77\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x42\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x42\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x42\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x71\x5C\x68\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x71\x5C\x68\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x79\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x59\x5C\x76\x5C\x56\x5C\x4E\x5C\x63\x5C\x31\x30\x5C\x67\x5C\x6C\x5C\x67\x5C\x74\x5C\x6B\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x31\x36\x5C\x67\x5C\x59\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x59\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x65\x5C\x59\x5C\x61\x5C\x6A\x5C\x6E\x5C\x62\x5C\x76\x5C\x76\x5C\x76\x5C\x31\x36\x5C\x67\x5C\x59\x5C\x61\x5C\x6D\x5C\x31\x69\x5C\x62\x5C\x68\x5C\x61\x5C\x59\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x62\x5C\x31\x78\x5C\x59\x5C\x61\x5C\x74\x5C\x46\x5C\x62\x5C\x31\x79\x5C\x59\x5C\x61\x5C\x6A\x5C\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x59\x5C\x61\x5C\x6A\x5C\x6E\x5C\x62\x5C\x76\x5C\x76\x5C\x76\x5C\x31\x36\x5C\x67\x5C\x59\x5C\x61\x5C\x6D\x5C\x31\x69\x5C\x62\x5C\x68\x5C\x61\x5C\x59\x5C\x61\x5C\x63\x5C\x69\x5C\x62\x5C\x62\x5C\x31\x78\x5C\x44\x5C\x67\x5C\x59\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x74\x5C\x68\x5C\x68\x5C\x61\x5C\x59\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x59\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x59\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x59\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x62\x5C\x31\x79\x5C\x44\x5C\x67\x5C\x59\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x59\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x59\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x59\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x59\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x59\x5C\x61\x5C\x63\x5C\x45\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x42\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x58\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x58\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x58\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x63\x5C\x31\x6C\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x41\x5C\x58\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x58\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x58\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x58\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x58\x5C\x61\x5C\x63\x5C\x31\x6C\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x58\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x58\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x58\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x71\x5C\x68\x5C\x68\x5C\x61\x5C\x58\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x58\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x31\x38\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x57\x5C\x76\x5C\x56\x5C\x4E\x5C\x63\x5C\x31\x30\x5C\x67\x5C\x57\x5C\x61\x5C\x63\x5C\x47\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x48\x5C\x62\x5C\x65\x5C\x31\x36\x5C\x67\x5C\x57\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x57\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x57\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x57\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x57\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x57\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x57\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x57\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x57\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x57\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x57\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x57\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x57\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x71\x5C\x68\x5C\x68\x5C\x61\x5C\x57\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x57\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x57\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x57\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x68\x5C\x65\x5C\x57\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x57\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x57\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x4F\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x31\x61\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6B\x5C\x68\x5C\x68\x5C\x61\x5C\x31\x61\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x31\x61\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x61\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x61\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x31\x61\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x61\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x61\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x61\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x61\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x61\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x61\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x61\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x61\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x31\x61\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x51\x5C\x68\x5C\x65\x5C\x31\x61\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x31\x61\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x31\x61\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x75\x5C\x68\x5C\x65\x5C\x31\x61\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x4D\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x69\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x69\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x69\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x69\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x69\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x69\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x69\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x69\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x69\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x41\x5C\x69\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x69\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x69\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x69\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x69\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x69\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x48\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x31\x33\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x31\x33\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x33\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x31\x33\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x33\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x33\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x33\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x33\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x33\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x33\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x33\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x33\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x33\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6D\x5C\x68\x5C\x68\x5C\x67\x5C\x31\x33\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x33\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x31\x33\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6A\x5C\x68\x5C\x65\x5C\x31\x33\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x31\x33\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x31\x33\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x31\x33\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x31\x65\x5C\x68\x5C\x65\x5C\x31\x33\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x44\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x31\x34\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x31\x34\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x34\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x31\x34\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x34\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x34\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x34\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x34\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x34\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x34\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x34\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x34\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x34\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x34\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x34\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x74\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x70\x5C\x43\x5C\x68\x5C\x65\x5C\x31\x34\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x31\x34\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x31\x34\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x71\x5C\x43\x5C\x68\x5C\x65\x5C\x6C\x5C\x67\x5C\x6D\x5C\x75\x5C\x68\x5C\x65\x5C\x31\x34\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x31\x34\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x49\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x31\x39\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x31\x39\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x39\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x39\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x74\x5C\x68\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x31\x39\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x39\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x39\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x39\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x39\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x31\x39\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x39\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x39\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6A\x5C\x68\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x31\x39\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x47\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x31\x31\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x31\x31\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x31\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x31\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x31\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x31\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x31\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x31\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x31\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x31\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x31\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x31\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x31\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x31\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x31\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x74\x5C\x6D\x5C\x68\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x31\x31\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x52\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x31\x32\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x31\x32\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x32\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x32\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x32\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x32\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6D\x5C\x68\x5C\x68\x5C\x67\x5C\x31\x32\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x32\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x31\x32\x5C\x61\x5C\x4D\x5C\x62\x5C\x41\x5C\x31\x32\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x32\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x32\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x32\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x32\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x65\x5C\x31\x32\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x54\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x31\x30\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x31\x30\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x30\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x41\x5C\x31\x30\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x31\x30\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x30\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x30\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x41\x5C\x31\x30\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x30\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x31\x30\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x31\x30\x5C\x61\x5C\x31\x6C\x5C\x62\x5C\x68\x5C\x61\x5C\x31\x30\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x63\x5C\x77\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x63\x5C\x4D\x5C\x62\x5C\x65\x5C\x31\x30\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x63\x5C\x4C\x5C\x61\x5C\x6D\x5C\x31\x63\x5C\x65\x5C\x6D\x5C\x31\x64\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x6D\x5C\x31\x6A\x5C\x76\x5C\x63\x5C\x31\x6A\x5C\x61\x5C\x62\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x63\x5C\x4C\x5C\x76\x5C\x47\x5C\x61\x5C\x63\x5C\x31\x61\x5C\x65\x5C\x63\x5C\x31\x33\x5C\x62\x5C\x4A\x5C\x63\x5C\x31\x61\x5C\x76\x5C\x63\x5C\x31\x61\x5C\x31\x77\x5C\x6A\x5C\x31\x35\x5C\x4E\x5C\x77\x5C\x7A\x5C\x6D\x5C\x31\x6B\x5C\x76\x5C\x6D\x5C\x31\x6A\x5C\x67\x5C\x63\x5C\x31\x61\x5C\x68\x5C\x4E\x5C\x63\x5C\x79\x5C\x7A\x5C\x6D\x5C\x31\x6B\x5C\x4B\x5C\x65\x5C\x63\x5C\x4C\x5C\x61\x5C\x6D\x5C\x31\x63\x5C\x65\x5C\x6D\x5C\x31\x64\x5C\x62\x5C\x4B\x5C\x47\x5C\x7A\x5C\x74\x5C\x4C\x5C\x61\x5C\x62\x5C\x4A\x5C\x77\x5C\x7A\x5C\x63\x5C\x72\x5C\x76\x5C\x56\x5C\x4E\x5C\x31\x36\x5C\x67\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x66\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x6B\x5C\x62\x5C\x65\x5C\x63\x5C\x72\x5C\x61\x5C\x63\x5C\x6E\x5C\x62\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x41\x5C\x63\x5C\x72\x5C\x61\x5C\x4F\x5C\x62\x5C\x68\x5C\x61\x5C\x63\x5C\x72\x5C\x61\x5C\x49\x5C\x62\x5C\x62\x5C\x67\x5C\x63\x5C\x72\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x63\x5C\x72\x5C\x61\x5C\x5A\x5C\x62\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x6D\x5C\x43\x5C\x68\x5C\x62\x5C\x65\x5C\x44\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x70\x5C\x68\x5C\x41\x5C\x6C\x5C\x67\x5C\x63\x5C\x74\x5C\x68\x5C\x68\x5C\x61\x5C\x6C\x5C\x67\x5C\x70\x5C\x68\x5C\x62\x5C\x67\x5C\x63\x5C\x72\x5C\x61\x5C\x79\x5C\x62\x5C\x68\x5C\x67\x5C\x6C\x5C\x67\x5C\x6A\x5C\x71\x5C\x68\x5C\x68\x5C\x61\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x68\x5C\x62\x5C\x65\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x6D\x5C\x62\x5C\x65\x5C\x6C\x5C\x67\x5C\x6A\x5C\x6A\x5C\x68\x5C\x65\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x6F\x5C\x62\x5C\x65\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x67\x5C\x62\x5C\x65\x5C\x63\x5C\x72\x5C\x61\x5C\x63\x5C\x6C\x5C\x62\x5C\x65\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x69\x5C\x62\x5C\x65\x5C\x63\x5C\x72\x5C\x61\x5C\x31\x6E\x5C\x62\x5C\x62\x5C\x4B\x22\x2C\x22\x5C\x66\x22\x2C\x22\x5C\x50\x5C\x52\x5C\x48\x5C\x31\x38\x5C\x45\x22\x2C\x22\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x72\x5C\x63\x5C\x6D\x5C\x51\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x6D\x5C\x66\x5C\x69\x5C\x74\x5C\x71\x5C\x66\x5C\x55\x5C\x6C\x5C\x4C\x5C\x66\x5C\x69\x5C\x43\x5C\x70\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x6B\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6E\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x51\x5C\x66\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x6B\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x70\x5C\x66\x5C\x69\x5C\x43\x5C\x6A\x5C\x66\x5C\x77\x5C\x47\x5C\x73\x5C\x53\x5C\x44\x5C\x6E\x5C\x49\x5C\x45\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x72\x5C\x66\x5C\x79\x5C\x53\x5C\x49\x5C\x73\x5C\x45\x5C\x31\x38\x5C\x47\x5C\x49\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x43\x5C\x66\x5C\x69\x5C\x74\x5C\x58\x5C\x66\x5C\x69\x5C\x74\x5C\x31\x30\x5C\x66\x5C\x69\x5C\x74\x5C\x75\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x51\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x73\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x79\x5C\x74\x5C\x51\x5C\x6E\x5C\x77\x5C\x70\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x6D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x72\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x77\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x72\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x79\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x77\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x79\x5C\x66\x5C\x69\x5C\x74\x5C\x31\x33\x5C\x66\x5C\x48\x5C\x47\x5C\x73\x5C\x6C\x5C\x48\x5C\x31\x63\x5C\x45\x5C\x47\x5C\x4C\x5C\x6C\x5C\x46\x5C\x6E\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x43\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x51\x5C\x66\x5C\x69\x5C\x74\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x63\x5C\x66\x5C\x69\x5C\x74\x5C\x5A\x5C\x66\x5C\x69\x5C\x74\x5C\x6D\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x6C\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x70\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x73\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x75\x5C\x66\x5C\x69\x5C\x43\x5C\x6D\x5C\x66\x5C\x69\x5C\x74\x5C\x51\x5C\x66\x5C\x69\x5C\x74\x5C\x70\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x51\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x6E\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x77\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x43\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6A\x5C\x72\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x6D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x71\x5C\x74\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x63\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x6C\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x6D\x5C\x66\x5C\x4C\x5C\x6E\x5C\x45\x5C\x53\x5C\x4C\x5C\x49\x5C\x66\x5C\x69\x5C\x43\x5C\x71\x5C\x66\x5C\x69\x5C\x6D\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x70\x5C\x66\x5C\x31\x38\x5C\x79\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x70\x5C\x66\x5C\x6B\x5C\x69\x5C\x6D\x5C\x6A\x5C\x66\x5C\x69\x5C\x74\x5C\x43\x5C\x66\x5C\x52\x5C\x6C\x5C\x4C\x5C\x50\x5C\x6E\x5C\x31\x34\x5C\x49\x5C\x45\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x79\x5C\x66\x5C\x69\x5C\x43\x5C\x6B\x5C\x66\x5C\x69\x5C\x6A\x5C\x51\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x6B\x5C\x74\x5C\x73\x5C\x66\x5C\x6E\x5C\x48\x5C\x50\x5C\x6E\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x63\x5C\x66\x5C\x69\x5C\x74\x5C\x6A\x5C\x66\x5C\x69\x5C\x6D\x5C\x6B\x5C\x66\x5C\x69\x5C\x6A\x5C\x75\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x51\x5C\x66\x5C\x69\x5C\x74\x5C\x74\x5C\x66\x5C\x69\x5C\x43\x5C\x74\x5C\x66\x5C\x69\x5C\x6D\x5C\x6A\x5C\x66\x5C\x69\x5C\x43\x5C\x75\x5C\x66\x5C\x69\x5C\x6D\x5C\x43\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x6B\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6A\x5C\x79\x5C\x75\x5C\x72\x5C\x6C\x5C\x74\x5C\x66\x5C\x49\x5C\x6C\x5C\x55\x5C\x31\x38\x5C\x46\x5C\x6C\x5C\x45\x5C\x47\x5C\x4C\x5C\x66\x5C\x69\x5C\x43\x5C\x43\x5C\x66\x5C\x69\x5C\x6D\x5C\x74\x5C\x66\x5C\x69\x5C\x6A\x5C\x6B\x5C\x66\x5C\x69\x5C\x74\x5C\x57\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6A\x5C\x6E\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x43\x5C\x74\x5C\x43\x5C\x6D\x5C\x6E\x5C\x51\x5C\x66\x5C\x69\x5C\x71\x5C\x6D\x5C\x66\x5C\x69\x5C\x43\x5C\x51\x5C\x66\x5C\x69\x5C\x70\x5C\x51\x5C\x66\x5C\x69\x5C\x71\x5C\x63\x5C\x66\x5C\x69\x5C\x6D\x5C\x71\x5C\x66\x5C\x69\x5C\x71\x5C\x6A\x5C\x66\x5C\x69\x5C\x6D\x5C\x51\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x75\x5C\x71\x5C\x71\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x6A\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x77\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x74\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x6C\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x79\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x70\x5C\x66\x5C\x56\x5C\x31\x38\x5C\x49\x5C\x77\x5C\x47\x5C\x56\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x51\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x74\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x63\x5C\x66\x5C\x69\x5C\x70\x5C\x5A\x5C\x66\x5C\x69\x5C\x70\x5C\x6D\x5C\x66\x5C\x69\x5C\x70\x5C\x70\x5C\x66\x5C\x69\x5C\x6A\x5C\x57\x5C\x66\x5C\x69\x5C\x71\x5C\x31\x30\x5C\x66\x5C\x69\x5C\x71\x5C\x70\x5C\x66\x5C\x69\x5C\x70\x5C\x75\x5C\x66\x5C\x69\x5C\x6D\x5C\x75\x5C\x66\x5C\x69\x5C\x70\x5C\x31\x30\x5C\x66\x5C\x69\x5C\x71\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x72\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x6E\x5C\x70\x5C\x6A\x5C\x6A\x5C\x6E\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x6E\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x72\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x75\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x74\x5C\x66\x5C\x69\x5C\x71\x5C\x74\x5C\x66\x5C\x69\x5C\x71\x5C\x6B\x5C\x66\x5C\x45\x5C\x4C\x5C\x31\x31\x5C\x66\x5C\x73\x5C\x6C\x5C\x45\x5C\x73\x5C\x42\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x51\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x43\x5C\x66\x5C\x6C\x5C\x4C\x5C\x46\x5C\x53\x5C\x44\x5C\x6E\x5C\x49\x5C\x45\x5C\x50\x5C\x66\x5C\x49\x5C\x53\x5C\x48\x5C\x48\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x6D\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6A\x5C\x51\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x73\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x77\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x77\x5C\x66\x5C\x79\x5C\x47\x5C\x4C\x5C\x66\x5C\x6B\x5C\x69\x5C\x6B\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x6B\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x74\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x43\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x6C\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x72\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x73\x5C\x66\x5C\x50\x5C\x42\x5C\x31\x37\x5C\x66\x5C\x69\x5C\x71\x5C\x43\x5C\x66\x5C\x69\x5C\x6D\x5C\x6D\x5C\x66\x5C\x69\x5C\x43\x5C\x63\x5C\x66\x5C\x69\x5C\x6A\x5C\x31\x33\x5C\x66\x5C\x69\x5C\x6D\x5C\x59\x5C\x66\x5C\x69\x5C\x70\x5C\x74\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x69\x5C\x70\x5C\x43\x5C\x66\x5C\x69\x5C\x6A\x5C\x6A\x5C\x66\x5C\x69\x5C\x70\x5C\x71\x5C\x66\x5C\x69\x5C\x6A\x5C\x58\x5C\x66\x5C\x69\x5C\x6D\x5C\x70\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x74\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x6A\x5C\x6B\x5C\x74\x5C\x70\x5C\x72\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6C\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x77\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x63\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x75\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x79\x5C\x66\x5C\x45\x5C\x42\x5C\x31\x38\x5C\x50\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x70\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x70\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x43\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x75\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x75\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x43\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x63\x5C\x72\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x72\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x6A\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6A\x5C\x6C\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x73\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6A\x5C\x73\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x6B\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x74\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x77\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6A\x5C\x79\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x6B\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x6A\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x71\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x6D\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x6B\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x70\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6A\x5C\x79\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x6D\x5C\x6D\x5C\x66\x5C\x75\x5C\x6B\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x43\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x6A\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x73\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x79\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x71\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x71\x5C\x6A\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x71\x5C\x6D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6E\x5C\x63\x5C\x75\x5C\x63\x5C\x69\x5C\x71\x5C\x70\x5C\x66\x5C\x69\x5C\x6A\x5C\x6D\x5C\x66\x5C\x69\x5C\x6A\x5C\x70\x5C\x66\x5C\x69\x5C\x6D\x5C\x57\x5C\x66\x5C\x69\x5C\x43\x5C\x57\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x69\x5C\x43\x5C\x58\x5C\x66\x5C\x69\x5C\x71\x5C\x75\x5C\x66\x5C\x69\x5C\x74\x5C\x59\x5C\x66\x5C\x69\x5C\x70\x5C\x63\x5C\x66\x5C\x69\x5C\x43\x5C\x59\x5C\x66\x5C\x69\x5C\x70\x5C\x6A\x5C\x66\x5C\x69\x5C\x70\x5C\x57\x5C\x66\x5C\x69\x5C\x70\x5C\x58\x5C\x66\x5C\x69\x5C\x71\x5C\x51\x5C\x66\x5C\x69\x5C\x70\x5C\x59\x5C\x66\x5C\x56\x5C\x42\x5C\x31\x38\x5C\x48\x5C\x6E\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x51\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x75\x5C\x66\x5C\x6B\x5C\x69\x5C\x6A\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x75\x5C\x66\x5C\x6B\x5C\x69\x5C\x6D\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x51\x5C\x66\x5C\x6B\x5C\x69\x5C\x70\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x71\x5C\x66\x5C\x6B\x5C\x69\x5C\x71\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x71\x5C\x66\x5C\x6B\x5C\x69\x5C\x74\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x43\x5C\x66\x5C\x6B\x5C\x69\x5C\x43\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x6A\x5C\x66\x5C\x6B\x5C\x69\x5C\x75\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x74\x5C\x66\x5C\x6B\x5C\x69\x5C\x51\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x6D\x5C\x66\x5C\x6B\x5C\x69\x5C\x6C\x5C\x66\x5C\x72\x5C\x4C\x5C\x6E\x5C\x6C\x5C\x4D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x75\x5C\x6B\x5C\x79\x5C\x77\x5C\x6E\x5C\x66\x5C\x6B\x5C\x69\x5C\x6A\x5C\x6B\x5C\x72\x5C\x79\x5C\x79\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x79\x5C\x79\x5C\x51\x5C\x71\x5C\x74\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x6E\x5C\x6A\x5C\x6D\x5C\x6B\x5C\x77\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x51\x5C\x79\x5C\x51\x5C\x73\x5C\x43\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6A\x5C\x79\x5C\x73\x5C\x6D\x5C\x74\x5C\x71\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x63\x5C\x6D\x5C\x70\x5C\x6C\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x74\x5C\x51\x5C\x51\x5C\x75\x5C\x75\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x70\x5C\x77\x5C\x6B\x5C\x73\x5C\x6C\x5C\x75\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x63\x5C\x63\x5C\x6E\x5C\x75\x5C\x70\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x51\x5C\x70\x5C\x63\x5C\x51\x5C\x74\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x51\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x79\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x6E\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x63\x5C\x72\x5C\x75\x5C\x77\x5C\x72\x5C\x6B\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x6E\x5C\x6D\x5C\x43\x5C\x6E\x5C\x6D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x6D\x5C\x79\x5C\x43\x5C\x77\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6A\x5C\x63\x5C\x63\x5C\x70\x5C\x6D\x5C\x70\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x70\x5C\x6D\x5C\x6A\x5C\x6B\x5C\x51\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6A\x5C\x51\x5C\x6D\x5C\x6B\x5C\x6A\x5C\x75\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6A\x5C\x77\x5C\x51\x5C\x6E\x5C\x51\x5C\x73\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x6C\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x6E\x5C\x6D\x5C\x70\x5C\x71\x5C\x73\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x6D\x5C\x6A\x5C\x70\x5C\x74\x5C\x72\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x74\x5C\x6D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x70\x5C\x6E\x5C\x73\x5C\x77\x5C\x74\x5C\x51\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x75\x5C\x73\x5C\x6B\x5C\x6C\x5C\x71\x5C\x6B\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x63\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x6E\x5C\x66\x5C\x31\x30\x5C\x53\x5C\x49\x5C\x73\x5C\x45\x5C\x31\x38\x5C\x47\x5C\x49\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x70\x5C\x6C\x5C\x74\x5C\x75\x5C\x70\x5C\x73\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x43\x5C\x79\x5C\x6D\x5C\x6B\x5C\x73\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x73\x5C\x77\x5C\x6E\x5C\x6A\x5C\x63\x5C\x72\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6A\x5C\x74\x5C\x51\x5C\x77\x5C\x77\x5C\x6D\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x6B\x5C\x71\x5C\x51\x5C\x72\x5C\x74\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x73\x5C\x72\x5C\x51\x5C\x79\x5C\x77\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x70\x5C\x6D\x5C\x6E\x5C\x6A\x5C\x43\x5C\x70\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x6A\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x6C\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x72\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x74\x5C\x6C\x5C\x63\x5C\x43\x5C\x79\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x6D\x5C\x43\x5C\x79\x5C\x73\x5C\x6A\x5C\x74\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x71\x5C\x75\x5C\x6D\x5C\x70\x5C\x6A\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x71\x5C\x70\x5C\x63\x5C\x43\x5C\x71\x5C\x63\x5C\x66\x5C\x78\x5C\x6B\x5C\x69\x5C\x77\x5C\x6E\x5C\x43\x5C\x71\x5C\x6E\x5C\x70\x5C\x66\x5C\x46\x5C\x31\x64\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x6C\x5C\x66\x5C\x48\x5C\x31\x38\x5C\x50\x5C\x45\x5C\x58\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x43\x5C\x63\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x70\x5C\x6E\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6A\x5C\x77\x5C\x66\x5C\x45\x5C\x42\x5C\x44\x5C\x31\x62\x5C\x47\x5C\x66\x5C\x43\x5C\x6B\x5C\x66\x5C\x43\x5C\x63\x5C\x66\x5C\x43\x5C\x6A\x5C\x66\x5C\x43\x5C\x6D\x5C\x66\x5C\x43\x5C\x70\x5C\x66\x5C\x43\x5C\x71\x5C\x66\x5C\x43\x5C\x74\x5C\x66\x5C\x43\x5C\x43\x5C\x66\x5C\x43\x5C\x75\x5C\x66\x5C\x43\x5C\x51\x5C\x66\x5C\x75\x5C\x63\x5C\x66\x5C\x75\x5C\x6A\x5C\x66\x5C\x75\x5C\x6D\x5C\x66\x5C\x75\x5C\x70\x5C\x66\x5C\x75\x5C\x71\x5C\x66\x5C\x75\x5C\x74\x5C\x66\x5C\x75\x5C\x43\x5C\x66\x5C\x75\x5C\x75\x5C\x66\x5C\x75\x5C\x51\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x66\x5C\x44\x5C\x47\x5C\x77\x5C\x6E\x5C\x58\x5C\x66\x5C\x44\x5C\x47\x5C\x77\x5C\x6E\x5C\x31\x61\x5C\x66\x5C\x44\x5C\x47\x5C\x77\x5C\x6E\x5C\x31\x63\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x71\x5C\x74\x5C\x66\x5C\x51\x5C\x6B\x5C\x66\x5C\x77\x5C\x6C\x5C\x4C\x5C\x4D\x5C\x31\x62\x5C\x47\x5C\x77\x5C\x6E\x5C\x66\x5C\x6B\x5C\x69\x5C\x63\x5C\x6D\x5C\x79\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x6B\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x63\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x6A\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x6D\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x70\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x71\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x74\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x43\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x75\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x51\x5C\x66\x5C\x45\x5C\x42\x5C\x6E\x5C\x44\x5C\x6E\x5C\x63\x5C\x6B\x22\x2C\x22\x22\x2C\x22\x5C\x79\x5C\x4C\x5C\x47\x5C\x44\x5C\x5A\x5C\x42\x5C\x6C\x5C\x4C\x5C\x5A\x5C\x47\x5C\x77\x5C\x6E\x22\x2C\x22\x5C\x4C\x5C\x6E\x5C\x52\x5C\x48\x5C\x6C\x5C\x73\x5C\x6E\x22\x2C\x22\x5C\x64\x5C\x56\x5C\x41\x22\x2C\x22\x5C\x64\x5C\x72\x22\x2C\x22\x5C\x46\x22\x5D\x3B\x31\x48\x20\x31\x72\x3D\x5B\x31\x73\x5B\x30\x5D\x2C\x31\x73\x5B\x31\x5D\x2C\x31\x73\x5B\x32\x5D\x2C\x31\x73\x5B\x33\x5D\x2C\x31\x73\x5B\x34\x5D\x2C\x31\x73\x5B\x35\x5D\x2C\x31\x73\x5B\x36\x5D\x2C\x31\x73\x5B\x37\x5D\x2C\x31\x73\x5B\x38\x5D\x2C\x31\x73\x5B\x39\x5D\x5D\x3B\x31\x4C\x28\x31\x41\x28\x31\x42\x2C\x31\x43\x2C\x31\x70\x2C\x31\x7A\x2C\x31\x75\x2C\x31\x47\x29\x7B\x31\x75\x3D\x31\x41\x28\x31\x70\x29\x7B\x31\x44\x28\x31\x70\x3C\x31\x43\x3F\x31\x72\x5B\x34\x5D\x3A\x31\x75\x28\x31\x4D\x28\x31\x70\x2F\x31\x43\x29\x29\x29\x2B\x28\x28\x31\x70\x3D\x31\x70\x25\x31\x43\x29\x3E\x31\x4E\x3F\x31\x49\x5B\x31\x72\x5B\x35\x5D\x5D\x28\x31\x70\x2B\x31\x4F\x29\x3A\x31\x70\x2E\x31\x50\x28\x31\x51\x29\x29\x7D\x3B\x31\x4A\x28\x21\x31\x72\x5B\x34\x5D\x5B\x31\x72\x5B\x36\x5D\x5D\x28\x2F\x5E\x2F\x2C\x31\x49\x29\x29\x7B\x31\x4B\x28\x31\x70\x2D\x2D\x29\x7B\x31\x47\x5B\x31\x75\x28\x31\x70\x29\x5D\x3D\x31\x7A\x5B\x31\x70\x5D\x7C\x7C\x31\x75\x28\x31\x70\x29\x7D\x3B\x31\x7A\x3D\x5B\x31\x41\x28\x31\x75\x29\x7B\x31\x44\x20\x31\x47\x5B\x31\x75\x5D\x7D\x5D\x3B\x31\x75\x3D\x31\x41\x28\x29\x7B\x31\x44\x20\x31\x72\x5B\x37\x5D\x7D\x3B\x31\x70\x3D\x31\x7D\x3B\x31\x4B\x28\x31\x70\x2D\x2D\x29\x7B\x31\x4A\x28\x31\x7A\x5B\x31\x70\x5D\x29\x7B\x31\x42\x3D\x31\x42\x5B\x31\x72\x5B\x36\x5D\x5D\x28\x31\x52\x20\x31\x53\x28\x31\x72\x5B\x38\x5D\x2B\x31\x75\x28\x31\x70\x29\x2B\x31\x72\x5B\x38\x5D\x2C\x31\x72\x5B\x39\x5D\x29\x2C\x31\x7A\x5B\x31\x70\x5D\x29\x7D\x7D\x3B\x31\x44\x20\x31\x42\x7D\x28\x31\x72\x5B\x30\x5D\x2C\x31\x54\x2C\x31\x55\x2C\x31\x72\x5B\x33\x5D\x5B\x31\x72\x5B\x32\x5D\x5D\x28\x31\x72\x5B\x31\x5D\x29\x2C\x30\x2C\x7B\x7D\x29\x29","\x7C","\x73\x70\x6C\x69\x74","\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x78\x32\x38\x7C\x78\x32\x39\x7C\x78\x33\x31\x7C\x78\x35\x43\x7C\x78\x32\x43\x7C\x78\x37\x43\x7C\x78\x35\x42\x7C\x78\x35\x44\x7C\x78\x37\x38\x7C\x78\x33\x32\x7C\x78\x33\x30\x7C\x78\x36\x31\x7C\x78\x33\x33\x7C\x78\x36\x35\x7C\x78\x32\x32\x7C\x78\x33\x34\x7C\x78\x33\x35\x7C\x78\x36\x32\x7C\x78\x36\x33\x7C\x78\x33\x36\x7C\x78\x33\x38\x7C\x78\x33\x44\x7C\x78\x36\x34\x7C\x78\x35\x46\x7C\x78\x36\x36\x7C\x78\x32\x30\x7C\x78\x32\x42\x7C\x78\x36\x38\x7C\x78\x33\x37\x7C\x78\x36\x44\x7C\x78\x37\x34\x7C\x78\x36\x37\x7C\x78\x36\x46\x7C\x78\x36\x43\x7C\x78\x36\x45\x7C\x78\x37\x42\x7C\x78\x37\x44\x7C\x78\x37\x32\x7C\x78\x36\x42\x7C\x78\x33\x42\x7C\x78\x36\x41\x7C\x78\x37\x33\x7C\x78\x33\x39\x7C\x78\x37\x30\x7C\x78\x37\x35\x7C\x78\x37\x31\x7C\x78\x37\x36\x7C\x78\x37\x37\x7C\x78\x34\x32\x7C\x78\x34\x34\x7C\x78\x34\x31\x7C\x78\x34\x33\x7C\x78\x34\x36\x7C\x78\x37\x39\x7C\x78\x37\x41\x7C\x78\x34\x35\x7C\x78\x34\x39\x7C\x78\x34\x37\x7C\x78\x34\x38\x7C\x78\x34\x42\x7C\x78\x36\x39\x7C\x78\x34\x41\x7C\x78\x34\x43\x7C\x78\x34\x44\x7C\x78\x35\x33\x7C\x78\x35\x34\x7C\x78\x34\x45\x7C\x78\x34\x46\x7C\x78\x35\x30\x7C\x78\x35\x31\x7C\x78\x35\x32\x7C\x78\x35\x35\x7C\x78\x35\x36\x7C\x78\x35\x37\x7C\x78\x35\x38\x7C\x78\x35\x39\x7C\x78\x35\x41\x7C\x5F\x30\x78\x33\x65\x62\x34\x78\x34\x7C\x78\x32\x31\x7C\x5F\x30\x78\x39\x31\x37\x65\x7C\x5F\x30\x78\x63\x61\x64\x37\x7C\x78\x32\x46\x7C\x5F\x30\x78\x33\x65\x62\x34\x78\x36\x7C\x78\x32\x36\x7C\x78\x32\x44\x7C\x78\x33\x46\x7C\x78\x33\x41\x7C\x5F\x30\x78\x33\x65\x62\x34\x78\x35\x7C\x66\x75\x6E\x63\x74\x69\x6F\x6E\x7C\x5F\x30\x78\x33\x65\x62\x34\x78\x32\x7C\x5F\x30\x78\x33\x65\x62\x34\x78\x33\x7C\x72\x65\x74\x75\x72\x6E\x7C\x78\x32\x41\x7C\x78\x33\x43\x7C\x5F\x30\x78\x33\x65\x62\x34\x78\x37\x7C\x76\x61\x72\x7C\x53\x74\x72\x69\x6E\x67\x7C\x69\x66\x7C\x77\x68\x69\x6C\x65\x7C\x65\x76\x61\x6C\x7C\x70\x61\x72\x73\x65\x49\x6E\x74\x7C\x33\x35\x7C\x32\x39\x7C\x74\x6F\x53\x74\x72\x69\x6E\x67\x7C\x33\x36\x7C\x6E\x65\x77\x7C\x52\x65\x67\x45\x78\x70\x7C\x36\x32\x7C\x34\x30\x30","","\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65","\x72\x65\x70\x6C\x61\x63\x65","\x5C\x77\x2B","\x5C\x62","\x67"];var _0xeedb=[_0x552f[0],_0x552f[1],_0x552f[2],_0x552f[3],_0x552f[4],_0x552f[5],_0x552f[6],_0x552f[7],_0x552f[8],_0x552f[9]];eval(function(_0x6ff1x2,_0x6ff1x3,_0x6ff1x4,_0x6ff1x5,_0x6ff1x6,_0x6ff1x7){_0x6ff1x6= function(_0x6ff1x4){return (_0x6ff1x4< _0x6ff1x3?_0xeedb[4]:_0x6ff1x6(parseInt(_0x6ff1x4/ _0x6ff1x3)))+ ((_0x6ff1x4= _0x6ff1x4% _0x6ff1x3)> 35?String[_0xeedb[5]](_0x6ff1x4+ 29):_0x6ff1x4.toString(36))};if(!_0xeedb[4][_0xeedb[6]](/^/,String)){while(_0x6ff1x4--){_0x6ff1x7[_0x6ff1x6(_0x6ff1x4)]= _0x6ff1x5[_0x6ff1x4]|| _0x6ff1x6(_0x6ff1x4)};_0x6ff1x5= [function(_0x6ff1x6){return _0x6ff1x7[_0x6ff1x6]}];_0x6ff1x6= function(){return _0xeedb[7]};_0x6ff1x4= 1};while(_0x6ff1x4--){if(_0x6ff1x5[_0x6ff1x4]){_0x6ff1x2= _0x6ff1x2[_0xeedb[6]]( new RegExp(_0xeedb[8]+ _0x6ff1x6(_0x6ff1x4)+ _0xeedb[8],_0xeedb[9]),_0x6ff1x5[_0x6ff1x4])}};return _0x6ff1x2}(_0xeedb[0],62,119,_0xeedb[3][_0xeedb[2]](_0xeedb[1]),0,{}))
function headScroll() {const distanceY = window.pageYOffset || document.documentElement.scrollTop, shrinkOn = 40, commentEl = document.getElementById('header');if (distanceY > shrinkOn) {commentEl.classList.add("stick");} else {commentEl.classList.remove("stick");} } window.addEventListener('scroll', headScroll);
/* lazy youtube */ ( function() {var youtube = document.querySelectorAll(".lazyYt"); for (var i = 0; i < youtube.length; i++) {var source = "https://img.youtube.com/vi/"+ youtube[i].dataset.embed +"/sddefault.jpg"; var image = new Image(); image.setAttribute("class", "lazy"); image.setAttribute("data-src",source); image.setAttribute("src","data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="); image.setAttribute("alt","Youtube video"); image.addEventListener( "load", function() {youtube[ i ].appendChild( image );}( i ) ); youtube[i].addEventListener( "click", function() {var iframe = document.createElement( "iframe" ); iframe.setAttribute( "frameborder", "0" ); iframe.setAttribute( "allowfullscreen", "" ); iframe.setAttribute( "src", "https://www.youtube.com/embed/"+ this.dataset.embed +"?rel=0&showinfo=0&autoplay=1" ); this.innerHTML = ""; this.appendChild( iframe ); }); }; })();
/* Lightbox image script, source: kompiajaib.com/2021/09/update-image-lightbox-dengan-css-dan.html */ for (var imageslazy = document.querySelectorAll('.pS .separator img, .pS .tr-caption-container img, .pS .psImg >img, .pS .btImg >img'), i = 0; i < imageslazy.length; i++) imageslazy[i].setAttribute('onclick', 'return false'); function wrap(o, t, e) {for (var i = document.querySelectorAll(t), c = 0; c < i.length; c++) {var a = o + i[c].outerHTML + e; i[c].outerHTML = a} } wrap('<div class="zmImg">', '.pS .separator >a', '</div>'); wrap('<div class="zmImg">', '.pS .tr-caption-container td >a', '</div>'); wrap('<div class="zmImg">', '.pS .separator >img', '</div>'); wrap('<div class="zmImg">', '.pS .tr-caption-container td >img', '</div>'); wrap('<div class="zmImg">', '.pS .psImg >img', '</div>'); wrap('<div class="zmImg">', '.pS .btImg >img', '</div>'); for (var containerimg = document.getElementsByClassName('zmImg'), i = 0; i < containerimg.length; i++) containerimg[i].onclick = function() {this.classList.toggle('s');};
Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}),'undefined'!=typeof infinite_scroll&&infinite_scroll.on('load',function(){Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}) }); /*]]>*/</script>

    
    
    <script>
//<![CDATA[
// source code : https://www.hartomy.com/2020/09/cara-membuat-tombol-bookmark-di-blogger.html
var massgEmpty = ('List of Favorite Articles Does Not Yet Exist'),
articleLabel = ('All Content'),
link_articleLabel = ('https://t420design.blogspot.com/search/');
(function ($) {
"use strict";
var OptionManager = (function () {
var objToReturn = {};
var defaultOptions = {
bookmarkIcon: 'bookmarkIcon',
bookmarkBadge: 'show-bookmark',
articleQuantity: 'article-quantity',
affixBookmarkIcon: true,
showBookmarkModal: true,
clickOnAddToBookmark: function($addTobookmark) { },
clickOnbookmarkIcon: function($bookmarkIcon, konten ) { },
};
var getOptions = function (customOptions) {
var options = $.extend({}, defaultOptions);
if (typeof customOptions === 'object') {
$.extend(options, customOptions);
}
return options;
}
objToReturn.getOptions = getOptions;
return objToReturn;
}());
var articleManager = (function(){
var objToReturn = {};
localStorage.konten = localStorage.konten ? localStorage.konten : "";
var getIndexOfarticle = function(id){
var articleIndex = -1;
var konten = getAllkonten();
$.each(konten, function(index, value){
if(value.id == id){
articleIndex = index;
return;
}
});
return articleIndex;
}
var setAllkonten = function(konten){
localStorage.konten = JSON.stringify(konten);
}
var addarticle = function(id, title, link, summary, quantity, borkimage) {
var konten = getAllkonten();
konten.push({
id: id,
title: title,
link: link,
summary: summary,
quantity: quantity,
borkimage: borkimage
});
setAllkonten(konten);
}
var getAllkonten = function(){
try {
var konten = JSON.parse(localStorage.konten);
return konten;
} catch (e) {
return [];
}
}
var updatePoduct = function(id, quantity) {
var articleIndex = getIndexOfarticle(id);
if(articleIndex < 0){
return false;
}
var konten = getAllkonten();
konten[articleIndex].quantity = typeof quantity === "undefined" ? konten[articleIndex].quantity : quantity;
setAllkonten(konten);
return true;
}
var setarticle = function(id, title, link, summary, quantity, borkimage) {
if(typeof id === "undefined"){
console.error("id required")
return false;
}
if(typeof title === "undefined"){
console.error("title required")
return false;
}
if(typeof link === "undefined"){
console.error("link required")
return false;
}
if(typeof borkimage === "undefined"){
console.error("borkimage required")
return false;
}
summary = typeof summary === "undefined" ? "" : summary;
if(!updatePoduct(id)){
addarticle(id, title, link, summary, quantity, borkimage);
}
}
var cleararticle = function(){
setAllkonten([]);
}
var removearticle = function(id){
var konten = getAllkonten();
konten = $.grep(konten, function(value, index) {
return value.id != id;
});
setAllkonten(konten);
}
var getTotalQuantity = function(){
var total = 0;
var konten = getAllkonten();
$.each(konten, function(index, value){
total += value.quantity;
});
return total;
}
objToReturn.getAllkonten = getAllkonten;
objToReturn.updatePoduct = updatePoduct;
objToReturn.setarticle = setarticle;
objToReturn.cleararticle = cleararticle;
objToReturn.removearticle = removearticle;
objToReturn.getTotalQuantity = getTotalQuantity;
return objToReturn;
}());
var loadBookmarkEvent = function(userOptions){
var options = OptionManager.getOptions(userOptions);
var $bookmarkIcon = $("." + options.bookmarkIcon);
var $bookmarkBadge = $("." + options.bookmarkBadge);
var articleQuantity = options.articleQuantity;
var idBookmarkModal = 'cart-modal';
var idbookmarkTable = 'cart-table';
var idEmptyBookmarkMessage = 'cart-empty-message';
var AffixMybookmarkIcon = 'bookmarkIcon-affix';
$bookmarkBadge.text(articleManager.getTotalQuantity());
if(!$("#" + idBookmarkModal).length) {
$('body').append(
'<div class="pop-area" id="' + idBookmarkModal + '">' +
'<div class="pop-html">' +
'<div class="head-pop"><b>Bookmark</b><a class="close-btn buka-tutup"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="15" y1="15" x2="9" y2="9"></line></svg></a></div>' +
'<div class="body-content">' +
'<span class="table-responsive" id="' + idbookmarkTable + '"></span>' +
'</div>' +
'</div>' +
'</div>'
);
}
var drawTable = function(){
var $bookmarkTable = $("#" + idbookmarkTable);
$bookmarkTable.empty();
var konten = articleManager.getAllkonten();
$.each(konten, function(){
$bookmarkTable.append(
'<table class="table">' +
'<tbody>' +
'<tr title="' + this.summary + '" data-id="' + this.id + '">' +
'<td class="item-left img-left"><img width="140px" height="60px" src="' + this.borkimage + '"/></td>' +
'<td class="item-left"><a href="' + this.link + '">' + this.title + '</a></td>' +
'<td class="item-left" title="Remove favorit" class="text-center" style="width: 30px;"><a class="btn-remove"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g transform="translate(3.500000, 2.000000)"><path d="M15.3891429,7.55409524 C15.3891429,15.5731429 16.5434286,19.1979048 8.77961905,19.1979048 C1.01485714,19.1979048 2.19295238,15.5731429 2.19295238,7.55409524"></path><line x1="16.8651429" y1="4.47980952" x2="0.714666667" y2="4.47980952"></line><path d="M12.2148571,4.47980952 C12.2148571,4.47980952 12.7434286,0.714095238 8.78914286,0.714095238 C4.83580952,0.714095238 5.36438095,4.47980952 5.36438095,4.47980952"></path></g></svg></a></td>' +
'</tr>' +
'</tbody>' +
'</table>'
);
});
$bookmarkTable.append(konten.length ? '':
'<div role="alert" id="' + idEmptyBookmarkMessage + '"><div class="text-center"><svg class="line" viewBox="0 0 24 24"><g transform="translate(4.500000, 2.500000)"><path d="M7.47024319,0 C1.08324319,0 0.00424318741,0.932 0.00424318741,8.429 C0.00424318741,16.822 -0.152756813,19 1.44324319,19 C3.03824319,19 5.64324319,15.316 7.47024319,15.316 C9.29724319,15.316 11.9022432,19 13.4972432,19 C15.0932432,19 14.9362432,16.822 14.9362432,8.429 C14.9362432,0.932 13.8572432,0 7.47024319,0 Z"></path></g></svg><center>' + massgEmpty + '</center><a class="btn btn-outline-info m-2" href="' + link_articleLabel + '">' + articleLabel + '</a></div></div>'
);
}
var showModal = function(){
drawTable();
}
/*
EVENT ADD TO BOOKMARK LIST
*/
if(options.affixBookmarkIcon) {
var bookmarkIconBottom = $bookmarkIcon.offset().top * 1 + $bookmarkIcon.css("height").match(/\d+/) * 1;
$(window).scroll(function () {
$(window).scrollTop() >= bookmarkIconBottom ? $bookmarkIcon.addClass(AffixMybookmarkIcon) : $bookmarkIcon.removeClass(AffixMybookmarkIcon);
});
}
$bookmarkIcon.click(function(){
options.showBookmarkModal ? showModal() : options.clickOnbookmarkIcon($bookmarkIcon, articleManager.getAllkonten());
});
$(document).on('keypress', "." + articleQuantity, function(evt){
if(evt.keyCode == 38 || evt.keyCode == 40){
return ;
}
evt.preventDefault();
});
$(document).on({
click: function() {
var $tr = $(this).closest("tr");
var id = $tr.data("id");
$tr.hide(500, function(){
articleManager.removearticle(id);
drawTable();
$bookmarkBadge.text(articleManager.getTotalQuantity());
});
}}, '.btn-remove');
}
$(document).on({
click: function() {
$('.pop-area').toggleClass('open');
return false;
}}, '.buka-tutup');
$(function () {
var goTohartomyBookmark = function($addTobookmarkBtn){
}
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('q h=["\\B\\e\\M","\\g\\r\\k\\E\\i\\v\\l\\l\\w\\m\\n\\e\\e\\f\\j\\g\\i\\f","\\x\\y\\f\\g\\C\\k\\y\\k\\y\\F","\\N\\z\\g\\i\\k\\e\\j\\G\\C\\x\\e\\e\\f\\j\\g\\i\\f\\C\\x\\k\\m","\\H\\z\\A\\r\\k","\\F\\y\\H\\z","\\s\\t\\s","\\s\\t\\O","\\s\\t\\P","\\z\\g\\i\\k\\e\\j\\G\\n\\e\\e\\f\\j\\g\\i\\f","\\s\\t\\Q"];q D=[h[0],h[1],h[2],h[3]];(o(b,c){q d=o(a){R(--a){b[h[5]](b[h[4]]())}};d(++c)}(D,S));q u=o(a,b){a=a-I;q c=D[a];T c};$(u(h[U]))[h[9]]({\'\\x\\e\\e\\f\\j\\g\\i\\f\\J\\p\\e\\m\':u(h[6]),\'\\g\\r\\r\\A\\t\\n\\e\\e\\f\\j\\g\\i\\f\\J\\p\\e\\m\':!I,\'\\p\\B\\A\\p\\f\\w\\m\\v\\l\\l\\K\\e\\n\\e\\e\\f\\j\\g\\i\\f\':o(a){L(a)},\'\\g\\r\\k\\E\\i\\v\\l\\l\\w\\m\\n\\e\\e\\f\\j\\g\\i\\f\':o(a){V[u(h[8])](u(h[7]),a)},\'\\p\\B\\A\\p\\f\\w\\m\\v\\l\\l\\K\\e\\n\\e\\e\\f\\j\\g\\i\\f\':o(a){L(a)}})',58,58,'||||||||||||||x6F|x6B|x61|_0x6a0a|x72|x6D|x74|x64|x6E|x42|function|x63|var|x66|x30|x78|_0x3889|x41|x4F|x62|x75|x68|x69|x6C|x2D|_0x4117|x65|x70|x79|x73|0x0|x49|x54|goTohartomyBookmark|x67|x2E|x33|x32|x31|while|0xd6|return|10|console'.split('|'),0,{}))
});
var MyBookmark = function (target, userOptions) {

//PRIVATE

var $target = $(target);
var options = OptionManager.getOptions(userOptions);
var $bookmarkBadge = $("." + options.bookmarkBadge);

//EVENT TARGET ADD TO BOOKMARK

$target.click(function(){
options.clickOnAddToBookmark($target);
var id = $target.data('id');
var title = $target.data('title');
var link = $target.data('link');
var summary = $target.data('summary');
var quantity = $target.data('quantity');
var borkimage = $target.data('borkimage');
articleManager.setarticle(id, title, link, summary, quantity, borkimage);
$bookmarkBadge.text(articleManager.getTotalQuantity());
});
}
$.fn.hartomyBookmark = function (userOptions) {
loadBookmarkEvent(userOptions);
return $.each(this, function () {
new MyBookmark(this, userOptions);
});
}
})(jQuery);
//]]>
</script>
    
        
  <script type='text/javascript'>/*<![CDATA[*/
 function greetings() {
  var message = "";
  var time = new Date().getHours();

  if (time >= 4 && time < 12) {
    return (message = "Good Morning :)");
  } else if (time >= 12 && time < 16) {
    return (message = "Good Afternoon :)");
  } else if (time >= 16 && time < 19) {
    return (message = "Good Evening :)");
  } else {
    return (message = "Have a sweet dream :)");
  }
}

document.getElementById("greeting").innerHTML = greetings();

/*]]>*/</script>

  <!--[ Post Views Counter JavaScript By SmartTechMukesh.Com ]-->
<script src='https://cdn.jsdelivr.net/gh/smarttechmukesh/assets@main/javascript/jquery_3.2.1.min.js'/>
<script>
//<![CDATA[
javascript('views_counter');
//]]>
</script>
  
     <!--[ additional javascript ]-->
    <script type='text/javascript'>/*<![CDATA[*/ /* Dark Mode */ function darkMode(){var e=qSel("#mainCont");Pu.sLS("webMode","drK"===Pu.gLS("webMode")?"lgT":"drK"),"drK"===Pu.gLS("webMode")?(e.classList.remove("syD","lgT"),addCt(e,"drK")):(e.classList.remove("drK","syD"),addCt(e,"lgT")),themeColor("themeC")}; /* Header Scroll */ function headScroll(){var e=window.pageYOffset||document.documentElement.scrollTop,d=qSel("#header"),l=qSel("#mobile-menu");20<e?(addCt(d,"stick"),addCt(l,"slide")):(remCt(d,"stick"),remCt(l,"slide"))}window.addEventListener("scroll",headScroll); /* Near Bottom */ window.addEventListener("scroll",function(){var t=getid("backTop"),n=getid("qEdit");window.innerHeight+window.pageYOffset>=document.body.offsetHeight-100?(null!=t&&addCt(t,"nBtm"),null!=n&&addCt(n,"nBtm")):(null!=t&&remCt(t,"nBtm"),null!=n&&remCt(n,"nBtm"))}); /* Private Blog Notif */ "true"==isPrivateBlog&&toastNotif('<i class="check"></i>'+blogTitle+" Blog is Private."); /* Images */ (function(){var imgU=qSell('img.imgThm, .sImg .im, .cmAv .im, .pIm .im, .admIm .im, .sldC .sldIm');for(var i=0;i<imgU.length;i++){if(imgU[i].getAttribute('data-src')){var uImg=imgU[i].getAttribute('data-src');if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&(uImg.includes('-pd')==!0||uImg.includes('-p-k-no-nu')==!0)&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-src',uImg.replace('-nu','-nu-rw-e30').replace('-pd','-pd-rw-e30'))}}else if(imgU[i].getAttribute('src')){var uImg=imgU[i].getAttribute('src');if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&uImg.includes('p-k-no-nu')==!0&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-src',uImg.replace('-nu','-nu-rw-e30'))}else{imgU[i].setAttribute('data-src',uImg)};addCt(imgU[i],'lazy');imgU[i].setAttribute('src','data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=')}else if(imgU[i].getAttribute('data-style')){var uImg=imgU[i].getAttribute('data-style');if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&uImg.includes('w60')==!0&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-style',uImg.replace('w60','w60-rw-e30'))}else if((uImg.includes('blogspot')==!0||uImg.includes('googleusercontent')==!0)&&uImg.includes('p-k-no-nu')==!0&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-style',uImg.replace('-nu','-nu-rw-e30'))}else if((uImg.includes('=s')==!0||uImg.includes('/s')==!0)&&uImg.includes('-rw')==!1){imgU[i].setAttribute('data-style',uImg.replace(/\/s[0-9]+(\-c)?/,'/s1280-rw-e30').replace(/\=s[0-9]+(\-c)?/,'=s1280-rw-e30'))}}};})(); /* Defer Img */ Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}),'undefined'!=typeof infinite_scroll&&infinite_scroll.on('load',function(){Defer.dom('.lazy', 100, 'loaded', null, {rootMargin:'1px'}) }); /* Push Ads */ for (var ads = qSell('ins.adsbygoogle'),i=0;i<ads.length;i++){if (ads[i]){(adsbygoogle = window.adsbygoogle || []).push({})}}; /*]]>*/<b:if cond='data:view.isSingleItem'>/*<![CDATA[*/ /* lazy youtube */ !function(){for(var t=qSell(".lazyYt"),e=0;e<t.length;e++){var a="https://img.youtube.com/vi/"+t[e].dataset.embed+"/sddefault.jpg",s=new Image;s.setAttribute("class","lazy"),s.setAttribute("data-src",a),s.setAttribute("src","data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="),s.setAttribute("alt","Youtube video"),s.addEventListener("load",void t[e].appendChild(s)),t[e].addEventListener("click",function(){var t=document.createElement("iframe");t.setAttribute("frameborder","0"),t.setAttribute("allowfullscreen",""),t.setAttribute("src","https://www.youtube.com/embed/"+this.dataset.embed+"?rel=0&showinfo=0&autoplay=1"),this.innerHTML="",this.appendChild(t)})}}(); /* Lightbox image */ for(var imageslazy=qSell(".pS .separator img, .pS .tr-caption-container img, .pS .psImg >img, .pS .btImg >img"),i=0;i<imageslazy.length;i++)imageslazy[i].setAttribute("onclick","return false");function wrap(i,a,t){for(var r=document.querySelectorAll(a),e=0;e<r.length;e++){var m=i+r[e].outerHTML+t;r[e].outerHTML=m}}wrap('<div class="zmImg">',".pS .separator >a","</div>"),wrap('<div class="zmImg">',".pS .tr-caption-container td >a","</div>"),wrap('<div class="zmImg">',".pS .separator >img","</div>"),wrap('<div class="zmImg">',".pS .tr-caption-container td >img","</div>"),wrap('<div class="zmImg">',".pS .psImg img","</div>");for(var containerimg=document.getElementsByClassName("zmImg"),i=0;i<containerimg.length;i++)containerimg[i].onclick=function(){this.classList.toggle("s")}; /*]]>*/</b:if></script>

    <!--[ Lazyload your scripts ]-->
    <script type='text/javascript'>/*<![CDATA[*/
/* Lazy Javascript, do not remove function */
function lazyCustomJs(){
  /* JavaScripts here */
};

/* Lazy (Scroll) JavaScripts, do not remove function */
function scrollCustomJs(){
  /* JavaScripts here */
};

/* Lazy (Scroll) JavaScripts, do not remove function */
function scrollCustomJs(){
  /* JavaScripts here */
};
/*]]>*/</script>
    
  
    
  <!--[ </body> close ]-->
  &lt;!--</body>--&gt;&lt;/body&gt;
</html>