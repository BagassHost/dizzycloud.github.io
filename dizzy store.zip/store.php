
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- META AREA -->
	<title>Store</title>
	<meta name="robots" content="follow, index"/>
	<meta name="keywords" content="nathan prinsley, nathan, prinsh, prinsley, prinshcom" />
	<link rel="shortcut icon" href="https://store.prinsh.com/public/storage/7aa66851a93f78b522f1bf0962af607a.png">
	<meta content="Berbagai Product menarik disini , ada source code php, node js maupun template html " name="description" />
	<meta content="" name="author" />
	<link rel="canonical" href="https://store.prinsh.com/store" />
	<meta property="og:locale" content="en_US" />
	<meta property="bb:client_area" content="https://store.prinsh.com/store">
	<meta property="og:url" content="https://store.prinsh.com/store" />
	<meta property="og:title" content="Store" />
	<meta property="og:image" content="https://store.prinsh.com/public/storage/7eeef0a82d2ae39ba13f3410828d488f.png" />
	<meta property="og:site_name" content="Store" />
	<meta property="og:type" content="website" />
	<meta property="og:description" content="Berbagai Product menarik disini , ada source code php, node js maupun template html " />
	<meta name="twitter:description" content="Berbagai Product menarik disini , ada source code php, node js maupun template html " />
	<meta name="twitter:card" content="summary" />
	<meta name="twitter:site" content="@Store" />
	<meta name="twitter:title" content="Store" />
	<meta name="twitter:image" content="https://store.prinsh.com/public/storage/7eeef0a82d2ae39ba13f3410828d488f.png" />	<!-- META AREA -->
	<!-- Bundle and Base CSS -->
	<link rel="stylesheet" href="https://store.prinsh.com/theme/frontend/crypto-light/assets/css/vendor.bundle.css?ver=558">
	<link rel="stylesheet" href="https://store.prinsh.com/theme/frontend/crypto-light/assets/css/style-dark.css?ver=558" id="changeTheme">
	<link rel="stylesheet" href="https://store.prinsh.com/theme/frontend/crypto-light/assets/css/style.css?ver=11">
	<link href="https://store.prinsh.com/public/assets/backend/css/icons.min.css" rel="stylesheet" type="text/css" />
	<style>
		.roundedsk {
			border-radius: 7px;
		}

		.card-footer {
			background-color: unset;
		}

		ul {
			padding-left: 30px;
			list-style: unset;
		}

		.menu,
		.ulnone {
			padding: 0px;
			list-style: none;
		}

		.pagination li a {
			height: 35px;
			min-width: 35px;
			padding: 8px 5px;
		}

		.tag-oneline {
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-line-clamp: 1;
			/* number of lines to show */
			-webkit-box-orient: vertical;
		}
	</style>
	<!-------head-------->
<style>
   
</style>
</head>


<body class="nk-body body-wider theme-light mode-onepage">
	<div class="nk-wrap">
		<header class="nk-header page-header is-sticky is-shrink is-transparent is-light" id="header">

			<div class="header-main">
	<div class="header-container container">
		<div class="header-wrap">
			<!-- Logo @s -->
			<div class="header-logo logo">
				<a href="/store" class="logo-link" style="display:flex">
					<img class="logo-dark" src="https://store.prinsh.com/public/storage/27449a94d6e0f6b6840aef14834b3815.png" alt="logo">
					<img class="logo-light" src="https://store.prinsh.com/public/storage/27449a94d6e0f6b6840aef14834b3815.png" alt="logo">
				</a>
			</div>

			<!-- Menu Toogle @s -->
			<div class="header-nav-toggle">
				<a href="#" class="navbar-toggle" data-menu-toggle="example-menu-04">
					<div class="toggle-line">
						<span></span>
					</div>
				</a>
			</div>
			<!-- Menu @s -->
			<div class="header-navbar header-navbar-s1">
				<nav class="header-menu" id="example-menu-04">
					<ul class="menu menu-s2">
						<li class="menu-item"><a class="menu-link nav-link" href="https://store.prinsh.com/">Home</a></li><li class="menu-item"><a class="menu-link nav-link" href="https://store.prinsh.com/redirect.php?domain=about.prinsh.com">About</a></li><li class="menu-item"><a class="menu-link nav-link" href="https://store.prinsh.com/redirect.php?domain=prinsh.com">Website</a></li><li class="menu-item"><a class="menu-link nav-link" href="https://store.prinsh.com/store">Store</a></li><li class="menu-item"><a class="menu-link nav-link" href="https://store.prinsh.com/testimoni/">Testimoni</a></li>					</ul>
					<ul class="ulnone menu-btns">
						<li><a href="javascript:void(0)" data-toggle="modal" data-target="#modal-seach" class="btn btn-rg btn-auto btn-grad on-bg-light btn-round"><span><i class="uil-search"></i></span></a></li>
					</ul>
				</nav>
			</div><!-- .header-navbar @e -->
		</div>
	</div>
</div>
<!-- Modal @s -->
<div class="modal fade" id="modal-seach">
	<div class="modal-dialog">
		<div class="modal-content">
			<a href="#" class="modal-close" data-dismiss="modal" aria-label="Close"><em class="ti ti-close"></em></a>
			<div class="modal-body pb-0 mb-0" style="padding-top: 35px;">
				<form action="https://store.prinsh.com/search" method="post">
					<div class="field-item">
						<div class="field-wrap">
							<input name="query" type="text" class="input-bordered" placeholder="Search Here..." required>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div><!-- .modal @e -->


			<div class="header-banner bg-light">
				<div class="nk-banner">
					<div class="banner banner-mask-fix banner-single">
						<div class="banner-wrap ov-v">
							<div class="container">
								<div class="section-head text-center wide-auto-sm">
									<h2 class="title title-s4" title="PRIN">STORE</h2>
								</div>
							</div>
						</div>
					</div>
				</div><!-- .nk-banner -->
				<div class="nk-ovm mask-c-light shape-v mask-contain-bottom"></div>
				<div id="particles-bg" class="particles-container particles-bg" data-pt-base="#00c0fa" data-pt-base-op=".3" data-pt-line="#2b56f5" data-pt-line-op=".5" data-pt-shape="#00c0fa" data-pt-shape-op=".2"></div>
			</div><!-- .nk-banner -->
		</header>

		<!-- Content -->
		<main class="nk-pages">
			<section class="section mask-c-blend-light bg-white ov-h pt-0" style="padding-bottom: 100px;">
				<div class="container">
					<div class="row">
													<div class="col-xl-3 col-lg-3 col-md-6 col-6" style="padding-left: 4px; padding-right: 4px;">
								<!-- Card -->
								<div class="card p-0 mb-4 shadow" style="height: 95%;">
									<a href="https://store.prinsh.com/ribuan-video-konten-craft-menarik-siap-upload"> <img src="https://store.prinsh.com/public/storage/thumbnails/0d1a51da3c9d56aef596344635a48d2a.jpg" onerror='this.src="https://store.prinsh.com/public/storage/default.jpg?v=2"' class="card-img roundedsk p-1" alt="7500+ Video Konten Craft Menarik Siap Upload">
									<div class="text-center" style="margin-top: -20px;"><span class="badge badge-xs" style="background-color:#00b265">Rp 10.000</span></div></a>
									<!-- Card body -->
									<div class="card-body pt-1 px-3 pb-1">
										<div class="tag-oneline">
											<a href="https://store.prinsh.com/store/vidkon" class="fw-bold mr-1"><small><i class="uil-tag"></i>Vidkon</small></a>										</div>
										<h6><a href="https://store.prinsh.com/ribuan-video-konten-craft-menarik-siap-upload" class="text-dark textrespon" style="font-size: 14px;">
												7500+ Video Konten Craft Menarik Siap Upload											</a>
										</h6>
									</div>
									<a href="https://store.prinsh.com/ribuan-video-konten-craft-menarik-siap-upload">
									<div class="card-footer pt-1 px-3 pb-1">
										<!--<div class="row align-items-center g-0">
											<div class="col-auto pr-0">
												<img src="https://store.prinsh.com/public/storage/avatar/03be6ced73b27dbbde29e8dd33fd1fed.png" alt="Nathan Prinsley" class="rounded-circle me-2" height="25" width="25">
											</div>
											<div class="col lh-1 pl-1">
												<span class="fw-bold tag-oneline"><small>Nathan Prinsley</small></span>
											</div>
											<div class="col-auto">
												<p class="mb-0"><small><i class="uil-eye"></i></small></p>
											</div>
										</div>-->
									</div>
									</a>
								</div>
							</div>
													<div class="col-xl-3 col-lg-3 col-md-6 col-6" style="padding-left: 4px; padding-right: 4px;">
								<!-- Card -->
								<div class="card p-0 mb-4 shadow" style="height: 95%;">
									<a href="https://store.prinsh.com/misteri-box-murah-menguntungkan"> <img src="https://store.prinsh.com/public/storage/thumbnails/a0ab5c9dcddd109c6de3961e53674c30.jpg" onerror='this.src="https://store.prinsh.com/public/storage/default.jpg?v=2"' class="card-img roundedsk p-1" alt="Virtual Mystery Box Ribuan Tools Keren ">
									<div class="text-center" style="margin-top: -20px;"><span class="badge badge-xs" style="background-color:#00b265">Rp 10.000</span></div></a>
									<!-- Card body -->
									<div class="card-body pt-1 px-3 pb-1">
										<div class="tag-oneline">
											<a href="https://store.prinsh.com/store/mystery-box" class="fw-bold mr-1"><small><i class="uil-tag"></i>MysteryBox</small></a>										</div>
										<h6><a href="https://store.prinsh.com/misteri-box-murah-menguntungkan" class="text-dark textrespon" style="font-size: 14px;">
												Virtual Mystery Box Ribuan Tools Keren 											</a>
										</h6>
									</div>
									<a href="https://store.prinsh.com/misteri-box-murah-menguntungkan">
									<div class="card-footer pt-1 px-3 pb-1">
										<!--<div class="row align-items-center g-0">
											<div class="col-auto pr-0">
												<img src="https://store.prinsh.com/public/storage/avatar/03be6ced73b27dbbde29e8dd33fd1fed.png" alt="Nathan Prinsley" class="rounded-circle me-2" height="25" width="25">
											</div>
											<div class="col lh-1 pl-1">
												<span class="fw-bold tag-oneline"><small>Nathan Prinsley</small></span>
											</div>
											<div class="col-auto">
												<p class="mb-0"><small><i class="uil-eye"></i></small></p>
											</div>
										</div>-->
									</div>
									</a>
								</div>
							</div>
													<div class="col-xl-3 col-lg-3 col-md-6 col-6" style="padding-left: 4px; padding-right: 4px;">
								<!-- Card -->
								<div class="card p-0 mb-4 shadow" style="height: 95%;">
									<a href="https://store.prinsh.com/source-code-web-online-tools"> <img src="https://store.prinsh.com/public/storage/thumbnails/77c2693aa06334034f148d1f7b0cb367.jpg" onerror='this.src="https://store.prinsh.com/public/storage/default.jpg?v=2"' class="card-img roundedsk p-1" alt="Source Code Web Online Tools">
									<div class="text-center" style="margin-top: -20px;"><span class="badge badge-xs" style="background-color:#00b265">Rp 15.000</span></div></a>
									<!-- Card body -->
									<div class="card-body pt-1 px-3 pb-1">
										<div class="tag-oneline">
											<a href="https://store.prinsh.com/store/source-code" class="fw-bold mr-1"><small><i class="uil-tag"></i>SourceCode</small></a>										</div>
										<h6><a href="https://store.prinsh.com/source-code-web-online-tools" class="text-dark textrespon" style="font-size: 14px;">
												Source Code Web Online Tools											</a>
										</h6>
									</div>
									<a href="https://store.prinsh.com/source-code-web-online-tools">
									<div class="card-footer pt-1 px-3 pb-1">
										<!--<div class="row align-items-center g-0">
											<div class="col-auto pr-0">
												<img src="https://store.prinsh.com/public/storage/avatar/03be6ced73b27dbbde29e8dd33fd1fed.png" alt="Nathan Prinsley" class="rounded-circle me-2" height="25" width="25">
											</div>
											<div class="col lh-1 pl-1">
												<span class="fw-bold tag-oneline"><small>Nathan Prinsley</small></span>
											</div>
											<div class="col-auto">
												<p class="mb-0"><small><i class="uil-eye"></i></small></p>
											</div>
										</div>-->
									</div>
									</a>
								</div>
							</div>
											</div>
					<div class="row mt-3">
						<div class="col-12">
							<nav class="w-100 d-flex" aria-label="Page navigation example">
															</nav>
						</div>
					</div>
				</div>
			</section>
		</main>
		<!-- content end -->

		<footer class="nk-footer bg-light">
	<div class="container col-12 col-lg-5 col-xl-5">
		<form action="https://store.prinsh.com/home/subscriber" class="pt-3" method="POST">
			<div class="field-inline field-inline-round field-inline-s2-sm bg-white shadow-soft">
				<div class="field-wrap">
					<input class="input-solid input-solid-md" type="email" placeholder="Enter your email" required name="email">
				</div>
				<div class="submit-wrap">
					<input type="submit" class="btn btn-md btn-round btn-secondary h-100" value="Subscribe"></input>
				</div>
			</div>
			<div class="form-results"></div>
		</form>
	</div>
	<div class="section-footer bg-transparent ov-h py-4">

		<div class="container">
			<!-- Block @s -->
			<div class="nk-block block-footer">
				<div class="row">
					<div class="col">
						<div class="wgs wgs-text text-center mb-3">
							<ul class="social pl-0 pb-2">
								<li><a class="text-dark" href="//facebook.com/prinshcom" data-bs-toggle="Facebook" data-bs-placement="bottom" title="Facebook"><i class="uil-facebook-f"></i></a></li>								<li><a class="text-dark" href="//twitter.com/prinshcom" data-bs-toggle="Twitter" data-bs-placement="bottom" title="Twitter"><i class="uil-twitter"></i></a></li>																<li><a class="text-dark" href="//instagram.com/prinshcom" data-bs-toggle="Instagram" data-bs-placement="bottom" title="Instagram"><i class="uil-instagram"></i></a></li>								<li><a class="text-dark" href="//wa.me/62895804048990" data-bs-toggle="Whatsapp" data-bs-placement="bottom" title="Whatsapp"><i class="uil-whatsapp"></i></a></li>								<li><a class="text-dark" href="//youtube.com/Prinsley" data-bs-toggle="Youtube" data-bs-placement="bottom" title="Youtube"><i class="uil-youtube"></i></a></li>															</ul>
							<!--
							<a href="./" class="footer-logo">
								<img src="https://store.prinsh.com/public/storage/27449a94d6e0f6b6840aef14834b3815.png" srcset="https://store.prinsh.com/public/storage/27449a94d6e0f6b6840aef14834b3815.png" alt="logo">
							</a>
							-->
							<div class="copyright-text copyright-text-s3 pdt-m text-center">
								<p><span class="d-sm-block">Made With ❤ by Nathan Prinsley</span></p>
							</div>
						</div>
					</div>
				</div>
			</div><!-- .block @e -->
		</div>
		<div class="nk-ovm shape-s"></div>
	</div>
</footer>
<style>
    .turbo-progress-bar {
        position: fixed;
        top: 0;
        left: 0;
        height: 3px;
        background: #d461fe;
        z-index: 9999;
        transition:
          width ${ProgressBar.animationDuration}ms ease-out,
          opacity ${ProgressBar.animationDuration / 2}ms ${ProgressBar.animationDuration / 2}ms ease-in;
        transform: translate3d(0, 0, 0);
      }
</style>
<script src="https://store.prinsh.com/theme/frontend/turbo.es2017-umd.js"></script>	</div>

	<!-- JavaScript -->
	<script src="https://store.prinsh.com/theme/frontend/crypto-light/assets/js/jquery.bundle.js"></script>
	<script src="https://store.prinsh.com/theme/frontend/crypto-light/assets/js/scripts.js"></script>
	<script src="https://store.prinsh.com/theme/frontend/crypto-light/assets/js/charts.js"></script>
	<script src="https://store.prinsh.com/theme/frontend/crypto-light/assets/js/typed.min.js" defer></script>
	<script type="text/javascript">
		(function($) {
			'use strict';
			$(document).ready(function() {
				$(function() {
					$(".headingTyped").typed({
						strings: ['Web Developer.', 'Blogger.', 'Digital Design.'],
						typeSpeed: 1,
						backDelay: 2000,
						loop: true
					});
				});
			})
		}(jQuery))
	</script>
	<!-------/body-------->
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"74f1ed762d28a02f","version":"2022.8.1","r":1,"token":"af76a0f2ef2c4842bd3334f3c2936a9f","si":100}' crossorigin="anonymous"></script>
</body>

</html>